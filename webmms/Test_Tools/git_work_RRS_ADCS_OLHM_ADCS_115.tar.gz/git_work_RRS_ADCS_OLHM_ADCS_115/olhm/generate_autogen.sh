#!/bin/bash

cp sicd/* autogen/sicd
cd autogen/Codegen/Python/
rm -f Output/Python/*
./validate_data_model_and_do_autogen.py autogen_configuration.xml
cp Output/Python/* ../../../OLHM/Source/Autogen
cp Output/Python/* ../../../OLHM_Test_Tool/Source/Autogen