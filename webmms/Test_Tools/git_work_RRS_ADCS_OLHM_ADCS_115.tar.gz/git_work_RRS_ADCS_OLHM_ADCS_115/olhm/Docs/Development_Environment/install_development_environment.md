
# How to install OLHM development environment

## Prepare 18.04.1 USB stick

* Obtain a USB stick of at least 8GB size. **Warning!!! All data will be lost.**
* Get the Ubuntu 18.04.1 ISO file. It's called ubuntu-18.04.1-desktop-amd64.iso
* On a Linux machine prepare the USB stick by typing -> ```sudo dd bs=4M if=ubuntu-18.04.1-desktop-amd64.iso of=/dev/sdX conv=fdatasync  status=progress``` **Warning!!! make sure to use the correct /dev/sdX**

## Install Ubuntu on processing platform

* Install Ubuntu with normal settings.
* When asked for the user name make it **adcs**. The rest of the guide assumes that was the name that was chosen.

## Commands to do after Ubuntu starts up the first time 

### Firewall

* ```sudo apt-get update```
* ```sudo apt install ufw```
* ```sudo apt install gufw```
* ```sudo ufw allow ssh```
* ```sudo ufw allow samba```

### Install some Python3.6 extra libs

* ```sudo apt install python3-pip```


### Install Mosquito MQTT broker

* ```sudo apt install mosquitto```
* ```sudo systemctl enable mosquitto```
* ```sudo systemctl start mosquitto```

### Google chrome 

* ```wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb```
* ```sudo dpkg -i google-chrome-stable_current_amd64.deb```

### Install VSCode

* Get the lastest VSCode deb file from ```https://code.visualstudio.com/```
* ```sudo dpkg -i code_1.39.2-1571154070_amd64.deb```

### Install Krusader

* ```sudo apt install kdiff3```
* ```sudo apt install kompare```
* ```sudo apt install xxdiff```
* ```sudo apt install krename```
* ```sudo apt install krusader```
* ```sudo apt install rar```
* ```sudo apt install unrar```


### Install Samba

* ```sudo apt-get install samba```
* ```sudo smbpasswd -a adcs```
* Modify the file ```/etc/samba/smb.conf``` to be appropiate

### Install Git

* ```sudo apt install git```

### Install Oracle Java 8 JDK (the one with JavaFX) + MQTT-Spy

**Warning: mqtt-spy will only work with Oracle (not Open) Java JDK 8. It simply will not work with anything else. Do not even try to make it work on OpenJava8/11 + openjfx.**

* Remove all existing versions of Java. Afterwards the ```java``` command should do nothing.
* Download the ```jdk-8u231-linux-x64.tar.gz``` file from **https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html**. **One must register a free account and then download the file that way**
* Copy ```jdk-8u231-linux-x64.tar.gz``` to ```/home/adcs/Apps/Java```.
* ```tar -zxvf jdk-8u231-linux-x64.tar.gz```
* ```cd /usr/bin/```
* ```sudo ln -s /home/adcs/Apps/Java/jdk1.8.0_231/bin/java java```




### Misc

* ```sudo apt install net-tools```
* ```sudo apt install socat```