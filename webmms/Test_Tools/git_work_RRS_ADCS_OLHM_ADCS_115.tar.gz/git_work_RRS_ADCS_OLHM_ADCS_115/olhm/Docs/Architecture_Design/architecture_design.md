# OLHM Architecture Design

## Table of contents

1. Functional Block diagram
2. Inter process communication definition and autogen requirements
3. Engineering data definition (published on ZeroMQ) 
4. Test philosophy, list of planned unit tests and DO-178 requirements
5. Development environment (programming language and development tools)
6. Version control philosophy
7. Draft dev schedule taking 50% functionality milestone into account

## 1. Functional block diagram

The diagram below shows the OLHM as part of a functional block diagram:
![Functional Block Diagram](Functional_Block_Diagram.png "Functional Block Diagram")

The high level functions of the OLHM can be seen in block diagram below:

![Block Diagram](ADCS_OLHM_module.png "Block Diagram")

Going from left to right on the diagram above, the On-Line Health Monitor (OLHM) receives MQTT messages from the Middleware (MW) and places them into a message buffer. It should be noted that the OLHM does not subscribe to any ZeroMQ messages and therefore does not process them. Messages in the buffer are then serviced and depending if they are related to status or control responses are sent to the parts of the OLHM which manage status and state respectively. Examples of typical control messages are the end-of-setup, end-of-ready, shutdown and PDBP control response messages.

The group status management portion of the OLHM consumes the group status messages. They are  collated into the combined group status. The group status will in turn be published for the consumption by other selected modules in the ADCS. The status management portion of the OLHM also needs the OLHM state as it forms part of the group’s status.

The state of each module in the group is monitored by consuming the control response messages and the module status messages. Each module in the group is driven by a state machine assigned to it. The OLHM state is also taken into when the overall group state is driven by the OLHM.

Messages designated for publishing are sent to MQTT client portion of the OLHM which then sends them out on the MW for other modules to consume.

## 2. Inter process communication definition and autogen requirements

### OLHM thread composition

The OLHM is only one process so there is no Inter Process Communication (IPC) definition.

In the OLHM process only two threads are utilised: The main OLHM thread and another used by the mqtt client. The diagram below shows the threads as they form part of OLHM process:<br>
![Process Threads Diagram](Process_Threads_Diagram.png "Process Threads Diagram")


### OLHM main thread state machine

The main OLHM thread functions according to the state machine shown below:

![OLHM Main Thread Machine](OLHM_Main_Thread_State_Machine.png "OLHM Main Thread Machine")


### Level of autogen

The autogen will provide the following required functionality for the OLHM:

* A class used by the Paho MQTT client to implement the **on_connect** functionality. In the autogen the **on_connect** method, messages will be subscribed to and callbacks registered. A received message will, provided it passed validation, be placed in the queue for processing by the main thread. The name of the class will be **clsPahoMqttClientOnConnectAutogen**. Inheritance can be used to extended the functionality of this class as needed.
* A class used by the OLHM main thread to process messages once received from the queue. This class, called **clsAsyncMessageProcessingAutogen**, will serve as a base class for other classes to inherit. Inheritance will be used here make code more modular and readable.

Shown below are the two classes in a class relationship diagram.

![OLHM Class Inheritance](OLHM_Class_Inheritance.png "OLHM Class Inheritance")

## 3. Engineering data definition (published on ZeroMQ) 

The OLHM does not publish any engineering data on the ZeroMQ segment of the MW.

## 4. Test philosophy, list of planned unit tests and DO-178 requirements

### Test philosophy

The OLHM source will be tested using a combination of unit tests and tests described in the OLHM STD document (**5850-BS-5000V01.00 TZ ADCS On-Line Health Monitor Software Test Description**).

### List of planned unit tests

The following unit tests are planned for the OLHM:
* BIT processing class for TEWA
* BIT processing class for TM
* BIT processing class for PDBP
* BIT processing class for DR
* BIT processing class for EIU
* BIT processing class for HMI-APM
* BIT processing class for HMI-FC
* BIT processing class for HMI-Oversight
* ADCS start-up transition rules
* Message autogen serialising
* Message autogen de-serialising
* Message autogen validation

### DO-178B level D requirements

The DO-178B level D software verification requirements applicable to the OLHM are shown below. For a full and more detailed list of requirements see document **5850-BS-0000V01.00 PT Plan For Software Aspects Of Certification For the ADCS**. The summary below lists the RTCA DO-178B requirement numbers and the associated verification method for each requirement.

**Req. number**: 4.1a; 4.3<br>
**Verification method**: 
* Review and approve the ADCS SDP
___

**Req. number**: 4.1d<br>
**Verification method**: 
* Review and approve the ADCS PSAC

___

**Req. number**: 5.1.1.a<br>
**Verification method**: 
* Review the OICD and SRS documents internally. 
* Review the OICD and SRS documents externally. 
* These review activities comprise the Software Specification Review (SSR).

___

**Req. number**: 5.1.1.b<br>
**Verification method**: 
* Review the SRS documents internally and verify that derived requirements are identified in the reverse traceability matrix. The reverse traceability matrix is included in the CSCI SRS documents.
* Review derived requirements (OICD and SRS documents) externally.

___

**Req. number**: 5.2.1.a<br>
**Verification method**:
* Review the ADCS SAD internally and externally.
* Review the interface definition design description document internally and externally.
* Review the software architecture design during the internal CSCI design reviews.

___

**Req. number**: 5.2.1.a<br>
**Verification method**:
* Review the OICD and SRS documents internally.
* Review the OICD and SRS documents externally.
* These review activities comprise the Software Specification Review (SSR).
* Review the low-level design (in SDF) during the internal CSCI design review.
___


**Req. number**: 5.2.1.b<br>
**Verification method**:
* Review the SRS documents internally and verify that derived requirements are identified in the reverse traceability matrix. The reverse traceability matrix is included in the CSCI SRS documents.
* Review derived requirements (OICD and SRS documents) externally.
* Review the low-level design during the internal CSCI design review.

___


**Req. number**: 5.3.1.a<br>
**Verification method**:
* Source Code under Configuration Control and uniquely identified by means of a CM number.
___

**Req. number**: 5.4.1.a<br>
**Verification method**:
* Executable Code under Configuration Control and uniquely identified by means of a CM number.
* Development and integration tests documented in the CSCI SDF (Software Design File).
___

**Req. number**: 6.3.1.a<br>
**Verification method**:
* During the internal review of the SRS documents, verify in the ACRM that each system requirement that has to be performed in software has been addressed by one or more related software requirements.
* If interface requirements are captured in the SRS (i.e. no IRS), ensure that the CSCI ICD covers the interface-related requirements.
* Verify that action items in the COARs for the SRS documents are implemented in the updated SRS documents.
___

**Req. number**: 6.3.1.b<br>
**Verification method**:
* During the internal review of the SRS documents, verify that high-level requirements are unambiguous and do not conflict with each other or with the system requirements. 
* Verify that high- level requirements are sufficiently detailed.
* Verify that the interface-related requirements are accurate and consistent.
* Verify that action items in the COARs for the SRS documents are implemented in the updated SRS documents.
___

**Req. number**: 6.3.1.f<br>
**Verification method**:
* During the internal review of the SRS documents, verify that there is a cross-reference matrix in the SRS that references all the software requirements and that each software requirement is traced to the applicable system requirement. 
* Verify that requirements that cannot be traced to system requirements are denoted as derived requirements and that the reasons for their existence are correctly defined.
* Verify that action items in the COARs for the SRS documents are implemented in the updated SRS documents.
___

**Req. number**: 6.3.3.f<br>
**Verification method**:
* During the internal review of the software architectures captured in the SDD documents, verify that partitioning breaches are prevented or isolated.
___

**Req. number**: 6.4.2.1; 6.4.3<br>
**Verification method**:
* During the internal review of the STD, verify that a test case exists in the STD for each requirement in the SRS for each CSCI.
* When testing code against the STD, verify that the executable software performs correctly for each test case.
___

**Req. number**: 6.4.2.2; 6.4.3<br>
**Verification method**:
* During the review of the robustness test cases, analyse the requirements in each SRS and verify that the robustness test cases address a comprehensive set of abnormal input conditions for the high-level requirements. 
* The review of the robustness test cases to be captured in the module design file.
* Verify that all robustness failures have been corrected.
___

**Req. number**: 6.4.3.a<br>
**Verification method**:
* During the internal TRR, verify that there are no software failures that can be attributed to incompatibility with the target computer.
* Present minutes of the internal TRR to the external TRR and verify that all action items have been addressed.
___

**Req. number**: 6.4.4.1<br>
**Verification method**:
* During the internal TRR, verify that each STD provides a traceability matrix to its corresponding SRS and that the traceability is complete.
* Present minutes of the internal TRR to the external TRR.
___

**Req. number**: 7.2.1<br>
**Verification method**:
* Verify the configuration items as part of the SDP or SCMP reviews.
* Verify that all configuration items are registered as part of a CM Audit.
___

**Req. number**: 7.2.2<br>
**Verification method**:
* Verify that the approach for establishing baselines and traceability is captured as part of the SDP or SCMP reviews.
* Review SCI documents internally.
* Verify SCM records as part of a CM Audit.
___

**Req. number**: 7.2.3; 7.2.4; 7.2.5; 7.2.6<br>
**Verification method**:
* Verify that the approach for problem reporting, change control, change review and configuration status accounting is captured as part of the SDP or SCMP reviews.
* Verify that problem reporting, change control, change review and configuration status accounting are established according to plans as part of a CM audit.
___

**Req. number**: 7.2.7<br>
**Verification method**:
* Verify that documents and source code are archived, documents and source code can be retrieved and documents are released as required.
* Verify that source code can be rebuilt to yield correct executable object files as part of the CM audit.
___

**Req. number**: 7.2.8<br>
**Verification method**:
* Perform a software load cycle as part of a CM audit and verify that load control safeguards are in place. 
___

**Req. number**: 7.2.9<br>
**Verification method**:
* As part of a CM audit, verify that CC1 and CC2 controls are in place.
* Verify that software development environment and libraries are under control.
___

**Req. number**: 8.1.a<br>
**Verification method**:
* Perform QA functions and audits in accordance with SQA plan.
___



## 5. Development environment (programming language and development tools)

### Operating System

* Linux Ubuntu 5.0.0-25-generic #26~18.04.1-Ubuntu SMP Thu Aug 1 13:51:02 UTC 2019 x86_64 x86_64 x86_64 GNU/Linux
* VMware virtual machine for development will be available on the RRS VM share, under "ADCS Development"

### Development Environment

* Python: Python 3.6.8 (default, Jan 14 2019, 11:02:34)
* IDE: Developer Choice (Visual Code, text editor)


### Python libraries

The following Python libraries will be used in the OLHM module:

| Name                            | Source                           | Intended use                  |
| ------------------------------- | -------------------------------- | ----------------------------- |
| argeparse                       | Native to Python                 | Command line argument parsing |
| asyncio                         | Native to Python                 | Concurrent processing         |
| ElementTree                     | Native to Python                 | XML parser                    |
| logging                         | Native to Python                 | Exception logging             |
| os                              | Native to Python                 | File I/O                      |
| sys                             | Native to Python                 | Manipulate the path           |
| signal                          | Native to Python                 | Signal handling               |
| time                            | Native to Python                 | Time related functions        |
| configparser                    | Python Package Index             | Config file parser            |
| flake8                          | Python Package Index             | Python linter                 |
| Jinja2                          | Python Package Index             | Template to code generator    |
| lxml                            | Python Package Index             | XML parser                    |
| paho-mqtt                       | Python Package Index             | MQTT client                   |
| pep8                            | Python Package Index             | Python linter                 |
| psutil                          | Python Package Index             | Process management            |
| pylint                          | Python Package Index             | Python linter                 |
| transitions                     | Python Package Index             | State machine handler         |


### Coding Standard/Style

* Existing RRS Python standard
* Unix line endings
* NO TABS (4 space characters for indentation)

### Deployment

* Releases to be packaged in Docker containers where applicable


### Repository: **BitBucket (GIT)**

The following philosophy will be followed with regards to GIT code repositories:
* There will be a high level ADCS repository.
* Each ADCS module will be a sub-module in the ADCS high level repository.
* Sub-module will be created for all shared or common code.
* The SICD repository will also be sub-module of the ADCS high level repository.

### Change Management

The following philosophy will be followed with regards to change management:
* A feature branch workflow will be used after first code baseline was committed to the master.
* All milestones (internal and official releases) will be linked to a Jira issue (and vice versa).
* All milestones will be subject to a pull request, allowing for code review and change management (Please see below for pull request workflow and output).
* All milestones will be tagged (the tag will reflect on the Jira issue when completed).
* Official release milestones will be subject to version control (in addition to the above).
* Official release milestones will be subject to ATP (in addition to the above).
* Official release milestones will be packaged (possibly docker containers).

### Pull request workflow

The following philosophy will be followed in regard to the workflow of a pull request:
* The source code must compile before a pull request is to be created.
* All unit tests should be run and pass before a pull request is to be created.
* Results of the unit tests should be included in the description of the pull request.


### Pull request output

The following philosophy will be followed in regard to the output of a pull request:
* A successfully accepted pull request must be noted as part of the Jira workflow. 
* The names of the individuals who approved the pull request must also be noted.

### Development Tool: **JIRA**

The JIRA development tool will be used provide the following functionality:

* To manage workflow and record progress.
* Describe all milestones (internal and official releases) as Jira issues linked to feature branches (and vice versa), which in turn is linked to an epic and assigned to the responsible resource.
* Enable labels to be added to issues which makes filtering possible.
* Allow for artifacts and records to be attached or linked to issues such as:
  * Applicable Documentation;
  * Design notes and decisions;
  * Informal meeting notes;
  * Informal records or artifacts;
  * Compliance records or artifacts (DO-178);
  * Bugs and issues.


## 6. Draft dev schedule taking 50% functionality milestone into account

| Description                                                                              | Estimation [hr] | Accumulated Total [hr] |
| ---------------------------------------------------------------------------------------- | --------------- |----------------------- | 
| Make ADCS Python toolbox repo to use as a submodule (use BR12)                           | 2               |2                       |
| Create OLHM skeleton (based on BR12: Python3\.6 + asyncio + transitions)                 | 16              |18                      |
| Create OLHM Test Tool (Simulate TEWA, TM, PDBP, DR, EIU, HMI x 3, Support Functions x 3) | 60              |78                      |
| State machine for OLHM                                                                   | 16              |94                      |
| State machine for PDBP                                                                   | 4               |98                      |
| State machine for DR                                                                     | 4               |102                     |
| State machine for TM                                                                     | 4               |106                     |
| Create message handler for OLHM                                                          | 24              |130                     |
| Create message handler for PDBP                                                          | 2               |132                     |
| Create message handler for DR                                                            | 2               |134                     |
| Create message handler for TM                                                            | 2               |136                     |