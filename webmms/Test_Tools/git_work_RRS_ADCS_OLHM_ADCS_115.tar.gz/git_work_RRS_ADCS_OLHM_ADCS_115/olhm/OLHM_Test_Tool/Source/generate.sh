#!/bin/bash

rm -rf python_toolbox/
cp -r ../../OLHM/Source/python_toolbox/ .

cp -f SICD/Module_Interface_Config_OTT.xml ../../sicd/
rm -f Autogen/*.py
rm -f Autogen/*.sha1
sed -i 's/IgnoreCheckForMultiplePublishersOfSameTopic="False"/IgnoreCheckForMultiplePublishersOfSameTopic="True"/g' ../../autogen/Codegen/Python/autogen_configuration.xml
cd ../../
./generate_autogen.sh
rm -f autogen/sicd/Module_Interface_Config_OTT.xml
rm -f sicd/Module_Interface_Config_OTT.xml
sed -i 's/IgnoreCheckForMultiplePublishersOfSameTopic="True"/IgnoreCheckForMultiplePublishersOfSameTopic="False"/g' autogen/Codegen/Python/autogen_configuration.xml