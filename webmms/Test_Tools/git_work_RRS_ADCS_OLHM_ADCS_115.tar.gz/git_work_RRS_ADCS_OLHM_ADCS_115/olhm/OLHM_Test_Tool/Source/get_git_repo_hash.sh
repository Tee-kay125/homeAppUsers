#!/bin/bash

git rev-parse HEAD > git_repo_hash.txt &