#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which processes HMI_APM messages

Todo:

"""
import sys
import logging


class clsHmiApmProcessMessages:
    """ This is a class which processes HMI_APM messages.

    Args:
        dctGlobalInterfaceDictionaryPar (object): The first parameter. The global interface dictionary.
    """
    def __init__(self, dctGlobalInterfaceDictionaryPar: dict):
        super().__init__()
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar

        return
