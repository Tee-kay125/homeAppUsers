#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which processes messages for the OLHM. 

Todo:

"""


import logging
import asyncio
from inspect import currentframe, getframeinfo  # We need this to get the current filename and lineno
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
from Autogen.asyncio_message_processing_ott import clsPythonAsyncioMessageProcessing
from python_toolbox.Process_Monitoring_And_Management.process_monitoring_and_management import clsProcessMonitoringAndManagement
from python_toolbox.Datetime_Utilities.datetime_utilities import clsDatetimeUtilities

# OLHM_Msg.xml 0x0002
from Autogen.olhm_msg import sOLHM_END_OF_READY_CMD
# OLHM_Msg.xml 0x0002
from Autogen.olhm_msg import sOLHM_END_OF_READY_CMD_RSP
# OLHM_Msg.xml 0x0010
from Autogen.olhm_msg import sOLHM_ADCS_SHUTDOWN_CMD
# OLHM_Msg.xml 0x0010
from Autogen.olhm_msg import sOLHM_ADCS_SHUTDOWN_CMD_RSP

class clsAsyncioMsgProcessingClassOtt(clsPythonAsyncioMessageProcessing):
    """This is a class for processing messages for the SCS.

    Args:
        objMqttClientPar (object): The first parameter. The MQTT client.
        dctMessagesPar (dict): The second parameter. The dictionary in which the base class saves the messages and their futures.
        objAsyncioLoopPar (object): The third parameter. The asyncio loop object.
        dctGlobalInterfaceDictionaryPar (dct): The fourth parameter. The global interface dictionary. See ott.py for the layout and breakdown of the keys.
        bLoggingEnabledPar (bool): The fifth parameter. A boolean flag used to indicate if the base class should log or not.

    """

    def __init__(self, objMqttClientPar: mqtt.Client, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar: bool = True):
        # Very important!!! The next constructor to be called will be clsPythonAsyncioMessageProcessing() init(...) - This class was last in the list multiple inheritance and therefore it special
        # The clsPythonAsyncioMessageProcessing() init(...) takes fewer parameters than the constructors which came before
        super().__init__(objMqttClientPar, dctMessagesPar, dctGlobalInterfaceDictionaryPar["dctMqtt"]["lstTasksAllowedForsimultaneousExecution"], objAsyncioLoopPar, bLoggingEnabledPar)
        self._objMqttClient = objMqttClientPar
        self._dctMessages = dctMessagesPar
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar

        return

    '''
    ==============================================================================================================
    Base class methods to override - START
    ==============================================================================================================
    '''

    

    '''
    ==============================================================================================================
    Base class methods to override - END
    ==============================================================================================================
    '''
