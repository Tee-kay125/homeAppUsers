#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which processes messages received from the OLHM.


Todo:

"""
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
from python_toolbox.Datetime_Utilities.datetime_utilities import clsDatetimeUtilities
from Autogen.asyncio_message_processing_ott import clsPythonAsyncioMessageProcessing
from Autogen.olhm_msg import sOLHM_ADCS_SHUTDOWN_CMD

class clsMessageProcessForMqttOlhm(clsPythonAsyncioMessageProcessing):
    """ This is the asyncio message processing class for the messages from the OLHM.

    Args:
        objMqttClientPar (mqtt.Client): The first parameter. The instance of the MQTT client
        dctMessagesPar (dict): The second parameter. A dictionary containing all messages and futures for messages which were automatically processed by the autogen. This must be passed in for the autogen base class.
        objAsyncioLoopPar (object): The third parameter. The asyncio loop passed in so tasks can be created and for other asyncio functionality
        dctGlobalInterfaceDictionaryPar (dict): The fourth parameter. The interface's global dictionary.
        bLoggingEnabledPar (bool): The fifth parameter. A boolean flag indicating if logging should be done or not.
    """

    def __init__(self, objMqttClientPar: mqtt.Client, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar: bool = True):
        # Very important!!! The MRO (method resolution order) will not yet call the autogen base because it isn't last in the list of inheritance - therefore pass more parameter than used for the base class
        super().__init__(objMqttClientPar, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar)
        self._objMqttClient = objMqttClientPar
        self._dctMessages = dctMessagesPar
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar
        self._objClsOlhmProcessMessages = self._dctGloInterDict["dctSubUnits"]["dctDR"]["objClsProcessMessages"]

        return

    '''
    ==============================================================================================================
    Base class methods to override - START
    ==============================================================================================================
    '''

# 0x0000 - OlhmAdcsStatusUnsol
    async def objProcessPayloadOlhmAdcsStatusUnsol(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for OlhmAdcsStatusUnsol

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        objsOLHM_ADCS_STATUS_UNSOL = await super().objProcessPayloadOlhmAdcsStatusUnsol(dctObjectPar)

        # Check that they are the same size
        if (dctObjectPar["MsgObject"].iSizeBytes() == self._dctGloInterDict["dctSubUnits"]["dctOLHM"]["objsOLHM_ADCS_STATUS_UNSOL"].iSizeBytes()):
            self._dctGloInterDict["dctSubUnits"]["dctOLHM"]["objsOLHM_ADCS_STATUS_UNSOL"].vDeserialise(dctObjectPar["MsgObject"].btaSerialise())

        return(None)

    '''
    ==============================================================================================================
    Base class methods to override - END
    ==============================================================================================================
    '''

# 0x0000 vSendOlhmAdcsShutdownCmd
    def vSendOlhmAdcsShutdownCmd(self):
        """ This is a public method which is used to send a sOLHM_ADCS_SHUTDOWN_CMD message

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        objsOLHM_ADCS_SHUTDOWN_CMD = sOLHM_ADCS_SHUTDOWN_CMD()

        self.vIncreaseMessageCounter((type(objsOLHM_ADCS_SHUTDOWN_CMD), ""))
        objsOLHM_ADCS_SHUTDOWN_CMD.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsOLHM_ADCS_SHUTDOWN_CMD), "")]
        objsOLHM_ADCS_SHUTDOWN_CMD.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsOLHM_ADCS_SHUTDOWN_CMD)

        return
