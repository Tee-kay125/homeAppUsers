#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which processes messages for the PDBP.


Todo:

"""
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
from Autogen.asyncio_message_processing_ott import clsPythonAsyncioMessageProcessing

from Autogen.adcs_common_types import E1_ADCS_SYSTEM_STATE
from Autogen.adcs_common_types import E1_ADCS_BOOLEAN
from Autogen.pdbp_msg import E1_PDBP_STATUS
from Autogen.pdbp_msg import sPDBP_STATUS_REPORT_UNSOL
from Autogen.pdbp_msg import sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP
from Autogen.dsf_msg import sADCS_CONSOLIDATED_ADCM_UNSOL


from python_toolbox.Datetime_Utilities.datetime_utilities import clsDatetimeUtilities

class clsMessageProcessForMqttPdbp(clsPythonAsyncioMessageProcessing):
    """ This is the asyncio message processing class for the PDBP.

    Args:
        objMqttClientPar (mqtt.Client): The first parameter. The instance of the MQTT client
        dctMessagesPar (dict): The second parameter. A dictionary containing all messages and futures for messages which were automatically processed by the autogen. This must be passed in for the autogen base class.
        objAsyncioLoopPar (object): The third parameter. The asyncio loop passed in so tasks can be created and for other asyncio functionality
        dctGlobalInterfaceDictionaryPar (dict): The fourth parameter. The interface's global dictionary.
        bLoggingEnabledPar (bool): The fifth parameter. A boolean flag indicating if logging should be done or not.
    """

    def __init__(self, objMqttClientPar: mqtt.Client, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar: bool = True):
        # Very important!!! The MRO (method resolution order) will not yet call the autogen base because it isn't last in the list of inheritance - therefore pass more parameter than used for the base class
        super().__init__(objMqttClientPar, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar)
        self._objMqttClient = objMqttClientPar
        self._dctMessages = dctMessagesPar
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar
        self._objClsPdbpProcessMessages = self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objClsProcessMessages"]

        self._dctStateStringToE1AdcsSystemStateLookup = {}
        self._dctStateStringToE1AdcsSystemStateLookup["OFFLINE"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE
        self._dctStateStringToE1AdcsSystemStateLookup["INITIALISE"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE
        self._dctStateStringToE1AdcsSystemStateLookup["READY"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY
        self._dctStateStringToE1AdcsSystemStateLookup["OPERATIONAL"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL
        self._dctStateStringToE1AdcsSystemStateLookup["SHUTDOWN"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN
        self._dctStateStringToE1AdcsSystemStateLookup["FAILED"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED
        self._dctStateStringToE1AdcsSystemStateLookup["UNKNOWN"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN

        return

    '''
    ==============================================================================================================
    Base class methods to override - START
    ==============================================================================================================
    '''

# 0x0002 - PdbpEndOfReadyCmd
    async def objProcessPayloadPdbpEndOfReadyCmd(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for PdbpEndOfReadyCmd

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        objsPDBP_END_OF_READY_CMD_RSP = await super().objProcessPayloadPdbpEndOfReadyCmd(dctObjectPar)

        self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objClsPdbpTransitionsManager"].trgPdbpEndOfReadyCmd()

        self.vIncreaseMessageCounter((type(objsPDBP_END_OF_READY_CMD_RSP), ""))
        objsPDBP_END_OF_READY_CMD_RSP.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsPDBP_END_OF_READY_CMD_RSP), "")]
        objsPDBP_END_OF_READY_CMD_RSP.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        return(objsPDBP_END_OF_READY_CMD_RSP)

# 0x0003 - PdbpShutdownCmd
    async def objProcessPayloadPdbpShutdownCmd(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for PdbpShutdownCmd

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        objsPDBP_SHUTDOWN_CMD_RSP = await super().objProcessPayloadPdbpShutdownCmd(dctObjectPar)

        self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objClsPdbpTransitionsManager"].trgPdbpShutdownCmd()

        self.vIncreaseMessageCounter((type(objsPDBP_SHUTDOWN_CMD_RSP), ""))
        objsPDBP_SHUTDOWN_CMD_RSP.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsPDBP_SHUTDOWN_CMD_RSP), "")]
        objsPDBP_SHUTDOWN_CMD_RSP.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        return(objsPDBP_SHUTDOWN_CMD_RSP)

# 0x0010 - PdbpSendOutModuleDbMessagesCmd
    async def objProcessPayloadPdbpSendOutModuleDbMessagesCmd(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for PdbpSendOutModuleDbMessagesCmd

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        objsPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP = sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP()

        self.vIncreaseMessageCounter((type(objsPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP), ""))
        objsPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP), "")]
        objsPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()
        objsPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP.sMsgPayload.acModuleName.Value = dctObjectPar["MsgObject"].sMsgPayload.acModuleName.Value
        objsPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP.sMsgPayload.e1CompletedSuccessfully.Value = E1_ADCS_BOOLEAN.ADCS_BOOLEAN_TRUE

        # Create a AdcsConsolidatedAdcmUnsol message
        objsADCS_CONSOLIDATED_ADCM_UNSOL = sADCS_CONSOLIDATED_ADCM_UNSOL()
        self.vIncreaseMessageCounter((type(objsADCS_CONSOLIDATED_ADCM_UNSOL), ""))
        objsADCS_CONSOLIDATED_ADCM_UNSOL.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsADCS_CONSOLIDATED_ADCM_UNSOL), "")]
        objsADCS_CONSOLIDATED_ADCM_UNSOL.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()
        self.bPublishMqttAutogenObject(objsADCS_CONSOLIDATED_ADCM_UNSOL)

        return(objsPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP)

    '''
    ==============================================================================================================
    Base class methods to override - END
    ==============================================================================================================
    '''


# 0x0000 vSendPdbpStatusReportUnsol
    def vSendPdbpStatusReportUnsol(self):
        """ This is a public method which is used to send a sPDBP_STATUS_REPORT_UNSOL message

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        objsPDBP_STATUS_REPORT_UNSOL = sPDBP_STATUS_REPORT_UNSOL()
        objsPDBP_STATUS_REPORT_UNSOL.sMsgPayload.sModuleState.e1SystemState.Value = self._dctStateStringToE1AdcsSystemStateLookup[self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objClsPdbpTransitionsManager"].state]
        objsPDBP_STATUS_REPORT_UNSOL.sMsgPayload.e1OverallStatus.Value = E1_PDBP_STATUS.PDBP_STATUS_PASSED

        self.vIncreaseMessageCounter((type(objsPDBP_STATUS_REPORT_UNSOL), ""))
        objsPDBP_STATUS_REPORT_UNSOL.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsPDBP_STATUS_REPORT_UNSOL), "")]
        objsPDBP_STATUS_REPORT_UNSOL.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsPDBP_STATUS_REPORT_UNSOL)

        self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objsSTATUSREPORTUNSOL"] = objsPDBP_STATUS_REPORT_UNSOL

        return
