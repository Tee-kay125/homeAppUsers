#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which processes messages received from the HMI_Maintainer.


Todo:

"""

import logging
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
from python_toolbox.Datetime_Utilities.datetime_utilities import clsDatetimeUtilities
from Autogen.asyncio_message_processing_ott import clsPythonAsyncioMessageProcessing
from Autogen.adcs_common_types import E1_ADCS_SYSTEM_STATE
from Autogen.hmi_msg import E1_HMI_ROLES
from Autogen.hmi_msg import sHMI_STATUS_REPORT_UNSOL
from Autogen.hmi_msg import sHMI_SHUTDOWN_UNSOL
from Autogen.hmi_msg import sHMI_ADCS_SHUTDOWN_CMD


class clsMessageProcessForMqttHmiMaintainer(clsPythonAsyncioMessageProcessing):
    """ This is the asyncio message processing class for the messages from the HMI_Maintainer.

    Args:
        objMqttClientPar (mqtt.Client): The first parameter. The instance of the MQTT client
        dctMessagesPar (dict): The second parameter. A dictionary containing all messages and futures for messages which were automatically processed by the autogen. This must be passed in for the autogen base class.
        objAsyncioLoopPar (object): The third parameter. The asyncio loop passed in so tasks can be created and for other asyncio functionality
        dctGlobalInterfaceDictionaryPar (dict): The fourth parameter. The interface's global dictionary.
        bLoggingEnabledPar (bool): The fifth parameter. A boolean flag indicating if logging should be done or not.
    """

    def __init__(self, objMqttClientPar: mqtt.Client, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar: bool = True):
        # Very important!!! The MRO (method resolution order) will not yet call the autogen base because it isn't last in the list of inheritance - therefore pass more parameter than used for the base class
        super().__init__(objMqttClientPar, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar)
        self._objMqttClient = objMqttClientPar
        self._dctMessages = dctMessagesPar
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar
        self._objClsHmiMaintainerProcessMessages = self._dctGloInterDict["dctSubUnits"]["dctHMIMaintainer"]["objClsProcessMessages"]

        self._dctStateStringToE1AdcsSystemStateLookup = {}
        self._dctStateStringToE1AdcsSystemStateLookup["OFFLINE"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE
        self._dctStateStringToE1AdcsSystemStateLookup["INITIALISE"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE
        self._dctStateStringToE1AdcsSystemStateLookup["READY"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY
        self._dctStateStringToE1AdcsSystemStateLookup["OPERATIONAL"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL
        self._dctStateStringToE1AdcsSystemStateLookup["SHUTDOWN"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN
        self._dctStateStringToE1AdcsSystemStateLookup["FAILED"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED
        self._dctStateStringToE1AdcsSystemStateLookup["UNKNOWN"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN

        return

    '''
    ==============================================================================================================
    Base class methods to override - START
    ==============================================================================================================
    '''

# 0x0001 - HmiEndOfSetupCmd
    async def objProcessPayloadHmiEndOfSetupCmdMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for HmiEndOfSetupCmd

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        objsHMI_END_OF_SETUP_CMD_RSP = await super().objProcessPayloadHmiEndOfSetupCmdMaintainer(dctObjectPar)

        self._dctGloInterDict["dctSubUnits"]["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"].trgHmiMaintainerEndOfSetupCmd()

        self.vIncreaseMessageCounter((type(objsHMI_END_OF_SETUP_CMD_RSP), "Maintainer"))
        objsHMI_END_OF_SETUP_CMD_RSP.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsHMI_END_OF_SETUP_CMD_RSP), "Maintainer")]
        objsHMI_END_OF_SETUP_CMD_RSP.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        return(objsHMI_END_OF_SETUP_CMD_RSP)

# 0x0002 - HmiEndOfReadyCmd
    async def objProcessPayloadHmiEndOfReadyCmdMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for HmiEndOfReadyCmd

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        objsHMI_END_OF_READY_CMD_RSP = await super().objProcessPayloadHmiEndOfReadyCmdMaintainer(dctObjectPar)

        self._dctGloInterDict["dctSubUnits"]["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"].trgHmiMaintainerEndOfReadyCmd()

        self.vIncreaseMessageCounter((type(objsHMI_END_OF_READY_CMD_RSP), "Maintainer"))
        objsHMI_END_OF_READY_CMD_RSP.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsHMI_END_OF_READY_CMD_RSP), "Maintainer")]
        objsHMI_END_OF_READY_CMD_RSP.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        return(objsHMI_END_OF_READY_CMD_RSP)

# 0x0003 - HmiShutdownCmd
    async def objProcessPayloadHmiShutdownCmdMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for HmiShutdownCmd

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        objsHMI_SHUTDOWN_CMD_RSP = await super().objProcessPayloadHmiShutdownCmdMaintainer(dctObjectPar)

        self._dctGloInterDict["dctSubUnits"]["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"].trgHmiMaintainerShutdownCmd()

        self.vIncreaseMessageCounter((type(objsHMI_SHUTDOWN_CMD_RSP), "Maintainer"))
        objsHMI_SHUTDOWN_CMD_RSP.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsHMI_SHUTDOWN_CMD_RSP), "Maintainer")]
        objsHMI_SHUTDOWN_CMD_RSP.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        return(objsHMI_SHUTDOWN_CMD_RSP)

    '''
    ==============================================================================================================
    Base class methods to override - END
    ==============================================================================================================
    '''


# 0x0000 vSendHmiStatusReportUnsolMaintainer
    def vSendHmiStatusReportUnsolMaintainer(self):
        """ This is a public method which is used to send a sHMI_STATUS_REPORT_UNSOL message

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        objsHMI_STATUS_REPORT_UNSOL = sHMI_STATUS_REPORT_UNSOL()
        objsHMI_STATUS_REPORT_UNSOL.sMsgPayload.sModuleState.e1SystemState.Value = self._dctStateStringToE1AdcsSystemStateLookup[self._dctGloInterDict["dctSubUnits"]["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"].state]
        objsHMI_STATUS_REPORT_UNSOL.sMsgPayload.e1Role.Value = E1_HMI_ROLES.MAINTAINER

        self.vIncreaseMessageCounter((type(objsHMI_STATUS_REPORT_UNSOL), "Maintainer"))
        objsHMI_STATUS_REPORT_UNSOL.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsHMI_STATUS_REPORT_UNSOL), "Maintainer")]
        objsHMI_STATUS_REPORT_UNSOL.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsHMI_STATUS_REPORT_UNSOL, "Maintainer")

        self._dctGloInterDict["dctSubUnits"]["dctHMIMaintainer"]["objsSTATUSREPORTUNSOL"] = objsHMI_STATUS_REPORT_UNSOL

        return

# 0x0004 vSendHmiShutdownUnsolMaintainer
    def vSendHmiShutdownUnsolMaintainer(self):
        """ This is a public method which is used to send a sHMI_SHUTDOWN_UNSOL message

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        objsHMI_SHUTDOWN_UNSOL = sHMI_SHUTDOWN_UNSOL()

        self.vIncreaseMessageCounter((type(objsHMI_SHUTDOWN_UNSOL), "Maintainer"))
        objsHMI_SHUTDOWN_UNSOL.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsHMI_SHUTDOWN_UNSOL), "Maintainer")]
        objsHMI_SHUTDOWN_UNSOL.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsHMI_SHUTDOWN_UNSOL, "Maintainer")

        return

# 0x0006 vSendHmiAdcsShutdownCmdMaintainer
    def vSendHmiAdcsShutdownCmdMaintainer(self):
        """ This is a public method which is used to send a sHMI_ADCS_SHUTDOWN_CMD message

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        objsHMI_ADCS_SHUTDOWN_CMD = sHMI_ADCS_SHUTDOWN_CMD()

        self.vIncreaseMessageCounter((type(objsHMI_ADCS_SHUTDOWN_CMD), "Maintainer"))
        objsHMI_ADCS_SHUTDOWN_CMD.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsHMI_ADCS_SHUTDOWN_CMD), "Maintainer")]
        objsHMI_ADCS_SHUTDOWN_CMD.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsHMI_ADCS_SHUTDOWN_CMD, "Maintainer")

        return
