#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which manages a transitions (PyPi library) state machine.

Todo:

"""
import logging
from transitions import Machine
from python_toolbox.Datetime_Utilities.datetime_utilities import clsDatetimeUtilities
from python_toolbox.State_Machine_Utilities.state_machine_utilities import clsStateMachineUtilities


class clsTmTransitionsManager:
    """ This is the periodic monitor manager.

    Args:
        dctGlobalInterfaceDictionaryPar (object): The first parameter. The global interface dictionary.
        acInitialStatePar (str): The second parameter. The initial state
    """
    def __init__(self, dctGlobalInterfaceDictionaryPar: object, acInitialStatePar: str = "OFFLINE"):
        super().__init__()
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar

        # These are the python loggger levels
        # Level	Numeric value
        # CRITICAL  50
        # ERROR     40
        # WARNING   30       Transitions uses WARNING level to report when state changes cannot be made - too verbose
        # INFO      20       Transitions uses INFO level to report entries and exits - too verbose
        # DEBUG     10
        # NOTSET    0
        #
        # The transitions library use the logger to display information. Increase the log level to make it less verbose
        logging.getLogger('transitions').setLevel(logging.ERROR)

        self._lstStates = []
        self._lstStates += [{"name": "OFFLINE", "on_enter": self._vOnEnter_OFFLINE}]
        self._lstStates += [{"name": "INITIALISE", "on_enter": self._vOnEnter_INITIALISE}]
        self._lstStates += [{"name": "READY", "on_enter": self._vOnEnter_READY}]
        self._lstStates += [{"name": "OPERATIONAL", "on_enter": self._vOnEnter_OPERATIONAL}]
        self._lstStates += [{"name": "FAILED", "on_enter": self._vOnEnter_FAILED}]
        self._lstStates += [{"name": "SHUTDOWN", "on_enter": self._vOnEnter_SHUTDOWN}]

        # guards are registered using the 'conditions' key
        # You can attach callbacks to transitions as well as states. Every transition has 'before' and 'after' attributes that contain a list of methods to call before and after the transition executes:
        # When a transition is called the guard is called first, then the before and then the after.
        # The before is before the transition
        # The after is after the transition
        self._lstTransitions = []
        self._lstTransitions += [{'trigger': "trgInitialise", 'source': ["OFFLINE"], 'dest': "INITIALISE"}]
        self._lstTransitions += [{'trigger': "trgTmEndOfSetupCmd", 'source': ["INITIALISE"], 'dest': "READY"}]
        self._lstTransitions += [{'trigger': "trgTmEndOfReadyCmd", 'source': ["READY"], 'dest': "OPERATIONAL"}]
        self._lstTransitions += [{'trigger': "trgTmFailure", 'source': ["INITIALISE"], 'dest': "FAILED"}]
        self._lstTransitions += [{'trigger': "trgTmShutdownCmd", 'source': ["FAILED", "OPERATIONAL"], 'dest': "SHUTDOWN"}]

        # Initialize the state machine
        self.objTransitionsMachine = Machine(model=self, states=self._lstStates, transitions=self._lstTransitions, initial=acInitialStatePar, ignore_invalid_triggers=True)

        self._acStateCurrent = acInitialStatePar
        self._acStatePrev = acInitialStatePar
        self._acUnit = "TM"

        self._objDatetimeMonRawLastEndOfSetupSent = clsDatetimeUtilities.objGetMonotonicRawCurrentDatetime()

        self._objDatetimeMonRawLastTmStatusUnsolSent = clsDatetimeUtilities.objGetMonotonicRawCurrentDatetime()

        return

    def acPrevState(self):
        """ This is a public method getter which gets the previous state.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        return(self._acStatePrev)

    def _vCapturePreviousState(self):
        """ This is a private method which stores the previous state.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        self._acStatePrev = self._acStateCurrent
        self._acStateCurrent = self.state
        clsStateMachineUtilities.vLogTransitionsStateChange(self._acStatePrev, self._acStateCurrent, "TM", acAdditionalMessagePar="", bLogOnlyOnChangePar=False)

        return

    def _vOnEnter_OFFLINE(self):
        """ This is a private method which is called when the OFFLINE state is entered.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        clsStateMachineUtilities.vLogTransitionsStateCurrent(self.state, self._acUnit)
        self._vCapturePreviousState()

        return

    def _vOnEnter_INITIALISE(self):
        """ This is a private method which is called when the INITIALISE state is entered.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        clsStateMachineUtilities.vLogTransitionsStateCurrent(self.state, self._acUnit)
        self._vCapturePreviousState()

        return

    def _vOnEnter_READY(self):
        """ This is a private method which is called when the READY state is entered.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        clsStateMachineUtilities.vLogTransitionsStateCurrent(self.state, self._acUnit)
        self._vCapturePreviousState()
        return

    def _vOnEnter_OPERATIONAL(self):
        """ This is a private method which is called when the OPERATIONAL state is entered.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        clsStateMachineUtilities.vLogTransitionsStateCurrent(self.state, self._acUnit)
        self._vCapturePreviousState()
        return

    def _vOnEnter_SHUTDOWN(self):
        """ This is a private method which is called when the SHUTDOWN state is entered.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        clsStateMachineUtilities.vLogTransitionsStateCurrent(self.state, self._acUnit)
        self._vCapturePreviousState()
        return

    def _vOnEnter_FAILED(self):
        """ This is a private method which is called when the FAILED state is entered.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        clsStateMachineUtilities.vLogTransitionsStateCurrent(self.state, self._acUnit)
        self._vCapturePreviousState()
        return

    def vProcessState(self, objDateTimeCurrent=None):
        """ This is a public method which monitors and drives the state of the TM

        Args:
            objDateTimeCurrent (datetime): The first parameter. The current datetime.

        Returns:

        Raises:
            Raises no exception.
        """

        if (self._acUnit in self._dctGloInterDict["dctOTT"]["lstModulesToExclude"]):
            return(None)

        if (self.state == "OFFLINE"):
            self.trgInitialise()

        if (self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"] is None):
            logging.error("objClsMessageProcessForMqtt cannot be None")
            return

        if (clsDatetimeUtilities.bCurrentMonotonicRawTimeExceedsDateTimePlusMSecThreshold(self._objDatetimeMonRawLastTmStatusUnsolSent, 1000) is True):
            self._objDatetimeMonRawLastTmStatusUnsolSent = clsDatetimeUtilities.objGetMonotonicRawCurrentDatetime()
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendTmStatusReportUnsol()

        return

    def _vUpdateBitTreeForOffline(self):
        """ This is a private method which sets the TM section of the BIT to UNKNOWN when the TM is OFFLINE

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        return
