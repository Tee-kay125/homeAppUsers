#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which processes SF3 messages

Todo:

"""
import sys
import logging


class clsSf3ProcessMessages:
    """ This is a class which processes SF3 messages.

    Args:
        dctGlobalInterfaceDictionaryPar (object): The first parameter. The global interface dictionary.
    """
    def __init__(self, dctGlobalInterfaceDictionaryPar: dict):
        super().__init__()
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar

        return
