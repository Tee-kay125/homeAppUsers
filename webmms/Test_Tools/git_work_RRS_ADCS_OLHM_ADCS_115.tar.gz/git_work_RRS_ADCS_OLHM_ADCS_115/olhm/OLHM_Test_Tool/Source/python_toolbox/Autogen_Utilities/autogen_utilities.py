#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module contains a class with static methods which are utilities for the autogen objects.


Todo:

"""

import sys
import zlib
import logging
sys.path.append("../Autogen")
from typing import List, Dict, Tuple
import CCS_Types
from CCS_Types import CCS_Base
from CCS_Types import CCS_Enum
from CCS_Types import CCS_EnumArray
from CCS_Types import CCS_Struct
from CCS_Types import CCS_StructArray


class clsAutogenUtilities():

    @staticmethod
    def vFromAutogenObjGenerateLinearFootprint(objAutogenObject: object, lstFootprint: List, iLevel: int = 0, acHashPar: str = ""):
        """ This is a public method which generates a linear footprint from an autogen object. This method uses recursion!

        A footprint is a string made out of the [NAME][TYPE][LEVEL]

        Args:
            objAutogenObject (obj): The first parameter. An autogen object.
            lstFootprint (list): The second parameter. The list starts empty and will be filled in with dictionary {"acFootprint":_, "MsgObject":_, "iLevel":_ }
            iLevel (int): The third parameter. This is for the recursion to know which level it is on.
            acHashPar (str): The fourth parameter. This is the parent's hash. It will used to calculate the hash for it's children.

        Returns:

        Raises:
            Raises no exceptions
        """

        acFootprint = ""
        bIsArrayValue = bool(False)  # CCS_StructArray and CCS_EnumArray are array type objects. Everything else uses attributes instead of a Value which is a list (array)
        acHash = ""  # This will store the hash of the footprint 

        # If the current level object is a CCS_Base or a CCS_Enum then the recursion stops
        if ((isinstance(objAutogenObject, CCS_Base) is True) or (isinstance(objAutogenObject, CCS_Enum) is True)):
            return("")
        else:
            bIsArrayValue = bool(False)
            # CCS_EnumArray and CCS_StructArray has a list as a value
            if ((isinstance(objAutogenObject, CCS_EnumArray) is True) or (isinstance(objAutogenObject, CCS_StructArray) is True)):
                iNumItemsInList = objAutogenObject.iGetCount()
                # Generate a name for this list because it doesn't have one - use TYPE+NUM_IN_LIST
                lstAcNames = [str(type(objAutogenObject)).split('\'')[1] + str(x) for x in range(iNumItemsInList)]
                # Get the value which is list so we can iterate through it later
                lstValue = objAutogenObject.Value
                bIsArrayValue = True
            else:
                # If we are here then this CCS_Types class have attributes and not a value which is a list
                # dir() gets the names (as strings) of the class attributes
                # NB!!! these are returned in alphabetical order not in the class order
                lstAcNames = [attr for attr in dir(objAutogenObject) if not callable(getattr(objAutogenObject, attr)) and not attr.startswith("_")]
                bIsArrayValue = False

            # Now iterate through the attributes or list items
            for iIndex, acName in enumerate(lstAcNames):
                acFootprint = ""
                acFootprint += acName

                if (bIsArrayValue is True):
                    # The object is CCS_EnumArray or CCS_StructArray so iterate through its list
                    objAttribute = lstValue[iIndex]
                else:
                    # getattr gets the object of the attribute with the name acName as an object
                    objAttribute = getattr(objAutogenObject, acName)

                # Get Type
                if (isinstance(objAttribute, (CCS_Base, CCS_Enum, CCS_EnumArray, CCS_StructArray, CCS_Struct)) is True):
                    lstAcType = str(type(objAttribute)).split('\'')
                    acFootprint += lstAcType[1]

                acFootprint += str(iLevel + 1)
                # We make a hash of the current footprint combined with the hash from method which called this one
                acHash = str(zlib.crc32(bytes(acFootprint + acHashPar, "utf8")))
                # Add the hash to the linear footprint. We will use it later to compare footprints.
                lstFootprint += [{"acFootprint": acFootprint, "MsgObject": objAttribute, "iLevel": iLevel + 1, "acHash": acHash}]

                # This level is not a CCS_Base or CCS_Enum so we do recursion!
                clsAutogenUtilities.vFromAutogenObjGenerateLinearFootprint(objAttribute, lstFootprint, iLevel + 1, acHash)

        return

    @staticmethod
    def bNestedDictToFootprint(dctNestDict: Dict, lstFootprint: List, iLevel: int = 0, acHashPar: str = "") -> bool:
        """ This is a public static method which populates a list with the footprints from a nested python dictionary. This method is called recursively!

        A footprint (acFootprint) is a string made out of the [NAME][TYPE][LEVEL].

        Args:
            dctNestDict (dict): The first parameter. A nested dictionary of an autogen item. The nested dictionary can on one level have the following keys
                namely "Name", "Type", "Value" and "Attr". The "Attr" key value if not None will either contain another dictionary or a list of dictionaries
                for the next level of the tree.
                An example picture of this might look like:
                    ['Attr'] =
                            ['Name'] = 'sMsgHeader'
                            ['Type'] = 'TEST_MSG_MsgDef.MsgHeader'
                            ['Attr'] =
                                    [0] =
                                        ['Name'] = 'u2ModuleAddress'
                                        ['Type'] = 'CCS_Types.CCS_Base'
                                        ['Value'] = 1
                                        ['Attr'] = None

            lstFootprint (list): The second parameter. The list starts empty and will be filled in with dictionary {"acFootprint":_, "Value":_, "iLevel":_ }
            iLevel (int): The third parameter. This is for the recursion to know which level it is on.
            acHashPar (str): The fourth parameter. Will contain the hash which was passed into this method. 

        Returns:
            (bool): A boolean value indicating if the method was succesfull

        Raises:
            Raises no exceptions
        """
        objAttr = None
        objValue = None
        acHash = acHashPar
        acFootprint = ""

        if (iLevel == 0):
            iLevel += 1
        else:
            iLevel = iLevel

        if (("Name" in dctNestDict) and ("Type" in dctNestDict)):
            objValue = None  # We must make this None for now
            if ("Value" in dctNestDict):
                # The CCS_Base object can also have a Value which is a list - for example Type U4 with Count 6 (U4 x 6)
                # In that case the Value will be a list
                if (isinstance(dctNestDict["Value"], (int, float, str, list)) is True):
                    objValue = dctNestDict["Value"]

            acFootprint = dctNestDict["Name"] + dctNestDict["Type"] + str(iLevel)
            # We make a hash of the current footprint combined with the hash from method which called this one
            acHash = str(zlib.crc32(bytes(acFootprint + acHashPar, "utf8")))
            lstFootprint += [{"acFootprint": acFootprint, "Value": objValue, "iLevel": iLevel, "acHash": acHash}]
        else:
            iLevel -= 1

        if ("Attr" in dctNestDict):
            objAttr = dctNestDict["Attr"]

            if (objAttr is None):
                return(True)

            if (isinstance(objAttr, list) is True):
                for _, objAttr in enumerate(objAttr):
                    clsAutogenUtilities.bNestedDictToFootprint(objAttr, lstFootprint, iLevel + 1, acHash)
            elif (isinstance(objAttr, dict) is True):
                clsAutogenUtilities.bNestedDictToFootprint(objAttr, lstFootprint, iLevel + 1, acHash)

        return(True)

    @staticmethod
    def lstLoadFootprintValuesIntoAutogenObject(lstA: List, lstB: List) -> Tuple[List, List, List]:
        """ This is a public static method which copies the values from one footprint into the objects stored in another footprint.
        Values from lstB will be copied into lstA. The values are only copied over if the footprints for that attribute match.
        A footprint (acFootprint) is a string made out of the [NAME][TYPE][LEVEL].

        Args:
            lstA (list): The first parameter. A list of dictionaries with keys "acFootprint" and "MsgObject".
            lstB (list): The second parameter. A list of dictionaries with keys "acFootprint" and "Value".

        Returns:
            (tuple): A tuple (lstValuesUpdated, lstAllFieldsWithMatchingFootprint)  
                    [0] A list contains the names of all the fields which have changed
                    [1] A list contains the names of all the fields which have matching footprints
                    [2] A list contains the hashes which has a matching partner

        Raises:
            Raises no exceptions
        """

        lstObjectsAlreadySet = []  # A list of strings - represents fields which got new values
        lstValuesUpdated = []  # A list of strings - all the fields already matched
        lstAllFieldsWithMatchingFootprint = []
        lstMatchingHashes = []
        tplReturn = (lstValuesUpdated, lstAllFieldsWithMatchingFootprint, lstMatchingHashes)
        bIsFieldMsgLengthInHeader = bool(False)
        iLstAIndex = int(0)  # We will use this index to keep track of where in lstA we are iterating

        if (lstA is None):
            logging.error("lstA cannot be None")
            return(tplReturn)

        if (lstB is None):
            logging.error("lstB cannot be None")
            return(tplReturn)

        if (isinstance(lstA, list) is False):
            logging.error("lstA must be a list")
            return(tplReturn)

        if (isinstance(lstB, list) is False):
            logging.error("lstB must be a list")
            return(tplReturn)

        if (not lstA):
            logging.error("lstA cannot be empty")
            return(tplReturn)

        if (not lstB):
            logging.error("lstB cannot be empty")
            return(tplReturn)

        # Brute force iterate through both lists. The big-o is O(n^2)
        for dctItemA in lstA:
            for dctItemB in lstB:
                # The hashes must match and this object must not have been set before
                if ((dctItemA["acHash"] == dctItemB["acHash"]) and (dctItemA["MsgObject"] not in lstObjectsAlreadySet)):
                    # Keep a record of the hashes which have already matched
                    if (dctItemA["acHash"] not in lstMatchingHashes):
                        lstMatchingHashes += [dctItemA["acHash"]]
                    # Keep a record of all the objects which have been set
                    lstObjectsAlreadySet += [dctItemA["MsgObject"]]

                    # Work out of this field is the u2MsgLength field in the header
                    # Because we are not guarenteed that fields will be in order (like in the XML)
                    # we will say that if it is the u2MsgLength field and it is in the header field range (1,2,3,4 or 5)
                    # and the values are different then exclude it
                    bIsFieldMsgLengthInHeader = (iLstAIndex < 6) and (dctItemA["acFootprint"] == "u2MsgLengthCCS_Types.CCS_Base2") and (dctItemA["MsgObject"].Value != dctItemB["Value"])

                    if (bIsFieldMsgLengthInHeader is True):
                        logging.warning("Will not update field u2MsgLength - it is excluded from upgrade")
                        if (len(lstA) >= 7):
                            logging.warning("Will not update field u2MsgLength for message with PL %s - it is excluded from upgrade", lstA[6]["acFootprint"])

                    # We only change values if the type is CCS_Base or CCS_Enum and it's not u2MsgLength
                    if ((isinstance(dctItemA["MsgObject"], (CCS_Base, CCS_Enum)) is True) and
                            (bIsFieldMsgLengthInHeader is False)):
                        lstAllFieldsWithMatchingFootprint += ["{} {}".format(dctItemB["acFootprint"], str(dctItemB["Value"]))]
                        if (dctItemA["MsgObject"].Value != dctItemB["Value"]):
                            dctItemA["MsgObject"].Value = dctItemB["Value"]
                            lstValuesUpdated += ["{} {}".format(dctItemB["acFootprint"], str(dctItemB["Value"]))]

            # We keep this index count to keep track of which lstA item we are now at
            iLstAIndex += 1

        if (len(lstMatchingHashes) != len(lstA)):
            logging.warning("The number of matching hashes is not the same as the length of the destination footprints")
            for dctItem in lstA:
                if (dctItem["acHash"] not in lstMatchingHashes):
                    logging.warning("XML default autogen object field %s did not have a matching hash in the JSON database", dctItem["acFootprint"])

        if (len(lstMatchingHashes) != len(lstB)):
            logging.warning("The number of matching hashes is not the same as the length of the source footprints")
            for dctItem in lstB:
                if (dctItem["acHash"] not in lstMatchingHashes):
                    logging.warning("JSON database field %s did not have a matching hash in the autogen default object", dctItem["acFootprint"])

        return((lstValuesUpdated, lstAllFieldsWithMatchingFootprint, lstMatchingHashes))

    @staticmethod
    def vPrintFootprintAsTree(lstFootprint: List):
        """ This is a public method which iterates the footprint and prints it as a tree structure

        Args:
            lstFootprint (list): The first parameter. The footprint.

        Returns:

        Raises:
            Raises no exceptions
        """
        acLineToPrint = str("")

        # Can't be None
        if (lstFootprint is None):
            return

        # Must be a list
        if (isinstance(lstFootprint, list) is False):
            return

        # Iterate through the list
        for _, dctItem in enumerate(lstFootprint):
            if (dctItem is not None):
                if (("iLevel" in dctItem) and ("acFootprint" in dctItem)):
                    acLineToPrint = "{} Footprint:{}".format(" " * dctItem["iLevel"], dctItem["acFootprint"])

                    # If this footprint includes values then print them
                    if ("Value" in dctItem):
                        if (dctItem["Value"] is not None):
                            acLineToPrint += " Value:{}".format(dctItem["Value"])

                    print(acLineToPrint)
