#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module contains a class with static methods for Datetime operations.

Todo:

"""
import datetime  # Needed to make datetime objects
import time  # Needed to 
import logging


class clsDatetimeUtilities():
    """This is a class used static defined datetime related methods.

    Args:

    """

    @staticmethod
    def objGetUtcCurrentDatetime():
        """ This is a public static method which gets the current UTC datetime.

        Args:

        Returns:
            (datetime): The current UTC datetime.

        Raises:
            Raises no exception.
        """
        # Note don't use datetime.datetime.utcnow() because it makes a naive object
        return(datetime.datetime.now(datetime.timezone.utc))

    @staticmethod
    def objGetUtcDatetimeFromEpochUtcMSec(iEpochTimeUtcMSec: int):
        """ This is a public static method which converts
        a Epoch Utc Msec into a python datetime

        Args:
            iEpochTimeUtcMSec (int): The first parameter. The epoch UTC time in MSec.

        Returns:
            (datetime): A datetime

        Raises:
            Raises no exception.

        """
        objDateTimeEpoch = datetime.datetime(1970, 1, 1, tzinfo=datetime.timezone.utc)
        objReturnValue = objDateTimeEpoch

        try:
            objTimeDelta = datetime.timedelta(milliseconds=iEpochTimeUtcMSec)
            objReturnValue = objDateTimeEpoch + objTimeDelta
        except Exception as E:
            logging.error("Could not do time calculation - Exception %s", str(E))

        return(objReturnValue)

    @staticmethod
    def iGetUtcCurrentDatetimeInMicroSecondsSinceEpoch():
        """ This is a public static method which gets the current UTC datetime in micro seconds since epoch 1 Jan 1970.

        Args:

        Returns:
            (int): The current UTC datetime in micro seconds.

        Raises:
            Raises no exception.
        """
        objDateTimeEpoch = datetime.datetime(1970, 1, 1, tzinfo=datetime.timezone.utc)
        # Convert from a float seconds to float microseconds
        # Note don't use datetime.datetime.utcnow() because it makes a naive object
        return(int(((datetime.datetime.now(datetime.timezone.utc) - objDateTimeEpoch).total_seconds()) * 1000000.0))

    @staticmethod
    def iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch():
        """ This is a public static method which gets the current UTC datetime in milli seconds since epoch 1 Jan 1970.

        Args:

        Returns:
            (int): The current UTC datetime in milli seconds.

        Raises:
            Raises no exception.
        """
        objDateTimeEpoch = datetime.datetime(1970, 1, 1, tzinfo=datetime.timezone.utc)
        # Convert from a float seconds to float milliseconds
        # Note don't use datetime.datetime.utcnow() because it makes a naive object
        return(int(((datetime.datetime.now(datetime.timezone.utc) - objDateTimeEpoch).total_seconds()) * 1000.0))

    @staticmethod
    def iGetEpochUtcMSecFromDateTime(objDateTimePar: object) -> int:
        objDateTimeEpoch = datetime.datetime(1970, 1, 1, tzinfo=datetime.timezone.utc)
        # Convert from a float seconds to float milliseconds
        return(int(((objDateTimePar - objDateTimeEpoch).total_seconds()) * 1000.0))

    @staticmethod
    def acEpochUtcUSecToStringFormat(iTimestampEpochUSecPar: int):
        """ This is a public static method which converts a Epoch UTC microseconds into a string with
            format (%Y%m%d_%H%M%S_%f)

        Args:

        Returns:
            (str): The string value of the epoch time sent in

        Raises:
            Raises no exception.
        """

        # See http://strftime.org/
        # %Y -> Year with century as a decimal number.
        # %m -> Month as a zero-padded decimal number.
        # %d -> Day of the month as a zero-padded decimal number.
        # %H -> Hour (24-hour clock) as a zero-padded decimal number.
        # %M -> Minute as a zero-padded decimal number.
        # %S -> Second as a zero-padded decimal number.
        # %f -> Microsecond as a decimal number, zero-padded on the left.

        objTimeUtc = datetime.datetime(1970, 1, 1, tzinfo=datetime.timezone.utc)

        try:
            objTimeUtc = datetime.datetime(1970, 1, 1, tzinfo=datetime.timezone.utc) + datetime.timedelta(microseconds=iTimestampEpochUSecPar)
        except Exception as E:
            logging.error("Could not do time calculation - Exception %s", str(E))

        return(objTimeUtc.strftime("%Y%m%d_%H%M%S_%f"))

    @staticmethod
    def tplFilenameUtcTimeStringNow():
        """ This is a public static method which provides a string of the current UTC time in
            format (%Y%m%d_%H%M%S_%f)

        Args:

        Returns:
            (str): The string value of the epoch time sent in

        Raises:
            Raises no exception.
        """
        objDateTimeUtcNow = clsDatetimeUtilities.objGetUtcCurrentDatetime()

        # See http://strftime.org/
        # %Y -> Year with century as a decimal number.
        # %m -> Month as a zero-padded decimal number.
        # %d -> Day of the month as a zero-padded decimal number.
        # %H -> Hour (24-hour clock) as a zero-padded decimal number.
        # %M -> Minute as a zero-padded decimal number.
        # %S -> Second as a zero-padded decimal number.
        # %f -> Microsecond as a decimal number, zero-padded on the left.

        return((objDateTimeUtcNow, objDateTimeUtcNow.strftime("%Y%m%d_%H%M%S_%f")))

    @staticmethod
    def objDatetimeDcpStringToDatetime(acString: str):
        """ This is a public static method which converts
            a string in format (%Y%m%d_%H%M%S_%f) to a DateTime

        Args:
            acString: The first parameter. The string to be converted into a datetime.

        Returns:
            (str): The string value of the epoch time sent in

        Raises:
            Raises no exception.
        """

        # See http://strftime.org/
        # %Y -> Year with century as a decimal number.
        # %m -> Month as a zero-padded decimal number.
        # %d -> Day of the month as a zero-padded decimal number.
        # %H -> Hour (24-hour clock) as a zero-padded decimal number.
        # %M -> Minute as a zero-padded decimal number.
        # %S -> Second as a zero-padded decimal number.
        # %f -> Microsecond as a decimal number, zero-padded on the left.
        # %z -> UTC offset in the form ±HHMM[SS] (empty string if the object is naive).

        # This is the format from the DCP filename
        acBaseFormatString = "%Y%m%d_%H%M%S_%f"
        # Now add the timezone so that the resultant datetime is timezone aware
        acFormatStringWithTz = acBaseFormatString + "_%z"

        objDatetime = datetime.datetime.strptime(acString + "_+0000", acFormatStringWithTz)

        return(objDatetime)

    @staticmethod
    def bCurrentMonotonicRawTimeExceedsDateTimePlusMSecThreshold(objDateTimeBasePar: object, iThresholdMSecPar: int):
        """ This is a public static method which checks if the current time
        exceeds a datetime plus a threshold

        Args:
            objDateTimeBasePar (datetime): The first parameter. Must be monotonic raw!!!
            iThresholdMSecPar (int): The second parameter. The threshold in msec.

        Returns:
            (bool): Bool value which indicates if the time was exceeded.

        Raises:
            Raises no exception.
        """
        bReturnValue = bool(False)

        if (objDateTimeBasePar is None):
            logging.error("objDateTimeBasePar cannot be None")
            return(bReturnValue)

        if (isinstance(iThresholdMSecPar, int) is False):
            logging.error("iThresholdMSecPar must be an int")
            return(bReturnValue)

        if (iThresholdMSecPar < 0):
            logging.error("iThresholdMSecPar cannot be negative")
            return(bReturnValue)

        objCurrentTime = clsDatetimeUtilities.objGetMonotonicRawCurrentDatetime()

        try:
            objThresholdTime = objDateTimeBasePar + datetime.timedelta(milliseconds=iThresholdMSecPar)
            bReturnValue = objCurrentTime > objThresholdTime
        except Exception:
            pass

        return(bReturnValue)

    @staticmethod
    def bCurrentUtcTimeExceedsDateTimePlusMSecThreshold(objDateTimeBasePar: object, iThresholdMSecPar: int):
        """ This is a public static method which checks if the current UTC time
        exceeds a datetime plus a threshold

        Args:
            objDateTimeBasePar (datetime): The first parameter. Must be UTC!!! Not monotonic raw!!! Timezone must be UTC not naive.
            iThresholdMSecPar (int): The second parameter. The threshold in msec.

        Returns:
            (bool): Bool value which indicates if the time was exceeded.

        Raises:
            Raises no exception.
        """
        bReturnValue = bool(False)

        if (objDateTimeBasePar is None):
            logging.error("objDateTimeBasePar cannot be None")
            return(bReturnValue)

        if (isinstance(iThresholdMSecPar, int) is False):
            logging.error("iThresholdMSecPar must be an int")
            return(bReturnValue)

        if (iThresholdMSecPar < 0):
            logging.error("iThresholdMSecPar cannot be negative")
            return(bReturnValue)

        # Get the current UTC time (with tz UTC not naive)
        objCurrentTime = clsDatetimeUtilities.objGetUtcCurrentDatetime()

        try:
            objThresholdTime = objDateTimeBasePar + datetime.timedelta(milliseconds=iThresholdMSecPar)
            bReturnValue = objCurrentTime > objThresholdTime
        except Exception:
            pass

        return(bReturnValue)

    @staticmethod
    def objGetMonotonicRawCurrentDatetime():
        """ This is a public static method which gets the raw CLOCK_MONOTONIC_RAW time as a datetime

        Args:

        Returns:
            (datetime): The CLOCK_MONOTONIC_RAW as a datetime.

        Raises:
            Raises no exception.
        """
        # Note make tz None so that the datetime object is naive
        return(datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None))
