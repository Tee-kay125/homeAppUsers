#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which provides state machine related utilities.


"""

import logging


class clsStateMachineUtilities():
    """ This is the utilities class which provides coordinate transformation methods

    Args:

    """

    @staticmethod
    def vLogTransitionsStateChange(acPreviousStatePar: str, acCurrentStatePar: str, acUnitPar: str, acAdditionalMessagePar: str = "", bLogOnlyOnChangePar: bool = True, iLogLevelPar: int = logging.INFO):
        """ This is a public method which logs a state machine change to the logger.

        Args:
            acPreviousStatePar (str): The first parameter. The previous state.
            acCurrentStatePar (str): The second parameter. The current state.
            acUnitPar (str). The third parameter. The unit which is having a state change
            acAdditionalMessagePar (str): The fourth parameter. An additional message which we may want to print.
            bLogOnlyOnChangePar (bool): The fifth parameter. Bool flag to indicate if we should log only when there is a change in state.
            iLogLevelPar (int): The sixth parameter. The log level. The default is INFO (level 20)

        Returns:

        Raises:
            Raises no exception.
        """

        # Log only when there is a change or when overwridden
        if ((acCurrentStatePar != acPreviousStatePar) or (bLogOnlyOnChangePar is False)):
            logging.log(iLogLevelPar, "%s state change from %s to %s %s", acUnitPar, acPreviousStatePar, acCurrentStatePar, acAdditionalMessagePar)

        return

    @staticmethod
    def vLogTransitionsStateCurrent(acCurrentStatePar, acUnitPar: str, acAdditionalMessagePar: str = ""):
        """ This is a public method which logs the current state machine state.

        Args:
            acCurrentStatePar (str): The first parameter. The current state.
            acUnitPar (str). The second parameter. The unit which is having a state change
            acAdditionalMessagePar (str): The third parameter. An additional message which we may want to print.

        Returns:

        Raises:
            Raises no exception.
        """

        logging.info("%s state change to %s %s", acUnitPar, acCurrentStatePar, acAdditionalMessagePar)

        return
