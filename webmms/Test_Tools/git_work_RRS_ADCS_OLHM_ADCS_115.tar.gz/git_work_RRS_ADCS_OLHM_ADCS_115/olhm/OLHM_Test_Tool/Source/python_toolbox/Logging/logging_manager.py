#! /usr/bin/env python
# -*- coding: utf-8 -*-
"""This module contains the logger manager class.

In order to use this module make an instance of it and the call vConfigureLogger()

Todo:

"""
import logging
import time
from logging.handlers import RotatingFileHandler  # noqa    # pylint: disable=W0611


class clsLoggingManager:
    """ This is the logging manager class.

    Args:
    """
    def __init__(self):
        super(clsLoggingManager, self).__init__()
        self._objRootLogger = None
        self._acModuleName = str("")  # Will be set later in vConfigureLogger(...)
        # Set up the logging format we want to use
        self._acLoggingFormat = str("")  # Will be set later in vConfigureLogger(...)
        self._acLoggingDateFormat = "%Y,%m,%d,%H,%M,%S"  # This follows the logging standard
        self._objLogFormatter = None
        self._objLoggingConsoleHandler = None
        self._objLoggingRotatingFileHandler = None

    def vConfigureLogger(self, acFilenamePar: str = 'logging.log', iMaxBytesPar: int = 536870912, iBackupCountPar: int = 1, acModuleNamePar: str = "") -> None:
        """ This public method which configures the logger manager after the constructor

        Parameters:
            acFilenamePar (str): The first parameter. The name of the log file.
            iMaxBytesPar (int): The second parameter. The maximum allowed size of the log file.
            iBackupCountPar (int): The third parameter. The number of backup files allowed.
            acModuleNamePar (str): The fourth parameter. The name of module logging.

        Returns:

        Raises:
            Raises no exceptions

        """

        self._objRootLogger = logging.getLogger()  # Get the logger instance
        self._objRootLogger.setLevel(logging.DEBUG)
        self._acModuleName = acModuleNamePar

        # This log format follows the logging standard
        # Insert the module name in its correct place
        self._acLoggingFormat = "%(asctime)s,%(msecs)03d," + self._acModuleName + ",%(levelname)s,%(filename)s,%(lineno)d,%(funcName)s,%(message)s"

        self._objLogFormatter = logging.Formatter(self._acLoggingFormat, self._acLoggingDateFormat)
        # Set up the logger to use UTC time instead of local time - this is to follow the logging standard
        logging.Formatter.converter = time.gmtime

        # Also make use of a StreamHandler so that we can log to the console as well to make development easier
        self._objLoggingConsoleHandler = logging.StreamHandler()
        self._objLoggingConsoleHandler.setLevel(logging.DEBUG)
        self._objLoggingConsoleHandler.setFormatter(self._objLogFormatter)
        self._objRootLogger.addHandler(self._objLoggingConsoleHandler)

        # When we log to file it must be a rotating log file
        self._objLoggingRotatingFileHandler = logging.handlers.RotatingFileHandler(filename=acFilenamePar, mode='a', maxBytes=iMaxBytesPar, backupCount=iBackupCountPar)
        self._objLoggingRotatingFileHandler.setLevel(logging.DEBUG)
        self._objLoggingRotatingFileHandler.setFormatter(self._objLogFormatter)
        self._objRootLogger.addHandler(self._objLoggingRotatingFileHandler)

        return

    def objGetLoggerInstance(self) -> None:
        """ This public method is used to get the instance of the logger.

        Parameters:

        Returns:
            (object): The getlogger() instance

        Raises:
            Raises no exceptions

        """
        return(self._objRootLogger)
