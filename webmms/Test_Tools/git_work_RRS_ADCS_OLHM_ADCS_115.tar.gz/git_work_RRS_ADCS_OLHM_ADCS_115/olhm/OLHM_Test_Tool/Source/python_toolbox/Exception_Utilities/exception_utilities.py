#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module contains a class with static methods for operations performed on Exceptions

Todo:

"""
import traceback
import logging


class clsExceptionUtilities():
    """This is a class used static defined datetime related methods.

    Args:

    """

    @staticmethod
    def vExcepthookHandler(typeException, objValue, objTraceback):
        """ This is a public static method which acts as a callback handler for the sys.excepthook callback.
        Please see https://docs.python.org/3/library/sys.html for more info

        Args:
            typeException (type): The first parameter. The exception type
            objValue (object): The second parameter. The exception type
            objTraceback (traceback): The third parameter. The exception traceback

        Returns:

        Raises:
            Raises no exception.
        """
        objStackSummary = None
        logging.error("Uncaught exception!!!: An uncaught exception has occured")

        if (typeException is not None):
            logging.error("Uncaught exception!!!: Exception type %s", str(typeException))

        if (objValue is not None):
            logging.error("Uncaught exception!!!: Exception value %s", str(objValue))

        # If the traceback is None exit early - then there is nothing we can do
        if (objTraceback is None):
            return

        # The extract_tb call will give us a traceback.StackSummary
        try:
            objStackSummary = traceback.extract_tb(objTraceback)
        except Exception as E:
            objStackSummary = None
            logging.error(str(E))

        if objStackSummary is None:
            return

        # Iterate through all the FrameSummary(s) in the StackSummary
        for objFrameSummary in objStackSummary:
            logging.error("Uncaught exception!!!: %s", str(objFrameSummary))

        return
