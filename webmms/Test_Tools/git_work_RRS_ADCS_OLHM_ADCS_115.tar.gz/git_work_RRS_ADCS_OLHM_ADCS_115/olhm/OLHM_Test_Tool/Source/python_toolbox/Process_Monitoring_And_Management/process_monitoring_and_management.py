#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module contains a class with static methods which are useful for the monitoring and management of processes.

Note!!! This class will only work for linux.

Todo:

"""

import os
import logging
import subprocess
import psutil


class clsProcessMonitoringAndManagement():
    """This is a class used static defined datetime related methods.

    Args:

    """

    @staticmethod
    def lstPidsOfSpecificCommandLine(lstCommandLineArgsToMatchPar: list) -> bool:
        """ This is a public static method which checks if process or process are running right now and also returns the PID if it is.

        Args:
            lstCommandLineArgsToMatchPar (list). The first parameter. A list of strings of the command line parameters to check for.

        Returns:
            (list): List of PIDs

        Raises:
            Raises no exception.
        """
        lstReturnValue = []
        bContinue = bool(False)
        bListsMatch = bool(False)
        lstCommandArgs = None  # Will be populated later

        if (lstCommandLineArgsToMatchPar is None):
            logging.error("lstCommandLineArgsToMatchPar cannot be None")
            return(lstReturnValue)

        if (not lstCommandLineArgsToMatchPar):
            logging.error("lstCommandLineArgsToMatchPar cannot be empty")
            return(lstReturnValue)

        for acArgument in lstCommandLineArgsToMatchPar:
            if (isinstance(acArgument, str) is False):
                logging.error("Items in lstCommandLineArgsToMatchPar must be strings")
                return(lstReturnValue)

            if (not acArgument):
                logging.error("Items in lstCommandLineArgsToMatchPar cannot be empty strings")
                return(lstReturnValue)

        bContinue = False
        # Now get a list of all the processes running on Linux
        try:
            lstProcesses = psutil.process_iter()
            bContinue = True
        except Exception as E:
            logging.error("Could not successfully call psutils.process_iter - Exception %s", str(E))
            return(lstReturnValue)

        if (bContinue is False):
            logging.error("Could not successfully call psutils.process_iter")
            return(lstReturnValue)

        # If the library says no processes are running then there is nothing we can do so return but don't log
        if (lstProcesses is None):
            return(lstReturnValue)

        # Now iterate through all the processes
        for objProc in lstProcesses:

            bContinue = False
            if (objProc is not None):
                try:
                    # Get the command line of when the process was executed
                    lstCommandArgs = objProc.cmdline()
                    bContinue = True
                except Exception as E:
                    continue

                if (lstCommandArgs is None):
                    continue

                if (isinstance(lstCommandArgs, list) is False):
                    continue

                # If the length of the args of the actual process is lesss
                # then what we are looking for then this can't be the match
                if (len(lstCommandArgs) < len(lstCommandLineArgsToMatchPar)):
                    continue

                bListsMatch = False  # Start with the flag as False
                for iIndex in range(min(len(lstCommandArgs), len(lstCommandLineArgsToMatchPar))):
                    bListsMatch = (lstCommandArgs[iIndex] == lstCommandLineArgsToMatchPar[iIndex])

                    if (bListsMatch is False):
                        continue

                # Check if all the arguments matched
                if (bListsMatch is True):
                    # Now that we know it is the right process get the PID as well and add it to the list
                    lstReturnValue += [objProc.pid]

        return(lstReturnValue)

    @staticmethod
    def bSendSigKillSignalToListOfPids(lstPidsPar: list) -> bool:
        """ This is a public static method which sends a SIGKILL Linux signal to a list of PIDs.

        Args:
            lstPidsPar (int): The first parameter. The list of PIDs.

        Returns:
            (bool): A bool indicating if the method was successful or not.

        Raises:
            Raises no exception.
        """
        bReturnValue = bool(False)
        bContinue = bool(False)
        objPsutilProcess = None

        if (lstPidsPar is None):
            logging.error("lstPidsPar cannot be None")
            return(bReturnValue)

        if (isinstance(lstPidsPar, list) is False):
            logging.error("lstPidsPar must be a list ")
            return(bReturnValue)

        if (not lstPidsPar):
            # Don't log here if the list is empty - just return
            return(bReturnValue)

        # Now iterate through all the PIDs
        for iPid in lstPidsPar:

            if (iPid <= 0):
                logging.error("iPid must be greater than zero")
                continue

            bContinue = False
            try:
                objPsutilProcess = psutil.Process(pid=iPid)
                bContinue = True
            except Exception as E:
                logging.error("Could not make an psutil Process object - Exception %s", str(E))
                continue

            if (bContinue is False):
                logging.error("Could not make an psutil Process object")
                continue

            if (objPsutilProcess is None):
                logging.error("objPsutilProcess cannot be None")
                continue

            bContinue = False
            try:
                objPsutilProcess.kill()
                bContinue = True
            except Exception as E:
                logging.error("Could not call the kill method of the objPsutilProcess object - Exception %s", str(E))
                continue

        return(True)

    @staticmethod
    def bSendSignalToListOfPids(lstPidsPar: list, iSignalNumberPar: int) -> bool:
        """ This is a public static method which sends a Linux signal to a list of PIDs.

        For all the signal numbers see http://www.comptechdoc.org/os/linux/programming/linux_pgsignals.html

        Args:
            lstPidsPar (int): The first parameter. The list of PIDs.
            iSignalNumberPar (int): The second parameter. The linux signal to send as a int number.

        Returns:
            (bool): A bool indicating if the method was successful or not.

        Raises:
            Raises no exception.
        """
        bReturnValue = bool(False)
        bContinue = bool(False)
        objPsutilProcess = None

        if (lstPidsPar is None):
            logging.error("lstPidsPar cannot be None")
            return(bReturnValue)

        if (isinstance(lstPidsPar, list) is False):
            logging.error("lstPidsPar must be a list ")
            return(bReturnValue)

        if (not lstPidsPar):
            # Don't log here if the list is empty - just return
            return(bReturnValue)

        # Now iterate through all the PIDs
        for iPid in lstPidsPar:

            if (iPid <= 0):
                logging.error("iPid must be greater than zero")
                continue

            bContinue = False
            try:
                objPsutilProcess = psutil.Process(pid=iPid)
                bContinue = True
            except Exception as E:
                logging.error("Could not make an psutil Process object - Exception %s", str(E))
                continue

            if (bContinue is False):
                logging.error("Could not make an psutil Process object")
                continue

            if (objPsutilProcess is None):
                logging.error("objPsutilProcess cannot be None")
                continue

            bContinue = False
            try:
                objPsutilProcess.send_signal(iSignalNumberPar)
                bContinue = True
            except Exception as E:
                logging.error("Could not call the kill method of the objPsutilProcess object - Exception %s", str(E))
                continue

        return(True)

    @staticmethod
    def bRunProcessUsingSubprocessRun(acCommandPar: str):
        """ This is a public static method which runs a command using the subprocess run method

        Args:
            acCommandPar (str). The first parameter. The string which contains the command we want to run.

        Returns:
            (bool): Bool flag indicating if the method was successful or not.

        Raises:
            Raises no exception.
        """
        bReturnValue = bool(False)

        if (acCommandPar is None):
            logging.error("acCommandPar cannot be None")
            return(bReturnValue)

        if (isinstance(acCommandPar, str) is False):
            logging.error("acCommandPar must be a str")
            return(bReturnValue)

        try:
            objCompleted = subprocess.run(acCommandPar)
            bReturnValue = True
        except Exception as E:
            logging.error("Could not call subprocess run for command %s - Exception %s", acCommandPar, str(E))
            return(bReturnValue)

        if (objCompleted is None):
            bReturnValue = False
            logging.error("objCompleted cannot be None")
            return(bReturnValue)

        return(bReturnValue)

    @staticmethod
    def bSendSignalToSpecifiedCommandLine(lstCommandLineArgsToMatchPar: list, iSignalNumberPar: int, iExcludePidPar: int = -1):
        """ This is a public static method which sends a Linux signal to the pid(s) of a specified command line.

        Args:
            lstCommandLineArgsToMatchPar (list). The first parameter. A list of string of the specified command line process.
            iSignalNumberPar (int). The second parameter. The signal to send.
            iExcludePidPar (int). The third parameter. A PID to be excluded from being sent a signal

        Returns:
            (bool): Bool flag indicating if we sent a signal to at least one process

        Raises:
            Raises no exception.
        """
        bReturnValue = bool(False)

        if (not lstCommandLineArgsToMatchPar):
            return(bReturnValue)

        if (iSignalNumberPar <= 0):
            logging.error("iSignalNumberPar must be greater than zero")
            return(bReturnValue)

        # Get the list of PIDs mathching the list of parameters
        lstPids = clsProcessMonitoringAndManagement.lstPidsOfSpecificCommandLine(lstCommandLineArgsToMatchPar)

        # Exit early if that list is empty - nothing to do
        if (not lstPids):
            return(bReturnValue)

        # If we have PID to exclude then remove it from the list
        if (iExcludePidPar > 0):
            try:
                lstPids.remove(iExcludePidPar)
            except Exception:
                pass

        # If after the remove the list is empty then return
        if (not lstPids):
            return(bReturnValue)

        return(clsProcessMonitoringAndManagement.bSendSignalToListOfPids(lstPids, iSignalNumberPar))

    @staticmethod
    def vShutdownThisMachineNow():
        """ This is a public static method which shuts down the machine.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        logging.info("Shutting down this system")
        os.system("shutdown -h now")
        return

    @staticmethod
    def vRebootThisMachineNow():
        """ This is a public static method which reboots the machine.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        logging.info("Rebooting this system")
        # os.system("reboot")
        return

    @staticmethod
    def tplGetCpuTempPhysicalId0WithThresholds():
        """ This is a public static method which gets the CPU temperature physical id 0 and the thresholds.

        Args:

        Returns:
            (tuple): (bool, float, float, float) -> (validity, cpu temp deg, high threshold deg, critical threshold deg)

        Raises:
            Raises no exception.
        """

        tplReturn = (bool(False), float(0.0), float(0.0), float(0.0))
        lstShwTempObjects = None
        objShwTemp = None
        objShwTempPhysicalId0 = None

        # Try to read the sensors
        try:
            dctPsutilSensorResult = psutil.sensors_temperatures()
        except Exception as E:
            logging.error("Could not call psutil.sensors_temperatures - Exception %s", str(E))
            return(tplReturn)

        if (dctPsutilSensorResult is None):
            logging.error("dctPsutilSensorResult cannot be None")
            return(tplReturn)

        if ("coretemp" not in dctPsutilSensorResult):
            logging.error("coretemp not in dctPsutilSensorResult")
            return(tplReturn)

        lstShwTempObjects = dctPsutilSensorResult["coretemp"]

        if (not lstShwTempObjects):
            logging.error("lstShwTempObjects cannot be empty")
            return(tplReturn)

        # Iterate through the list of shwtemp objects and find "Physical id 0"
        for objShwTemp in lstShwTempObjects:
            if (objShwTemp is None):
                logging.error("objShwTemp cannot be None")
                continue
            elif ((len(objShwTemp) >= 4) and (objShwTemp[0] == "Physical id 0")):
                objShwTempPhysicalId0 = objShwTemp
                break

        if ((objShwTempPhysicalId0 is not None) and (len(objShwTempPhysicalId0) >= 4)):
            tplReturn = (bool(True), objShwTempPhysicalId0[1], objShwTempPhysicalId0[2], objShwTempPhysicalId0[3])

        return(tplReturn)
