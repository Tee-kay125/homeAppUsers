#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module contains a class with static methods which are utilities for the autogen objects.


Todo:

"""


import os
import logging
from typing import List, Dict, Tuple


class clsMqttSpyUtilities():

    @staticmethod
    def vGenerateMqttSpyJavaScriptFileUsingTopicAndData(objAutogenObjectPar: object, acTopicPar: str, acDestDirectoryPar: str):
        """ This is a public method which generates a MQTT-Spy javascript text for testing purposes.

        Args:
            objAutogenObjectPar (object): The first parameter. An autogen object containing a message.
            acTopicPar (str): The second parameter. The topic of the message.
            acDestDirectoryPar (str): The directory where the file should be saved.

        Returns:

        Raises:
            Raises no exception.
        """

        bCanOpenForWrite = bool(False)
        btaRawPayload = bytes()
        acTopic = acTopicPar
        acOneLine = ""
        acFilename = ""

        acJsText = "// Wrap the script in a method, so that you can do \"return false;\" in case of an error or stop request \nfunction publish()\n{\n        data = ["

        if (objAutogenObjectPar is None):
            logging.error("objAutogenObjectPar cannot be None")
            return

        btaRawPayload = objAutogenObjectPar.StoreToStream()

        if (os.path.exists(acDestDirectoryPar) is False):
            logging.error("Directory path does not exists")
            return

        acFilename = os.path.join(acDestDirectoryPar, "{}.js".format(acTopic).replace("/", "_"))

        bCanOpenForWrite = bool(False)
        try:
            file = open(acFilename, "w")
            bCanOpenForWrite = True
        except Exception as E:
            logging.error("Could not open file for write - Exceptions %s", str(E))

        if (bCanOpenForWrite is False):
            return

        for iIndex, u1Byte in enumerate(btaRawPayload):
            acOneLine += "0x{0:02x}".format(u1Byte)
            if (iIndex < (len(btaRawPayload) - 1)):
                acOneLine += ","
        acOneLine += "]\n"

        acJsText += acOneLine
        acJsText += "        mqttspy.publish(\"{}\", data, 0, false);\n".format(acTopic)
        acJsText += "        return true;\n}\npublish();"
        file.write(acJsText)

        file.close()

        return
