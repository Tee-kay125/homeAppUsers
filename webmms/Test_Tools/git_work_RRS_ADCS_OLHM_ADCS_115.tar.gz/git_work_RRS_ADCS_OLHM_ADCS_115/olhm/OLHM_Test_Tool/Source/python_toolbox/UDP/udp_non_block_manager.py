#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module is a non-blocking UDP wrapper class. It provides basic functionality.

Todo:

"""
import socket
import select
import logging
import datetime
import time


class clsUdpNonBlockManager():
    """ This is the non-blocking UDP manager class. It uses select to read with a timeout.

    Args:
        iUdpBindPortPar (int): The first parameter. The port with which the socket is going to bind with.
        fReadTimeoutSecPar (float): The second parameter. How long the socket must wait while trying to read.
    """
    def __init__(self, iUdpBindPortPar: int = 0, fReadTimeoutSecPar: float = 0.001):
        super(clsUdpNonBlockManager, self).__init__()
        self._iUdpBindPort = iUdpBindPortPar  # The port to which we will bind - with default value this will be 0
        self._fReadTimeoutSec = fReadTimeoutSecPar  # How long we will wait while trying to read
        self._objSocket = None
        self._btaRxBuffer = bytearray([])
        self._iMaxAccumulatedRxBufferBytes = 0x10000  # The is size of the accumulated buffer
        self._iMaxRecvfromBufferBytes = 1024  # This is the size we will allow from a recvfrom
        self._bIsBound = bool(False)
        self._objDatetimeLastSend = None  # Store the last datetime
        self._objDatetimeLastReceive = None  # Store the last datetime

        # Create a new UDP socket inside the class
        try:
            self._objSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # UDP socket
            self._objSocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        except Exception as E:
            logging.error("Could not create new socket - Exception %s", str(E))

        # Set the blocking mode to False because we will use select to read
        if (self._objSocket is not None):
            try:
                self._objSocket.setblocking(False)
            except Exception as E:
                logging.error("Could not set setblocking to False - Exception %s", str(E))

    def bBind(self) -> bool:
        """ This public method which binds the socket to the port
        Parameters:

        Returns:
            bool: Boolean value indicating if the socket successfully bound to socket.

        Raises:
            Raises no exceptions

        """
        bReturnValue = False
        if (self._objSocket is None):
            logging.error("self._objSocket is None")
            return(bReturnValue)

        if (isinstance(self._iUdpBindPort, int) is False):
            logging.error("self._iUdpBindPort must be an int")
            return(bReturnValue)

        # If the class constructor was called with a default value for the bind port than this will be 0
        if (self._iUdpBindPort <= 0):
            logging.error("self._iUdpBindPort must be greater than zero")
            return(bReturnValue)

        if (self.bIsBound() is True):
            logging.error("Socket is already bound to a port")
            return(bReturnValue)

        try:
            self._objSocket.bind(("0.0.0.0", self._iUdpBindPort))
            # IF we made it to here then we bounded successfully
            self._bIsBound = bool(True)
            bReturnValue = bool(True)
        except Exception as E:
            logging.error("Could not bind socket to port - Exception %s", str(E))

        return(bReturnValue)

    def bSetBoundPort(self, iBoundPortPar: int) -> bool:
        """ This is a public method which sets the bound port.

        Parameters:
            iBoundPortPar (int): The first parameter. The port to bind with.

        Returns:
            bool: Boolean value indicating if the method was succesful.

        Raises:
            Raises no exceptions

        """
        bReturnValue = bool(False)
        if (isinstance(iBoundPortPar, int) is False):
            logging.error("iBoundPortPar must be an int")
            return(bReturnValue)

        if (iBoundPortPar <= 0):
            logging.error("iBoundPortPar must be greater than 0")
            return(bReturnValue)

        self._iUdpBindPort = iBoundPortPar
        bReturnValue = True
        return(bReturnValue)

    def iGetBoundPort(self) -> int:
        """ This is a public method which gets the bound port.

        Parameters:

        Returns:
            int: The bind port as int.

        Raises:
            Raises no exceptions

        """
        return(self._iUdpBindPort)


    def bIsBound(self) -> bool:
        """ This is a public method which returns the socket to port bound state.

        Parameters:

        Returns:
            bool: Boolean value indicating if socket is bound to a port.

        Raises:
            Raises no exceptions

        """
        return(self._bIsBound)

    def bRead(self) -> bool:
        """ This public method which will read from the UDP socket
        Parameters:

        Returns:
            bool: Boolean flag which indicates if new data was read.

        Raises:
            Raises no exceptions

        """

        bReadData = bool(False)
        bRecvfromSuccess = bool(False)
        btaRxData = bytes([])

        # Check if we are bound
        if (self._bIsBound is False):
            logging.error("Socket is not bound to a port - cannot read")
            return(bReadData)

        # Use select here to read for while with a timeout
        ready = select.select([self._objSocket], [], [], self._fReadTimeoutSec)
        if ready[0]:
            try:
                (btaRxData, _) = self._objSocket.recvfrom(self._iMaxRecvfromBufferBytes)
                bRecvfromSuccess = True
            except Exception as E:
                logging.error("recvfrom call failed - Exception %s", str(E))

        # Verify that btaRxData is not empty and we did read successfully
        if ((btaRxData) and (bRecvfromSuccess is True)):
            if ((len(self._btaRxBuffer) + len(btaRxData)) < self._iMaxAccumulatedRxBufferBytes):
                self._btaRxBuffer += btaRxData
                self._objDatetimeLastReceive = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                bReadData = True
            else:
                logging.error("The RX is now exceeding its allowed capacity of %d bytes", self._iMaxAccumulatedRxBufferBytes)
                # Clear the buffer
                del self._btaRxBuffer[:]

        return(bReadData)

    def btaGetRxBuffer(self) -> bytearray:
        """ This is public method which return the accunmulated RX buffer.

        Parameters:

        Returns:
            bytearray: The accumulated RX buffer

        Raises:
            Raises no exceptions

        """

        return(self._btaRxBuffer)

    def bSendTo(self, btaDataPar: bytes, tplAddressPar) -> bool:
        """ This is public method which send the data into the socket. If the socket is bound to a port
        then the source port will be that port. If the socket is not bound then the source port will be random.

        Parameters:
            btaDataPar (bytes): The first parameter. The data to be sent.
            tplAddressPar (host, port): The second parameter. The address to which the data should be sent.

        Returns:
            bool: Boolean value indicating if the send was successfull.

        Raises:
            Raises no exceptions

        """
        bReturnValue = bool(False)

        if (self._objSocket is None):
            logging.error("self._objSocket is None")
            return(bReturnValue)

        if ((isinstance(btaDataPar, bytes) is False) and (isinstance(btaDataPar, bytearray) is False)):
            logging.error("btaDataPar can only be a bytes or bytearray")
            return(bReturnValue)

        if (not btaDataPar):
            logging.error("btaDataPar cannot be empty")
            return(bReturnValue)

        if (isinstance(tplAddressPar, tuple) is False):
            logging.error("tplAddressPar is not a tuple")
            return(bReturnValue)

        if (len(tplAddressPar) != 2):
            logging.error("tplAddressPar can only have two items")
            return(bReturnValue)

        if (isinstance(tplAddressPar[0], str) is False):
            logging.error("tplAddressPar[0] must be a string")
            return(bReturnValue)

        if (isinstance(tplAddressPar[1], int) is False):
            logging.error("tplAddressPar[1] must be an int")
            return(bReturnValue)

        try:
            self._objSocket.sendto(btaDataPar, tplAddressPar)
            self._objDatetimeLastSend = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
            bReturnValue = bool(True)
        except Exception as E:
            logging.error("Could not call the sendto method successfully - Exception %s", str(E))

        return(bReturnValue)

    def tplReceiveSendTimeDelta(self):
        """ This is public method which calculates the difference in time between the receive and send. The return tuple
        will also contain a bool indicating if the calculation was possible. In the event that the interface have not yet
        exchanged any data, the bool value will be False and the timedelta be zero.

        Parameters:

        Returns:
            tuple: A tuple value (bSuccess: bool, objDatetimeDelta: datetime.timedelta)

        Raises:
            Raises no exceptions

        """
        tplDeltaTime = (bool(False), datetime.time(0))

        if ((self._objDatetimeLastSend is None) or (self._objDatetimeLastReceive is None)):
            return(tplDeltaTime)

        if (isinstance(self._objDatetimeLastSend, datetime.datetime) is False):
            return(tplDeltaTime)

        if (isinstance(self._objDatetimeLastReceive, datetime.datetime) is False):
            return(tplDeltaTime)

        try:
            # The calculation is RX - TX
            tplDeltaTime = (bool(True), self._objDatetimeLastReceive - self._objDatetimeLastSend)
        except Exception as E:
            logging.error("Could not calculate the time delta - Exception %s", str(E))

        return(tplDeltaTime)
