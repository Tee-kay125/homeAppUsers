#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module contains a class with static utility methods related to TOML files.

Todo:

"""
import logging


class clsTomlUtilities():
    """This class contains static utility methods related to TOML files.

    Args:

    """

    @staticmethod
    def bTomlFieldIsValidIpV4Address(acTomlFieldPar: str):
        """ This is a public static method which determines if a TOML field is a valid IP address.

        Args:
            acTomlFieldPar (str): The TOML field which contains the IP

        Returns:
            (bool): A flag indicating if the field is valid or not.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        lstIpNumber = []
        iIpNumber = int(0)

        if (acTomlFieldPar is None):
            logging.error("TOML field is not allowed to be None")
            return(bReturn)

        if (isinstance(acTomlFieldPar, str) is False):
            logging.error("TOML field should a string and it is of a different type")
            return(bReturn)

        if (not acTomlFieldPar):
            logging.error("TOML field is not allowed to be an empty string")
            return(bReturn)

        if (acTomlFieldPar.count(".") != 3):
            logging.error("IP field %s should have 3 full stop characters", acTomlFieldPar)
            return(bReturn)

        lstIpNumber = acTomlFieldPar.split(".")

        if (len(lstIpNumber) != 4):
            logging.error("IP field %s is invalid", acTomlFieldPar)
            return(bReturn)

        for acIpNumber in lstIpNumber:
            try:
                iIpNumber = int(acIpNumber)
            except Exception as E:
                logging.error("IP number %s is not a valid integer - Exception %s", acIpNumber, str(E))
                return(bReturn)

            if (iIpNumber < 0):
                logging.error("IP number %s cannot be smaller than 0", acIpNumber)
                return(bReturn)

            if (iIpNumber > 255):
                logging.error("IP number %s cannot be greater than 255", acIpNumber)
                return(bReturn)

        return(True)

    @staticmethod
    def bTomlFieldIsValidPort(iTomlFieldPar: int):
        """ This is a public static method which determines if a TOML field is a valid port.

        Args:
            acTomlFieldPar (str): The TOML field which contains the IP

        Returns:
            (bool): A flag indicating if the field is valid or not.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)

        if (iTomlFieldPar is None):
            logging.error("TOML field is not allowed to be None")
            return(bReturn)

        if (isinstance(iTomlFieldPar, int) is False):
            logging.error("TOML field should a string and it is of a different type")
            return(bReturn)

        if (iTomlFieldPar < 1):
            logging.error("TOML field %d used to specify port cannot be smaller than 1", iTomlFieldPar)
            return(bReturn)

        if (iTomlFieldPar > 65535):
            logging.error("TOML field %d used to specify port cannot be greater than 65535", iTomlFieldPar)
            return(bReturn)

        return(True)

    @staticmethod
    def bTomlObjectContainsPath(objTomlObjectPar: object, lstPathTokensPar: list):
        """ This is a public static method which determines if a TOML field is a valid port.

        Args:
            objTomlObjectPar (object): The TOML object
            lstPathTokensPar (list): A list of string tokens

        Returns:
            (bool): A flag indicating if the path was found in the TOML object

        Raises:
            Raises no exception.
        """
        bValid = bool(False)
        objChildObject = None

        if (objTomlObjectPar is None):
            logging.error("objTomlObjectPar cannot be None")
            return(bValid)

        if (lstPathTokensPar is None):
            logging.error("lstPathTokensPar cannot be None")
            return(bValid)

        if (not lstPathTokensPar):
            # If the list of tokens is empty then it is valid
            bValid = bool(True)
            return(bValid)

        # Set the child object to the root before we start to check all the tokens
        objChildObject = objTomlObjectPar

        for acPathToken in lstPathTokensPar:

            # Make sure the child object is not None
            if (objChildObject is None):
                bValid = bool(False)
                return(bValid)

            # Check if all path tokens are strings
            if (isinstance(acPathToken, str) is False):
                logging.error("acPathToken should be a string")
                bValid = bool(False)
                return(bValid)

            # Check that all string tokens are not empty
            if (not acPathToken):
                logging.error("acPathToken cannot be empty")
                bValid = bool(False)
                return(bValid)

            # Check that key exists on this level
            if (acPathToken not in objChildObject):
                logging.error("Path token %s is not key in the TOML object", acPathToken)
                bValid = bool(False)
                return(bValid)

            # Now that we know the key exists get the child using token as a key
            objChildObject = objChildObject[acPathToken]

        # If we are then the path exists
        bValid = bool(True)
        return(bValid)

    @staticmethod
    def bTomlFieldIsAValidInteger(objFieldValuePar: object):
        """ This is a public static method which determines if a TOML field is an integer.

        Args:
            objFieldValuePar (object): The TOML field value

        Returns:
            (bool): A flag indicating if the value is an integer

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)

        if (objFieldValuePar is None):
            return(bReturn)

        if (isinstance(objFieldValuePar, int) is False):
            return(bReturn)

        bReturn = bool(True)
        return(bReturn)

    @staticmethod
    def bTomlFieldIsAValidFloat(objFieldValuePar: object):
        """ This is a public static method which determines if a TOML field is a float.

        Args:
            objFieldValuePar (object): The TOML field value

        Returns:
            (bool): A flag indicating if the value is a float

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)

        if (objFieldValuePar is None):
            return(bReturn)

        if (isinstance(objFieldValuePar, float) is False):
            return(bReturn)

        bReturn = bool(True)
        return(bReturn)
