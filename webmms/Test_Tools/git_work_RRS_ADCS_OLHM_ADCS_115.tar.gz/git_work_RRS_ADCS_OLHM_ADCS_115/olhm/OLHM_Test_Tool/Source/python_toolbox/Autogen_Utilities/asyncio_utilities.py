#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which provides common asyncio utility methods for the autogen.

NOTE!!! This class can only be used by inheriting it from a class which inherits clsMessageProcess() in message_processing.py
NOTE!!! Never make an instance of this class on its own.

"""
import sys
import logging
import asyncio
import typing
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client

class clsAsyncioUtilities():
    """ This is the utilities class which can only be used with the autogen.

    NOTE!!! This class can only be used by inheriting it from a class which inherits clsMessageProcess() in message_processing.py
    NOTE!!! Never make an instance of this class on its own.

    Args:

    """
    '''
    def __init__(self, objMqttClientPar: mqtt.Client, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar: bool = True):
        super(clsAsyncioUtilities, self).__init__(objMqttClientPar, dctMessagesPar, objAsyncioLoopPar, bLoggingEnabledPar)
    '''

    async def bWaitForFutureBasedOnTopic(self, acTopicPar: str, f4TimeOutPar: float) -> bool:
        """ This is a public method which asyncio waits for a Future based on a Topic.

        This inherited class needs base class property self._dctMessages
        This inherited class needs base class property self._objAsyncioLoop

        Args:
            acTopicPar (str): The first parameter. The topic of the messages to be waited for.
            f4TimeOutPar (float): The second parameter. The length of time to wait before the asyncio wait should time out.

        Returns:
            (bool): A boolean value indicating if the methods was successful.

        Raises:
            Raises no exception.
        """
        bReturnValue = bool(False)
        objFuturesDone = None

        if (self._objAsyncioLoop is None):
            logging.error("self._objAsyncioLoop cannot be None")
            return(bReturnValue)

        if (self._dctMessages is None):
            logging.error("self._dctMessages cannot be None")
            return(bReturnValue)

        if (acTopicPar not in self._dctMessages):
            logging.error("Topic %s is not in self._dctMessages", acTopicPar)
            return(bReturnValue)

        if (self._dctMessages[acTopicPar]["objAsyncioFutureProcessCompleted"] is None):
            logging.error("objAsyncioFutureProcessCompleted dictionary item cannot be None for topic %s", acTopicPar)
            return(bReturnValue)

        # Asyncio refernce: coroutine asyncio.wait_for(fut, timeout, *, loop=None)¶
        # Now wait for the Futures
        try:
            # Upon a timeout an exception will be generated
            objFuturesDone = await asyncio.wait_for(self._dctMessages[acTopicPar]["objAsyncioFutureProcessCompleted"], loop=self._objAsyncioLoop, timeout=f4TimeOutPar)
            bReturnValue = bool(True)
        except asyncio.TimeoutError:
            logging.error("asyncio.TimeoutError exception for %s", acTopicPar)
            return(bReturnValue)
        except Exception as E:
            logging.error("Waiting for future exception was thrown for %s - Exception %s", acTopicPar, str(E))
            return(bReturnValue)

        return(bReturnValue)

    async def lstSendListOfMessagesAndWaitForResponse(self, lstMqttMessagesToSendPar: list) -> list:
        """ This is a public method which sends out a list of messages in series and asyncio waits for a Future based on a Topic.

        The Future is there for the asyncio to wait for the response for the message that was sent out

        This inherited class needs base class property self._dctMessages
        This inherited class needs base class property self._objAsyncioLoop
        This inherited class needs base class property self._dctReverseLookupClassNameToTopic

        Args:
            lstMqttMessagesToSendPar (list): The first parameter. A list of messages to send out
                Keys:
                    "tplMessageTypeRolePairCmd" (tuple):
                    "tplMessageTypeRolePairRsp" (tuple):
                    "objCmdMessage" (Autogen object): The message to be sent out
                    "objCmdRspMessage" (Autogen object): Will be None. Will be filled in inside the method.
                    "fTimeoutPeriodS" (float): The threshold for asyncio waiting for the response.

        Returns:
            (list): A list of messages
                Keys:
                    "acTopicCmd" (str): The topic of the message which was sent out.
                    "bResponseInTime" (bool): Bool value which indicates if a response was received before the timeout threshold

        Raises:
            Raises no exception.
        """
        lstReturnValue = []  # The return list will be empty for now

        # Cannot be None
        if (lstMqttMessagesToSendPar is None):
            logging.error("lstMqttMessagesToSendPar cannot be None")
            return(lstReturnValue)

        # Must be a list
        if (isinstance(lstMqttMessagesToSendPar, list) is False):
            logging.error("lstMqttMessagesToSendPar must be a list")
            return(lstReturnValue)

        # Autogen dictionary cannot be None
        if (self._dctMessages is None):
            logging.error("self._dctMessages cannot be None")
            return(lstReturnValue)

        if (self._dctReverseLookupClassNameToTopic is None):
            logging.error("self._dctReverseLookupClassNameToTopic cannot be None")
            return(lstReturnValue)

        # Iterate through all the dictionary items in the list
        for dctItem in lstMqttMessagesToSendPar:
            dctReturnItem = {}

            # Check that all required dict keys are there
            if (not(all(acKey in dctItem for acKey in ["tplMessageTypeRolePairCmd", "tplMessageTypeRolePairRsp", "objCmdMessage", "objCmdRspMessage", "fTimeoutPeriodS"]))):
                continue

            # See if the message type and role is in the reverse lookup
            if (dctItem["tplMessageTypeRolePairCmd"] not in self._dctReverseLookupClassNameToTopic):
                continue

            if (dctItem["tplMessageTypeRolePairRsp"] not in self._dctReverseLookupClassNameToTopic):
                continue

            dctItem["acTopicCmd"] = self._dctReverseLookupClassNameToTopic[dctItem["tplMessageTypeRolePairCmd"]]
            dctItem["acTopicCmdRsp"] = self._dctReverseLookupClassNameToTopic[dctItem["tplMessageTypeRolePairRsp"]]
            dctReturnItem["acTopicCmd"] = dctItem["acTopicCmd"]
            dctReturnItem["bResponseInTime"] = bool(False)  # We set this to False by default

            # Verify all the keys are there before we continue
            if (all(acKey in dctItem for acKey in ["acTopicCmd", "acTopicCmdRsp", "objCmdMessage", "objCmdRspMessage", "fTimeoutPeriodS"])):
                if (dctItem["objCmdMessage"] is not None):
                    # Validate the message before sending it out
                    if (dctItem["objCmdMessage"].bValidate() is True):
                        # Prepare the Future of the CmdRsp before sending
                        if (self.bPrepapreFutureBasedOnTopic(dctItem["acTopicCmdRsp"])):

                            # Publish the command message
                            if (self.bPublishMqttTopicAndData(dctItem["acTopicCmd"], dctItem["objCmdMessage"].btaSerialise())):
                                # Now wait for the CmdRsp based on the topic
                                if (await self.bWaitForFutureBasedOnTopic(dctItem["acTopicCmdRsp"], dctItem["fTimeoutPeriodS"]) is False):
                                    logging.debug("Future not completed for %s - timeout after %f seconds", dctItem["acTopicCmdRsp"], dctItem["fTimeoutPeriodS"])
                                else:
                                    dctItem["objCmdRspMessage"] = self._dctMessages[dctItem["acTopicCmdRsp"]]["MsgObject"]
                                    logging.debug("Future completed for %s", dctItem["acTopicCmdRsp"])
                                    dctReturnItem["bResponseInTime"] = bool(True)
                            else:
                                logging.error("Could not publish MQTT topic %s", dctItem["acTopicCmd"])
                        else:
                            logging.error("Could not prepare Future for topic %s", dctItem["acTopicCmdRsp"])
                    else:
                        logging.error("%s failed validation after retrieving it from the database", dctItem["acTopicCmd"])
                else:
                    logging.error("Key %s for acTopicCmd is None", dctItem["acTopicCmd"])

                # If all the keys are present in the input list, then add a dict item to the output list
                lstReturnValue += [dctReturnItem]

        return(lstReturnValue)

    def bPrepapreFutureBasedOnTopic(self, acTopicPar: str) -> bool:
        """ This is a public method which prepares a Future based on topic.

        This inherited class needs base class property self._dctMessages

        Args:
            acTopicPar (str): The first parameter. The topic of the future to prepare.

        Returns:
            (bool): A boolean value indicating if the methods was successful.

        Raises:
            Raises no exception.
        """
        bReturnValue = bool(False)

        # Topic cannot be None
        if (acTopicPar is None):
            logging.error("acTopicPar cannot be None")
            return(bReturnValue)

        # Topic must be string
        if (isinstance(acTopicPar, str) is False):
            logging.error("acTopicPar must be a str")
            return(bReturnValue)

        # Autogen dictionary must exist
        if (self._dctMessages is None):
            logging.error("Autogen dictionary self._dctMessages cannot be None")
            return(bReturnValue)

        # The topic must be in the dictionary
        if (acTopicPar in self._dctMessages is False):
            logging.error("Topic %s is not in the autogen dictionary", acTopicPar)
            return(bReturnValue)

        # First see if the Future object is None
        if (self._dctMessages[acTopicPar]["objAsyncioFutureProcessCompleted"] is None):
            logging.error("Topic %s does not have a future object in self._dctMessages", acTopicPar)
            return(bReturnValue)

        # Now try to cancel the Future
        try:
            self._dctMessages[acTopicPar]["objAsyncioFutureProcessCompleted"].cancel()
        except Exception as E:
            logging.error("Unable to cancel Future for topic %s - Exception %s", acTopicPar, str(E))
            return(bReturnValue)

        # Make a new instance of the Future
        try:
            self._dctMessages[acTopicPar]["objAsyncioFutureProcessCompleted"] = asyncio.Future()
            bReturnValue = bool(True)
        except Exception as E:
            logging.error("Unable to make new instance of Future for topic %s - Exception %s", acTopicPar, str(E))
            return(bReturnValue)

        return(bReturnValue)

    def bPublishMqttTopicAndData(self, acTopicPar: str, btaDataPar: bytes) -> bool:
        """ This is a public method which publishes a MQTT message based on topic data.

        This inherited class needs base class property self._dctMessages

        Args:
            acTopicPar (str): The first parameter. The topic of the future to prepare.
            btaDataPar (bytes, bytearray): The second parameter. The data to be sent.

        Returns:
            (bool): A boolean value indicating if the methods was successful.

        Raises:
            Raises no exception.
        """

        bReturnValue = bool(False)
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            logging.error("self._objMqttClient cannot be None")
            return(bReturnValue)

        if (acTopicPar is None):
            logging.error("acTopicPar cannot be None")
            return(bReturnValue)

        if (isinstance(acTopicPar, str) is False):
            logging.error("acTopicPar must be a string")
            return(bReturnValue)

        if (not acTopicPar):
            logging.error("acTopicPar cannot be empty")
            return(bReturnValue)

        if (btaDataPar is None):
            logging.error("btaDataPar cannot be None")
            return(bReturnValue)

        if (isinstance(btaDataPar, (bytes, bytearray)) is False):
            logging.error("btaDataPar must be a bytes or bytearray")
            return(bReturnValue)

        if (not btaDataPar):
            logging.error("btaDataPar cannot be empty")
            return(bReturnValue)

        # Get the publish result so we can know if we are still connected to the mqtt broker
        try:
            tplReturn = self._objMqttClient.publish(acTopicPar, btaDataPar, retain=False)
        except Exception as E:
            logging.error("self._objMqttClient.publish() raised an exception - Exception %s", str(E))

        if (tplReturn.rc != mqtt.MQTT_ERR_SUCCESS):
            # Note!!! do not use the tplReturn.is_published() method - seems to buggy
            if (tplReturn.rc == mqtt.MQTT_ERR_NO_CONN):
                logging.error("Could not publish with mqtt.publish - rc MQTT_ERR_NO_CONN")
            elif (tplReturn.rc == mqtt.MQTT_ERR_QUEUE_SIZE):
                logging.error("Could not publish with mqtt.publish - rc MQTT_ERR_QUEUE_SIZE")
            else:
                logging.error("Could not publish with mqtt.publish - rc %d", tplReturn.rc)

        self.vStorePublishConnectionState(tplReturn)

        return(True)

    def bAreMessagesCurrentlyBeingProcessed(self) -> bool:
        """ This is a public method which determines if any messages are being processed right now.
        This method uses the base class dictionary to make this determination.

        This inherited class needs base class property self._dctNumExecutingTasks

        Args:

        Returns:
            (bool): A boolean value indicating if any messages are being processed right now.

        Raises:
            Raises no exception.
        """
        # If now tasks are being executed for that topic then that topic is being executed.
        # In addition if no topics are being processed then nothing is being processed right now.
        lstTopicCurrentProcessing = [x for x in self._dctNumExecutingTasks.items() if x[1] != 0]

        # Here we are not using the else so as to avoid a pylint warning
        if (not lstTopicCurrentProcessing):
            return(False)

        return(True)
