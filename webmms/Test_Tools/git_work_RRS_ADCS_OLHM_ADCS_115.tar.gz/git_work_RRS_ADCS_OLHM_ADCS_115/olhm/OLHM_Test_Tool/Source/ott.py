#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module is the OLHM Test Tool process.

Example:
    To run this file do the following:

        $ python3.6 ott.py -i config.ini


Todo:

"""
# ===========================================
# Imports
# ===========================================

import sys  # Needed to append the path
import os  # Needed to check if files exist
import signal
import logging  # Needed for logging
from logging.handlers import RotatingFileHandler  # noqa
import time  # Needed for sleeping
import queue  # Needed for a queue between the main and the MQTT thread
from collections import deque  # We need this to make a FIFO of work to be processed using asyncio. Note this is seperate from the MQTT queue
import asyncio  # Needed for the message processing loop
import toml  # Needed to parse the factory configuration files
import argparse  # Needed to help manage command line arguments
import paho.mqtt.client as mqtt  # Needed to send and receive message between the rest of the system using mosquitto

from python_toolbox.Logging.logging_manager import clsLoggingManager
from python_toolbox.Exception_Utilities.exception_utilities import clsExceptionUtilities
from python_toolbox.Process_Monitoring_And_Management.process_monitoring_and_management import clsProcessMonitoringAndManagement
from python_toolbox.Datetime_Utilities.datetime_utilities import clsDatetimeUtilities
from asyncio_msg_processing_class import clsMessageProcessForMqtt  # noqa
from ott_mqtt_autogen_handler import clsOttMqttAutogenHandler
from ott_manager import clsOttManager
from ott_launcher_manager import clsOttLauncherManager

from External_Interfaces.DR.dr_transitions_manager import clsDrTransitionsManager
from External_Interfaces.PDBP.pdbp_transitions_manager import clsPdbpTransitionsManager
from External_Interfaces.EIU.eiu_transitions_manager import clsEiuTransitionsManager
from External_Interfaces.TM.tm_transitions_manager import clsTmTransitionsManager
from External_Interfaces.TEWA.tewa_transitions_manager import clsTewaTransitionsManager
from External_Interfaces.SF1.sf1_transitions_manager import clsSf1TransitionsManager
from External_Interfaces.SF2.sf2_transitions_manager import clsSf2TransitionsManager
from External_Interfaces.SF3.sf3_transitions_manager import clsSf3TransitionsManager
from External_Interfaces.HMI_APM.hmi_apm_transitions_manager import clsHmiApmTransitionsManager
from External_Interfaces.HMI_APM_FCO.hmi_apm_fco_transitions_manager import clsHmiApmFcoTransitionsManager
from External_Interfaces.HMI_FCO.hmi_fco_transitions_manager import clsHmiFcoTransitionsManager
from External_Interfaces.HMI_SPM.hmi_spm_transitions_manager import clsHmiSpmTransitionsManager
from External_Interfaces.HMI_SPM_FUFC.hmi_spm_fufc_transitions_manager import clsHmiSpmFufcTransitionsManager
from External_Interfaces.HMI_FUFC.hmi_fufc_transitions_manager import clsHmiFufcTransitionsManager
from External_Interfaces.HMI_Maintainer.hmi_maintainer_transitions_manager import clsHmiMaintainerTransitionsManager
from External_Interfaces.HMI_Oversight.hmi_oversight_transitions_manager import clsHmiOversightTransitionsManager


from Autogen.dr_msg import sDR_STATUS_REPORT_UNSOL
from Autogen.pdbp_msg import sPDBP_STATUS_REPORT_UNSOL
from Autogen.eiu_msg import sEIU_STATUS_REPORT_UNSOL
from Autogen.tm_msg import sTM_STATUS_REPORT_UNSOL
from Autogen.tewa_msg import sTEWA_STATUS_REPORT_UNSOL
from Autogen.sf1_msg import sSF1_STATUS_REPORT_UNSOL
from Autogen.sf2_msg import sSF2_STATUS_REPORT_UNSOL
from Autogen.sf3_msg import sSF3_STATUS_REPORT_UNSOL
from Autogen.hmi_msg import sHMI_STATUS_REPORT_UNSOL
from Autogen.olhm_msg import sOLHM_ADCS_HMI_STATUS_UNSOL

from External_Interfaces.DR.dr_process_messages import clsDrProcessMessages
from External_Interfaces.PDBP.pdbp_process_messages import clsPdbpProcessMessages
from External_Interfaces.EIU.eiu_process_messages import clsEiuProcessMessages
from External_Interfaces.TM.tm_process_messages import clsTmProcessMessages
from External_Interfaces.TEWA.tewa_process_messages import clsTewaProcessMessages
from External_Interfaces.SF1.sf1_process_messages import clsSf1ProcessMessages
from External_Interfaces.SF2.sf2_process_messages import clsSf2ProcessMessages
from External_Interfaces.SF3.sf3_process_messages import clsSf3ProcessMessages
from External_Interfaces.HMI_APM.hmi_apm_process_messages import clsHmiApmProcessMessages
from External_Interfaces.HMI_APM_FCO.hmi_apm_fco_process_messages import clsHmiApmFcoProcessMessages
from External_Interfaces.HMI_FCO.hmi_fco_process_messages import clsHmiFcoProcessMessages
from External_Interfaces.HMI_SPM.hmi_spm_process_messages import clsHmiSpmProcessMessages
from External_Interfaces.HMI_SPM_FUFC.hmi_spm_fufc_process_messages import clsHmiSpmFufcProcessMessages
from External_Interfaces.HMI_FUFC.hmi_fufc_process_messages import clsHmiFufcProcessMessages
from External_Interfaces.HMI_Maintainer.hmi_maintainer_process_messages import clsHmiMaintainerProcessMessages
from External_Interfaces.HMI_Oversight.hmi_oversight_process_messages import clsHmiOversightProcessMessages

# Note!!! Don't make any global attributes

# The install this exception hook to catch any uncaught exections so that we can log them
sys.excepthook = clsExceptionUtilities.vExcepthookHandler

# ===========================================
# Async main function
# ===========================================


async def main(objAsyncioLoopPar, objMqttClientPar: mqtt.Client, dctGlobalInterfaceDictionaryPar: dict) -> None:
    """ This is a public method which is called in the main thread as part of the asyncio loop.

    This is a public method which is called in the main thread as part of the asyncio loop. The main focus of this function is to always be
    servicing the queue and process the messages received. The processing of a message must always be done with a asyncio create_task() call.

    Args:
        objAsyncioLoopPar (obj): The first parameter. The asyncio event loop.
        objMqqtClient (obj): The second parameter. The MQTT client. It is needed to publish messages to the mosquitto broker.
        dctGlobalInterfaceDictionaryPar (dict): The third parameter. The global interface dictionary.

    Returns:

    Raises:
        Raises no exceptions
    """

    # Make a local variable for the queue so that the text is shorter
    objMqttQueue = dctGlobalInterfaceDictionaryPar["dctMqtt"]["objQueue"]
    # Make a local variable for the deque so that the text is shorter
    objDequeTasksToCreate = dctGlobalInterfaceDictionaryPar["dctOTT"]["objDequeAsyncioTasksToBeCreated"]

    # Here class clsMessageProcessForMqtt() inherits from autogen class clsMessageProcess() in message_processing.py
    objClsMessageProcessForMqtt = clsMessageProcessForMqtt(objMqttClientPar, dctGlobalInterfaceDictionaryPar["dctMqtt"]["dctMessagesMqtt"], objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar)
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["objClsMessageProcessForMqtt"] = objClsMessageProcessForMqtt  # Save the message processing derived class in the global dictionary
    dctGlobalInterfaceDictionaryPar["dctAsyncio"]["objAsyncioLoopPar"] = objAsyncioLoopPar  # Now that we have the asyncio loop save it in the global dictionary

    while True:  # main loop
        # For each asyncio tick/loop call the vAsyncioLoopProcess method
        dctGlobalInterfaceDictionaryPar["dctOTT"]["objClsOttManager"].vAsyncioLoopProcess()

        # Check if the MQTT connection is still connected. This is done by getting the result from a publish command.
        # Every time we try to publish the return state is stored in the processing class
        if (objClsMessageProcessForMqtt.bMqttIsConnected() is False):
            logging.error("Disconnected from MQTT broker")
            try:
                objMqttClientPar.reconnect()
                logging.debug("Successfully reconnected to MQTT broker")
                objClsMessageProcessForMqtt.vClearPublishConnectionState()
            except Exception as E:
                logging.error("Could not reconnect to MQTT broker - Exception %s - Sleeping", str(E))
                time.sleep(1)

        # This section processes messages from the mqtt python queue
        # To avoid blocking always first check how many elements are stored in the queue - only get() when something is there
        if (objMqttQueue.qsize() > 0):
            dctObject = objMqttQueue.get()  # get the message from the queue if something is there - get will always return one item at a time

            # To avoid blocking behaviour process the message using a asyncio create_task() call
            objAsyncioLoopPar.create_task(objClsMessageProcessForMqtt.vProcessDictObj(dctObject))

        # This deque stores an ordered list of asyncio methods which must called using the asyncio create_task method
        # First check if the deque is non-empty
        if (objDequeTasksToCreate):
            # Pop one item from the deque - the item will be a tuple with (method, lstMethodParams)
            tplMethodAndParams = objDequeTasksToCreate.pop()
            objAsyncioLoopPar.create_task(tplMethodAndParams[0](tplMethodAndParams[1]))

        # We must always end the while with at least one "await" call. We can use "await asyncio.sleep(0)" but then we use a lot of CPU.
        # We must therefore at least sleep a little bit
        if (objMqttQueue.qsize() > 0):
            await asyncio.sleep(0.002)
        else:
            await asyncio.sleep(0.002)

# ===========================================
# Global functions
# ===========================================


def bValidateIniFileAndSetGlobalDict(dctGlobalInterfaceDictionaryPar: dict):
    """ This is a public function which verifies that all the required INI file sections and fields are there.

    Args:
        dctGlobalInterfaceDictionaryPar (dict): The first parameter. The global interface dictionary.

    Returns:

    Raises:
        Raises no exceptions
    """
    dctStringBoolToBoolLookup = {}
    dctStringBoolToBoolLookup["True"] = bool(True)
    dctStringBoolToBoolLookup["False"] = bool(False)
    objFactoryConfigTomlObject = None
    lstModulesToExclude = []
    lstModulesToInclude = []

    if (dctGlobalInterfaceDictionaryPar is None):
        logging.error("dctGlobalInterfaceDictionaryPar cannot be None")
        sys.exit()

    if (dctGlobalInterfaceDictionaryPar["dctOTT"]["objFactoryConfigTomlObject"] is None):
        logging.error("objFactoryConfigTomlObject")
        sys.exit()

    # Make this local variable to make the text a little shorter
    objFactoryConfigTomlObject = dctGlobalInterfaceDictionaryPar["dctOTT"]["objFactoryConfigTomlObject"]

    # Check that the INI file contains everything we need
    if("MQTT" in objFactoryConfigTomlObject):
        logging.debug("INI file section [MQTT] is present")
    else:
        logging.error("INI file section [MQTT] is missing")
        sys.exit()

    # Check that the INI file contains everything we need
    if ("mosquitto_broker_ip" in objFactoryConfigTomlObject["MQTT"]):
        logging.debug("INI file option mosquitto_broker_ip in section [MQTT] is present")
    else:
        logging.error("INI file option mosquitto_broker_ip in section [MQTT] is missing")
        sys.exit()

    # Check that the INI file contains everything we need
    if ("mosquitto_broker_port" in objFactoryConfigTomlObject["MQTT"]):
        logging.debug("INI file option mosquitto_broker_port in section [MQTT] is present")
    else:
        logging.error("INI file option mosquitto_broker_port in section [MQTT] is missing")
        sys.exit()

    # Check that the INI file contains everything we need
    if ("mosquitto_broker_keepalive" in objFactoryConfigTomlObject["MQTT"]):
        logging.debug("INI file option mosquitto_broker_keepalive in section [MQTT] is present")
    else:
        logging.error("INI file option mosquitto_broker_keepalive in section [MQTT] is missing")
        sys.exit()

    # Now set the MQTT fields in the global dictionary
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["acMosquittoBrokerIp"] = objFactoryConfigTomlObject["MQTT"]["mosquitto_broker_ip"]
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["iMosquittoBrokerPort"] = int(objFactoryConfigTomlObject["MQTT"]["mosquitto_broker_port"])
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["iMosquittoBrokerKeepAliveSec"] = int(objFactoryConfigTomlObject["MQTT"]["mosquitto_broker_keepalive"])

    if("OTT" in objFactoryConfigTomlObject):
        logging.debug("INI file section [OTT] is present")
    else:
        logging.error("INI file section [OTT] is missing")
        sys.exit()

    if ("do_not_send_out_status_messages" in objFactoryConfigTomlObject["OTT"]):
        logging.debug("INI file option do_not_send_out_status_messages in section [OTT] is present")
    else:
        logging.error("INI file option do_not_send_out_status_messages in section [OTT] is missing")
        sys.exit()

    if ("exclude_DR" in objFactoryConfigTomlObject["OTT"]):
        logging.debug("INI file option exclude_DR in section [OTT] is present")
    else:
        logging.error("INI file option exclude_DR in section [OTT] is missing")
        sys.exit()

    if ("exclude_PDBP" in objFactoryConfigTomlObject["OTT"]):
        logging.debug("INI file option exclude_PDBP in section [OTT] is present")
    else:
        logging.error("INI file option exclude_PDBP in section [OTT] is missing")
        sys.exit()

    if ("exclude_EIU" in objFactoryConfigTomlObject["OTT"]):
        logging.debug("INI file option exclude_EIU in section [OTT] is present")
    else:
        logging.error("INI file option exclude_EIU in section [OTT] is missing")
        sys.exit()

    if ("exclude_TM" in objFactoryConfigTomlObject["OTT"]):
        logging.debug("INI file option exclude_TM in section [OTT] is present")
    else:
        logging.error("INI file option exclude_TM in section [OTT] is missing")
        sys.exit()

    if ("exclude_TEWA" in objFactoryConfigTomlObject["OTT"]):
        logging.debug("INI file option exclude_TEWA in section [OTT] is present")
    else:
        logging.error("INI file option exclude_TEWA in section [OTT] is missing")
        sys.exit()

    if ("exclude_SF1" in objFactoryConfigTomlObject["OTT"]):
        logging.debug("INI file option exclude_SF1 in section [OTT] is present")
    else:
        logging.error("INI file option exclude_SF1 in section [OTT] is missing")
        sys.exit()

    if ("exclude_SF2" in objFactoryConfigTomlObject["OTT"]):
        logging.debug("INI file option exclude_SF2 in section [OTT] is present")
    else:
        logging.error("INI file option exclude_SF2 in section [OTT] is missing")
        sys.exit()

    if ("exclude_SF3" in objFactoryConfigTomlObject["OTT"]):
        logging.debug("INI file option exclude_SF3 in section [OTT] is present")
    else:
        logging.error("INI file option exclude_SF3 in section [OTT] is missing")
        sys.exit()

    if ("exclude_HMI_APM" in objFactoryConfigTomlObject["OTT"]):
        logging.debug("INI file option exclude_HMI_APM in section [OTT] is present")
    else:
        logging.error("INI file option exclude_HMI_APM in section [OTT] is missing")
        sys.exit()

    if ("exclude_HMI_APM_FCO" in objFactoryConfigTomlObject["OTT"]):
        logging.debug("INI file option exclude_HMI_APM_FCO in section [OTT] is present")
    else:
        logging.error("INI file option exclude_HMI_APM_FCO in section [OTT] is missing")
        sys.exit()

    if ("exclude_HMI_FCO" in objFactoryConfigTomlObject["OTT"]):
        logging.debug("INI file option exclude_HMI_FCO in section [OTT] is present")
    else:
        logging.error("INI file option exclude_HMI_FCO in section [OTT] is missing")
        sys.exit()

    if ("exclude_HMI_SPM" in objFactoryConfigTomlObject["OTT"]):
        logging.debug("INI file option exclude_HMI_SPM in section [OTT] is present")
    else:
        logging.error("INI file option exclude_HMI_SPM in section [OTT] is missing")
        sys.exit()

    if ("exclude_HMI_SPM_FUFC" in objFactoryConfigTomlObject["OTT"]):
        logging.debug("INI file option exclude_HMI_SPM_FUFC in section [OTT] is present")
    else:
        logging.error("INI file option exclude_HMI_SPM_FUFC in section [OTT] is missing")
        sys.exit()

    if ("exclude_HMI_FUFC" in objFactoryConfigTomlObject["OTT"]):
        logging.debug("INI file option exclude_HMI_FUFC in section [OTT] is present")
    else:
        logging.error("INI file option exclude_HMI_FUFC in section [OTT] is missing")
        sys.exit()

    if ("exclude_HMI_Maintainer" in objFactoryConfigTomlObject["OTT"]):
        logging.debug("INI file option exclude_HMI_Maintainer in section [OTT] is present")
    else:
        logging.error("INI file option exclude_HMI_Maintainer in section [OTT] is missing")
        sys.exit()

    if ("exclude_HMI_Oversight" in objFactoryConfigTomlObject["OTT"]):
        logging.debug("INI file option exclude_HMI_Oversight in section [OTT] is present")
    else:
        logging.error("INI file option exclude_HMI_Oversight in section [OTT] is missing")
        sys.exit()

    dctGlobalInterfaceDictionaryPar["dctOTT"]["bDoNotSendOutStatusMessages"] = objFactoryConfigTomlObject["OTT"]["do_not_send_out_status_messages"]

    if (objFactoryConfigTomlObject["OTT"]["exclude_DR"] is True):
        lstModulesToExclude.append("DR")
    else:
        lstModulesToInclude.append("DR")

    if (objFactoryConfigTomlObject["OTT"]["exclude_PDBP"] is True):
        lstModulesToExclude.append("PDBP")
    else:
        lstModulesToInclude.append("PDBP")

    if (objFactoryConfigTomlObject["OTT"]["exclude_EIU"] is True):
        lstModulesToExclude.append("EIU")
    else:
        lstModulesToInclude.append("EIU")

    if (objFactoryConfigTomlObject["OTT"]["exclude_TM"] is True):
        lstModulesToExclude.append("TM")
    else:
        lstModulesToInclude.append("TM")

    if (objFactoryConfigTomlObject["OTT"]["exclude_TEWA"] is True):
        lstModulesToExclude.append("TEWA")
    else:
        lstModulesToInclude.append("TEWA")

    if (objFactoryConfigTomlObject["OTT"]["exclude_SF1"] is True):
        lstModulesToExclude.append("SF1")
    else:
        lstModulesToInclude.append("SF1")

    if (objFactoryConfigTomlObject["OTT"]["exclude_SF2"] is True):
        lstModulesToExclude.append("SF2")
    else:
        lstModulesToInclude.append("SF2")

    if (objFactoryConfigTomlObject["OTT"]["exclude_SF3"] is True):
        lstModulesToExclude.append("SF3")
    else:
        lstModulesToInclude.append("SF3")

    if (objFactoryConfigTomlObject["OTT"]["exclude_HMI_APM"] is True):
        lstModulesToExclude.append("HMI_APM")
    else:
        lstModulesToInclude.append("HMI_APM")

    if (objFactoryConfigTomlObject["OTT"]["exclude_HMI_APM_FCO"] is True):
        lstModulesToExclude.append("HMI_APM_FCO")
    else:
        lstModulesToInclude.append("HMI_APM_FCO")

    if (objFactoryConfigTomlObject["OTT"]["exclude_HMI_FCO"] is True):
        lstModulesToExclude.append("HMI_FCO")
    else:
        lstModulesToInclude.append("HMI_FCO")

    if (objFactoryConfigTomlObject["OTT"]["exclude_HMI_SPM"] is True):
        lstModulesToExclude.append("HMI_SPM")
    else:
        lstModulesToInclude.append("HMI_SPM")

    if (objFactoryConfigTomlObject["OTT"]["exclude_HMI_SPM_FUFC"] is True):
        lstModulesToExclude.append("HMI_SPM_FUFC")
    else:
        lstModulesToInclude.append("HMI_SPM_FUFC")

    if (objFactoryConfigTomlObject["OTT"]["exclude_HMI_FUFC"] is True):
        lstModulesToExclude.append("HMI_FUFC")
    else:
        lstModulesToInclude.append("HMI_FUFC")

    if (objFactoryConfigTomlObject["OTT"]["exclude_HMI_Maintainer"] is True):
        lstModulesToExclude.append("HMI_Maintainer")
    else:
        lstModulesToInclude.append("HMI_Maintainer")

    if (objFactoryConfigTomlObject["OTT"]["exclude_HMI_Oversight"] is True):
        lstModulesToExclude.append("HMI_Oversight")
    else:
        lstModulesToInclude.append("HMI_Oversight")

    dctGlobalInterfaceDictionaryPar["dctOTT"]["lstModulesToExclude"] = lstModulesToExclude
    dctGlobalInterfaceDictionaryPar["dctOTT"]["lstModulesToInclude"] = lstModulesToInclude

    if("Debug" in objFactoryConfigTomlObject):
        logging.info("INI file section [Debug] is present")

        # Check that the INI file contains everything we need
        if ("log_level" in objFactoryConfigTomlObject["Debug"]):
            logging.info("INI file option log_level in section [Debug] is present")

            dctGlobalInterfaceDictionaryPar["dctOTT"]["acLogLevel"] = objFactoryConfigTomlObject["Debug"]["log_level"]

    return(True)


def vCheckIfFilesAndDirectoriesExist(dctGlobalInterfaceDictionaryPar: dict):
    """ This is a public function which checks if mandatory directories and files exists.

    Args:
        dctGlobalInterfaceDictionaryPar (dict): The first parameter. The global interface dictionary.

    Returns:

    Raises:
        Raises no exceptions
    """

    dctGlobalInterfaceDictionaryPar["dctOTT"]["acFactoryConfigAbsolutePath"] = os.path.join(dctGlobalInterfaceDictionaryPar["dctOTT"]["acCurrentDirectory"], dctGlobalInterfaceDictionaryPar["dctOTT"]["objArgs"].i)
    logging.debug("The full path of the INI file is %s", dctGlobalInterfaceDictionaryPar["dctOTT"]["acFactoryConfigAbsolutePath"])

    # Verify if the INI file exists
    if (os.path.exists(dctGlobalInterfaceDictionaryPar["dctOTT"]["acFactoryConfigAbsolutePath"]) is False):
        logging.error("Cannot open INI file - exit now")
        sys.exit()

    return


def vInitialiseGlobalDictionarySkeleton(dctGlobalInterfaceDictionaryPar: dict):
    """ This is a public function which sets up the global dictionary skeleton. This will not set up complex instances of classes because it might be
    premature given the design of the code.

    Args:
        dctGlobalInterfaceDictionaryPar (dict): The first parameter. The global interface dictionary.

    Returns:

    Raises:
        Raises no exceptions
    """

    # Things related to MQTT
    dctGlobalInterfaceDictionaryPar["dctMqtt"] = {}
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["objQueue"] = None  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["acMosquittoBrokerIp"] = ""  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["iMosquittoBrokerPort"] = ""  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["iMosquittoBrokerKeepAliveSec"] = ""  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["acMqttId"] = ""  # Will be set later
    # This is the main message received dictionary for mqtt. It must be defined and passed in because it is integral to the auto generated code.
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["dctMessagesMqtt"] = {}  # This is the main dictionary into which all received MQTT messages will be stored - it will start empty
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["objClsMessageProcessForMqtt"] = None  # Will be assigned later - it's base class will use ["dctMessagesMqtt"]
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["objMqttClientPar"] = None  # Will be assigned later when the client is connected
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["lstTasksAllowedForsimultaneousExecution"] = []  # This list starts empty - it isn't normally used

    # Things related to OTT state
    dctGlobalInterfaceDictionaryPar["dctOTT"] = {}
    dctGlobalInterfaceDictionaryPar["dctOTT"]["objConfigParser"] = None   # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOTT"]["objArgs"] = None  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOTT"]["iVersionMajor"] = int(0)  # The OTT unit major version number
    dctGlobalInterfaceDictionaryPar["dctOTT"]["iVersionMinor"] = int(1)  # The OTT unit minor version number
    dctGlobalInterfaceDictionaryPar["dctOTT"]["iVersionInternal"] = int(4)  # The OTT unit internal version number
    dctGlobalInterfaceDictionaryPar["dctOTT"]["acGitRepoHash"] = str("")  # This will be filled in when the read the text file containing the hash as text
    dctGlobalInterfaceDictionaryPar["dctOTT"]["acPartNumber"] = str("5840-BR-1803")  # The OTT part number
    dctGlobalInterfaceDictionaryPar["dctOTT"]["bDebugMode"] = bool(False)
    dctGlobalInterfaceDictionaryPar["dctOTT"]["acLogLevel"] = "INFO"
    dctGlobalInterfaceDictionaryPar["dctOTT"]["bDoNotSendOutStatusMessages"] = bool(False)  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOTT"]["lstModulesToExclude"] = []  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOTT"]["lstModulesToInclude"] = []  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOTT"]["objClsOttManager"] = None  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOTT"]["objClsOttTransitionsManager"] = None  # Will be set later

    dctGlobalInterfaceDictionaryPar["dctOTT"]["objClsOttLauncherManager"] = None  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOTT"]["objClsOttConstructSystemStatus"] = None  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOTT"]["acCurrentDirectory"] = ""  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOTT"]["acIniFileAbsolutePath"] = ""  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOTT"]["objDequeAsyncioTasksToBeCreated"] = deque(maxlen=20)  # This is a FIFO for storing tasks which must be created usign asyncio loop
    dctGlobalInterfaceDictionaryPar["dctOTT"]["acFactoryConfigAbsolutePath"] = str("")
    dctGlobalInterfaceDictionaryPar["dctOTT"]["objFactoryConfigTomlObject"] = None
    dctGlobalInterfaceDictionaryPar["dctOTT"]["acFactoryConfigFileContents"] = str("")

    # Group together some OTT BIT which is to be displayed on the HMI BIT tree
    dctGlobalInterfaceDictionaryPar["dctOTT"]["dctOTTBIT"] = {}

    # Things related to Asyncio
    dctGlobalInterfaceDictionaryPar["dctAsyncio"] = {}
    dctGlobalInterfaceDictionaryPar["dctAsyncio"]["objAsyncioLoopPar"] = None  # Will be set later

    # SUBUNITS - List According To Importance
    # SUBUNITS - List According To Importance
    # SUBUNITS - List According To Importance
    dctGlobalInterfaceDictionaryPar["dctSubUnits"] = {}

    # Things related to subunits - TEWA
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTEWA"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTEWA"]["acLRUName"] = str("TEWA")

    # Things related to subunits - DR
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctDR"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctDR"]["acLRUName"] = str("DR")

    # Things related to subunits - PDBP
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctPDBP"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctPDBP"]["acLRUName"] = str("PDBP")

    # Things related to subunits - EIU
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctEIU"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctEIU"]["acLRUName"] = str("EIU")

    # Things related to subunits - TM
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTM"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTM"]["acLRUName"] = str("TM")

    # Things related to subunits - SF1
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF1"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF1"]["acLRUName"] = str("SF1")

    # Things related to subunits - SF2
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF2"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF2"]["acLRUName"] = str("SF2")

    # Things related to subunits - SF3
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF3"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF3"]["acLRUName"] = str("SF3")

    # Things related to subunits - HMI_APM
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPM"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPM"]["acLRUName"] = str("HMI_APM")

    # Things related to subunits - HMI_APM_FCO
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPMFCO"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPMFCO"]["acLRUName"] = str("HMI_APM_FCO")

    # Things related to subunits - HMI_FCO
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFCO"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFCO"]["acLRUName"] = str("HMI_FCO")

    # Things related to subunits - HMI_SPM
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPM"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPM"]["acLRUName"] = str("HMI_SPM")

    # Things related to subunits - HMI_SPM_FUFC
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPMFUFC"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPMFUFC"]["acLRUName"] = str("HMI_SPM_FUFC")

    # Things related to subunits - HMI_FUFC
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFUFC"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFUFC"]["acLRUName"] = str("HMI_FUFC")

    # Things related to subunits - HMI_Maintainer
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIMaintainer"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIMaintainer"]["acLRUName"] = str("HMI_Maintainer")

    # Things related to subunits - HMI_Oversight
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIOversight"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIOversight"]["acLRUName"] = str("HMI_Oversight")

    # Things related to subunits - OLHM
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctOLHM"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctOLHM"]["acLRUName"] = str("OLHM")

    # Iterate through all the subunits and set additional keys with values
    iCounter = int(0)
    for _, dctSubUnit in dctGlobalInterfaceDictionaryPar["dctSubUnits"].items():
        dctSubUnit["objsSTATUSREQRSP"] = None  # Store the StatusReqRsp in here
        dctSubUnit["objClsProcessMessages"] = None  # Will be set later
        dctSubUnit["fTimeoutPeriodS"] = float(3.0)
        dctSubUnit["dctSubUnits"] = {}
        iCounter = iCounter + 1

    # DR
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctDR"]["objsSTATUSREPORTUNSOL"] = sDR_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctDR"]["objClsDrTransitionsManager"] = clsDrTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctDR"]["objClsProcessMessages"] = clsDrProcessMessages(dctGlobalInterfaceDictionaryPar)

    # PDBP
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctPDBP"]["objsSTATUSREPORTUNSOL"] = sPDBP_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctPDBP"]["objClsPdbpTransitionsManager"] = clsPdbpTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctPDBP"]["objClsProcessMessages"] = clsPdbpProcessMessages(dctGlobalInterfaceDictionaryPar)

    # EIU
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctEIU"]["objsSTATUSREPORTUNSOL"] = sEIU_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctEIU"]["objClsEiuTransitionsManager"] = clsEiuTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctEIU"]["objClsProcessMessages"] = clsEiuProcessMessages(dctGlobalInterfaceDictionaryPar)

    # TM
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTM"]["objsSTATUSREPORTUNSOL"] = sTM_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTM"]["objClsTmTransitionsManager"] = clsTmTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTM"]["objClsProcessMessages"] = clsTmProcessMessages(dctGlobalInterfaceDictionaryPar)

    # TEWA
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTEWA"]["objsSTATUSREPORTUNSOL"] = sTEWA_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTEWA"]["objClsTewaTransitionsManager"] = clsTewaTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTEWA"]["objClsProcessMessages"] = clsTewaProcessMessages(dctGlobalInterfaceDictionaryPar)

    # SF1
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF1"]["objsSTATUSREPORTUNSOL"] = sSF1_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF1"]["objClsSf1TransitionsManager"] = clsSf1TransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF1"]["objClsProcessMessages"] = clsSf1ProcessMessages(dctGlobalInterfaceDictionaryPar)

    # SF2
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF2"]["objsSTATUSREPORTUNSOL"] = sSF2_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF2"]["objClsSf2TransitionsManager"] = clsSf2TransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF2"]["objClsProcessMessages"] = clsSf2ProcessMessages(dctGlobalInterfaceDictionaryPar)

    # SF3
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF3"]["objsSTATUSREPORTUNSOL"] = sSF3_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF3"]["objClsSf3TransitionsManager"] = clsSf3TransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF3"]["objClsProcessMessages"] = clsSf3ProcessMessages(dctGlobalInterfaceDictionaryPar)

    # HMI_APM
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPM"]["objsSTATUSREPORTUNSOL"] = sHMI_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPM"]["objClsHmiApmTransitionsManager"] = clsHmiApmTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPM"]["objClsProcessMessages"] = clsHmiApmProcessMessages(dctGlobalInterfaceDictionaryPar)

    # HMI_APM_FCO
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPMFCO"]["objsSTATUSREPORTUNSOL"] = sHMI_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"] = clsHmiApmFcoTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPMFCO"]["objClsProcessMessages"] = clsHmiApmFcoProcessMessages(dctGlobalInterfaceDictionaryPar)

    # HMI_FCO
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFCO"]["objsSTATUSREPORTUNSOL"] = sHMI_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFCO"]["objClsHmiFcoTransitionsManager"] = clsHmiFcoTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFCO"]["objClsProcessMessages"] = clsHmiFcoProcessMessages(dctGlobalInterfaceDictionaryPar)

    # HMI_SPM
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPM"]["objsSTATUSREPORTUNSOL"] = sHMI_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPM"]["objClsHmiSpmTransitionsManager"] = clsHmiSpmTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPM"]["objClsProcessMessages"] = clsHmiSpmProcessMessages(dctGlobalInterfaceDictionaryPar)

    # HMI_SPM_FUFC
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPMFUFC"]["objsSTATUSREPORTUNSOL"] = sHMI_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"] = clsHmiSpmFufcTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPMFUFC"]["objClsProcessMessages"] = clsHmiSpmFufcProcessMessages(dctGlobalInterfaceDictionaryPar)

    # HMI_FUFC
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFUFC"]["objsSTATUSREPORTUNSOL"] = sHMI_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"] = clsHmiFufcTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFUFC"]["objClsProcessMessages"] = clsHmiFufcProcessMessages(dctGlobalInterfaceDictionaryPar)

    # HMI_Maintainer
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIMaintainer"]["objsSTATUSREPORTUNSOL"] = sHMI_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"] = clsHmiMaintainerTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIMaintainer"]["objClsProcessMessages"] = clsHmiMaintainerProcessMessages(dctGlobalInterfaceDictionaryPar)

    # HMI_Oversight
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIOversight"]["objsSTATUSREPORTUNSOL"] = sHMI_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIOversight"]["objClsHmiOversightTransitionsManager"] = clsHmiOversightTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIOversight"]["objClsProcessMessages"] = clsHmiOversightProcessMessages(dctGlobalInterfaceDictionaryPar)

    # OLHM
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctOLHM"]["objsOLHM_ADCS_STATUS_UNSOL"] = sOLHM_ADCS_HMI_STATUS_UNSOL()

    return


def vInitialiseGlobalDictionaryAdvancedItems(dctGlobalInterfaceDictionaryPar: dict):
    """ This is a public function which sets up the global dictionary. This does not set up the skeleton!
    We only set things like instances of classes which needed to be delayed for some reason.

    Args:
        dctGlobalInterfaceDictionaryPar (dict): The first parameter. The global interface dictionary.

    Returns:

    Raises:
        Raises no exceptions
    """

    # Store an instance of the OLHM manager
    dctGlobalInterfaceDictionaryPar["dctOTT"]["objClsOttManager"] = clsOttManager(dctGlobalInterfaceDictionaryPar)
    # dctGlobalInterfaceDictionaryPar["dctOTT"]["objClsOttTransitionsManager"] = clsOttTransitionsManager(dctGlobalInterfaceDictionaryPar)
    dctGlobalInterfaceDictionaryPar["dctOTT"]["objClsOttLauncherManager"] = clsOttLauncherManager(dctGlobalInterfaceDictionaryPar)
    dctGlobalInterfaceDictionaryPar["dctOTT"]["objClsOttLauncherManager"].vGetGitHash()

    # dctGlobalInterfaceDictionaryPar["dctOTT"]["objClsOttConstructSystemStatus"] = clsOttConstructSystemStatus(dctGlobalInterfaceDictionaryPar)

    return


def vGetGitRepoHash(dctGlobalInterfaceDictionaryPar: dict):
    """ This is a public function which read a text file in the OLHM source directory which contains the 
    git repo hash as a text string. Shell script get_git_repo_hash.sh is responsible for creating the
    file we want to read here.

    Args:
        dctGlobalInterfaceDictionaryPar (dict): The first parameter. The global interface dictionary.

    Returns:

    Raises:
        Raises no exceptions
    """
    bGitRepoHashFileExists = bool(False)
    bContinue = bool(False)
    objFileHandler = None
    acFileRawData = None
    acGitRepoHashFilename = "./git_repo_hash.txt"  # This is the file which will contain the git repo hash

    # First verify that the file with the git hash in it exists
    try:
        bGitRepoHashFileExists = os.path.isfile(acGitRepoHashFilename)
    except Exception as E:
        return

    if (bGitRepoHashFileExists is False):
        logging.error("File git_repo_hash.txt does not exist")
        return

    # Try to open the file
    bContinue = bool(False)
    try:
        objFileHandler = open(acGitRepoHashFilename, "r")
        bContinue = True
    except Exception as E:
        logging.error("Could not open file %s", acGitRepoHashFilename)
        return

    if (objFileHandler is None):
        return

    if (bContinue is False):
        return

    bContinue = bool(False)
    try:
        acFileRawData = objFileHandler.read()
        bContinue = True
    except Exception as E:
        logging.error("Could not read file")

    # Check that the data we read is valid
    if ((bContinue is True) and (isinstance(acFileRawData, str) is True) and (acFileRawData)):
        # Strip possible newlines from the string
        acFileRawData = acFileRawData.rstrip()
        # Save the hash back into the global dictionary
        dctGlobalInterfaceDictionaryPar["dctOTT"]["acGitRepoHash"] = acFileRawData

        logging.info("GIT repo hash is %s", acFileRawData)

    if (objFileHandler is not None):
        try:
            objFileHandler.close()
        except Exception as E:
            logging.error("Could not close file")

    return


def vModuleMain():
    """ This is a public function which is called when the global name is __main__. The entire Pythom module is kicked off using this
    method.

    Args:

    Returns:

    Raises:
        Raises no exceptions
    """

    C_I_MAX_MESSAGE_QUEUE_SIZE = int(10000)  # This value is used later to construct the python queue
    dctGlobalInterfaceDictionary = {}
    objDateTimeUtc = clsDatetimeUtilities.objGetUtcCurrentDatetime()

    objQueue = queue.Queue(C_I_MAX_MESSAGE_QUEUE_SIZE)  # Create a python queue to pass to the mqtt template

    # Before we do anything else first see if there is already an existing instance of myself running
    if (clsProcessMonitoringAndManagement.bSendSignalToSpecifiedCommandLine(["python3.6", "olhm.py"], signal.SIGTERM, os.getpid()) is True):
        print("Please wait while I terminate another instance of myself already running")
        time.sleep(1)

    # For argparse arguments
    # -> -i PATH                     The path of the ini file (REQUIRED)
    # -> -t                          Run the unit tests and exit (OPTIONAL)
    # -> -h                          Show the argparse help (OPTIONAL)

    # Make an instance of a argeparse to help us manage command line arguments
    objArgParser = argparse.ArgumentParser()
    objArgParser.add_argument("-i", required=True, help="The INI file path")  # We must supply a INI file path
    args = objArgParser.parse_args()  # Parse the args and make sure we have everything we need

    # Immediately start the logger
    # We log datetime, filename, line number and message
    # Open the file in append mode so that we don't lose the history

    objClsLoggerManager = clsLoggingManager()
    objClsLoggerManager.vConfigureLogger(acFilenamePar="../OTT_Logs/logging.log", acModuleNamePar="OTT")
    objRootLogger = objClsLoggerManager.objGetLoggerInstance()
    objRootLogger.setLevel(logging.INFO)

    # Indicate that the logging has started
    logging.info("======================================================")
    logging.info("= OLHM TEST TOOL                                     =")
    logging.info("======================================================")

    # Build up the global dictionary after getting the logger up
    # Note!!! this will only set up a basic skeleton
    vInitialiseGlobalDictionarySkeleton(dctGlobalInterfaceDictionary)

    dctGlobalInterfaceDictionary["dctMqtt"]["objQueue"] = objQueue  # Now store the Python Queue in the global dictionary
    dctGlobalInterfaceDictionary["dctOTT"]["objArgs"] = args  # Save the args

    # Build up the client name as a combination of the filename, OTT interface version number and the PID
    dctGlobalInterfaceDictionary["dctMqtt"]["acMqttId"] = os.path.basename(__file__) + ":V:" + str(dctGlobalInterfaceDictionary["dctOTT"]["iVersionMajor"]) + "." + str(dctGlobalInterfaceDictionary["dctOTT"]["iVersionMinor"]) + "." + str(dctGlobalInterfaceDictionary["dctOTT"]["iVersionInternal"]) + ":PID:" + str(os.getpid())

    logging.info("OLHM version is %d.%d.%d ", dctGlobalInterfaceDictionary["dctOTT"]["iVersionMajor"], dctGlobalInterfaceDictionary["dctOTT"]["iVersionMinor"], dctGlobalInterfaceDictionary["dctOTT"]["iVersionInternal"])
    logging.info("Startup UTC date and time is %s", str(objDateTimeUtc))

    logging.debug("Python version is [major] %d ", sys.version_info[0])
    logging.debug("Python version is [minor] %d ", sys.version_info[1])
    logging.debug("MQTT client name is %s", dctGlobalInterfaceDictionary["dctMqtt"]["acMqttId"])

    if ((float(sys.version_info[0]) + (float(sys.version_info[1]) / 10.0)) < 3.6):
        logging.error("Python version must be 3.6 or higher")
        sys.exit()

    logging.debug("This platform is %s", sys.platform)

    # Get the current directory
    acCurrentDirectory = os.getcwd()
    logging.debug("The current directory is %s", str(acCurrentDirectory))

    dctGlobalInterfaceDictionary["dctOTT"]["acCurrentDirectory"] = acCurrentDirectory

    vCheckIfFilesAndDirectoriesExist(dctGlobalInterfaceDictionary)

    # Read the container config file
    try:
        objFileObjectFactoryConfig = open(dctGlobalInterfaceDictionary["dctOTT"]["acFactoryConfigAbsolutePath"], 'r')
        dctGlobalInterfaceDictionary["dctOTT"]["acFactoryConfigFileContents"] = objFileObjectFactoryConfig.read()
        dctGlobalInterfaceDictionary["dctOTT"]["objFactoryConfigTomlObject"] = toml.loads(dctGlobalInterfaceDictionary["dctOTT"]["acFactoryConfigFileContents"])
        logging.debug("INI file read successfully")
    except Exception as E:
        logging.error("Could not read and parse INI file - Exception %s", str(E))
        sys.exit()

    # Try to close the container config file
    if (objFileObjectFactoryConfig is not None):
        try:
            objFileObjectFactoryConfig.close()
        except Exception as E:
            logging.error("Could not close file %s", dctGlobalInterfaceDictionary["dctOLHM"]["acFactoryConfigAbsolutePath"])

    # Go through the entire INI file and check it for validity. Also set the global dictionary with the values in the INI file
    if (bValidateIniFileAndSetGlobalDict(dctGlobalInterfaceDictionary) is False):
        logging.error("OLHM INI file validation failed - exit now")
        sys.exit()

    if (dctGlobalInterfaceDictionary["dctOTT"]["acLogLevel"] == "NOTSET"):
        objRootLogger.setLevel(logging.NOTSET)
    elif (dctGlobalInterfaceDictionary["dctOTT"]["acLogLevel"] == "DEBUG"):
        objRootLogger.setLevel(logging.DEBUG)
    elif (dctGlobalInterfaceDictionary["dctOTT"]["acLogLevel"] == "INFO"):
        objRootLogger.setLevel(logging.INFO)
    elif (dctGlobalInterfaceDictionary["dctOTT"]["acLogLevel"] == "WARNING"):
        objRootLogger.setLevel(logging.WARNING)
    elif (dctGlobalInterfaceDictionary["dctOTT"]["acLogLevel"] == "ERROR"):
        objRootLogger.setLevel(logging.ERROR)
    elif (dctGlobalInterfaceDictionary["dctOTT"]["acLogLevel"] == "CRITICAL"):
        objRootLogger.setLevel(logging.CRITICAL)

    # Now that the INI file has been read, validated and more global dictionary items set, we can
    # now proceed and create instances of certain classes which needed some information from the INI file.
    vInitialiseGlobalDictionaryAdvancedItems(dctGlobalInterfaceDictionary)

    client = mqtt.Client(client_id=dctGlobalInterfaceDictionary["dctMqtt"]["acMqttId"])  # Make an instance of a MQTT client
    objClsOttMqttAutogenHandler = clsOttMqttAutogenHandler(objQueue, [])    # Pass the queue on to the template so that messages can be sent back to the main thread
    client.on_connect = objClsOttMqttAutogenHandler.vOnConnect

    # Save the mqtt client object in the global dictionry
    dctGlobalInterfaceDictionary["dctMqtt"]["objMqttClientPar"] = client

    while True:
        try:
            client.connect(dctGlobalInterfaceDictionary["dctMqtt"]["acMosquittoBrokerIp"],
                           dctGlobalInterfaceDictionary["dctMqtt"]["iMosquittoBrokerPort"],
                           dctGlobalInterfaceDictionary["dctMqtt"]["iMosquittoBrokerKeepAliveSec"])
            logging.info("Connected to MQTT broker IP %s on port %d with keep alive as %d", dctGlobalInterfaceDictionary["dctMqtt"]["acMosquittoBrokerIp"], dctGlobalInterfaceDictionary["dctMqtt"]["iMosquittoBrokerPort"], dctGlobalInterfaceDictionary["dctMqtt"]["iMosquittoBrokerKeepAliveSec"])
            break
        except Exception as E:
            logging.error("Could not connect to the mosquitto broker - Exception %s - Retrying", str(E))
            time.sleep(1)

    try:
        client.loop_start()
        logging.debug("MQTT loop_start")
    except Exception as E:
        logging.error(str(E))

    objAsyncioLoop = None  # First declare the loop instance as None

    # Read the file created by the shell script which saves the git repo hash in a text file
    vGetGitRepoHash(dctGlobalInterfaceDictionary)

    try:
        # Get the asyncio event loop instance
        objAsyncioLoop = asyncio.get_event_loop()
    except Exception as E:
        logging.error(str(E))
        objAsyncioLoop = None

    if (objAsyncioLoop is not None):
        objAsyncioLoop.run_until_complete(main(objAsyncioLoop, client, dctGlobalInterfaceDictionary))

    logging.info("Exiting %s", dctGlobalInterfaceDictionary["dctMqtt"]["acMqttId"])


# ===========================================
# Module "__main__" function
# ===========================================


if __name__ == "__main__":
    vModuleMain()
