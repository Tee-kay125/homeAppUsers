#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which processes messages received

This module provides a class which processes messages received. This class will inherit
autogen class clsMessageProcess from message_processing.py

Todo:

"""
import sys
import os
import logging
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
from External_Interfaces.OTT.asyncio_msg_processing_class_ott import clsAsyncioMsgProcessingClassOtt
from External_Interfaces.DR.asyncio_msg_processing_class_dr import clsMessageProcessForMqttDr
from External_Interfaces.PDBP.asyncio_msg_processing_class_pdbp import clsMessageProcessForMqttPdbp
from External_Interfaces.EIU.asyncio_msg_processing_class_eiu import clsMessageProcessForMqttEiu
from External_Interfaces.TM.asyncio_msg_processing_class_tm import clsMessageProcessForMqttTm
from External_Interfaces.TEWA.asyncio_msg_processing_class_tewa import clsMessageProcessForMqttTewa
from External_Interfaces.SF1.asyncio_msg_processing_class_sf1 import clsMessageProcessForMqttSf1
from External_Interfaces.SF2.asyncio_msg_processing_class_sf2 import clsMessageProcessForMqttSf2
from External_Interfaces.SF3.asyncio_msg_processing_class_sf3 import clsMessageProcessForMqttSf3
from External_Interfaces.HMI_APM.asyncio_msg_processing_class_hmi_apm import clsMessageProcessForMqttHmiApm
from External_Interfaces.HMI_APM_FCO.asyncio_msg_processing_class_hmi_apm_fco import clsMessageProcessForMqttHmiApmFco
from External_Interfaces.HMI_FCO.asyncio_msg_processing_class_hmi_fco import clsMessageProcessForMqttHmiFco
from External_Interfaces.HMI_SPM.asyncio_msg_processing_class_hmi_spm import clsMessageProcessForMqttHmiSpm
from External_Interfaces.HMI_SPM_FUFC.asyncio_msg_processing_class_hmi_spm_fufc import clsMessageProcessForMqttHmiSpmFufc
from External_Interfaces.HMI_FUFC.asyncio_msg_processing_class_hmi_fufc import clsMessageProcessForMqttHmiFufc
from External_Interfaces.HMI_Maintainer.asyncio_msg_processing_class_hmi_maintainer import clsMessageProcessForMqttHmiMaintainer
from External_Interfaces.HMI_Oversight.asyncio_msg_processing_class_hmi_oversight import clsMessageProcessForMqttHmiOversight
from External_Interfaces.OLHM.asyncio_msg_processing_class_olhm import clsMessageProcessForMqttOlhm
from External_Interfaces.MMS.asyncio_msg_processing_class_mms import clsMessageProcessForMqttMms

from python_toolbox.Autogen_Utilities.asyncio_utilities import clsAsyncioUtilities
from python_toolbox.Autogen_Utilities.mqtt_spy_utilities import clsMqttSpyUtilities

from Autogen.dr_msg import sDR_STATUS_REPORT_UNSOL
from Autogen.dr_msg import sDR_END_OF_SETUP_CMD_RSP
from Autogen.dr_msg import sDR_END_OF_READY_CMD_RSP
from Autogen.dr_msg import sDR_SHUTDOWN_CMD_RSP

from Autogen.pdbp_msg import sPDBP_STATUS_REPORT_UNSOL
from Autogen.pdbp_msg import sPDBP_END_OF_READY_CMD_RSP
from Autogen.pdbp_msg import sPDBP_SHUTDOWN_CMD_RSP
from Autogen.pdbp_msg import sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP

from Autogen.eiu_msg import sEIU_STATUS_REPORT_UNSOL
from Autogen.eiu_msg import sEIU_END_OF_SETUP_CMD_RSP
from Autogen.eiu_msg import sEIU_END_OF_READY_CMD_RSP
from Autogen.eiu_msg import sEIU_SHUTDOWN_CMD_RSP

from Autogen.tm_msg import sTM_STATUS_REPORT_UNSOL
from Autogen.tm_msg import sTM_END_OF_SETUP_CMD_RSP
from Autogen.tm_msg import sTM_END_OF_READY_CMD_RSP
from Autogen.tm_msg import sTM_SHUTDOWN_CMD_RSP

from Autogen.tewa_msg import sTEWA_STATUS_REPORT_UNSOL
from Autogen.tewa_msg import sTEWA_END_OF_SETUP_CMD_RSP
from Autogen.tewa_msg import sTEWA_END_OF_READY_CMD_RSP
from Autogen.tewa_msg import sTEWA_SHUTDOWN_CMD_RSP

from Autogen.sf1_msg import sSF1_STATUS_REPORT_UNSOL
from Autogen.sf1_msg import sSF1_END_OF_SETUP_CMD_RSP
from Autogen.sf1_msg import sSF1_END_OF_READY_CMD_RSP
from Autogen.sf1_msg import sSF1_SHUTDOWN_CMD_RSP
from Autogen.sf1_msg import sSF1_MODE_CMD

from Autogen.sf2_msg import sSF2_STATUS_REPORT_UNSOL
from Autogen.sf2_msg import sSF2_END_OF_SETUP_CMD_RSP
from Autogen.sf2_msg import sSF2_END_OF_READY_CMD_RSP
from Autogen.sf2_msg import sSF2_SHUTDOWN_CMD_RSP

from Autogen.sf3_msg import sSF3_STATUS_REPORT_UNSOL
from Autogen.sf3_msg import sSF3_END_OF_SETUP_CMD_RSP
from Autogen.sf3_msg import sSF3_END_OF_READY_CMD_RSP
from Autogen.sf3_msg import sSF3_SHUTDOWN_CMD_RSP

from Autogen.hmi_msg import sHMI_STATUS_REPORT_UNSOL
from Autogen.hmi_msg import sHMI_END_OF_SETUP_CMD_RSP
from Autogen.hmi_msg import sHMI_END_OF_READY_CMD_RSP
from Autogen.hmi_msg import sHMI_SHUTDOWN_CMD_RSP
from Autogen.hmi_msg import sHMI_SHUTDOWN_UNSOL
from Autogen.hmi_msg import sHMI_ADCS_SHUTDOWN_CMD

from Autogen.mms_msg import sMMS_SHUTDOWN_CMD

from Autogen.olhm_msg import sOLHM_ADCS_SHUTDOWN_CMD

from Autogen.dsf_msg import sADCS_CONSOLIDATED_ADCM_UNSOL


# Note!!! In this list of multiple inheritance the clsAsyncioMsgProcessingClassOtt one must be last in the list!!! This is because it will call the autogen base class constructor which takes less agruments
class clsMessageProcessForMqtt(clsAsyncioUtilities, clsMessageProcessForMqttDr, clsMessageProcessForMqttPdbp, clsMessageProcessForMqttEiu, clsMessageProcessForMqttTm, clsMessageProcessForMqttTewa, clsMessageProcessForMqttSf1, clsMessageProcessForMqttSf2, clsMessageProcessForMqttSf3, clsMessageProcessForMqttHmiApm, clsMessageProcessForMqttHmiApmFco, clsMessageProcessForMqttHmiFco, clsMessageProcessForMqttHmiSpm, clsMessageProcessForMqttHmiSpmFufc, clsMessageProcessForMqttHmiFufc, clsMessageProcessForMqttHmiMaintainer, clsMessageProcessForMqttHmiOversight, clsMessageProcessForMqttOlhm, clsMessageProcessForMqttMms, clsAsyncioMsgProcessingClassOtt):
    """ This is the message processing class

    This is the message processing class. It inherits clsMessageProcess.

    Args:
        objMqttClientPar (mqtt.Client): The first parameter. The instance of the MQTT client
        dctMessagesPar (dict): The second parameter. A dictionary containing all messages and futures for messages which were automatically processed by the autogen. This must be passed in for the autogen base class.
        objAsyncioLoopPar (object): The fourth parameter. The asyncio loop passed in so tasks can be created and for other asyncio functionality
        dctMessagesFromIffPar (dict): The fifth parameter. A dictionary with messages from the IFF.
        dctGlobalInterfaceDictionaryPar (dict): The sixth parameter. The interface's global dictionary.
        bLoggingEnabledPar (bool): The seventh parameter. A boolean flag indicating if logging should be done or not.
    """
    def __init__(self, objMqttClientPar: mqtt.Client, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar: bool = True):
        # Very important!!! The MRO (method resolution order) will not yet call the autogen base because it isn't last in the list of inheritance - therefore pass more parameter than used for the base class
        super(clsMessageProcessForMqtt, self).__init__(objMqttClientPar, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar)
        self._objMqttClient = objMqttClientPar
        self._dctMessages = dctMessagesPar
        # By default tasks are not allowed to run simultaneously for the same topic. To override just for example -> lstTasksAllowedForsimultaneousExecutionMqtt += ["ADCS/DR/DrStatusReportUnsol"]
        # This is a list of tasks which are allowed to have simultaneous execution for mqtt
        # Make the list empty for now - no simultaneous execution is allowed
        self._lstTasksAllowedForsimultaneousExecution = []
        self._dctReverseLookupClassNameToTopic = {}
        self._objAsyncioLoop = objAsyncioLoopPar
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar
        self._bLoggingEnabled = bLoggingEnabledPar

        self.bGenerateReverseTopicLookupDictionary()

        self.vGenerateMqttSpyJavaScriptFileForGroup()

        self._dctMessageCounters = {}
        # DR
        self._dctMessageCounters[(type(sDR_STATUS_REPORT_UNSOL()), "")] = int(0)
        self._dctMessageCounters[(type(sDR_END_OF_SETUP_CMD_RSP()), "")] = int(0)
        self._dctMessageCounters[(type(sDR_END_OF_READY_CMD_RSP()), "")] = int(0)
        self._dctMessageCounters[(type(sDR_SHUTDOWN_CMD_RSP()), "")] = int(0)
        # PDBP
        self._dctMessageCounters[(type(sPDBP_STATUS_REPORT_UNSOL()), "")] = int(0)
        self._dctMessageCounters[(type(sPDBP_END_OF_READY_CMD_RSP()), "")] = int(0)
        self._dctMessageCounters[(type(sPDBP_SHUTDOWN_CMD_RSP()), "")] = int(0)
        self._dctMessageCounters[(type(sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP()), "")] = int(0)
        # EIU
        self._dctMessageCounters[(type(sEIU_STATUS_REPORT_UNSOL()), "")] = int(0)
        self._dctMessageCounters[(type(sEIU_END_OF_SETUP_CMD_RSP()), "")] = int(0)
        self._dctMessageCounters[(type(sEIU_END_OF_READY_CMD_RSP()), "")] = int(0)
        self._dctMessageCounters[(type(sEIU_SHUTDOWN_CMD_RSP()), "")] = int(0)
        # TM
        self._dctMessageCounters[(type(sTM_STATUS_REPORT_UNSOL()), "")] = int(0)
        self._dctMessageCounters[(type(sTM_END_OF_SETUP_CMD_RSP()), "")] = int(0)
        self._dctMessageCounters[(type(sTM_END_OF_READY_CMD_RSP()), "")] = int(0)
        self._dctMessageCounters[(type(sTM_SHUTDOWN_CMD_RSP()), "")] = int(0)
        # TEWA
        self._dctMessageCounters[(type(sTEWA_STATUS_REPORT_UNSOL()), "")] = int(0)
        self._dctMessageCounters[(type(sTEWA_END_OF_SETUP_CMD_RSP()), "")] = int(0)
        self._dctMessageCounters[(type(sTEWA_END_OF_READY_CMD_RSP()), "")] = int(0)
        self._dctMessageCounters[(type(sTEWA_SHUTDOWN_CMD_RSP()), "")] = int(0)
        # SF1
        self._dctMessageCounters[(type(sSF1_STATUS_REPORT_UNSOL()), "")] = int(0)
        self._dctMessageCounters[(type(sSF1_END_OF_SETUP_CMD_RSP()), "")] = int(0)
        self._dctMessageCounters[(type(sSF1_END_OF_READY_CMD_RSP()), "")] = int(0)
        self._dctMessageCounters[(type(sSF1_SHUTDOWN_CMD_RSP()), "")] = int(0)
        self._dctMessageCounters[(type(sSF1_MODE_CMD()), "")] = int(0)
        # SF2
        self._dctMessageCounters[(type(sSF2_STATUS_REPORT_UNSOL()), "")] = int(0)
        self._dctMessageCounters[(type(sSF2_END_OF_SETUP_CMD_RSP()), "")] = int(0)
        self._dctMessageCounters[(type(sSF2_END_OF_READY_CMD_RSP()), "")] = int(0)
        self._dctMessageCounters[(type(sSF2_SHUTDOWN_CMD_RSP()), "")] = int(0)
        # SF3
        self._dctMessageCounters[(type(sSF3_STATUS_REPORT_UNSOL()), "")] = int(0)
        self._dctMessageCounters[(type(sSF3_END_OF_SETUP_CMD_RSP()), "")] = int(0)
        self._dctMessageCounters[(type(sSF3_END_OF_READY_CMD_RSP()), "")] = int(0)
        self._dctMessageCounters[(type(sSF3_SHUTDOWN_CMD_RSP()), "")] = int(0)
        # HMI_APM
        self._dctMessageCounters[(type(sHMI_STATUS_REPORT_UNSOL()), "APM")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_SETUP_CMD_RSP()), "APM")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_READY_CMD_RSP()), "APM")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_CMD_RSP()), "APM")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_UNSOL()), "APM")] = int(0)
        self._dctMessageCounters[(type(sHMI_ADCS_SHUTDOWN_CMD()), "APM")] = int(0)
        # HMI_APM_FCO
        self._dctMessageCounters[(type(sHMI_STATUS_REPORT_UNSOL()), "APM_FCO")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_SETUP_CMD_RSP()), "APM_FCO")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_READY_CMD_RSP()), "APM_FCO")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_CMD_RSP()), "APM_FCO")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_UNSOL()), "APM_FCO")] = int(0)
        self._dctMessageCounters[(type(sHMI_ADCS_SHUTDOWN_CMD()), "APM_FCO")] = int(0)
        # HMI_FCO
        self._dctMessageCounters[(type(sHMI_STATUS_REPORT_UNSOL()), "FCO")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_SETUP_CMD_RSP()), "FCO")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_READY_CMD_RSP()), "FCO")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_CMD_RSP()), "FCO")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_UNSOL()), "FCO")] = int(0)
        self._dctMessageCounters[(type(sHMI_ADCS_SHUTDOWN_CMD()), "FCO")] = int(0)
        # HMI_SPM
        self._dctMessageCounters[(type(sHMI_STATUS_REPORT_UNSOL()), "SPM")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_SETUP_CMD_RSP()), "SPM")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_READY_CMD_RSP()), "SPM")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_CMD_RSP()), "SPM")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_UNSOL()), "SPM")] = int(0)
        self._dctMessageCounters[(type(sHMI_ADCS_SHUTDOWN_CMD()), "SPM")] = int(0)
        # HMI_SPM_FUFC
        self._dctMessageCounters[(type(sHMI_STATUS_REPORT_UNSOL()), "SPM_FUFC")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_SETUP_CMD_RSP()), "SPM_FUFC")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_READY_CMD_RSP()), "SPM_FUFC")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_CMD_RSP()), "SPM_FUFC")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_UNSOL()), "SPM_FUFC")] = int(0)
        self._dctMessageCounters[(type(sHMI_ADCS_SHUTDOWN_CMD()), "SPM_FUFC")] = int(0)
        # HMI_FUFC
        self._dctMessageCounters[(type(sHMI_STATUS_REPORT_UNSOL()), "FUFC")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_SETUP_CMD_RSP()), "FUFC")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_READY_CMD_RSP()), "FUFC")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_CMD_RSP()), "FUFC")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_UNSOL()), "FUFC")] = int(0)
        self._dctMessageCounters[(type(sHMI_ADCS_SHUTDOWN_CMD()), "FUFC")] = int(0)
        # HMI_Maintainer
        self._dctMessageCounters[(type(sHMI_STATUS_REPORT_UNSOL()), "Maintainer")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_SETUP_CMD_RSP()), "Maintainer")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_READY_CMD_RSP()), "Maintainer")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_CMD_RSP()), "Maintainer")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_UNSOL()), "Maintainer")] = int(0)
        self._dctMessageCounters[(type(sHMI_ADCS_SHUTDOWN_CMD()), "Maintainer")] = int(0)
        # HMI_Oversight
        self._dctMessageCounters[(type(sHMI_STATUS_REPORT_UNSOL()), "Oversight")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_SETUP_CMD_RSP()), "Oversight")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_READY_CMD_RSP()), "Oversight")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_CMD_RSP()), "Oversight")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_UNSOL()), "Oversight")] = int(0)
        self._dctMessageCounters[(type(sHMI_ADCS_SHUTDOWN_CMD()), "Oversight")] = int(0)
        # MMS
        self._dctMessageCounters[(type(sMMS_SHUTDOWN_CMD()), "")] = int(0)
        # OLHM
        self._dctMessageCounters[(type(sOLHM_ADCS_SHUTDOWN_CMD()), "")] = int(0)
        # DSF
        self._dctMessageCounters[(type(sADCS_CONSOLIDATED_ADCM_UNSOL()), "")] = int(0)

        return

    async def vProcessDictObj(self, dctObjectPar) -> None:
        """ This is a public method which overloads the vProcessDictObj() method in the autogen base class.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        # Get the module name from the topic
        acModuleName = self._acGetModuleNameFromTopic(dctObjectPar["Topic"])

        # See if we should ignore all messages from this module
        if ((acModuleName) and ((acModuleName in self._dctGloInterDict["dctOTT"]["lstModulesToInclude"]) or (acModuleName == "OLHM"))):
            await super().vProcessDictObj(dctObjectPar)

        return

    def bPublishMqttAutogenObject(self, objAutogenObjectPar: object, acRolePar: str = "") -> bool:
        """ This is a public method which publishes a MQTT by just providing the message object.

        The reverse lookup dictionary is used to resolve an object to a topic. Then when we publish we easily
        know what the topic of the message should be.

        Args:
            objAutogenObjectPar (object): The first parameter. An autogen object containing a message.
            acRolePar (str): The second parameter. The HMI role if there is one.

        Returns:
            (bool): A boolean value indicating if the methods was successful.

        Raises:
            Raises no exception.
        """
        bReturnValue = bool(False)
        acTopic = str("")

        # The object sent in cannot be None
        if (objAutogenObjectPar is None):
            logging.error("objAutogenObjectPar cannot be None")
            return(bReturnValue)

        # The main autogen dictionary cannot be None
        if (self._dctMessages is None):
            logging.error("self._dctMessages cannot be None")
            return(bReturnValue)

        # pylint warning C0123 here is fine because there is no inheritance for this class
        if ((type(objAutogenObjectPar), acRolePar) in self._dctReverseLookupClassNameToTopic):
            # Get the topic of the message by using the reverse lookup dictionary
            acTopic = self._dctReverseLookupClassNameToTopic[(type(objAutogenObjectPar), acRolePar)]

            # To publish provide the topic, raw bytes, and flag to say if message is retained
            bReturnValue = self.bPublishMqttTopicAndData(acTopic, objAutogenObjectPar.btaSerialise())
        else:
            logging.error("The type of objAutogenObjectPar is not in the autogen message dictionary")
            bReturnValue = False

        return(bReturnValue)

    def bGenerateReverseTopicLookupDictionary(self):
        """ This is a public method iterates through the autogen message dictionary (self._dctMessages) and populates a new dictionary
        which will be used to resolve a class name to a topic. This is done so that the topic can be derived from the autogen and
        also so that we can access the self._dctMessages dictionary without searching through it.

        Args:

        Returns:
            (bool): A boolean value indicating if the methods was successful.

        Raises:
            Raises no exception.
        """
        bReturnValue = bool(False)
        lstTopicParts = []

        if (self._dctMessages is None):
            logging.error("self._dctMessages cannot be None")
            return(bReturnValue)

        # Iterate through the autogen message dictionary
        for dctItem in self._dctMessages.items():
            # Split the autogened topic in parts
            lstTopicParts = dctItem[0].split("/")

            # The topic must be made out of 3 or 4 parts
            if (len(lstTopicParts) not in [3, 4]):
                logging.error("The topic %s provided by the autogen is invalid - it must have 3 or 4 parts", dctItem[0])
                sys.exit()

            if (len(lstTopicParts) == 3):
                self._dctReverseLookupClassNameToTopic[(dctItem[1]["Class"], "")] = dctItem[0]
            elif (len(lstTopicParts) == 4):
                self._dctReverseLookupClassNameToTopic[(dctItem[1]["Class"], lstTopicParts[3])] = dctItem[0]

        return(True)

    def vGenerateMqttSpyJavaScriptFile(self, objAutogenObjectPar: object):
        """ This is a public method which generates a MQTT-Spy javascript text for testing purposes.

        Args:
            objAutogenObjectPar (object): The first parameter. An autogen object containing a message.

        Returns:

        Raises:
            Raises no exception.
        """

        bCanOpenForWrite = bool(False)
        btaRawPayload = bytes()
        acTopic = ""
        acOneLine = ""
        acFilename = ""

        acJsText = "// Wrap the script in a method, so that you can do \"return false;\" in case of an error or stop request \nfunction publish()\n{\n        data = ["

        if (objAutogenObjectPar is None):
            logging.error("objAutogenObjectPar cannot be None")
            return

        # pylint warning C0123 here is fine because there is no inheritance for this class
        if (type(objAutogenObjectPar) in self._dctReverseLookupClassNameToTopic):
            acTopic = self._dctReverseLookupClassNameToTopic[type(objAutogenObjectPar)]
            btaRawPayload = objAutogenObjectPar.StoreToStream()

            acFilename = os.path.join(self._dctGloInterDict["dctOTT"]["acCurrentDirectory"], "../Mqtt_Scripts")

            if (os.path.exists(acFilename) is False):
                logging.error("Path does not exists")
                return

            acFilename = os.path.join(acFilename, "{}.js".format(acTopic).replace("/", "_"))

            bCanOpenForWrite = bool(False)
            try:
                file = open(acFilename, "w")
                bCanOpenForWrite = True
            except Exception as E:
                logging.error("Could not open file for write - Exceptions %s", str(E))

            if (bCanOpenForWrite is False):
                return

            for iIndex, u1Byte in enumerate(btaRawPayload):
                acOneLine += "0x{0:02x}".format(u1Byte)
                if (iIndex < (len(btaRawPayload) - 1)):
                    acOneLine += ","
            acOneLine += "]\n"

            acJsText += acOneLine
            acJsText += "        mqttspy.publish(\"{}\", data, 0, false);\n".format(acTopic)
            acJsText += "        return true;\n}\npublish();"
            file.write(acJsText)

            file.close()

        return

    def vGenerateMqttSpyJavaScriptFileForGroup(self):
        """ This is a public method which generates a MQTT-Spy javascripts for a group

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        return

    def vIncreaseMessageCounter(self, tplDictKeyPar: tuple):
        """ This is a public method which increases the message counter of a specific message

        Args:
            tplDictKeyPar (tuple): The first parameter. The key we will use for the counter dictionary

        Returns:

        Raises:
            Raises no exception.
        """
        iCountValue = int(0)

        if (tplDictKeyPar is None):
            logging.error("tplDictKeyPar cannot be None")
            return

        if (isinstance(tplDictKeyPar, tuple) is False):
            logging.error("tplDictKeyPar must be a tuple")
            return

        if (len(tplDictKeyPar) != 2):
            logging.error("tplDictKeyPar must be of length 2")
            return

        if (tplDictKeyPar not in self._dctMessageCounters):
            logging.error("tplDictKeyPar is not a key for self._dctMessageCounters")
            return

        # Get the current value
        iCountValue = self._dctMessageCounters[tplDictKeyPar]
        # Increase the value
        iCountValue += 1
        # Check if we are overflowing a U2
        iCountValue = iCountValue if iCountValue <= 65535 else 0
        self._dctMessageCounters[tplDictKeyPar] = iCountValue

        return

    def _acGetModuleNameFromTopic(self, acTopicPar):
        """ This is a public method which increases the message counter of a specific message

        Args:
            tplDictKeyPar (tuple): The first parameter. The key we will use for the counter dictionary

        Returns:
            (str): The resultant module name

        Raises:
            Raises no exception.
        """
        lstTokens = []
        acReturnModuleName = str("")

        lstTokens = acTopicPar.split("/")

        if (len(lstTokens) == 3):
            return(lstTokens[1])
        elif (len(lstTokens) == 4):
            return(lstTokens[1] + "_" + lstTokens[3])

        return(acReturnModuleName)
