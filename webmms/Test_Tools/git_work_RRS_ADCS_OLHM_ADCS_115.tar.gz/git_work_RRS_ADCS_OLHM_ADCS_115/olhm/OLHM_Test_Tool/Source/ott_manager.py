#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module contains a class to manage the states of the OTT

Todo:

"""
import logging
import datetime
import socket
from python_toolbox.Datetime_Utilities.datetime_utilities import clsDatetimeUtilities
from python_toolbox.UDP.udp_non_block_manager import clsUdpNonBlockManager

from Autogen.dr_msg import sDR_STATUS_REPORT_UNSOL_PL
from Autogen.pdbp_msg import sPDBP_STATUS_REPORT_UNSOL_PL
from Autogen.eiu_msg import sEIU_STATUS_REPORT_UNSOL_PL
from Autogen.tm_msg import sTM_STATUS_REPORT_UNSOL_PL
from Autogen.tewa_msg import sTEWA_STATUS_REPORT_UNSOL_PL
from Autogen.sf1_msg import E1_SF1_MODE
from Autogen.sf1_msg import sSF1_STATUS_REPORT_UNSOL_PL
from Autogen.sf2_msg import sSF2_STATUS_REPORT_UNSOL_PL
from Autogen.sf3_msg import sSF3_STATUS_REPORT_UNSOL_PL
from Autogen.hmi_msg import sHMI_STATUS_REPORT_UNSOL_PL
from Autogen.adcs_common_types import E1_ADCS_SYSTEM_STATE
from Autogen.olhm_msg import sOLHM_ADCS_STATUS_UNSOL
from Autogen.olhm_msg import E1_OLHM_HEALTH_STATUS
from Autogen.olhm_msg import E1_OLHM_STATE


class clsOttManager():
    """ This is the OTT manager class.

    Args:
        dctGlobalInterfaceDictionaryPar (object): The first parameter. The global interface dictionary.

    """

    def __init__(self, dctGlobalInterfaceDictionaryPar):
        super().__init__()
        # Make this name short to be more readable
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar
        self._dctDateTime = {}
        self._dctDateTime["objDateTimeMonotonicRawCurrent"] = None
        self._dctDateTime["objDateTimeMonotonicRawPrev"] = None
        self._dctDateTime["iDateTimeMonotonicRawCurrent"] = int(0)
        self._dctDateTime["iDateTimeMonotonicRawPrev"] = int(0)
        self._dctDateTime["fDateTimeMonotonicRawCurrent"] = float(0.0)
        self._dctDateTime["fDateTimeMonotonicRawPrev"] = float(0.0)

        # We keep a socket for sending out OTT state information as a text monitor screen
        self._objUdpTextMonitorSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._bClearAnsiScreen = bool(True)
        self._objDateTimeAnsiTerLastRedraw = None
        self._objDateTimeMonitorSubunit = clsDatetimeUtilities.objGetMonotonicRawCurrentDatetime()
        self._objDateTimeLasteScsStatusReqRsp = None
        self._iAnsiRedrawTick = int(0)

        self._btaUdpRxBuffer = None
        self._objClsUdpNonBlockManager = clsUdpNonBlockManager(64110, fReadTimeoutSecPar=0.0)
        if (self._objClsUdpNonBlockManager.bBind() is False):
            logging.error("bBind in self._objClsUdpNonBlockManager failed")

        self._btaUdpRxBuffer = self._objClsUdpNonBlockManager.btaGetRxBuffer()

        # DR
        self._dctDRStatusReportUnsolState = {}
        self._dctDRStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctDRStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctDRStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctDRStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctDRStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctDRStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctDRStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # PDBP
        self._dctPDBPStatusReportUnsolState = {}
        self._dctPDBPStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctPDBPStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctPDBPStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctPDBPStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctPDBPStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctPDBPStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctPDBPStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # EIU
        self._dctEIUStatusReportUnsolState = {}
        self._dctEIUStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctEIUStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctEIUStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctEIUStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctEIUStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctEIUStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctEIUStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # TM
        self._dctTMStatusReportUnsolState = {}
        self._dctTMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctTMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctTMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctTMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctTMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctTMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctTMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # TEWA
        self._dctTEWAStatusReportUnsolState = {}
        self._dctTEWAStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctTEWAStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctTEWAStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctTEWAStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctTEWAStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctTEWAStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctTEWAStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # SF1
        self._dctSF1StatusReportUnsolState = {}
        self._dctSF1StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctSF1StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctSF1StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctSF1StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctSF1StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctSF1StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctSF1StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # SF2
        self._dctSF2StatusReportUnsolState = {}
        self._dctSF2StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctSF2StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctSF2StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctSF2StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctSF2StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctSF2StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctSF2StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # SF3
        self._dctSF3StatusReportUnsolState = {}
        self._dctSF3StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctSF3StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctSF3StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctSF3StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctSF3StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctSF3StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctSF3StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # HMI_APM
        self._dctHMIAPMStatusReportUnsolState = {}
        self._dctHMIAPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctHMIAPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctHMIAPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctHMIAPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctHMIAPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctHMIAPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctHMIAPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # HMI_APM_FCO
        self._dctHMIAPMFCOStatusReportUnsolState = {}
        self._dctHMIAPMFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctHMIAPMFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctHMIAPMFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctHMIAPMFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctHMIAPMFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctHMIAPMFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctHMIAPMFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # HMI_FCO
        self._dctHMIFCOStatusReportUnsolState = {}
        self._dctHMIFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctHMIFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctHMIFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctHMIFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctHMIFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctHMIFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctHMIFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # HMI_SPM
        self._dctHMISPMStatusReportUnsolState = {}
        self._dctHMISPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctHMISPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctHMISPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctHMISPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctHMISPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctHMISPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctHMISPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # HMI_SPM_FUFC
        self._dctHMISPMFUFCStatusReportUnsolState = {}
        self._dctHMISPMFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctHMISPMFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctHMISPMFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctHMISPMFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctHMISPMFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctHMISPMFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctHMISPMFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # HMI_SPM_FUFC
        self._dctHMIFUFCStatusReportUnsolState = {}
        self._dctHMIFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctHMIFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctHMIFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctHMIFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctHMIFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctHMIFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctHMIFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # HMI_Maintainer
        self._dctHMIMaintainerStatusReportUnsolState = {}
        self._dctHMIMaintainerStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctHMIMaintainerStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctHMIMaintainerStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctHMIMaintainerStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctHMIMaintainerStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctHMIMaintainerStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctHMIMaintainerStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # HMI_Oversight
        self._dctHMIOversightStatusReportUnsolState = {}
        self._dctHMIOversightStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctHMIOversightStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctHMIOversightStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctHMIOversightStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctHMIOversightStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctHMIOversightStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctHMIOversightStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        self._dctE1_OLHM_STATEToStringLookup = {}
        self._dctE1_OLHM_STATEToStringLookup[E1_OLHM_STATE.OLHM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctE1_OLHM_STATEToStringLookup[E1_OLHM_STATE.OLHM_STATE_OFFLINE] = "OFFLINE"
        self._dctE1_OLHM_STATEToStringLookup[E1_OLHM_STATE.OLHM_STATE_INITIALISE] = "INITIALISE"
        self._dctE1_OLHM_STATEToStringLookup[E1_OLHM_STATE.OLHM_STATE_READY] = "READY"
        self._dctE1_OLHM_STATEToStringLookup[E1_OLHM_STATE.OLHM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctE1_OLHM_STATEToStringLookup[E1_OLHM_STATE.OLHM_STATE_FAILED] = "FAILED"
        self._dctE1_OLHM_STATEToStringLookup[E1_OLHM_STATE.OLHM_STATE_SHUTDOWN] = "SHUTDOWN"

        self._dctHmiSystemHealthLookup = {}
        self._dctHmiSystemHealthLookup[E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN] = "UNKNOWN"
        self._dctHmiSystemHealthLookup[E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_PASSED] = "PASSED"
        self._dctHmiSystemHealthLookup[E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_NOT_FITTED] = "NOT_FITTED"
        self._dctHmiSystemHealthLookup[E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_FAILED] = "FAILED"
        self._dctHmiSystemHealthLookup[E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_DEGRADED] = "DEGRADED"

        self._dctAnsiColourLookup = {}
        self._dctAnsiColourLookup[E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_PASSED] = "\x1b[32;1m"
        self._dctAnsiColourLookup[E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_FAILED] = "\x1b[48;5;15m\x1b[31;1m"
        self._dctAnsiColourLookup[E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_DEGRADED] = "\x1b[33;1m"
        self._dctAnsiColourLookup[E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN] = "\x1b[38;5;81m"
        self._dctAnsiColourLookup[E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_NOT_FITTED] = "\x1b[36;1m"

        self._dctANSIMonitorRowLookup = {}
        self._dctANSIMonitorRowLookup["dctDR"] = {"acUnit": "DR", "acManager": "objClsDrTransitionsManager", "iRow": 2, "dctStateLookup": self._dctDRStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctPDBP"] = {"acUnit": "PDBP", "acManager": "objClsPdbpTransitionsManager", "iRow": 3, "dctStateLookup": self._dctPDBPStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctEIU"] = {"acUnit": "EIU", "acManager": "objClsEiuTransitionsManager", "iRow": 4, "dctStateLookup": self._dctEIUStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctTM"] = {"acUnit": "TM", "acManager": "objClsTmTransitionsManager", "iRow": 5, "dctStateLookup": self._dctTMStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctTEWA"] = {"acUnit": "TEWA", "acManager": "objClsTewaTransitionsManager", "iRow": 6, "dctStateLookup": self._dctTEWAStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctSF1"] = {"acUnit": "SF1", "acManager": "objClsSf1TransitionsManager", "iRow": 7, "dctStateLookup": self._dctSF1StatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctSF2"] = {"acUnit": "SF2", "acManager": "objClsSf2TransitionsManager", "iRow": 8, "dctStateLookup": self._dctSF2StatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctSF3"] = {"acUnit": "SF3", "acManager": "objClsSf3TransitionsManager", "iRow": 9, "dctStateLookup": self._dctSF3StatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctHMIAPM"] = {"acUnit": "HMI_APM", "acManager": "objClsHmiApmTransitionsManager", "iRow": 10, "dctStateLookup": self._dctHMIAPMStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctHMIAPMFCO"] = {"acUnit": "HMI_APM_FCO", "acManager": "objClsHmiApmFcoTransitionsManager", "iRow": 11, "dctStateLookup": self._dctHMIAPMFCOStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctHMIFCO"] = {"acUnit": "HMI_FCO", "acManager": "objClsHmiFcoTransitionsManager", "iRow": 12, "dctStateLookup": self._dctHMIFCOStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctHMISPM"] = {"acUnit": "HMI_SPM", "acManager": "objClsHmiSpmTransitionsManager", "iRow": 13, "dctStateLookup": self._dctHMISPMStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctHMISPMFUFC"] = {"acUnit": "HMI_SPM_FUFC", "acManager": "objClsHmiSpmFufcTransitionsManager", "iRow": 14, "dctStateLookup": self._dctHMISPMFUFCStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctHMIFUFC"] = {"acUnit": "HMI_FUFC", "acManager": "objClsHmiFufcTransitionsManager", "iRow": 15, "dctStateLookup": self._dctHMIFUFCStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctHMIMaintainer"] = {"acUnit": "HMI_Maintainer", "acManager": "objClsHmiMaintainerTransitionsManager", "iRow": 16, "dctStateLookup": self._dctHMIMaintainerStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctHMIOversight"] = {"acUnit": "HMI_Oversight", "acManager": "objClsHmiOversightTransitionsManager", "iRow": 17, "dctStateLookup": self._dctHMIOversightStatusReportUnsolState}

        return

    def vAsyncioLoopProcess(self):
        """ This is a public method which is called repeatedly inside the Asyncio loop. This method in turn will call other methods which need to do some work.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        self._vGetTimestamp()  # This method must always be called first so that we get our current and previous timestamps
        self._vTesting()
        self._vMonitorSubunitStatus()  # Call each subunits' state manager
        self._vUdpTextStateMonitor()
        self._vProcessUdpBindPort()

        return

    def _vGetTimestamp(self):
        """ This is a private method which saves the current timestamp when called. The resultant timestamp is stored locally as a class attribute.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        self._dctDateTime["fDateTimeMonotonicRawPrev"] = self._dctDateTime["fDateTimeMonotonicRawCurrent"]
        self._dctDateTime["iDateTimeMonotonicRawPrev"] = self._dctDateTime["iDateTimeMonotonicRawCurrent"]
        self._dctDateTime["objDateTimeMonotonicRawPrev"] = self._dctDateTime["objDateTimeMonotonicRawCurrent"]
        self._dctDateTime["objDateTimeMonotonicRawCurrent"] = clsDatetimeUtilities.objGetMonotonicRawCurrentDatetime()
        # Python reference: timestamp() -> Return POSIX timestamp corresponding to the datetime instance. The return value is a float similar to that returned by time.time().
        self._dctDateTime["fDateTimeMonotonicRawCurrent"] = self._dctDateTime["objDateTimeMonotonicRawCurrent"].timestamp()
        self._dctDateTime["iDateTimeMonotonicRawCurrent"] = int(self._dctDateTime["fDateTimeMonotonicRawCurrent"])

    def _vMonitorSubunitStatus(self):
        """ This is a private method which call each subunits' state manager to ascertain the state and status of the system.

        This is method which will actually do the state transition of the SCS.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        if (self._dctDateTime["objDateTimeMonotonicRawCurrent"] is None):
            return

        # Monitor high rate items
        # Nothing yet

        # Enter every 100ms - exit if we haven't waited that long yet
        if ((datetime.timedelta(seconds=0.1)) > (self._dctDateTime["objDateTimeMonotonicRawCurrent"] - self._objDateTimeMonitorSubunit)):
            return

        # Get a new datetime for the MonitorSubUnit
        self._objDateTimeMonitorSubunit = clsDatetimeUtilities.objGetMonotonicRawCurrentDatetime()

        if (self._dctGloInterDict["dctOTT"]["bDoNotSendOutStatusMessages"] is False):
            # Process subunit state and BIT (XxxStatusReportUnsol OFFLINE)
            self._dctGloInterDict["dctSubUnits"]["dctDR"]["objClsDrTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the DR state
            self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objClsPdbpTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the PDBP state
            self._dctGloInterDict["dctSubUnits"]["dctEIU"]["objClsEiuTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the EIU state
            self._dctGloInterDict["dctSubUnits"]["dctTM"]["objClsTmTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the TM state
            self._dctGloInterDict["dctSubUnits"]["dctTEWA"]["objClsTewaTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the TEWA state
            self._dctGloInterDict["dctSubUnits"]["dctSF1"]["objClsSf1TransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the SF1 state
            self._dctGloInterDict["dctSubUnits"]["dctSF2"]["objClsSf2TransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the SF2 state
            self._dctGloInterDict["dctSubUnits"]["dctSF3"]["objClsSf3TransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the SF3 state
            self._dctGloInterDict["dctSubUnits"]["dctHMIAPM"]["objClsHmiApmTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the HMI_APM state
            self._dctGloInterDict["dctSubUnits"]["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the HMI_APM_FCO state
            self._dctGloInterDict["dctSubUnits"]["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the HMI_FCO state
            self._dctGloInterDict["dctSubUnits"]["dctHMISPM"]["objClsHmiSpmTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the HMI_SPM state
            self._dctGloInterDict["dctSubUnits"]["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the HMI_SPM_FUFC state
            self._dctGloInterDict["dctSubUnits"]["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the HMI_FUFC state
            self._dctGloInterDict["dctSubUnits"]["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the HMI_Maintainer state
            self._dctGloInterDict["dctSubUnits"]["dctHMIOversight"]["objClsHmiOversightTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the HMI_Oversight state

        return

    def _vTesting(self):
        """ This is a private method which is used to test the states of the OTT.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        return

    def _vUdpTextStateMonitor(self):
        """ This is a private method which sends ANSI strings to a specific UDP port and IP address. Used for testing.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        # The last datetime cannot be None
        if (self._objDateTimeAnsiTerLastRedraw is None):
            self._objDateTimeAnsiTerLastRedraw = clsDatetimeUtilities.objGetMonotonicRawCurrentDatetime()
            return

        # Redraw every 100ms - exit if we haven't waited that long yet
        if ((datetime.timedelta(seconds=0.1)) > (self._dctDateTime["objDateTimeMonotonicRawCurrent"] - self._objDateTimeAnsiTerLastRedraw)):
            return

        # Take a new timestamp
        self._objDateTimeAnsiTerLastRedraw = clsDatetimeUtilities.objGetMonotonicRawCurrentDatetime()

        if (self._objUdpTextMonitorSocket is None):
            logging.error("self._objUdpTextMonitorSocket cannot be None")
            return

        acSendIp = "127.0.0.1"
        iSendPort = 64111
        acText = ""
        acTextFull = ""
        iAnsiColumn0Num = int(0)
        iAnsiColumn1Num = int(15)
        iAnsiColumn2Num = int(30)
        iAnsiColumn3Num = int(50)
        iAnsiColumn4Num = int(65)
        iAnsiColumn5Num = int(75)

        objDateTimeUtc = clsDatetimeUtilities.objGetUtcCurrentDatetime()
        objsOLHM_ADCS_STATUS_UNSOL = None

        # Clear the ANSI screen
        acTextFull += "\x1b[2J"

        # ANSI - [ <Y> ; <X> H

        # Header
        acText = "\x1b[1;{}HUnit \x1b[1;{}HCurrent \x1b[1;{}HPrev \x1b[1;{}HStatusUnsol".format(iAnsiColumn0Num, iAnsiColumn1Num, iAnsiColumn2Num, iAnsiColumn3Num)
        acTextFull += acText

        for acKey, dctValue in self._dctANSIMonitorRowLookup.items():

            acText = "\x1b[{};{}H{}".format(dctValue["iRow"], iAnsiColumn0Num, dctValue["acUnit"])
            acTextFull += acText

            if (acKey in []):
                continue

            tplStatusReqRspStateValue = self._tplGetStateValueFromStatusUnsol(self._dctGloInterDict["dctSubUnits"][acKey]["objsSTATUSREPORTUNSOL"].sMsgPayload)

            if (tplStatusReqRspStateValue[0] is False):
                continue

            acText = "\x1b[{};{}H{}".format(dctValue["iRow"], iAnsiColumn1Num, self._dctGloInterDict["dctSubUnits"][acKey][dctValue["acManager"]].state)
            acTextFull += acText
            acText = "\x1b[{};{}H{}".format(dctValue["iRow"], iAnsiColumn2Num, self._dctGloInterDict["dctSubUnits"][acKey][dctValue["acManager"]].acPrevState())
            acTextFull += acText
            acText = "\x1b[{};{}H{}".format(dctValue["iRow"], iAnsiColumn3Num, dctValue["dctStateLookup"][tplStatusReqRspStateValue[1]])
            acTextFull += acText

        # Do the status tree here
        if (self._dctGloInterDict["dctSubUnits"]["dctOLHM"]["objsOLHM_ADCS_STATUS_UNSOL"] is not None):
            objsOLHM_ADCS_STATUS_UNSOL = self._dctGloInterDict["dctSubUnits"]["dctOLHM"]["objsOLHM_ADCS_STATUS_UNSOL"]

            if (objsOLHM_ADCS_STATUS_UNSOL is not None):
                acText = self._acBuildOlhmAdcsStatusUnsolStringTree(objsOLHM_ADCS_STATUS_UNSOL)
                acTextFull += acText

        acText = "\x1b[43;{}HUTC TIME {}".format(iAnsiColumn0Num, str(objDateTimeUtc))
        acTextFull += acText

        # Write the redraw to see that we are still alive
        acText = "\x1b[44;{}H{}".format(iAnsiColumn0Num, self._iAnsiRedrawTick)
        acTextFull += acText

        # Write the version number
        acText = "\x1b[44;{}H OLHM TEST TOOL V{}.{}.{} {}".format(iAnsiColumn1Num, self._dctGloInterDict["dctOTT"]["iVersionMajor"], self._dctGloInterDict["dctOTT"]["iVersionMinor"], self._dctGloInterDict["dctOTT"]["iVersionInternal"], self._dctGloInterDict["dctOTT"]["acGitRepoHash"])
        acTextFull += acText

        # Now send the full text
        self._objUdpTextMonitorSocket.sendto(acTextFull.encode(encoding="ascii"), (acSendIp, iSendPort))  # Label

        self._iAnsiRedrawTick += 1

        return

    def _tplGetStateValueFromStatusUnsol(self, objStatusReqRspPayloadPar: object):
        """ This is a private method which resolves a StatusReqRsp payload to a state enum value

        Args:
            objStatusReqRspPayloadPar (object). The a payload of a StatusReqRsp message.

        Returns:
            (tuple): (bSuccess, iValue) tuple with bool to indicate if lookup was a success and then an int with the value.

        Raises:
            Raises no exception.
        """
        tplReturn = (False, int(0))

        if (isinstance(objStatusReqRspPayloadPar, sDR_STATUS_REPORT_UNSOL_PL) is True):
            return((True, objStatusReqRspPayloadPar.sModuleState.e1SystemState.Value))
        elif (isinstance(objStatusReqRspPayloadPar, sPDBP_STATUS_REPORT_UNSOL_PL) is True):
            return((True, objStatusReqRspPayloadPar.sModuleState.e1SystemState.Value))
        elif (isinstance(objStatusReqRspPayloadPar, sEIU_STATUS_REPORT_UNSOL_PL) is True):
            return((True, objStatusReqRspPayloadPar.sModuleState.e1SystemState.Value))
        elif (isinstance(objStatusReqRspPayloadPar, sTM_STATUS_REPORT_UNSOL_PL) is True):
            return((True, objStatusReqRspPayloadPar.sModuleState.e1SystemState.Value))
        elif (isinstance(objStatusReqRspPayloadPar, sTEWA_STATUS_REPORT_UNSOL_PL) is True):
            return((True, objStatusReqRspPayloadPar.sModuleState.e1SystemState.Value))
        elif (isinstance(objStatusReqRspPayloadPar, sSF1_STATUS_REPORT_UNSOL_PL) is True):
            return((True, objStatusReqRspPayloadPar.sModuleState.e1SystemState.Value))
        elif (isinstance(objStatusReqRspPayloadPar, sSF2_STATUS_REPORT_UNSOL_PL) is True):
            return((True, objStatusReqRspPayloadPar.sModuleState.e1SystemState.Value))
        elif (isinstance(objStatusReqRspPayloadPar, sSF3_STATUS_REPORT_UNSOL_PL) is True):
            return((True, objStatusReqRspPayloadPar.sModuleState.e1SystemState.Value))
        elif (isinstance(objStatusReqRspPayloadPar, sHMI_STATUS_REPORT_UNSOL_PL) is True):
            return((True, objStatusReqRspPayloadPar.sModuleState.e1SystemState.Value))
        else:
            return(tplReturn)

        return(tplReturn)

    def _acBuildOlhmAdcsStatusUnsolStringTree(self, objsOLHM_ADCS_STATUS_UNSOLPar: sOLHM_ADCS_STATUS_UNSOL):
        """ This is a private method which converts a sOLHM_ADCS_STATUS_UNSOL into a string which we can display

        Args:
            objsOLHM_ADCS_STATUS_UNSOLPar (sOLHM_ADCS_STATUS_UNSOL): The first parameter. The autogen object.

        Returns:

        Raises:
            Raises no exception.
        """
        acFullText = ""
        acText = ""
        iCol = int(1)
        iRow = int(0)
        objsOLHM_DETAILED_STATUS = None
        iCnt = int(0)
        iNumBitItems = int(0)
        iIndentLevel = int(0)

        if (objsOLHM_ADCS_STATUS_UNSOLPar is None):
            return(acFullText)

        iNumBitItems = objsOLHM_ADCS_STATUS_UNSOLPar.sMsgPayload.u2NumberOfValidBitItems.Value

        iCnt = int(0)
        for objsOLHM_DETAILED_STATUS in objsOLHM_ADCS_STATUS_UNSOLPar.sMsgPayload.asBitItems.Value:

            if (iCnt >= iNumBitItems):
                break

            iRow = (iCnt % 20) + 20
            iCol = 0 if iCnt < 20 else 40

            if (objsOLHM_DETAILED_STATUS.i2Level2Index.Value > -1):
                iIndentLevel = 2
            elif (objsOLHM_DETAILED_STATUS.i2Level1Index.Value > -1):
                iIndentLevel = 1
            elif (objsOLHM_DETAILED_STATUS.i2Level0Index.Value > -1):
                iIndentLevel = 0
            else:
                iIndentLevel = 0

            acText = ""
            # Position the cursor
            acText += "\x1b[%s;%sH" % (iRow, iCol)
            # Do the indentation if there is any
            acText += "  " * iIndentLevel
            # Write the Name and the Value
            acText += "{} {} ".format(objsOLHM_DETAILED_STATUS.acName.Value, objsOLHM_DETAILED_STATUS.acValue.Value)
            # Set the colour, write the status and then reset the colour
            acText += " {}{}\x1b[0m".format(self._dctAnsiColourLookup[objsOLHM_DETAILED_STATUS.e1Status.Value], self._dctHmiSystemHealthLookup[objsOLHM_DETAILED_STATUS.e1Status.Value])
            # Write the module state
            if (iIndentLevel == 0):
                acText += " %s" % (self._dctE1_OLHM_STATEToStringLookup[objsOLHM_DETAILED_STATUS.e1State.Value])
            acFullText += acText
            acText = ""

            iCnt += 1

        return(acFullText)

    def _vProcessUdpBindPort(self):
        """ This is a private method which processes data in the UDP bind port buffer if there is any

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        acModuleName = str()

        # Do some sanity checks

        if (self._objClsUdpNonBlockManager is None):
            logging.error("self._objClsUdpNonBlockManager cannot be None")
            return

        if (self._dctGloInterDict is None):
            logging.error("self._dctGloInterDict cannot be None")
            return

        if (self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"] is None):
            logging.error("objClsMessageProcessForMqtt cannot be None")
            return

        if (self._btaUdpRxBuffer is None):
            logging.error("self._btaUdpRxBuffer cannot be None")
            return

        if (self._objClsUdpNonBlockManager.bIsBound() is False):
            logging.error("UDP port is not bound")
            return

        if (self._objClsUdpNonBlockManager.bRead() is False):
            return

        if ((len(self._btaUdpRxBuffer) == 2) or (len(self._btaUdpRxBuffer) == 3)):
            if (self._btaUdpRxBuffer == b"1\n"):
                self._vModuleEnable("DR")
            elif (self._btaUdpRxBuffer == b"2\n"):
                self._vModuleEnable("PDBP")
            elif (self._btaUdpRxBuffer == b"3\n"):
                self._vModuleEnable("EIU")
            elif (self._btaUdpRxBuffer == b"4\n"):
                self._vModuleEnable("TM")
            elif (self._btaUdpRxBuffer == b"5\n"):
                self._vModuleEnable("TEWA")
            elif (self._btaUdpRxBuffer == b"6\n"):
                self._vModuleEnable("SF1")
            elif (self._btaUdpRxBuffer == b"7\n"):
                self._vModuleEnable("SF2")
            elif (self._btaUdpRxBuffer == b"8\n"):
                self._vModuleEnable("SF3")
            elif (self._btaUdpRxBuffer == b"9\n"):
                self._vModuleEnable("HMI_APM")
            elif (self._btaUdpRxBuffer == b"10\n"):
                self._vModuleEnable("HMI_APM_FCO")
            elif (self._btaUdpRxBuffer == b"11\n"):
                self._vModuleEnable("HMI_FCO")
            elif (self._btaUdpRxBuffer == b"12\n"):
                self._vModuleEnable("HMI_SPM")
            elif (self._btaUdpRxBuffer == b"13\n"):
                self._vModuleEnable("HMI_SPM_FUFC")
            elif (self._btaUdpRxBuffer == b"14\n"):
                self._vModuleEnable("HMI_FUFC")
            elif (self._btaUdpRxBuffer == b"15\n"):
                self._vModuleEnable("HMI_Maintainer")
            elif (self._btaUdpRxBuffer == b"16\n"):
                self._vModuleEnable("HMI_Oversight")
            elif (self._btaUdpRxBuffer == b"o\n"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendOlhmAdcsShutdownCmd()
            elif (self._btaUdpRxBuffer == b"p\n"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendMmsShutdownCmd()
            elif (self._btaUdpRxBuffer == b"q\n"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiAdcsShutdownCmdAPM()
            elif (self._btaUdpRxBuffer == b"w\n"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiAdcsShutdownCmdAPM_FCO()
            elif (self._btaUdpRxBuffer == b"e\n"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiAdcsShutdownCmdFCO()
            elif (self._btaUdpRxBuffer == b"r\n"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiAdcsShutdownCmdSPM()
            elif (self._btaUdpRxBuffer == b"t\n"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiAdcsShutdownCmdSPM_FUFC()
            elif (self._btaUdpRxBuffer == b"y\n"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiAdcsShutdownCmdFUFC()
            elif (self._btaUdpRxBuffer == b"u\n"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiAdcsShutdownCmdMaintainer()
            elif (self._btaUdpRxBuffer == b"i\n"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiAdcsShutdownCmdOversight()
            elif (self._btaUdpRxBuffer == b"a\n"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendSf1ModeCmd(E1_SF1_MODE(E1_SF1_MODE.SF1_MODE_TRAINING))
            elif (self._btaUdpRxBuffer == b"s\n"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendSf1ModeCmd(E1_SF1_MODE(E1_SF1_MODE.SF1_MODE_MAINTENANCE))

        # Clear the Udp Rx buffer
        if (self._btaUdpRxBuffer):
            del self._btaUdpRxBuffer[:]

        return

    def _vModuleEnable(self, acModuleNamePar: str):
        """


        """

        if (self._dctGloInterDict is None):
            return

        if (acModuleNamePar in self._dctGloInterDict["dctOTT"]["lstModulesToExclude"]):
            self._dctGloInterDict["dctOTT"]["lstModulesToExclude"].remove(acModuleNamePar)

        if (acModuleNamePar not in self._dctGloInterDict["dctOTT"]["lstModulesToInclude"]):
            self._dctGloInterDict["dctOTT"]["lstModulesToInclude"].append(acModuleNamePar)

        return

    def _vModuleDisable(self, acModuleNamePar: str):
        """


        """

        if (self._dctGloInterDict is None):
            return

        if (acModuleNamePar in self._dctGloInterDict["dctOTT"]["lstModulesToInclude"]):
            self._dctGloInterDict["dctOTT"]["lstModulesToInclude"].remove(acModuleNamePar)

        if (acModuleNamePar not in self._dctGloInterDict["dctOTT"]["lstModulesToExclude"]):
            self._dctGloInterDict["dctOTT"]["lstModulesToExclude"].append(acModuleNamePar)

        return
