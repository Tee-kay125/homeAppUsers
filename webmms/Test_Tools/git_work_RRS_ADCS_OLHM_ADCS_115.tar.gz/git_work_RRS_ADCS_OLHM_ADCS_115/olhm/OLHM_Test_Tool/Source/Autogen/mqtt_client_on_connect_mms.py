#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:32:41 SAST

    This module is the mqtt client on connect class, generated automatically from XML file(s). Its intended use is as a class
    with mqtt callbacks for on_connect() and on_message(). This class should be instantiated before the mqtt connect. The mqtt 
    on_connect() callback should be redirected as -> client.on_connect = objClsMqttAutogenHandler.vOnConnect
    It should be noted that all operations inside this class will execute inside the mqtt thread. The processing methods in this class
    will validate the incoming messages and reply only if validation failed. Messages which passed validation will be placed in a queue provided to
    the constructor of the class. 

"""
# ==========================================================
# AUTOGEN START
# ==========================================================
import logging  # This is required to be able to log if there are problems
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
import queue  # This is required to put the received message in a queue to pass on to another non-mqtt thread
from copy import deepcopy  # This is required to make a deepcopy of the message before insertion in the queue - it ensures proper garbage collection
from Autogen.mw_common_types import E2_MW_MESSAGE_STATUS
from Autogen.mms_msg import *  # noqa: F401

# ==========================================================
# MQTT TEMPLATE CLASS START
# ==========================================================


class clsMqttAutogenHandler():
    """ This is the MQTT message handling autogen base class

    This is the MQTT message handling autogen base class. An instance of this class should be made before giving the mqtt client
    a on_connect() callback from this class.

    Args:
        objQueuePar (queue.Queue): The first parameter. The instance of the python queue into which we will push messages received
        bLoggingEnabledPar (bool): The second parameter. A boolean flag indicating if logging should be done or not. This parameter is by default True

    """
    def __init__(self, objQueuePar: queue.Queue, bLoggingEnabledPar: bool = True):
        super().__init__()
        self._bLoggingEnabled = bLoggingEnabledPar
        self._objQueue = objQueuePar
        # By default all subscriptions will auto reply if a ReplyMsg was specified
        self.bAutoReplyForSubscriptionMmsShutdownCmdRsp = True

    def vOnConnect(self, objMqttClientPar: mqtt.Client, userDataPar, dctFlags, iConnectionResult: int) -> None:  # pylint: disable=W0613
        """ This is the callback method for when client receives a CONNACK response from the server

        This is the callback method for when client receives a CONNACK response from the server. This method subscribes
        and registers callback methods for all incoming messages. Messages from secondary XML files will not automatically be
        subscribed to. The on message callbacks will however all automatically be registered even for secondary XML files.

        Args:
            objMqttClientPar (obj): The first parameter. A MQTT client object
            userDataPar: The second parameter. The private user data as set in Client() or userdata_set()
            flags: The third parameter. flags is a dict that contains response flags from the broker:
            rc: The fourth parameter. The connection result

        Returns:

        Raises:
            Raises no exceptions
        """

        # Subscribing and adding callback for MmsShutdownCmdRsp 
        # Subscribing and adding callback for MmsShutdownCmdRsp 
        # Subscribing and adding callback for MmsShutdownCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message MmsShutdownCmdRsp  with topic ADCS/MMS/MmsShutdownCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/MMS/MmsShutdownCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message MmsShutdownCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for MmsShutdownCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/MMS/MmsShutdownCmdRsp", self.vOnMessageCallbackMmsShutdownCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for MmsShutdownCmdRsp  - Exception %s", str(E))

        return

# =========================================================="
# MQTT CALLBACK METHODS START
# =========================================================="

    def vOnMessageCallbackMmsShutdownCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message MmsShutdownCmdRsp

        This is a public method callback for message MmsShutdownCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objMmsShutdownCmdRsp = sMMS_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for MmsShutdownCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for MmsShutdownCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for MmsShutdownCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objMmsShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for MmsShutdownCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objMmsShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for MmsShutdownCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objMmsShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message MmsShutdownCmdRsp  validation failed")
            elif (objMmsShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objMmsShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message MmsShutdownCmdRsp  length field is invalid - it is %d and should be %d bytes", objMmsShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objMmsShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/MMS/MmsShutdownCmdRsp", "Class": sMMS_SHUTDOWN_CMD_RSP, "ClassName": "sMMS_SHUTDOWN_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objMmsShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/MMS/MmsShutdownCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return
# ==========================================================
# MQTT CALLBACK METHODS STOP
# ==========================================================
# ==========================================================
# MQTT SUBSCRIPTION METHODS START
# ==========================================================

    def vSubscribeMessageMmsShutdownCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message MmsShutdownCmdRsp.

        This is the auto generated method for subscribing message MmsShutdownCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for MmsShutdownCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/MMS/MmsShutdownCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message MmsShutdownCmdRsp  - Exception %s", str(E))

        return

# ==========================================================
# MQTT SUBSCRIPTION METHODS START
# ==========================================================
# ==========================================================
# MQTT TEMPLATE CLASS STOP
# ==========================================================
# ==========================================================
# AUTOGEN STOP
# ==========================================================