#! /usr/bin/env python
# -*- coding: utf-8 -*-
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:32:42 SAST

    This module is the asyncio message processing class generated automatically from XML file(s). It is intended use is as a base class
    for a derived class which will be used in the asyncio event loop. The vProcessDictObj() method should only be called inside the
    asyncio event loop and using a create_task() call. Failure to do so might block the process currently running and should only be used
    as intended in a well designed asyncio implementation.

"""
# ==========================================================
# AUTOGEN START
# ==========================================================
import logging  # This is required to be able to log if there are problems
import asyncio  # This is required to concurrent operations in a single thread
import datetime  # This is needed to set a datetime result on a future
import time  # This is needed to get the time as time.CLOCK_MONOTONIC_RAW
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
from Autogen.mw_common_types import E2_MW_MESSAGE_STATUS
from Autogen.dr_msg import *  # noqa: F401

# ==========================================================
# MQTT TEMPLATE CLASS START
# ==========================================================


class clsPythonAsyncioMessageProcessing():
    """ This is the message asyncio processing autogen class

    This is the message processing asyncio autogen class. Inherit this class in order to
    override the methods if required.

    Args:
        objMqttClientPar (mqtt.Client): The first parameter. The MQTT client instance for sending to the broker.
        dctMessagesPar (dict): The second parameter. A dictionary containing all messages and futures for messages which were automatically processed by the autogen
        lstTasksAllowedForsimultaneousExecutionPar (list): The third parameter. A list of topics for which simultaneous task execution is allowed. An empty list means no topics are allowed to execute simultaneously.
        objAsyncioLoopPar (object): The fourth parameter. The asyncio loop passed in so tasks can be created and for other asyncio functionality
        bLoggingEnabledPar (bool): The fifth parameter. A boolean flag indicating if logging should be done or not.

    """
    def __init__(self, objMqttClientPar: mqtt.Client, dctMessagesPar: dict, lstTasksAllowedForsimultaneousExecutionPar: list, objAsyncioLoopPar: object, bLoggingEnabledPar: bool = True):
        super().__init__()
        self._objMqttClient = objMqttClientPar
        self._dctMessages = dctMessagesPar
        self._lstTasksAllowedForsimultaneousExecution = lstTasksAllowedForsimultaneousExecutionPar
        self._objAsyncioLoop = objAsyncioLoopPar
        self._bLoggingEnabled = bLoggingEnabledPar
        # When we mqtt publish the connection state is returned - This property stores the last state
        self._tplPublishConnectionStateLast = (mqtt.MQTT_ERR_SUCCESS, 0)
        # When we mqtt publish the connection state is returned - This property stores the first time it failed 
        self._tplPublishConnectionStateFirstFail = (mqtt.MQTT_ERR_SUCCESS, 0)

        # In the message dictionary we store the Topic, ClassName, Class, MsgObject, Future, UTC timestamp, monotonic raw timestamp and role
        self._dctMessages["ADCS/DR/DrStatusReportUnsol"] = {"ClassName": "sDR_STATUS_REPORT_UNSOL", "Class": sDR_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"] = {"ClassName": "sDR_END_OF_SETUP_CMD_RSP", "Class": sDR_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"] = {"ClassName": "sDR_END_OF_READY_CMD_RSP", "Class": sDR_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/DR/DrShutdownCmdRsp"] = {"ClassName": "sDR_SHUTDOWN_CMD_RSP", "Class": sDR_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/DR/DrRecordingStateCmdRsp"] = {"ClassName": "sDR_RECORDING_STATE_CMD_RSP", "Class": sDR_RECORDING_STATE_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmdRsp"] = {"ClassName": "sDR_CLEAR_RECORDING_DATABASE_CMD_RSP", "Class": sDR_CLEAR_RECORDING_DATABASE_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/DR/DrEndOfSetupCmd"] = {"ClassName": "sDR_END_OF_SETUP_CMD", "Class": sDR_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/DR/DrEndOfReadyCmd"] = {"ClassName": "sDR_END_OF_READY_CMD", "Class": sDR_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/DR/DrShutdownCmd"] = {"ClassName": "sDR_SHUTDOWN_CMD", "Class": sDR_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/DR/DrRecordingStateCmd"] = {"ClassName": "sDR_RECORDING_STATE_CMD", "Class": sDR_RECORDING_STATE_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmd"] = {"ClassName": "sDR_CLEAR_RECORDING_DATABASE_CMD", "Class": sDR_CLEAR_RECORDING_DATABASE_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        # We have this dictionary to demux a topic into the processing method which should be called - it's more efficient than a long list of if statements
        self._dctDemuxTopicToMethod = {
            "ADCS/DR/DrStatusReportUnsol": self.vProcessDrStatusReportUnsol,
            "ADCS/DR/DrEndOfSetupCmdRsp": self.vProcessDrEndOfSetupCmdRsp,
            "ADCS/DR/DrEndOfReadyCmdRsp": self.vProcessDrEndOfReadyCmdRsp,
            "ADCS/DR/DrShutdownCmdRsp": self.vProcessDrShutdownCmdRsp,
            "ADCS/DR/DrRecordingStateCmdRsp": self.vProcessDrRecordingStateCmdRsp,
            "ADCS/DR/DrClearRecordingDatabaseCmdRsp": self.vProcessDrClearRecordingDatabaseCmdRsp,
            "ADCS/DR/DrEndOfSetupCmd": self.vProcessDrEndOfSetupCmd,
            "ADCS/DR/DrEndOfReadyCmd": self.vProcessDrEndOfReadyCmd,
            "ADCS/DR/DrShutdownCmd": self.vProcessDrShutdownCmd,
            "ADCS/DR/DrRecordingStateCmd": self.vProcessDrRecordingStateCmd,
            "ADCS/DR/DrClearRecordingDatabaseCmd": self.vProcessDrClearRecordingDatabaseCmd,
        }

        # This is a dictionary which keeps track of how many tasks are currently being executed per topic - for typical use this number will be either 0 or 1
        self._dctNumExecutingTasks = {
            "ADCS/DR/DrStatusReportUnsol": 0,
            "ADCS/DR/DrEndOfSetupCmdRsp": 0,
            "ADCS/DR/DrEndOfReadyCmdRsp": 0,
            "ADCS/DR/DrShutdownCmdRsp": 0,
            "ADCS/DR/DrRecordingStateCmdRsp": 0,
            "ADCS/DR/DrClearRecordingDatabaseCmdRsp": 0,
            "ADCS/DR/DrEndOfSetupCmd": 0,
            "ADCS/DR/DrEndOfReadyCmd": 0,
            "ADCS/DR/DrShutdownCmd": 0,
            "ADCS/DR/DrRecordingStateCmd": 0,
            "ADCS/DR/DrClearRecordingDatabaseCmd": 0,
        }

    # ==========================================================
    # PROCESS DICTIONARY START
    # ==========================================================
    async def vProcessDictObj(self, dctObjectPar) -> None:
        """ This is a public method which demuxes messages from the python queue.

        This is a public method which demuxes messages from the python queue. It uses a dictionary as a lookup in
        order to determine which method to call. Unknown topics will be logged as an error.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """

        # Make sure our input parameter is not None
        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        # Make sure our input parameter dictionary does have a topic key
        if ("Topic" not in dctObjectPar):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar does not contain the key Topic")
            return

        # Use the demux dictionary to determine which method should be called
        if (dctObjectPar["Topic"] in self._dctDemuxTopicToMethod):
            if ((self._dctNumExecutingTasks[dctObjectPar["Topic"]] <= 0) or (dctObjectPar["Topic"] in self._lstTasksAllowedForsimultaneousExecution)):
                self._dctNumExecutingTasks[dctObjectPar["Topic"]] += 1
                await self._dctDemuxTopicToMethod[dctObjectPar["Topic"]](dctObjectPar)
                self._dctNumExecutingTasks[dctObjectPar["Topic"]] -= 1
            else:
                logging.warning("Incoming topic %s cannot be processed right now because there is already a task executing for it - the task counter is %d", dctObjectPar["Topic"], self._dctNumExecutingTasks[dctObjectPar["Topic"]])
        else:
            logging.error("Received message with topic %s does not have a corresponding processing method to call - demux failed because topic unknown", dctObjectPar["Topic"])

        return

    # ==========================================================
    # PROCESS DICTIONARY START
    # ==========================================================
    async def vProcessDrStatusReportUnsol(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/DR/DrStatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrStatusReportUnsol is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/DR/DrStatusReportUnsol"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/DR/DrStatusReportUnsol"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/DR/DrStatusReportUnsol"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/DR/DrStatusReportUnsol"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/DR/DrStatusReportUnsol"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/DR/DrStatusReportUnsol"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadDrStatusReportUnsol(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadDrStatusReportUnsol(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/DR/DrStatusReportUnsol", "Class": sDR_STATUS_REPORT_UNSOL, "ClassName": "sDR_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/DR/DrStatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrStatusReportUnsol is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/DR/DrStatusReportUnsol"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/DR/DrStatusReportUnsol"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/DR/DrStatusReportUnsol"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("DrStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessDrEndOfSetupCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/DR/DrEndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrEndOfSetupCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadDrEndOfSetupCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadDrEndOfSetupCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/DR/DrEndOfSetupCmdRsp", "Class": sDR_END_OF_SETUP_CMD_RSP, "ClassName": "sDR_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/DR/DrEndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrEndOfSetupCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("DrEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessDrEndOfReadyCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/DR/DrEndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrEndOfReadyCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadDrEndOfReadyCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadDrEndOfReadyCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/DR/DrEndOfReadyCmdRsp", "Class": sDR_END_OF_READY_CMD_RSP, "ClassName": "sDR_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/DR/DrEndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrEndOfReadyCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("DrEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessDrShutdownCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/DR/DrShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrShutdownCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/DR/DrShutdownCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/DR/DrShutdownCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/DR/DrShutdownCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/DR/DrShutdownCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/DR/DrShutdownCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/DR/DrShutdownCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadDrShutdownCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadDrShutdownCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/DR/DrShutdownCmdRsp", "Class": sDR_SHUTDOWN_CMD_RSP, "ClassName": "sDR_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/DR/DrShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrShutdownCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/DR/DrShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/DR/DrShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/DR/DrShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("DrShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessDrRecordingStateCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/DR/DrRecordingStateCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrRecordingStateCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/DR/DrRecordingStateCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/DR/DrRecordingStateCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/DR/DrRecordingStateCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/DR/DrRecordingStateCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/DR/DrRecordingStateCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/DR/DrRecordingStateCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadDrRecordingStateCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadDrRecordingStateCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/DR/DrRecordingStateCmdRsp", "Class": sDR_RECORDING_STATE_CMD_RSP, "ClassName": "sDR_RECORDING_STATE_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/DR/DrRecordingStateCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrRecordingStateCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/DR/DrRecordingStateCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/DR/DrRecordingStateCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/DR/DrRecordingStateCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("DrRecordingStateCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessDrClearRecordingDatabaseCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/DR/DrClearRecordingDatabaseCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrClearRecordingDatabaseCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadDrClearRecordingDatabaseCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadDrClearRecordingDatabaseCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/DR/DrClearRecordingDatabaseCmdRsp", "Class": sDR_CLEAR_RECORDING_DATABASE_CMD_RSP, "ClassName": "sDR_CLEAR_RECORDING_DATABASE_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/DR/DrClearRecordingDatabaseCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrClearRecordingDatabaseCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("DrClearRecordingDatabaseCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessDrEndOfSetupCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/DR/DrEndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrEndOfSetupCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/DR/DrEndOfSetupCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/DR/DrEndOfSetupCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/DR/DrEndOfSetupCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/DR/DrEndOfSetupCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/DR/DrEndOfSetupCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/DR/DrEndOfSetupCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadDrEndOfSetupCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTDrEndOfSetupCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadDrEndOfSetupCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/DR/DrEndOfSetupCmd", "Class": sDR_END_OF_SETUP_CMD, "ClassName": "sDR_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/DR/DrEndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrEndOfSetupCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/DR/DrEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/DR/DrEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/DR/DrEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("DrEndOfSetupCmd's future -> %s", str(E))

        return(sDR_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTDrEndOfSetupCmdRsp(self, objDrEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objDrEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objDrEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objDrEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/DR/DrEndOfSetupCmdRsp", objDrEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessDrEndOfReadyCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/DR/DrEndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrEndOfReadyCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/DR/DrEndOfReadyCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/DR/DrEndOfReadyCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/DR/DrEndOfReadyCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/DR/DrEndOfReadyCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/DR/DrEndOfReadyCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/DR/DrEndOfReadyCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadDrEndOfReadyCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTDrEndOfReadyCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadDrEndOfReadyCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/DR/DrEndOfReadyCmd", "Class": sDR_END_OF_READY_CMD, "ClassName": "sDR_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/DR/DrEndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrEndOfReadyCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/DR/DrEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/DR/DrEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/DR/DrEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("DrEndOfReadyCmd's future -> %s", str(E))

        return(sDR_END_OF_READY_CMD_RSP())

    def vPublishToMQQTDrEndOfReadyCmdRsp(self, objDrEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objDrEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objDrEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objDrEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/DR/DrEndOfReadyCmdRsp", objDrEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessDrShutdownCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/DR/DrShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrShutdownCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/DR/DrShutdownCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/DR/DrShutdownCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/DR/DrShutdownCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/DR/DrShutdownCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/DR/DrShutdownCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/DR/DrShutdownCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadDrShutdownCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTDrShutdownCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadDrShutdownCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/DR/DrShutdownCmd", "Class": sDR_SHUTDOWN_CMD, "ClassName": "sDR_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/DR/DrShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrShutdownCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/DR/DrShutdownCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/DR/DrShutdownCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/DR/DrShutdownCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("DrShutdownCmd's future -> %s", str(E))

        return(sDR_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTDrShutdownCmdRsp(self, objDrShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objDrShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objDrShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objDrShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/DR/DrShutdownCmdRsp", objDrShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessDrRecordingStateCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/DR/DrRecordingStateCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrRecordingStateCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/DR/DrRecordingStateCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/DR/DrRecordingStateCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/DR/DrRecordingStateCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/DR/DrRecordingStateCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/DR/DrRecordingStateCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/DR/DrRecordingStateCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadDrRecordingStateCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTDrRecordingStateCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadDrRecordingStateCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/DR/DrRecordingStateCmd", "Class": sDR_RECORDING_STATE_CMD, "ClassName": "sDR_RECORDING_STATE_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/DR/DrRecordingStateCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrRecordingStateCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/DR/DrRecordingStateCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/DR/DrRecordingStateCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/DR/DrRecordingStateCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("DrRecordingStateCmd's future -> %s", str(E))

        return(sDR_RECORDING_STATE_CMD_RSP())

    def vPublishToMQQTDrRecordingStateCmdRsp(self, objDrRecordingStateCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objDrRecordingStateCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objDrRecordingStateCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objDrRecordingStateCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/DR/DrRecordingStateCmdRsp", objDrRecordingStateCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessDrClearRecordingDatabaseCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/DR/DrClearRecordingDatabaseCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrClearRecordingDatabaseCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadDrClearRecordingDatabaseCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTDrClearRecordingDatabaseCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadDrClearRecordingDatabaseCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/DR/DrClearRecordingDatabaseCmd", "Class": sDR_CLEAR_RECORDING_DATABASE_CMD, "ClassName": "sDR_CLEAR_RECORDING_DATABASE_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/DR/DrClearRecordingDatabaseCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrClearRecordingDatabaseCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/DR/DrClearRecordingDatabaseCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("DrClearRecordingDatabaseCmd's future -> %s", str(E))

        return(sDR_CLEAR_RECORDING_DATABASE_CMD_RSP())

    def vPublishToMQQTDrClearRecordingDatabaseCmdRsp(self, objDrClearRecordingDatabaseCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objDrClearRecordingDatabaseCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objDrClearRecordingDatabaseCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objDrClearRecordingDatabaseCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/DR/DrClearRecordingDatabaseCmdRsp", objDrClearRecordingDatabaseCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    def vStorePublishConnectionState(self, tplPublishReturnStatePar):
        """ This is a public method which sets the connection state after a publish is done

        Args:
            tplPublishReturnStatePar (tuple): The first parameter. A tuple which came from the mqtt publish method. The items are (result, mid).

        Returns:

        Raises:
            Raises no exception.
        """
        # Store the current connection state
        self._tplPublishConnectionStateLast = tplPublishReturnStatePar
        if (self._tplPublishConnectionStateLast[0] != mqtt.MQTT_ERR_SUCCESS):
            self._tplPublishConnectionStateFirstFail = self._tplPublishConnectionStateLast

        return

    def vClearPublishConnectionState(self):
        """ This is a public method which sets the connection state to SUCCESS

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        # Set the current connection state
        self._tplPublishConnectionStateLast = (mqtt.MQTT_ERR_SUCCESS, 0)
        self._tplPublishConnectionStateFirstFail = (mqtt.MQTT_ERR_SUCCESS, 0)

        return

    def bMqttIsConnected(self):
        """ This is a public method which returns the mqtt broker connection state

        Args:

        Returns:
            (bool): Boolean value indicating if the mqtt broker connection is still active.

        Raises:
            Raises no exception.
        """
        # Store the current connection state
        return(self._tplPublishConnectionStateFirstFail[0] == mqtt.MQTT_ERR_SUCCESS)

# ==========================================================
# MQTT TEMPLATE CLASS STOP
# ==========================================================
# ==========================================================
# AUTOGEN STOP
# ==========================================================