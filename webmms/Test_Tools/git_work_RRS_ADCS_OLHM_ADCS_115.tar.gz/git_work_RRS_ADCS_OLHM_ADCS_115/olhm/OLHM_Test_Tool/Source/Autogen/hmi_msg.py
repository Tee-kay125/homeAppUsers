#!/usr/bin/env python3.6
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:32:36 SAST
"""


from Autogen.adcs_base_types import clsAdcsBaseType
from Autogen.adcs_base_types import clsAdcsEnumType
from Autogen.adcs_base_types import clsAdcsEnumArrayType
from Autogen.adcs_base_types import clsAdcsStructType
from Autogen.adcs_base_types import clsAdcsStructArrayType
from Autogen.adcs_base_types import clsAdcsMessageType
from Autogen.adcs_base_types import vAddEnum
from Autogen.adcs_base_types import vAddClass
from Autogen.adcs_base_types import vAddMessage
from Autogen.adcs_base_types import clsAdcsHeaderStructType
from Autogen.adcs_base_types import clsAdcsMessageStructType

# IMPORT CODE START
from Autogen.mw_common_types import *
from Autogen.adcs_common_types import *
# IMPORT CODE END

# TYPEDEFS START
class E1_HMI_ATTRITION_LEVEL(clsAdcsEnumType):
    """Public class definition of type E1_HMI_ATTRITION_LEVEL
    """
    def __init__(self, defaultValue=0):
        super().__init__("U1", defaultValue)
    DETERRENCE = 0x00
    MEDIUM_ATTRITION = 0x01
    HIGH_ATTRITION = 0x02


vAddEnum("E1_HMI_ATTRITION_LEVEL", E1_HMI_ATTRITION_LEVEL)


class E1_HMI_EXCLUSION_RANGE_OPTIONS(clsAdcsEnumType):
    """Public class definition of type E1_HMI_EXCLUSION_RANGE_OPTIONS
    """
    def __init__(self, defaultValue=0):
        super().__init__("U1", defaultValue)
    THREAT_TYPE_BASED = 0x00
    BATTERY_LEVEL_NOMINAL = 0x01
    DA_RADIUS_BASED = 0x02


vAddEnum("E1_HMI_EXCLUSION_RANGE_OPTIONS", E1_HMI_EXCLUSION_RANGE_OPTIONS)


class E1_HMI_WA_OBJECTIVE(clsAdcsEnumType):
    """Public class definition of type E1_HMI_WA_OBJECTIVE
    """
    def __init__(self, defaultValue=0):
        super().__init__("U1", defaultValue)
    LOWEST_LEAK_RATE = 0x00
    HIGHEST_ATTRITION_RATE = 0x01


vAddEnum("E1_HMI_WA_OBJECTIVE", E1_HMI_WA_OBJECTIVE)


class E1_HMI_ROLES(clsAdcsEnumType):
    """Public class definition of type E1_HMI_ROLES
    """
    def __init__(self, defaultValue=0):
        super().__init__("U1", defaultValue)
    APM = 0x00
    FCO = 0x01
    APM_FCO = 0x02
    SPM = 0x03
    FUFC = 0x04
    SPM_FUFC = 0x05
    OVERSIGHT = 0x06
    MAINTAINER = 0x07


vAddEnum("E1_HMI_ROLES", E1_HMI_ROLES)


class E1_HMI_MODE(clsAdcsEnumType):
    """Public class definition of type E1_HMI_MODE
    """
    def __init__(self, defaultValue=0):
        super().__init__("U1", defaultValue)
    OPERATIONAL = 0x00
    TRAINING = 0x01
    MAINTENANCE = 0x02
    REVIEW = 0x03


vAddEnum("E1_HMI_MODE", E1_HMI_MODE)


# TYPEDEFS END

# MESSAGE HEADERS START
class sHMI_STATUS_REPORT_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_STATUS_REPORT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0000)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_STATUS_REPORT_UNSOL_MESSAGE_HEADER", sHMI_STATUS_REPORT_UNSOL_MESSAGE_HEADER)


class sHMI_END_OF_SETUP_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_END_OF_SETUP_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0001)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_END_OF_SETUP_CMD_MESSAGE_HEADER", sHMI_END_OF_SETUP_CMD_MESSAGE_HEADER)


class sHMI_END_OF_SETUP_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_END_OF_SETUP_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0001)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_END_OF_SETUP_CMD_RSP_MESSAGE_HEADER", sHMI_END_OF_SETUP_CMD_RSP_MESSAGE_HEADER)


class sHMI_END_OF_READY_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_END_OF_READY_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0002)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_END_OF_READY_CMD_MESSAGE_HEADER", sHMI_END_OF_READY_CMD_MESSAGE_HEADER)


class sHMI_END_OF_READY_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_END_OF_READY_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0002)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_END_OF_READY_CMD_RSP_MESSAGE_HEADER", sHMI_END_OF_READY_CMD_RSP_MESSAGE_HEADER)


class sHMI_SHUTDOWN_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_SHUTDOWN_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0003)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_SHUTDOWN_CMD_MESSAGE_HEADER", sHMI_SHUTDOWN_CMD_MESSAGE_HEADER)


class sHMI_SHUTDOWN_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_SHUTDOWN_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0003)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_SHUTDOWN_CMD_RSP_MESSAGE_HEADER", sHMI_SHUTDOWN_CMD_RSP_MESSAGE_HEADER)


class sHMI_SHUTDOWN_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_SHUTDOWN_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0004)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_SHUTDOWN_UNSOL_MESSAGE_HEADER", sHMI_SHUTDOWN_UNSOL_MESSAGE_HEADER)


class sHMI_EMERGENCY_ERASE_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_EMERGENCY_ERASE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0005)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_EMERGENCY_ERASE_UNSOL_MESSAGE_HEADER", sHMI_EMERGENCY_ERASE_UNSOL_MESSAGE_HEADER)


class sHMI_ADCS_SHUTDOWN_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_ADCS_SHUTDOWN_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0006)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_ADCS_SHUTDOWN_CMD_MESSAGE_HEADER", sHMI_ADCS_SHUTDOWN_CMD_MESSAGE_HEADER)


class sHMI_ADCS_SHUTDOWN_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_ADCS_SHUTDOWN_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0006)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_ADCS_SHUTDOWN_CMD_RSP_MESSAGE_HEADER", sHMI_ADCS_SHUTDOWN_CMD_RSP_MESSAGE_HEADER)


class sHMI_MANUAL_POINT_TRACK_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_MANUAL_POINT_TRACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0010)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_MANUAL_POINT_TRACK_UNSOL_MESSAGE_HEADER", sHMI_MANUAL_POINT_TRACK_UNSOL_MESSAGE_HEADER)


class sHMI_MANUAL_BEARING_TRACK_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_MANUAL_BEARING_TRACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0011)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_MANUAL_BEARING_TRACK_UNSOL_MESSAGE_HEADER", sHMI_MANUAL_BEARING_TRACK_UNSOL_MESSAGE_HEADER)


class sHMI_EARLY_WARNING_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_EARLY_WARNING_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0012)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_EARLY_WARNING_UNSOL_MESSAGE_HEADER", sHMI_EARLY_WARNING_UNSOL_MESSAGE_HEADER)


class sHMI_HOSTILITY_OVERRIDE_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_HOSTILITY_OVERRIDE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0020)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_HOSTILITY_OVERRIDE_UNSOL_MESSAGE_HEADER", sHMI_HOSTILITY_OVERRIDE_UNSOL_MESSAGE_HEADER)


class sHMI_ENVIRONMENT_OVERRIDE_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_ENVIRONMENT_OVERRIDE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0021)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_ENVIRONMENT_OVERRIDE_UNSOL_MESSAGE_HEADER", sHMI_ENVIRONMENT_OVERRIDE_UNSOL_MESSAGE_HEADER)


class sHMI_TYPE_OVERRIDE_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_TYPE_OVERRIDE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0022)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_TYPE_OVERRIDE_UNSOL_MESSAGE_HEADER", sHMI_TYPE_OVERRIDE_UNSOL_MESSAGE_HEADER)


class sHMI_DESCRIPTION_OVERRIDE_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_DESCRIPTION_OVERRIDE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0030)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_DESCRIPTION_OVERRIDE_UNSOL_MESSAGE_HEADER", sHMI_DESCRIPTION_OVERRIDE_UNSOL_MESSAGE_HEADER)


class sHMI_HEIGHT_OVERRIDE_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_HEIGHT_OVERRIDE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0031)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_HEIGHT_OVERRIDE_UNSOL_MESSAGE_HEADER", sHMI_HEIGHT_OVERRIDE_UNSOL_MESSAGE_HEADER)


class sHMI_PLANNED_ENGAGEMENT_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_PLANNED_ENGAGEMENT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0040)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_PLANNED_ENGAGEMENT_UNSOL_MESSAGE_HEADER", sHMI_PLANNED_ENGAGEMENT_UNSOL_MESSAGE_HEADER)


class sHMI_ENGAGEMENT_ORDER_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_ENGAGEMENT_ORDER_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0041)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_ENGAGEMENT_ORDER_UNSOL_MESSAGE_HEADER", sHMI_ENGAGEMENT_ORDER_UNSOL_MESSAGE_HEADER)


class sHMI_CANCEL_ENGAGEMENT_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_CANCEL_ENGAGEMENT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0042)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_CANCEL_ENGAGEMENT_UNSOL_MESSAGE_HEADER", sHMI_CANCEL_ENGAGEMENT_UNSOL_MESSAGE_HEADER)


class sHMI_LWO_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_LWO_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0043)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_LWO_UNSOL_MESSAGE_HEADER", sHMI_LWO_UNSOL_MESSAGE_HEADER)


class sHMI_CANCEL_LWO_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_CANCEL_LWO_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0044)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_CANCEL_LWO_UNSOL_MESSAGE_HEADER", sHMI_CANCEL_LWO_UNSOL_MESSAGE_HEADER)


class sHMI_VETO_ENGAGEMENT_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_VETO_ENGAGEMENT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0045)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_VETO_ENGAGEMENT_UNSOL_MESSAGE_HEADER", sHMI_VETO_ENGAGEMENT_UNSOL_MESSAGE_HEADER)


class sHMI_REVISE_ENGAGEMENT_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_REVISE_ENGAGEMENT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0046)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_REVISE_ENGAGEMENT_UNSOL_MESSAGE_HEADER", sHMI_REVISE_ENGAGEMENT_UNSOL_MESSAGE_HEADER)


class sHMI_CIRCULAR_AIR_ZONE_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_CIRCULAR_AIR_ZONE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0050)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_CIRCULAR_AIR_ZONE_UNSOL_MESSAGE_HEADER", sHMI_CIRCULAR_AIR_ZONE_UNSOL_MESSAGE_HEADER)


class sHMI_POLYGON_AIR_ZONE_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_POLYGON_AIR_ZONE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0051)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_POLYGON_AIR_ZONE_UNSOL_MESSAGE_HEADER", sHMI_POLYGON_AIR_ZONE_UNSOL_MESSAGE_HEADER)


class sHMI_AIR_LANE_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_AIR_LANE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0052)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_AIR_LANE_UNSOL_MESSAGE_HEADER", sHMI_AIR_LANE_UNSOL_MESSAGE_HEADER)


class sHMI_FLIGHT_PLAN_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_FLIGHT_PLAN_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0053)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_FLIGHT_PLAN_UNSOL_MESSAGE_HEADER", sHMI_FLIGHT_PLAN_UNSOL_MESSAGE_HEADER)


class sHMI_IFF_LINE_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_IFF_LINE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0054)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_IFF_LINE_UNSOL_MESSAGE_HEADER", sHMI_IFF_LINE_UNSOL_MESSAGE_HEADER)


class sHMI_EFFECTOR_TRACK_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_EFFECTOR_TRACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0060)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_EFFECTOR_TRACK_UNSOL_MESSAGE_HEADER", sHMI_EFFECTOR_TRACK_UNSOL_MESSAGE_HEADER)


class sHMI_ASSET_TRACK_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_ASSET_TRACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0061)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_ASSET_TRACK_UNSOL_MESSAGE_HEADER", sHMI_ASSET_TRACK_UNSOL_MESSAGE_HEADER)


class sHMI_SENSOR_TRACK_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_SENSOR_TRACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0062)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_SENSOR_TRACK_UNSOL_MESSAGE_HEADER", sHMI_SENSOR_TRACK_UNSOL_MESSAGE_HEADER)


class sHMI_PE_TRACK_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_PE_TRACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0063)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_PE_TRACK_UNSOL_MESSAGE_HEADER", sHMI_PE_TRACK_UNSOL_MESSAGE_HEADER)


class sHMI_OP_TRACK_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_OP_TRACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0064)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_OP_TRACK_UNSOL_MESSAGE_HEADER", sHMI_OP_TRACK_UNSOL_MESSAGE_HEADER)


class sHMI_OPERATOR_TRACK_DELETE_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_OPERATOR_TRACK_DELETE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0065)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_OPERATOR_TRACK_DELETE_UNSOL_MESSAGE_HEADER", sHMI_OPERATOR_TRACK_DELETE_UNSOL_MESSAGE_HEADER)


class sHMI_WEAPON_CONTROL_ORDER_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_WEAPON_CONTROL_ORDER_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0070)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_WEAPON_CONTROL_ORDER_UNSOL_MESSAGE_HEADER", sHMI_WEAPON_CONTROL_ORDER_UNSOL_MESSAGE_HEADER)


class sHMI_AIR_DEFENCE_READINESS_STATE_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_AIR_DEFENCE_READINESS_STATE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0071)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_AIR_DEFENCE_READINESS_STATE_UNSOL_MESSAGE_HEADER", sHMI_AIR_DEFENCE_READINESS_STATE_UNSOL_MESSAGE_HEADER)


class sHMI_AIR_RAID_WARNING_STATE_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_AIR_RAID_WARNING_STATE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0072)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_AIR_RAID_WARNING_STATE_UNSOL_MESSAGE_HEADER", sHMI_AIR_RAID_WARNING_STATE_UNSOL_MESSAGE_HEADER)


class sHMI_AOR_CENTRE_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_AOR_CENTRE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0073)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_AOR_CENTRE_UNSOL_MESSAGE_HEADER", sHMI_AOR_CENTRE_UNSOL_MESSAGE_HEADER)


class sHMI_ROE_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_ROE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0080)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_ROE_UNSOL_MESSAGE_HEADER", sHMI_ROE_UNSOL_MESSAGE_HEADER)


class sHMI_EXCLUSION_BOUNDARIES_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_EXCLUSION_BOUNDARIES_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0080)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_EXCLUSION_BOUNDARIES_UNSOL_MESSAGE_HEADER", sHMI_EXCLUSION_BOUNDARIES_UNSOL_MESSAGE_HEADER)


class sHMI_IFF_INTERROGATION_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_IFF_INTERROGATION_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x00A0)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_IFF_INTERROGATION_UNSOL_MESSAGE_HEADER", sHMI_IFF_INTERROGATION_UNSOL_MESSAGE_HEADER)


class sHMI_TRACK_DISTRIBUTION_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_TRACK_DISTRIBUTION_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x00A1)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_TRACK_DISTRIBUTION_UNSOL_MESSAGE_HEADER", sHMI_TRACK_DISTRIBUTION_UNSOL_MESSAGE_HEADER)


class sHMI_MESSAGE_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_MESSAGE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x00B0)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_MESSAGE_UNSOL_MESSAGE_HEADER", sHMI_MESSAGE_UNSOL_MESSAGE_HEADER)


class sHMI_MESSAGE_ACKNOWLEDGEMENT_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sHMI_MESSAGE_ACKNOWLEDGEMENT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_HMI)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x00B1)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sHMI_MESSAGE_ACKNOWLEDGEMENT_UNSOL_MESSAGE_HEADER", sHMI_MESSAGE_ACKNOWLEDGEMENT_UNSOL_MESSAGE_HEADER)


# MESSAGE HEADERS END

# PAYLOADS START
class sHMI_STATUS_REPORT_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_STATUS_REPORT_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sModuleInfo = sADCS_MODULE_INFO()
        self.vAddType("sModuleInfo")
        self.sModuleState = sADCS_MODULE_STATE()
        self.vAddType("sModuleState")
        self.e1Role = E1_HMI_ROLES(E1_HMI_ROLES.APM)
        self.vAddType("e1Role")
        self.e1Mode = E1_HMI_MODE(E1_HMI_MODE.OPERATIONAL)
        self.vAddType("e1Mode")


vAddClass("sHMI_STATUS_REPORT_UNSOL_PL", sHMI_STATUS_REPORT_UNSOL_PL)


class sHMI_MANUAL_POINT_TRACK_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_MANUAL_POINT_TRACK_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4TrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4TrackNumber")
        self.sKinematics = sADCS_POINT_KINEMATICS()
        self.vAddType("sKinematics")
        self.f8SecondsToLive = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8SecondsToLive")
        self.e1Delete = E1_MW_BOOLEAN_ENUM(E1_MW_BOOLEAN_ENUM.MW_BOOLEAN_FALSE)
        self.vAddType("e1Delete")


vAddClass("sHMI_MANUAL_POINT_TRACK_UNSOL_PL", sHMI_MANUAL_POINT_TRACK_UNSOL_PL)


class sHMI_MANUAL_BEARING_TRACK_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_MANUAL_BEARING_TRACK_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4TrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4TrackNumber")
        self.sKinematics = sADCS_ANGULAR_KINEMATICS()
        self.vAddType("sKinematics")
        self.f8SecondsToLive = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8SecondsToLive")
        self.e1Delete = E1_MW_BOOLEAN_ENUM(E1_MW_BOOLEAN_ENUM.MW_BOOLEAN_FALSE)
        self.vAddType("e1Delete")


vAddClass("sHMI_MANUAL_BEARING_TRACK_UNSOL_PL", sHMI_MANUAL_BEARING_TRACK_UNSOL_PL)


class sHMI_EARLY_WARNING_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_EARLY_WARNING_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4TrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4TrackNumber")
        self.sKinematics = sADCS_POINT_KINEMATICS()
        self.vAddType("sKinematics")
        self.sClassification = sADCS_CLASSIFICATION()
        self.vAddType("sClassification")
        self.e1Delete = E1_MW_BOOLEAN_ENUM(E1_MW_BOOLEAN_ENUM.MW_BOOLEAN_FALSE)
        self.vAddType("e1Delete")


vAddClass("sHMI_EARLY_WARNING_UNSOL_PL", sHMI_EARLY_WARNING_UNSOL_PL)


class sHMI_HOSTILITY_OVERRIDE_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_HOSTILITY_OVERRIDE_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4TrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4TrackNumber")
        self.e1Hostility = E1_ADCS_HOSTILITY_TYPE(E1_ADCS_HOSTILITY_TYPE.UNKNOWN_HOSTILITY)
        self.vAddType("e1Hostility")
        self.e1Override = E1_ADCS_OVERRIDE(E1_ADCS_OVERRIDE.NOT_OVERRIDDEN)
        self.vAddType("e1Override")


vAddClass("sHMI_HOSTILITY_OVERRIDE_UNSOL_PL", sHMI_HOSTILITY_OVERRIDE_UNSOL_PL)


class sHMI_ENVIRONMENT_OVERRIDE_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_ENVIRONMENT_OVERRIDE_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4TrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4TrackNumber")
        self.e1Environment = E1_ADCS_ENVIRONMENT_TYPE(E1_ADCS_ENVIRONMENT_TYPE.UNKNOWN_ENVIRONMENT)
        self.vAddType("e1Environment")
        self.e1Override = E1_ADCS_OVERRIDE(E1_ADCS_OVERRIDE.NOT_OVERRIDDEN)
        self.vAddType("e1Override")


vAddClass("sHMI_ENVIRONMENT_OVERRIDE_UNSOL_PL", sHMI_ENVIRONMENT_OVERRIDE_UNSOL_PL)


class sHMI_TYPE_OVERRIDE_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_TYPE_OVERRIDE_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4TrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4TrackNumber")
        self.sType = sADCS_SPECIFIC()
        self.vAddType("sType")
        self.e1Override = E1_ADCS_OVERRIDE(E1_ADCS_OVERRIDE.NOT_OVERRIDDEN)
        self.vAddType("e1Override")


vAddClass("sHMI_TYPE_OVERRIDE_UNSOL_PL", sHMI_TYPE_OVERRIDE_UNSOL_PL)


class sHMI_DESCRIPTION_OVERRIDE_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_DESCRIPTION_OVERRIDE_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4TrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4TrackNumber")
        self.sDescription = sADCS_STRING24()
        self.vAddType("sDescription")
        self.e1Override = E1_ADCS_OVERRIDE(E1_ADCS_OVERRIDE.NOT_OVERRIDDEN)
        self.vAddType("e1Override")


vAddClass("sHMI_DESCRIPTION_OVERRIDE_UNSOL_PL", sHMI_DESCRIPTION_OVERRIDE_UNSOL_PL)


class sHMI_HEIGHT_OVERRIDE_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_HEIGHT_OVERRIDE_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4TrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4TrackNumber")
        self.sManualHeight = sADCS_QVALUE()
        self.vAddType("sManualHeight")
        self.e1Override = E1_ADCS_OVERRIDE(E1_ADCS_OVERRIDE.NOT_OVERRIDDEN)
        self.vAddType("e1Override")


vAddClass("sHMI_HEIGHT_OVERRIDE_UNSOL_PL", sHMI_HEIGHT_OVERRIDE_UNSOL_PL)


class sHMI_PLANNED_ENGAGEMENT_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_PLANNED_ENGAGEMENT_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4EngagementId = clsAdcsBaseType("U4", 0)
        self.vAddType("u4EngagementId")
        self.u4TrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4TrackNumber")
        self.u4EffectorTrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4EffectorTrackNumber")


vAddClass("sHMI_PLANNED_ENGAGEMENT_UNSOL_PL", sHMI_PLANNED_ENGAGEMENT_UNSOL_PL)


class sHMI_ENGAGEMENT_ORDER_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_ENGAGEMENT_ORDER_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4EngagementId = clsAdcsBaseType("U4", 0)
        self.vAddType("u4EngagementId")
        self.u4TrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4TrackNumber")
        self.u4EffectorTrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4EffectorTrackNumber")
        self.e1EngagementStatus = E1_ADCS_ENGAGEMENT_STATUS(E1_ADCS_ENGAGEMENT_STATUS.UNKNOWN_ES)
        self.vAddType("e1EngagementStatus")


vAddClass("sHMI_ENGAGEMENT_ORDER_UNSOL_PL", sHMI_ENGAGEMENT_ORDER_UNSOL_PL)


class sHMI_CANCEL_ENGAGEMENT_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_CANCEL_ENGAGEMENT_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4EngagementId = clsAdcsBaseType("U4", 0)
        self.vAddType("u4EngagementId")


vAddClass("sHMI_CANCEL_ENGAGEMENT_UNSOL_PL", sHMI_CANCEL_ENGAGEMENT_UNSOL_PL)


class sHMI_LWO_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_LWO_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4LwoId = clsAdcsBaseType("U4", 0)
        self.vAddType("u4LwoId")
        self.u4ThreatTrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4ThreatTrackNumber")
        self.u4EffectorTrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4EffectorTrackNumber")


vAddClass("sHMI_LWO_UNSOL_PL", sHMI_LWO_UNSOL_PL)


class sHMI_CANCEL_LWO_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_CANCEL_LWO_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4LwoId = clsAdcsBaseType("U4", 0)
        self.vAddType("u4LwoId")


vAddClass("sHMI_CANCEL_LWO_UNSOL_PL", sHMI_CANCEL_LWO_UNSOL_PL)


class sHMI_VETO_ENGAGEMENT_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_VETO_ENGAGEMENT_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4EngagementId = clsAdcsBaseType("U4", 0)
        self.vAddType("u4EngagementId")


vAddClass("sHMI_VETO_ENGAGEMENT_UNSOL_PL", sHMI_VETO_ENGAGEMENT_UNSOL_PL)


class sHMI_REVISE_ENGAGEMENT_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_REVISE_ENGAGEMENT_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4EngagementId = clsAdcsBaseType("U4", 0)
        self.vAddType("u4EngagementId")


vAddClass("sHMI_REVISE_ENGAGEMENT_UNSOL_PL", sHMI_REVISE_ENGAGEMENT_UNSOL_PL)


class sHMI_CIRCULAR_AIR_ZONE_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_CIRCULAR_AIR_ZONE_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.sZoneDetails = sADCS_AIR_ZONE_CIRCULAR()
        self.vAddType("sZoneDetails")


vAddClass("sHMI_CIRCULAR_AIR_ZONE_UNSOL_PL", sHMI_CIRCULAR_AIR_ZONE_UNSOL_PL)


class sHMI_POLYGON_AIR_ZONE_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_POLYGON_AIR_ZONE_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.sZoneDetails = sADCS_AIR_ZONE_POLYGON()
        self.vAddType("sZoneDetails")


vAddClass("sHMI_POLYGON_AIR_ZONE_UNSOL_PL", sHMI_POLYGON_AIR_ZONE_UNSOL_PL)


class sHMI_AIR_LANE_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_AIR_LANE_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.sLaneDetails = sADCS_AIR_LANE()
        self.vAddType("sLaneDetails")


vAddClass("sHMI_AIR_LANE_UNSOL_PL", sHMI_AIR_LANE_UNSOL_PL)


class sHMI_FLIGHT_PLAN_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_FLIGHT_PLAN_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.sPlanDetails = sADCS_FLIGHT_PLAN()
        self.vAddType("sPlanDetails")


vAddClass("sHMI_FLIGHT_PLAN_UNSOL_PL", sHMI_FLIGHT_PLAN_UNSOL_PL)


class sHMI_IFF_LINE_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_IFF_LINE_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.sLineDetails = sADCS_IFF_LINE()
        self.vAddType("sLineDetails")


vAddClass("sHMI_IFF_LINE_UNSOL_PL", sHMI_IFF_LINE_UNSOL_PL)


class sHMI_EFFECTOR_TRACK_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_EFFECTOR_TRACK_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.sTrack = sADCS_EFFECTOR()
        self.vAddType("sTrack")


vAddClass("sHMI_EFFECTOR_TRACK_UNSOL_PL", sHMI_EFFECTOR_TRACK_UNSOL_PL)


class sHMI_ASSET_TRACK_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_ASSET_TRACK_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.sTrack = sADCS_ASSET()
        self.vAddType("sTrack")


vAddClass("sHMI_ASSET_TRACK_UNSOL_PL", sHMI_ASSET_TRACK_UNSOL_PL)


class sHMI_SENSOR_TRACK_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_SENSOR_TRACK_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.sTrack = sADCS_SENSOR()
        self.vAddType("sTrack")


vAddClass("sHMI_SENSOR_TRACK_UNSOL_PL", sHMI_SENSOR_TRACK_UNSOL_PL)


class sHMI_PE_TRACK_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_PE_TRACK_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.sTrack = sADCS_PHYSICAL_ELEMENT()
        self.vAddType("sTrack")


vAddClass("sHMI_PE_TRACK_UNSOL_PL", sHMI_PE_TRACK_UNSOL_PL)


class sHMI_OP_TRACK_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_OP_TRACK_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.sTrack = sADCS_OBSERVATION_POST()
        self.vAddType("sTrack")


vAddClass("sHMI_OP_TRACK_UNSOL_PL", sHMI_OP_TRACK_UNSOL_PL)


class sHMI_OPERATOR_TRACK_DELETE_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_OPERATOR_TRACK_DELETE_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4SystemTrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4SystemTrackNumber")


vAddClass("sHMI_OPERATOR_TRACK_DELETE_UNSOL_PL", sHMI_OPERATOR_TRACK_DELETE_UNSOL_PL)


class sHMI_WEAPON_CONTROL_ORDER_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_WEAPON_CONTROL_ORDER_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.sWco = sADCS_WCO()
        self.vAddType("sWco")


vAddClass("sHMI_WEAPON_CONTROL_ORDER_UNSOL_PL", sHMI_WEAPON_CONTROL_ORDER_UNSOL_PL)


class sHMI_AIR_DEFENCE_READINESS_STATE_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_AIR_DEFENCE_READINESS_STATE_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.sAdrs = sADCS_ADRS()
        self.vAddType("sAdrs")


vAddClass("sHMI_AIR_DEFENCE_READINESS_STATE_UNSOL_PL", sHMI_AIR_DEFENCE_READINESS_STATE_UNSOL_PL)


class sHMI_AIR_RAID_WARNING_STATE_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_AIR_RAID_WARNING_STATE_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.sArws = sADCS_ARWS()
        self.vAddType("sArws")


vAddClass("sHMI_AIR_RAID_WARNING_STATE_UNSOL_PL", sHMI_AIR_RAID_WARNING_STATE_UNSOL_PL)


class sHMI_AOR_CENTRE_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_AOR_CENTRE_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.sAorCentre = sADCS_AOR_CENTRE()
        self.vAddType("sAorCentre")


vAddClass("sHMI_AOR_CENTRE_UNSOL_PL", sHMI_AOR_CENTRE_UNSOL_PL)


class sHMI_ROE_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_ROE_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.f8SaafResponsibilityAltitude = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8SaafResponsibilityAltitude")
        self.e1AttritionLevel = E1_HMI_ATTRITION_LEVEL(E1_HMI_ATTRITION_LEVEL.DETERRENCE)
        self.vAddType("e1AttritionLevel")
        self.e1RecedingEngagementAllowed = E1_MW_BOOLEAN_ENUM(E1_MW_BOOLEAN_ENUM.MW_BOOLEAN_FALSE)
        self.vAddType("e1RecedingEngagementAllowed")
        self.e1AmmunitionRetentionPreferred = E1_MW_BOOLEAN_ENUM(E1_MW_BOOLEAN_ENUM.MW_BOOLEAN_TRUE)
        self.vAddType("e1AmmunitionRetentionPreferred")
        self.e1CostPenalisationPreferred = E1_MW_BOOLEAN_ENUM(E1_MW_BOOLEAN_ENUM.MW_BOOLEAN_TRUE)
        self.vAddType("e1CostPenalisationPreferred")
        self.e1FireOverOwnAllowed = E1_MW_BOOLEAN_ENUM(E1_MW_BOOLEAN_ENUM.MW_BOOLEAN_TRUE)
        self.vAddType("e1FireOverOwnAllowed")
        self.e1EngageLateUnmaskedAllowed = E1_MW_BOOLEAN_ENUM(E1_MW_BOOLEAN_ENUM.MW_BOOLEAN_TRUE)
        self.vAddType("e1EngageLateUnmaskedAllowed")
        self.e1WaObjective = E1_HMI_WA_OBJECTIVE(E1_HMI_WA_OBJECTIVE.LOWEST_LEAK_RATE)
        self.vAddType("e1WaObjective")
        self.e1ExclusionRangeOption = E1_HMI_EXCLUSION_RANGE_OPTIONS(E1_HMI_EXCLUSION_RANGE_OPTIONS.THREAT_TYPE_BASED)
        self.vAddType("e1ExclusionRangeOption")


vAddClass("sHMI_ROE_UNSOL_PL", sHMI_ROE_UNSOL_PL)


class sHMI_EXCLUSION_BOUNDARIES_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_EXCLUSION_BOUNDARIES_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.f8ExclusionBoundariesCount = clsAdcsBaseType("F8", 0.0)
        self.f8ExclusionBoundariesCount.vSetMin(0)
        self.f8ExclusionBoundariesCount.vSetMax(100)
        self.vAddType("f8ExclusionBoundariesCount")
        self.asExclusionBoundaries = clsAdcsStructArrayType("sADCS_EXCLUSION_BOUNDARIES:100")
        self.vAddType("asExclusionBoundaries")
        self.f8BatteryWideExclusionBoundary = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8BatteryWideExclusionBoundary")


vAddClass("sHMI_EXCLUSION_BOUNDARIES_UNSOL_PL", sHMI_EXCLUSION_BOUNDARIES_UNSOL_PL)


class sHMI_IFF_INTERROGATION_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_IFF_INTERROGATION_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4ThreatTrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4ThreatTrackNumber")
        self.u4PrimaryMode = clsAdcsBaseType("U4", 0)
        self.vAddType("u4PrimaryMode")
        self.u4SecondaryMode = clsAdcsBaseType("U4", 0)
        self.vAddType("u4SecondaryMode")
        self.u4MaxRetries = clsAdcsBaseType("U4", 0)
        self.vAddType("u4MaxRetries")


vAddClass("sHMI_IFF_INTERROGATION_UNSOL_PL", sHMI_IFF_INTERROGATION_UNSOL_PL)


class sHMI_TRACK_DISTRIBUTION_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_TRACK_DISTRIBUTION_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4ThreatTrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4ThreatTrackNumber")
        self.u4DestinationCount = clsAdcsBaseType("U4", 0)
        self.u4DestinationCount.vSetMin(1)
        self.u4DestinationCount.vSetMax(100)
        self.vAddType("u4DestinationCount")
        self.au4DestinationTrackNumbers = clsAdcsBaseType("U4:100", 0)
        self.vAddType("au4DestinationTrackNumbers")


vAddClass("sHMI_TRACK_DISTRIBUTION_UNSOL_PL", sHMI_TRACK_DISTRIBUTION_UNSOL_PL)


class sHMI_MESSAGE_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_MESSAGE_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4MessageId = clsAdcsBaseType("U4", 0)
        self.vAddType("u4MessageId")
        self.sMessage = sADCS_STRING1024()
        self.vAddType("sMessage")
        self.u4DestinationCount = clsAdcsBaseType("U4", 0)
        self.u4DestinationCount.vSetMin(1)
        self.u4DestinationCount.vSetMax(100)
        self.vAddType("u4DestinationCount")
        self.au4DestinationTrackNumbers = clsAdcsBaseType("U4:100", 0)
        self.vAddType("au4DestinationTrackNumbers")


vAddClass("sHMI_MESSAGE_UNSOL_PL", sHMI_MESSAGE_UNSOL_PL)


class sHMI_MESSAGE_ACKNOWLEDGEMENT_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sHMI_MESSAGE_ACKNOWLEDGEMENT_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4Type = clsAdcsBaseType("U4", 0)
        self.vAddType("u4Type")
        self.u4Source = clsAdcsBaseType("U4", 0)
        self.vAddType("u4Source")
        self.u4Destination = clsAdcsBaseType("U4", 0)
        self.vAddType("u4Destination")


vAddClass("sHMI_MESSAGE_ACKNOWLEDGEMENT_UNSOL_PL", sHMI_MESSAGE_ACKNOWLEDGEMENT_UNSOL_PL)


# PAYLOADS END

# MESSAGES START
class sHMI_STATUS_REPORT_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_STATUS_REPORT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_STATUS_REPORT_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_STATUS_REPORT_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_STATUS_REPORT_UNSOL", sHMI_STATUS_REPORT_UNSOL)


class sHMI_END_OF_SETUP_CMD(clsAdcsMessageType):
    """Public class definition of type sHMI_END_OF_SETUP_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_END_OF_SETUP_CMD_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_END_OF_SETUP_CMD", sHMI_END_OF_SETUP_CMD)


class sHMI_END_OF_SETUP_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sHMI_END_OF_SETUP_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_END_OF_SETUP_CMD_RSP_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_END_OF_SETUP_CMD_RSP", sHMI_END_OF_SETUP_CMD_RSP)


class sHMI_END_OF_READY_CMD(clsAdcsMessageType):
    """Public class definition of type sHMI_END_OF_READY_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_END_OF_READY_CMD_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_END_OF_READY_CMD", sHMI_END_OF_READY_CMD)


class sHMI_END_OF_READY_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sHMI_END_OF_READY_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_END_OF_READY_CMD_RSP_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_END_OF_READY_CMD_RSP", sHMI_END_OF_READY_CMD_RSP)


class sHMI_SHUTDOWN_CMD(clsAdcsMessageType):
    """Public class definition of type sHMI_SHUTDOWN_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_SHUTDOWN_CMD_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_SHUTDOWN_CMD", sHMI_SHUTDOWN_CMD)


class sHMI_SHUTDOWN_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sHMI_SHUTDOWN_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_SHUTDOWN_CMD_RSP_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_SHUTDOWN_CMD_RSP", sHMI_SHUTDOWN_CMD_RSP)


class sHMI_SHUTDOWN_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_SHUTDOWN_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_SHUTDOWN_UNSOL_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_SHUTDOWN_UNSOL", sHMI_SHUTDOWN_UNSOL)


class sHMI_EMERGENCY_ERASE_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_EMERGENCY_ERASE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_EMERGENCY_ERASE_UNSOL_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_EMERGENCY_ERASE_UNSOL", sHMI_EMERGENCY_ERASE_UNSOL)


class sHMI_ADCS_SHUTDOWN_CMD(clsAdcsMessageType):
    """Public class definition of type sHMI_ADCS_SHUTDOWN_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_ADCS_SHUTDOWN_CMD_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_ADCS_SHUTDOWN_CMD", sHMI_ADCS_SHUTDOWN_CMD)


class sHMI_ADCS_SHUTDOWN_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sHMI_ADCS_SHUTDOWN_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_ADCS_SHUTDOWN_CMD_RSP_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_ADCS_SHUTDOWN_CMD_RSP", sHMI_ADCS_SHUTDOWN_CMD_RSP)


class sHMI_MANUAL_POINT_TRACK_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_MANUAL_POINT_TRACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_MANUAL_POINT_TRACK_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_MANUAL_POINT_TRACK_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_MANUAL_POINT_TRACK_UNSOL", sHMI_MANUAL_POINT_TRACK_UNSOL)


class sHMI_MANUAL_BEARING_TRACK_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_MANUAL_BEARING_TRACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_MANUAL_BEARING_TRACK_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_MANUAL_BEARING_TRACK_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_MANUAL_BEARING_TRACK_UNSOL", sHMI_MANUAL_BEARING_TRACK_UNSOL)


class sHMI_EARLY_WARNING_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_EARLY_WARNING_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_EARLY_WARNING_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_EARLY_WARNING_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_EARLY_WARNING_UNSOL", sHMI_EARLY_WARNING_UNSOL)


class sHMI_HOSTILITY_OVERRIDE_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_HOSTILITY_OVERRIDE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_HOSTILITY_OVERRIDE_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_HOSTILITY_OVERRIDE_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_HOSTILITY_OVERRIDE_UNSOL", sHMI_HOSTILITY_OVERRIDE_UNSOL)


class sHMI_ENVIRONMENT_OVERRIDE_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_ENVIRONMENT_OVERRIDE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_ENVIRONMENT_OVERRIDE_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_ENVIRONMENT_OVERRIDE_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_ENVIRONMENT_OVERRIDE_UNSOL", sHMI_ENVIRONMENT_OVERRIDE_UNSOL)


class sHMI_TYPE_OVERRIDE_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_TYPE_OVERRIDE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_TYPE_OVERRIDE_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_TYPE_OVERRIDE_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_TYPE_OVERRIDE_UNSOL", sHMI_TYPE_OVERRIDE_UNSOL)


class sHMI_DESCRIPTION_OVERRIDE_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_DESCRIPTION_OVERRIDE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_DESCRIPTION_OVERRIDE_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_DESCRIPTION_OVERRIDE_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_DESCRIPTION_OVERRIDE_UNSOL", sHMI_DESCRIPTION_OVERRIDE_UNSOL)


class sHMI_HEIGHT_OVERRIDE_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_HEIGHT_OVERRIDE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_HEIGHT_OVERRIDE_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_HEIGHT_OVERRIDE_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_HEIGHT_OVERRIDE_UNSOL", sHMI_HEIGHT_OVERRIDE_UNSOL)


class sHMI_PLANNED_ENGAGEMENT_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_PLANNED_ENGAGEMENT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_PLANNED_ENGAGEMENT_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_PLANNED_ENGAGEMENT_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_PLANNED_ENGAGEMENT_UNSOL", sHMI_PLANNED_ENGAGEMENT_UNSOL)


class sHMI_ENGAGEMENT_ORDER_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_ENGAGEMENT_ORDER_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_ENGAGEMENT_ORDER_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_ENGAGEMENT_ORDER_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_ENGAGEMENT_ORDER_UNSOL", sHMI_ENGAGEMENT_ORDER_UNSOL)


class sHMI_CANCEL_ENGAGEMENT_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_CANCEL_ENGAGEMENT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_CANCEL_ENGAGEMENT_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_CANCEL_ENGAGEMENT_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_CANCEL_ENGAGEMENT_UNSOL", sHMI_CANCEL_ENGAGEMENT_UNSOL)


class sHMI_LWO_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_LWO_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_LWO_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_LWO_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_LWO_UNSOL", sHMI_LWO_UNSOL)


class sHMI_CANCEL_LWO_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_CANCEL_LWO_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_CANCEL_LWO_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_CANCEL_LWO_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_CANCEL_LWO_UNSOL", sHMI_CANCEL_LWO_UNSOL)


class sHMI_VETO_ENGAGEMENT_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_VETO_ENGAGEMENT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_VETO_ENGAGEMENT_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_VETO_ENGAGEMENT_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_VETO_ENGAGEMENT_UNSOL", sHMI_VETO_ENGAGEMENT_UNSOL)


class sHMI_REVISE_ENGAGEMENT_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_REVISE_ENGAGEMENT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_REVISE_ENGAGEMENT_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_REVISE_ENGAGEMENT_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_REVISE_ENGAGEMENT_UNSOL", sHMI_REVISE_ENGAGEMENT_UNSOL)


class sHMI_CIRCULAR_AIR_ZONE_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_CIRCULAR_AIR_ZONE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_CIRCULAR_AIR_ZONE_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_CIRCULAR_AIR_ZONE_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_CIRCULAR_AIR_ZONE_UNSOL", sHMI_CIRCULAR_AIR_ZONE_UNSOL)


class sHMI_POLYGON_AIR_ZONE_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_POLYGON_AIR_ZONE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_POLYGON_AIR_ZONE_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_POLYGON_AIR_ZONE_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_POLYGON_AIR_ZONE_UNSOL", sHMI_POLYGON_AIR_ZONE_UNSOL)


class sHMI_AIR_LANE_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_AIR_LANE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_AIR_LANE_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_AIR_LANE_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_AIR_LANE_UNSOL", sHMI_AIR_LANE_UNSOL)


class sHMI_FLIGHT_PLAN_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_FLIGHT_PLAN_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_FLIGHT_PLAN_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_FLIGHT_PLAN_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_FLIGHT_PLAN_UNSOL", sHMI_FLIGHT_PLAN_UNSOL)


class sHMI_IFF_LINE_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_IFF_LINE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_IFF_LINE_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_IFF_LINE_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_IFF_LINE_UNSOL", sHMI_IFF_LINE_UNSOL)


class sHMI_EFFECTOR_TRACK_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_EFFECTOR_TRACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_EFFECTOR_TRACK_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_EFFECTOR_TRACK_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_EFFECTOR_TRACK_UNSOL", sHMI_EFFECTOR_TRACK_UNSOL)


class sHMI_ASSET_TRACK_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_ASSET_TRACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_ASSET_TRACK_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_ASSET_TRACK_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_ASSET_TRACK_UNSOL", sHMI_ASSET_TRACK_UNSOL)


class sHMI_SENSOR_TRACK_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_SENSOR_TRACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_SENSOR_TRACK_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_SENSOR_TRACK_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_SENSOR_TRACK_UNSOL", sHMI_SENSOR_TRACK_UNSOL)


class sHMI_PE_TRACK_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_PE_TRACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_PE_TRACK_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_PE_TRACK_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_PE_TRACK_UNSOL", sHMI_PE_TRACK_UNSOL)


class sHMI_OP_TRACK_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_OP_TRACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_OP_TRACK_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_OP_TRACK_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_OP_TRACK_UNSOL", sHMI_OP_TRACK_UNSOL)


class sHMI_OPERATOR_TRACK_DELETE_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_OPERATOR_TRACK_DELETE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_OPERATOR_TRACK_DELETE_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_OPERATOR_TRACK_DELETE_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_OPERATOR_TRACK_DELETE_UNSOL", sHMI_OPERATOR_TRACK_DELETE_UNSOL)


class sHMI_WEAPON_CONTROL_ORDER_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_WEAPON_CONTROL_ORDER_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_WEAPON_CONTROL_ORDER_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_WEAPON_CONTROL_ORDER_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_WEAPON_CONTROL_ORDER_UNSOL", sHMI_WEAPON_CONTROL_ORDER_UNSOL)


class sHMI_AIR_DEFENCE_READINESS_STATE_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_AIR_DEFENCE_READINESS_STATE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_AIR_DEFENCE_READINESS_STATE_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_AIR_DEFENCE_READINESS_STATE_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_AIR_DEFENCE_READINESS_STATE_UNSOL", sHMI_AIR_DEFENCE_READINESS_STATE_UNSOL)


class sHMI_AIR_RAID_WARNING_STATE_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_AIR_RAID_WARNING_STATE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_AIR_RAID_WARNING_STATE_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_AIR_RAID_WARNING_STATE_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_AIR_RAID_WARNING_STATE_UNSOL", sHMI_AIR_RAID_WARNING_STATE_UNSOL)


class sHMI_AOR_CENTRE_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_AOR_CENTRE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_AOR_CENTRE_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_AOR_CENTRE_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_AOR_CENTRE_UNSOL", sHMI_AOR_CENTRE_UNSOL)


class sHMI_ROE_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_ROE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_ROE_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_ROE_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_ROE_UNSOL", sHMI_ROE_UNSOL)


class sHMI_EXCLUSION_BOUNDARIES_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_EXCLUSION_BOUNDARIES_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_EXCLUSION_BOUNDARIES_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_EXCLUSION_BOUNDARIES_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_EXCLUSION_BOUNDARIES_UNSOL", sHMI_EXCLUSION_BOUNDARIES_UNSOL)


class sHMI_IFF_INTERROGATION_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_IFF_INTERROGATION_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_IFF_INTERROGATION_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_IFF_INTERROGATION_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_IFF_INTERROGATION_UNSOL", sHMI_IFF_INTERROGATION_UNSOL)


class sHMI_TRACK_DISTRIBUTION_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_TRACK_DISTRIBUTION_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_TRACK_DISTRIBUTION_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_TRACK_DISTRIBUTION_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_TRACK_DISTRIBUTION_UNSOL", sHMI_TRACK_DISTRIBUTION_UNSOL)


class sHMI_MESSAGE_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_MESSAGE_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_MESSAGE_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_MESSAGE_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_MESSAGE_UNSOL", sHMI_MESSAGE_UNSOL)


class sHMI_MESSAGE_ACKNOWLEDGEMENT_UNSOL(clsAdcsMessageType):
    """Public class definition of type sHMI_MESSAGE_ACKNOWLEDGEMENT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sHMI_MESSAGE_ACKNOWLEDGEMENT_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sHMI_MESSAGE_ACKNOWLEDGEMENT_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sHMI_MESSAGE_ACKNOWLEDGEMENT_UNSOL", sHMI_MESSAGE_ACKNOWLEDGEMENT_UNSOL)


# MESSAGES END




