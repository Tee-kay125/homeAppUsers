#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:32:42 SAST

    This module is the mqtt client on connect class, generated automatically from XML file(s). Its intended use is as a class
    with mqtt callbacks for on_connect() and on_message(). This class should be instantiated before the mqtt connect. The mqtt 
    on_connect() callback should be redirected as -> client.on_connect = objClsMqttAutogenHandler.vOnConnect
    It should be noted that all operations inside this class will execute inside the mqtt thread. The processing methods in this class
    will validate the incoming messages and reply only if validation failed. Messages which passed validation will be placed in a queue provided to
    the constructor of the class. 

"""
# ==========================================================
# AUTOGEN START
# ==========================================================
import logging  # This is required to be able to log if there are problems
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
import queue  # This is required to put the received message in a queue to pass on to another non-mqtt thread
from copy import deepcopy  # This is required to make a deepcopy of the message before insertion in the queue - it ensures proper garbage collection
from Autogen.mw_common_types import E2_MW_MESSAGE_STATUS
from Autogen.eiu_msg import *  # noqa: F401

# ==========================================================
# MQTT TEMPLATE CLASS START
# ==========================================================


class clsMqttAutogenHandler():
    """ This is the MQTT message handling autogen base class

    This is the MQTT message handling autogen base class. An instance of this class should be made before giving the mqtt client
    a on_connect() callback from this class.

    Args:
        objQueuePar (queue.Queue): The first parameter. The instance of the python queue into which we will push messages received
        bLoggingEnabledPar (bool): The second parameter. A boolean flag indicating if logging should be done or not. This parameter is by default True

    """
    def __init__(self, objQueuePar: queue.Queue, bLoggingEnabledPar: bool = True):
        super().__init__()
        self._bLoggingEnabled = bLoggingEnabledPar
        self._objQueue = objQueuePar
        # By default all subscriptions will auto reply if a ReplyMsg was specified
        self.bAutoReplyForSubscriptionEiuEndOfSetupCmd = True
        self.bAutoReplyForSubscriptionEiuEndOfReadyCmd = True
        self.bAutoReplyForSubscriptionEiuShutdownCmd = True

    def vOnConnect(self, objMqttClientPar: mqtt.Client, userDataPar, dctFlags, iConnectionResult: int) -> None:  # pylint: disable=W0613
        """ This is the callback method for when client receives a CONNACK response from the server

        This is the callback method for when client receives a CONNACK response from the server. This method subscribes
        and registers callback methods for all incoming messages. Messages from secondary XML files will not automatically be
        subscribed to. The on message callbacks will however all automatically be registered even for secondary XML files.

        Args:
            objMqttClientPar (obj): The first parameter. A MQTT client object
            userDataPar: The second parameter. The private user data as set in Client() or userdata_set()
            flags: The third parameter. flags is a dict that contains response flags from the broker:
            rc: The fourth parameter. The connection result

        Returns:

        Raises:
            Raises no exceptions
        """

        # Subscribing and adding callback for EiuEndOfSetupCmd 
        # Subscribing and adding callback for EiuEndOfSetupCmd 
        # Subscribing and adding callback for EiuEndOfSetupCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message EiuEndOfSetupCmd  with topic ADCS/EIU/EiuEndOfSetupCmd")

        try:
            objMqttClientPar.subscribe("ADCS/EIU/EiuEndOfSetupCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message EiuEndOfSetupCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for EiuEndOfSetupCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/EIU/EiuEndOfSetupCmd", self.vOnMessageCallbackEiuEndOfSetupCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for EiuEndOfSetupCmd  - Exception %s", str(E))
        # Subscribing and adding callback for EiuEndOfReadyCmd 
        # Subscribing and adding callback for EiuEndOfReadyCmd 
        # Subscribing and adding callback for EiuEndOfReadyCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message EiuEndOfReadyCmd  with topic ADCS/EIU/EiuEndOfReadyCmd")

        try:
            objMqttClientPar.subscribe("ADCS/EIU/EiuEndOfReadyCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message EiuEndOfReadyCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for EiuEndOfReadyCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/EIU/EiuEndOfReadyCmd", self.vOnMessageCallbackEiuEndOfReadyCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for EiuEndOfReadyCmd  - Exception %s", str(E))
        # Subscribing and adding callback for EiuShutdownCmd 
        # Subscribing and adding callback for EiuShutdownCmd 
        # Subscribing and adding callback for EiuShutdownCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message EiuShutdownCmd  with topic ADCS/EIU/EiuShutdownCmd")

        try:
            objMqttClientPar.subscribe("ADCS/EIU/EiuShutdownCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message EiuShutdownCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for EiuShutdownCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/EIU/EiuShutdownCmd", self.vOnMessageCallbackEiuShutdownCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for EiuShutdownCmd  - Exception %s", str(E))

        return

# =========================================================="
# MQTT CALLBACK METHODS START
# =========================================================="

    def vOnMessageCallbackEiuEndOfSetupCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message EiuEndOfSetupCmd

        This is a public method callback for message EiuEndOfSetupCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objEiuEndOfSetupCmd = sEIU_END_OF_SETUP_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objEiuEndOfSetupCmdRsp = sEIU_END_OF_SETUP_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuEndOfSetupCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuEndOfSetupCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuEndOfSetupCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objEiuEndOfSetupCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuEndOfSetupCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objEiuEndOfSetupCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for EiuEndOfSetupCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objEiuEndOfSetupCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message EiuEndOfSetupCmd  validation failed")
            elif (objEiuEndOfSetupCmd.sMsgHeader.u2MsgLength.Value != (objEiuEndOfSetupCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message EiuEndOfSetupCmd  length field is invalid - it is %d and should be %d bytes", objEiuEndOfSetupCmd.sMsgHeader.u2MsgLength.Value, objEiuEndOfSetupCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/EIU/EiuEndOfSetupCmd", "Class": sEIU_END_OF_SETUP_CMD, "ClassName": "sEIU_END_OF_SETUP_CMD", "acRole": "", "MsgObject": deepcopy(objEiuEndOfSetupCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/EIU/EiuEndOfSetupCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionEiuEndOfSetupCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objEiuEndOfSetupCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/EIU/EiuEndOfSetupCmdRsp", objEiuEndOfSetupCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("EiuEndOfSetupCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackEiuEndOfReadyCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message EiuEndOfReadyCmd

        This is a public method callback for message EiuEndOfReadyCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objEiuEndOfReadyCmd = sEIU_END_OF_READY_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objEiuEndOfReadyCmdRsp = sEIU_END_OF_READY_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuEndOfReadyCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuEndOfReadyCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuEndOfReadyCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objEiuEndOfReadyCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuEndOfReadyCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objEiuEndOfReadyCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for EiuEndOfReadyCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objEiuEndOfReadyCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message EiuEndOfReadyCmd  validation failed")
            elif (objEiuEndOfReadyCmd.sMsgHeader.u2MsgLength.Value != (objEiuEndOfReadyCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message EiuEndOfReadyCmd  length field is invalid - it is %d and should be %d bytes", objEiuEndOfReadyCmd.sMsgHeader.u2MsgLength.Value, objEiuEndOfReadyCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/EIU/EiuEndOfReadyCmd", "Class": sEIU_END_OF_READY_CMD, "ClassName": "sEIU_END_OF_READY_CMD", "acRole": "", "MsgObject": deepcopy(objEiuEndOfReadyCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/EIU/EiuEndOfReadyCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionEiuEndOfReadyCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objEiuEndOfReadyCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/EIU/EiuEndOfReadyCmdRsp", objEiuEndOfReadyCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("EiuEndOfReadyCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackEiuShutdownCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message EiuShutdownCmd

        This is a public method callback for message EiuShutdownCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objEiuShutdownCmd = sEIU_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objEiuShutdownCmdRsp = sEIU_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuShutdownCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuShutdownCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuShutdownCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objEiuShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuShutdownCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objEiuShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for EiuShutdownCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objEiuShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message EiuShutdownCmd  validation failed")
            elif (objEiuShutdownCmd.sMsgHeader.u2MsgLength.Value != (objEiuShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message EiuShutdownCmd  length field is invalid - it is %d and should be %d bytes", objEiuShutdownCmd.sMsgHeader.u2MsgLength.Value, objEiuShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/EIU/EiuShutdownCmd", "Class": sEIU_SHUTDOWN_CMD, "ClassName": "sEIU_SHUTDOWN_CMD", "acRole": "", "MsgObject": deepcopy(objEiuShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/EIU/EiuShutdownCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionEiuShutdownCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objEiuShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/EIU/EiuShutdownCmdRsp", objEiuShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("EiuShutdownCmd's publish threw exception - %s", str(E))

        return
# ==========================================================
# MQTT CALLBACK METHODS STOP
# ==========================================================
# ==========================================================
# MQTT SUBSCRIPTION METHODS START
# ==========================================================

    def vSubscribeMessageEiuEndOfSetupCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message EiuEndOfSetupCmd.

        This is the auto generated method for subscribing message EiuEndOfSetupCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for EiuEndOfSetupCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/EIU/EiuEndOfSetupCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message EiuEndOfSetupCmd  - Exception %s", str(E))

        return

    def vSubscribeMessageEiuEndOfReadyCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message EiuEndOfReadyCmd.

        This is the auto generated method for subscribing message EiuEndOfReadyCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for EiuEndOfReadyCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/EIU/EiuEndOfReadyCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message EiuEndOfReadyCmd  - Exception %s", str(E))

        return

    def vSubscribeMessageEiuShutdownCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message EiuShutdownCmd.

        This is the auto generated method for subscribing message EiuShutdownCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for EiuShutdownCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/EIU/EiuShutdownCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message EiuShutdownCmd  - Exception %s", str(E))

        return

# ==========================================================
# MQTT SUBSCRIPTION METHODS START
# ==========================================================
# ==========================================================
# MQTT TEMPLATE CLASS STOP
# ==========================================================
# ==========================================================
# AUTOGEN STOP
# ==========================================================