#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:32:41 SAST

    This module is the mqtt client on connect class, generated automatically from XML file(s). Its intended use is as a class
    with mqtt callbacks for on_connect() and on_message(). This class should be instantiated before the mqtt connect. The mqtt 
    on_connect() callback should be redirected as -> client.on_connect = objClsMqttAutogenHandler.vOnConnect
    It should be noted that all operations inside this class will execute inside the mqtt thread. The processing methods in this class
    will validate the incoming messages and reply only if validation failed. Messages which passed validation will be placed in a queue provided to
    the constructor of the class. 

"""
# ==========================================================
# AUTOGEN START
# ==========================================================
import logging  # This is required to be able to log if there are problems
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
import queue  # This is required to put the received message in a queue to pass on to another non-mqtt thread
from copy import deepcopy  # This is required to make a deepcopy of the message before insertion in the queue - it ensures proper garbage collection
from Autogen.mw_common_types import E2_MW_MESSAGE_STATUS
from Autogen.dsf_msg import *  # noqa: F401
from Autogen.tewa_msg import *  # noqa: F401
from Autogen.tm_msg import *  # noqa: F401
from Autogen.olhm_msg import *  # noqa: F401
from Autogen.hmi_msg import *  # noqa: F401

# ==========================================================
# MQTT TEMPLATE CLASS START
# ==========================================================


class clsMqttAutogenHandler():
    """ This is the MQTT message handling autogen base class

    This is the MQTT message handling autogen base class. An instance of this class should be made before giving the mqtt client
    a on_connect() callback from this class.

    Args:
        objQueuePar (queue.Queue): The first parameter. The instance of the python queue into which we will push messages received
        bLoggingEnabledPar (bool): The second parameter. A boolean flag indicating if logging should be done or not. This parameter is by default True

    """
    def __init__(self, objQueuePar: queue.Queue, bLoggingEnabledPar: bool = True):
        super().__init__()
        self._bLoggingEnabled = bLoggingEnabledPar
        self._objQueue = objQueuePar
        # By default all subscriptions will auto reply if a ReplyMsg was specified
        self.bAutoReplyForSubscriptionHmiEndOfSetupCmdAPM = True
        self.bAutoReplyForSubscriptionHmiEndOfSetupCmdFCO = True
        self.bAutoReplyForSubscriptionHmiEndOfSetupCmdAPM_FCO = True
        self.bAutoReplyForSubscriptionHmiEndOfSetupCmdSPM = True
        self.bAutoReplyForSubscriptionHmiEndOfSetupCmdFUFC = True
        self.bAutoReplyForSubscriptionHmiEndOfSetupCmdSPM_FUFC = True
        self.bAutoReplyForSubscriptionHmiEndOfSetupCmdOversight = True
        self.bAutoReplyForSubscriptionHmiEndOfSetupCmdMaintainer = True
        self.bAutoReplyForSubscriptionHmiEndOfReadyCmdAPM = True
        self.bAutoReplyForSubscriptionHmiEndOfReadyCmdFCO = True
        self.bAutoReplyForSubscriptionHmiEndOfReadyCmdAPM_FCO = True
        self.bAutoReplyForSubscriptionHmiEndOfReadyCmdSPM = True
        self.bAutoReplyForSubscriptionHmiEndOfReadyCmdFUFC = True
        self.bAutoReplyForSubscriptionHmiEndOfReadyCmdSPM_FUFC = True
        self.bAutoReplyForSubscriptionHmiEndOfReadyCmdOversight = True
        self.bAutoReplyForSubscriptionHmiEndOfReadyCmdMaintainer = True
        self.bAutoReplyForSubscriptionHmiShutdownCmdAPM = True
        self.bAutoReplyForSubscriptionHmiShutdownCmdFCO = True
        self.bAutoReplyForSubscriptionHmiShutdownCmdAPM_FCO = True
        self.bAutoReplyForSubscriptionHmiShutdownCmdSPM = True
        self.bAutoReplyForSubscriptionHmiShutdownCmdFUFC = True
        self.bAutoReplyForSubscriptionHmiShutdownCmdSPM_FUFC = True
        self.bAutoReplyForSubscriptionHmiShutdownCmdOversight = True
        self.bAutoReplyForSubscriptionHmiShutdownCmdMaintainer = True
        self.bAutoReplyForSubscriptionOlhmAdcsHmiStatusUnsol = True
        self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdRspAPM = True
        self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdRspFCO = True
        self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdRspAPM_FCO = True
        self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdRspSPM = True
        self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdRspFUFC = True
        self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdRspSPM_FUFC = True
        self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdRspOversight = True
        self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdRspMaintainer = True

    def vOnConnect(self, objMqttClientPar: mqtt.Client, userDataPar, dctFlags, iConnectionResult: int) -> None:  # pylint: disable=W0613
        """ This is the callback method for when client receives a CONNACK response from the server

        This is the callback method for when client receives a CONNACK response from the server. This method subscribes
        and registers callback methods for all incoming messages. Messages from secondary XML files will not automatically be
        subscribed to. The on message callbacks will however all automatically be registered even for secondary XML files.

        Args:
            objMqttClientPar (obj): The first parameter. A MQTT client object
            userDataPar: The second parameter. The private user data as set in Client() or userdata_set()
            flags: The third parameter. flags is a dict that contains response flags from the broker:
            rc: The fourth parameter. The connection result

        Returns:

        Raises:
            Raises no exceptions
        """

        # Subscribing and adding callback for HmiEndOfSetupCmd APM
        # Subscribing and adding callback for HmiEndOfSetupCmd APM
        # Subscribing and adding callback for HmiEndOfSetupCmd APM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfSetupCmd APM with topic ADCS/HMI/HmiEndOfSetupCmd/APM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmd/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmd APM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfSetupCmd APM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfSetupCmd/APM", self.vOnMessageCallbackHmiEndOfSetupCmdAPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfSetupCmd APM - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfSetupCmd FCO
        # Subscribing and adding callback for HmiEndOfSetupCmd FCO
        # Subscribing and adding callback for HmiEndOfSetupCmd FCO

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfSetupCmd FCO with topic ADCS/HMI/HmiEndOfSetupCmd/FCO")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmd/FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmd FCO - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfSetupCmd FCO")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfSetupCmd/FCO", self.vOnMessageCallbackHmiEndOfSetupCmdFCO)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfSetupCmd FCO - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfSetupCmd APM_FCO
        # Subscribing and adding callback for HmiEndOfSetupCmd APM_FCO
        # Subscribing and adding callback for HmiEndOfSetupCmd APM_FCO

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfSetupCmd APM_FCO with topic ADCS/HMI/HmiEndOfSetupCmd/APM_FCO")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmd/APM_FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmd APM_FCO - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfSetupCmd APM_FCO")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfSetupCmd/APM_FCO", self.vOnMessageCallbackHmiEndOfSetupCmdAPM_FCO)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfSetupCmd APM_FCO - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfSetupCmd SPM
        # Subscribing and adding callback for HmiEndOfSetupCmd SPM
        # Subscribing and adding callback for HmiEndOfSetupCmd SPM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfSetupCmd SPM with topic ADCS/HMI/HmiEndOfSetupCmd/SPM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmd/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmd SPM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfSetupCmd SPM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfSetupCmd/SPM", self.vOnMessageCallbackHmiEndOfSetupCmdSPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfSetupCmd SPM - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfSetupCmd FUFC
        # Subscribing and adding callback for HmiEndOfSetupCmd FUFC
        # Subscribing and adding callback for HmiEndOfSetupCmd FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfSetupCmd FUFC with topic ADCS/HMI/HmiEndOfSetupCmd/FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmd/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmd FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfSetupCmd FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfSetupCmd/FUFC", self.vOnMessageCallbackHmiEndOfSetupCmdFUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfSetupCmd FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfSetupCmd SPM_FUFC
        # Subscribing and adding callback for HmiEndOfSetupCmd SPM_FUFC
        # Subscribing and adding callback for HmiEndOfSetupCmd SPM_FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfSetupCmd SPM_FUFC with topic ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmd SPM_FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfSetupCmd SPM_FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC", self.vOnMessageCallbackHmiEndOfSetupCmdSPM_FUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfSetupCmd SPM_FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfSetupCmd Oversight
        # Subscribing and adding callback for HmiEndOfSetupCmd Oversight
        # Subscribing and adding callback for HmiEndOfSetupCmd Oversight

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfSetupCmd Oversight with topic ADCS/HMI/HmiEndOfSetupCmd/Oversight")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmd/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmd Oversight - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfSetupCmd Oversight")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfSetupCmd/Oversight", self.vOnMessageCallbackHmiEndOfSetupCmdOversight)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfSetupCmd Oversight - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfSetupCmd Maintainer
        # Subscribing and adding callback for HmiEndOfSetupCmd Maintainer
        # Subscribing and adding callback for HmiEndOfSetupCmd Maintainer

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfSetupCmd Maintainer with topic ADCS/HMI/HmiEndOfSetupCmd/Maintainer")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmd/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmd Maintainer - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfSetupCmd Maintainer")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfSetupCmd/Maintainer", self.vOnMessageCallbackHmiEndOfSetupCmdMaintainer)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfSetupCmd Maintainer - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfReadyCmd APM
        # Subscribing and adding callback for HmiEndOfReadyCmd APM
        # Subscribing and adding callback for HmiEndOfReadyCmd APM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfReadyCmd APM with topic ADCS/HMI/HmiEndOfReadyCmd/APM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmd/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmd APM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfReadyCmd APM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfReadyCmd/APM", self.vOnMessageCallbackHmiEndOfReadyCmdAPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfReadyCmd APM - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfReadyCmd FCO
        # Subscribing and adding callback for HmiEndOfReadyCmd FCO
        # Subscribing and adding callback for HmiEndOfReadyCmd FCO

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfReadyCmd FCO with topic ADCS/HMI/HmiEndOfReadyCmd/FCO")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmd/FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmd FCO - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfReadyCmd FCO")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfReadyCmd/FCO", self.vOnMessageCallbackHmiEndOfReadyCmdFCO)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfReadyCmd FCO - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfReadyCmd APM_FCO
        # Subscribing and adding callback for HmiEndOfReadyCmd APM_FCO
        # Subscribing and adding callback for HmiEndOfReadyCmd APM_FCO

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfReadyCmd APM_FCO with topic ADCS/HMI/HmiEndOfReadyCmd/APM_FCO")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmd/APM_FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmd APM_FCO - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfReadyCmd APM_FCO")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfReadyCmd/APM_FCO", self.vOnMessageCallbackHmiEndOfReadyCmdAPM_FCO)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfReadyCmd APM_FCO - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfReadyCmd SPM
        # Subscribing and adding callback for HmiEndOfReadyCmd SPM
        # Subscribing and adding callback for HmiEndOfReadyCmd SPM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfReadyCmd SPM with topic ADCS/HMI/HmiEndOfReadyCmd/SPM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmd/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmd SPM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfReadyCmd SPM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfReadyCmd/SPM", self.vOnMessageCallbackHmiEndOfReadyCmdSPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfReadyCmd SPM - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfReadyCmd FUFC
        # Subscribing and adding callback for HmiEndOfReadyCmd FUFC
        # Subscribing and adding callback for HmiEndOfReadyCmd FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfReadyCmd FUFC with topic ADCS/HMI/HmiEndOfReadyCmd/FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmd/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmd FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfReadyCmd FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfReadyCmd/FUFC", self.vOnMessageCallbackHmiEndOfReadyCmdFUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfReadyCmd FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfReadyCmd SPM_FUFC
        # Subscribing and adding callback for HmiEndOfReadyCmd SPM_FUFC
        # Subscribing and adding callback for HmiEndOfReadyCmd SPM_FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfReadyCmd SPM_FUFC with topic ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmd SPM_FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfReadyCmd SPM_FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC", self.vOnMessageCallbackHmiEndOfReadyCmdSPM_FUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfReadyCmd SPM_FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfReadyCmd Oversight
        # Subscribing and adding callback for HmiEndOfReadyCmd Oversight
        # Subscribing and adding callback for HmiEndOfReadyCmd Oversight

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfReadyCmd Oversight with topic ADCS/HMI/HmiEndOfReadyCmd/Oversight")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmd/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmd Oversight - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfReadyCmd Oversight")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfReadyCmd/Oversight", self.vOnMessageCallbackHmiEndOfReadyCmdOversight)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfReadyCmd Oversight - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfReadyCmd Maintainer
        # Subscribing and adding callback for HmiEndOfReadyCmd Maintainer
        # Subscribing and adding callback for HmiEndOfReadyCmd Maintainer

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfReadyCmd Maintainer with topic ADCS/HMI/HmiEndOfReadyCmd/Maintainer")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmd/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmd Maintainer - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfReadyCmd Maintainer")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfReadyCmd/Maintainer", self.vOnMessageCallbackHmiEndOfReadyCmdMaintainer)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfReadyCmd Maintainer - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownCmd APM
        # Subscribing and adding callback for HmiShutdownCmd APM
        # Subscribing and adding callback for HmiShutdownCmd APM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownCmd APM with topic ADCS/HMI/HmiShutdownCmd/APM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmd/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmd APM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownCmd APM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownCmd/APM", self.vOnMessageCallbackHmiShutdownCmdAPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownCmd APM - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownCmd FCO
        # Subscribing and adding callback for HmiShutdownCmd FCO
        # Subscribing and adding callback for HmiShutdownCmd FCO

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownCmd FCO with topic ADCS/HMI/HmiShutdownCmd/FCO")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmd/FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmd FCO - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownCmd FCO")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownCmd/FCO", self.vOnMessageCallbackHmiShutdownCmdFCO)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownCmd FCO - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownCmd APM_FCO
        # Subscribing and adding callback for HmiShutdownCmd APM_FCO
        # Subscribing and adding callback for HmiShutdownCmd APM_FCO

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownCmd APM_FCO with topic ADCS/HMI/HmiShutdownCmd/APM_FCO")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmd/APM_FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmd APM_FCO - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownCmd APM_FCO")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownCmd/APM_FCO", self.vOnMessageCallbackHmiShutdownCmdAPM_FCO)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownCmd APM_FCO - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownCmd SPM
        # Subscribing and adding callback for HmiShutdownCmd SPM
        # Subscribing and adding callback for HmiShutdownCmd SPM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownCmd SPM with topic ADCS/HMI/HmiShutdownCmd/SPM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmd/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmd SPM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownCmd SPM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownCmd/SPM", self.vOnMessageCallbackHmiShutdownCmdSPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownCmd SPM - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownCmd FUFC
        # Subscribing and adding callback for HmiShutdownCmd FUFC
        # Subscribing and adding callback for HmiShutdownCmd FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownCmd FUFC with topic ADCS/HMI/HmiShutdownCmd/FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmd/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmd FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownCmd FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownCmd/FUFC", self.vOnMessageCallbackHmiShutdownCmdFUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownCmd FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownCmd SPM_FUFC
        # Subscribing and adding callback for HmiShutdownCmd SPM_FUFC
        # Subscribing and adding callback for HmiShutdownCmd SPM_FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownCmd SPM_FUFC with topic ADCS/HMI/HmiShutdownCmd/SPM_FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmd/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmd SPM_FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownCmd SPM_FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownCmd/SPM_FUFC", self.vOnMessageCallbackHmiShutdownCmdSPM_FUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownCmd SPM_FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownCmd Oversight
        # Subscribing and adding callback for HmiShutdownCmd Oversight
        # Subscribing and adding callback for HmiShutdownCmd Oversight

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownCmd Oversight with topic ADCS/HMI/HmiShutdownCmd/Oversight")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmd/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmd Oversight - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownCmd Oversight")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownCmd/Oversight", self.vOnMessageCallbackHmiShutdownCmdOversight)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownCmd Oversight - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownCmd Maintainer
        # Subscribing and adding callback for HmiShutdownCmd Maintainer
        # Subscribing and adding callback for HmiShutdownCmd Maintainer

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownCmd Maintainer with topic ADCS/HMI/HmiShutdownCmd/Maintainer")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmd/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmd Maintainer - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownCmd Maintainer")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownCmd/Maintainer", self.vOnMessageCallbackHmiShutdownCmdMaintainer)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownCmd Maintainer - Exception %s", str(E))
        # Subscribing and adding callback for OlhmAdcsHmiStatusUnsol 
        # Subscribing and adding callback for OlhmAdcsHmiStatusUnsol 
        # Subscribing and adding callback for OlhmAdcsHmiStatusUnsol 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message OlhmAdcsHmiStatusUnsol  with topic ADCS/HMI/OlhmAdcsHmiStatusUnsol")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/OlhmAdcsHmiStatusUnsol", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message OlhmAdcsHmiStatusUnsol  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for OlhmAdcsHmiStatusUnsol ")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/OlhmAdcsHmiStatusUnsol", self.vOnMessageCallbackOlhmAdcsHmiStatusUnsol)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for OlhmAdcsHmiStatusUnsol  - Exception %s", str(E))
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp APM
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp APM
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp APM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiAdcsShutdownCmdRsp APM with topic ADCS/HMI/HmiAdcsShutdownCmdRsp/APM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmdRsp/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmdRsp APM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiAdcsShutdownCmdRsp APM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiAdcsShutdownCmdRsp/APM", self.vOnMessageCallbackHmiAdcsShutdownCmdRspAPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiAdcsShutdownCmdRsp APM - Exception %s", str(E))
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp FCO
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp FCO
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp FCO

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiAdcsShutdownCmdRsp FCO with topic ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmdRsp FCO - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiAdcsShutdownCmdRsp FCO")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO", self.vOnMessageCallbackHmiAdcsShutdownCmdRspFCO)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiAdcsShutdownCmdRsp FCO - Exception %s", str(E))
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp APM_FCO
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp APM_FCO
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp APM_FCO

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiAdcsShutdownCmdRsp APM_FCO with topic ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmdRsp APM_FCO - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiAdcsShutdownCmdRsp APM_FCO")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO", self.vOnMessageCallbackHmiAdcsShutdownCmdRspAPM_FCO)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiAdcsShutdownCmdRsp APM_FCO - Exception %s", str(E))
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp SPM
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp SPM
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp SPM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiAdcsShutdownCmdRsp SPM with topic ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmdRsp SPM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiAdcsShutdownCmdRsp SPM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM", self.vOnMessageCallbackHmiAdcsShutdownCmdRspSPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiAdcsShutdownCmdRsp SPM - Exception %s", str(E))
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp FUFC
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp FUFC
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiAdcsShutdownCmdRsp FUFC with topic ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmdRsp FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiAdcsShutdownCmdRsp FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC", self.vOnMessageCallbackHmiAdcsShutdownCmdRspFUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiAdcsShutdownCmdRsp FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp SPM_FUFC
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp SPM_FUFC
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp SPM_FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiAdcsShutdownCmdRsp SPM_FUFC with topic ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmdRsp SPM_FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiAdcsShutdownCmdRsp SPM_FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC", self.vOnMessageCallbackHmiAdcsShutdownCmdRspSPM_FUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiAdcsShutdownCmdRsp SPM_FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp Oversight
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp Oversight
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp Oversight

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiAdcsShutdownCmdRsp Oversight with topic ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmdRsp Oversight - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiAdcsShutdownCmdRsp Oversight")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight", self.vOnMessageCallbackHmiAdcsShutdownCmdRspOversight)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiAdcsShutdownCmdRsp Oversight - Exception %s", str(E))
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp Maintainer
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp Maintainer
        # Subscribing and adding callback for HmiAdcsShutdownCmdRsp Maintainer

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiAdcsShutdownCmdRsp Maintainer with topic ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmdRsp Maintainer - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiAdcsShutdownCmdRsp Maintainer")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer", self.vOnMessageCallbackHmiAdcsShutdownCmdRspMaintainer)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiAdcsShutdownCmdRsp Maintainer - Exception %s", str(E))

        return

# =========================================================="
# MQTT CALLBACK METHODS START
# =========================================================="

    def vOnMessageCallbackHmiEndOfSetupCmdAPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfSetupCmdAPM

        This is a public method callback for message HmiEndOfSetupCmdAPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfSetupCmd = sHMI_END_OF_SETUP_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiEndOfSetupCmdRsp = sHMI_END_OF_SETUP_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd APM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd APM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd APM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfSetupCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd APM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfSetupCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfSetupCmd APM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfSetupCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmd APM validation failed")
            elif (objHmiEndOfSetupCmd.sMsgHeader.u2MsgLength.Value != (objHmiEndOfSetupCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmd APM length field is invalid - it is %d and should be %d bytes", objHmiEndOfSetupCmd.sMsgHeader.u2MsgLength.Value, objHmiEndOfSetupCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfSetupCmd/APM", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "acRole": "APM", "MsgObject": deepcopy(objHmiEndOfSetupCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfSetupCmd/APM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiEndOfSetupCmdAPM is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiEndOfSetupCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/APM", objHmiEndOfSetupCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiEndOfSetupCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiEndOfSetupCmdFCO(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfSetupCmdFCO

        This is a public method callback for message HmiEndOfSetupCmdFCO. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfSetupCmd = sHMI_END_OF_SETUP_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiEndOfSetupCmdRsp = sHMI_END_OF_SETUP_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd FCO objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd FCO objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd FCO objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfSetupCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd FCO length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfSetupCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfSetupCmd FCO - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfSetupCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmd FCO validation failed")
            elif (objHmiEndOfSetupCmd.sMsgHeader.u2MsgLength.Value != (objHmiEndOfSetupCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmd FCO length field is invalid - it is %d and should be %d bytes", objHmiEndOfSetupCmd.sMsgHeader.u2MsgLength.Value, objHmiEndOfSetupCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfSetupCmd/FCO", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "acRole": "FCO", "MsgObject": deepcopy(objHmiEndOfSetupCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfSetupCmd/FCO")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiEndOfSetupCmdFCO is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiEndOfSetupCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/FCO", objHmiEndOfSetupCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiEndOfSetupCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiEndOfSetupCmdAPM_FCO(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfSetupCmdAPM_FCO

        This is a public method callback for message HmiEndOfSetupCmdAPM_FCO. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfSetupCmd = sHMI_END_OF_SETUP_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiEndOfSetupCmdRsp = sHMI_END_OF_SETUP_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd APM_FCO objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd APM_FCO objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd APM_FCO objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfSetupCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd APM_FCO length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfSetupCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfSetupCmd APM_FCO - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfSetupCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmd APM_FCO validation failed")
            elif (objHmiEndOfSetupCmd.sMsgHeader.u2MsgLength.Value != (objHmiEndOfSetupCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmd APM_FCO length field is invalid - it is %d and should be %d bytes", objHmiEndOfSetupCmd.sMsgHeader.u2MsgLength.Value, objHmiEndOfSetupCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfSetupCmd/APM_FCO", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "acRole": "APM_FCO", "MsgObject": deepcopy(objHmiEndOfSetupCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfSetupCmd/APM_FCO")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiEndOfSetupCmdAPM_FCO is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiEndOfSetupCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FCO", objHmiEndOfSetupCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiEndOfSetupCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiEndOfSetupCmdSPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfSetupCmdSPM

        This is a public method callback for message HmiEndOfSetupCmdSPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfSetupCmd = sHMI_END_OF_SETUP_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiEndOfSetupCmdRsp = sHMI_END_OF_SETUP_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd SPM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd SPM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd SPM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfSetupCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd SPM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfSetupCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfSetupCmd SPM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfSetupCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmd SPM validation failed")
            elif (objHmiEndOfSetupCmd.sMsgHeader.u2MsgLength.Value != (objHmiEndOfSetupCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmd SPM length field is invalid - it is %d and should be %d bytes", objHmiEndOfSetupCmd.sMsgHeader.u2MsgLength.Value, objHmiEndOfSetupCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfSetupCmd/SPM", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "acRole": "SPM", "MsgObject": deepcopy(objHmiEndOfSetupCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfSetupCmd/SPM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiEndOfSetupCmdSPM is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiEndOfSetupCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM", objHmiEndOfSetupCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiEndOfSetupCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiEndOfSetupCmdFUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfSetupCmdFUFC

        This is a public method callback for message HmiEndOfSetupCmdFUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfSetupCmd = sHMI_END_OF_SETUP_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiEndOfSetupCmdRsp = sHMI_END_OF_SETUP_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfSetupCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfSetupCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfSetupCmd FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfSetupCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmd FUFC validation failed")
            elif (objHmiEndOfSetupCmd.sMsgHeader.u2MsgLength.Value != (objHmiEndOfSetupCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmd FUFC length field is invalid - it is %d and should be %d bytes", objHmiEndOfSetupCmd.sMsgHeader.u2MsgLength.Value, objHmiEndOfSetupCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfSetupCmd/FUFC", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "acRole": "FUFC", "MsgObject": deepcopy(objHmiEndOfSetupCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfSetupCmd/FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiEndOfSetupCmdFUFC is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiEndOfSetupCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC", objHmiEndOfSetupCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiEndOfSetupCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiEndOfSetupCmdSPM_FUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfSetupCmdSPM_FUFC

        This is a public method callback for message HmiEndOfSetupCmdSPM_FUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfSetupCmd = sHMI_END_OF_SETUP_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiEndOfSetupCmdRsp = sHMI_END_OF_SETUP_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd SPM_FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd SPM_FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd SPM_FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfSetupCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd SPM_FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfSetupCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfSetupCmd SPM_FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfSetupCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmd SPM_FUFC validation failed")
            elif (objHmiEndOfSetupCmd.sMsgHeader.u2MsgLength.Value != (objHmiEndOfSetupCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmd SPM_FUFC length field is invalid - it is %d and should be %d bytes", objHmiEndOfSetupCmd.sMsgHeader.u2MsgLength.Value, objHmiEndOfSetupCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "acRole": "SPM_FUFC", "MsgObject": deepcopy(objHmiEndOfSetupCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiEndOfSetupCmdSPM_FUFC is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiEndOfSetupCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC", objHmiEndOfSetupCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiEndOfSetupCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiEndOfSetupCmdOversight(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfSetupCmdOversight

        This is a public method callback for message HmiEndOfSetupCmdOversight. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfSetupCmd = sHMI_END_OF_SETUP_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiEndOfSetupCmdRsp = sHMI_END_OF_SETUP_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd Oversight objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd Oversight objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd Oversight objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfSetupCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd Oversight length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfSetupCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfSetupCmd Oversight - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfSetupCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmd Oversight validation failed")
            elif (objHmiEndOfSetupCmd.sMsgHeader.u2MsgLength.Value != (objHmiEndOfSetupCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmd Oversight length field is invalid - it is %d and should be %d bytes", objHmiEndOfSetupCmd.sMsgHeader.u2MsgLength.Value, objHmiEndOfSetupCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfSetupCmd/Oversight", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "acRole": "Oversight", "MsgObject": deepcopy(objHmiEndOfSetupCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfSetupCmd/Oversight")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiEndOfSetupCmdOversight is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiEndOfSetupCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight", objHmiEndOfSetupCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiEndOfSetupCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiEndOfSetupCmdMaintainer(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfSetupCmdMaintainer

        This is a public method callback for message HmiEndOfSetupCmdMaintainer. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfSetupCmd = sHMI_END_OF_SETUP_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiEndOfSetupCmdRsp = sHMI_END_OF_SETUP_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd Maintainer objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd Maintainer objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd Maintainer objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfSetupCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmd Maintainer length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfSetupCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfSetupCmd Maintainer - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfSetupCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmd Maintainer validation failed")
            elif (objHmiEndOfSetupCmd.sMsgHeader.u2MsgLength.Value != (objHmiEndOfSetupCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmd Maintainer length field is invalid - it is %d and should be %d bytes", objHmiEndOfSetupCmd.sMsgHeader.u2MsgLength.Value, objHmiEndOfSetupCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfSetupCmd/Maintainer", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "acRole": "Maintainer", "MsgObject": deepcopy(objHmiEndOfSetupCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfSetupCmd/Maintainer")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiEndOfSetupCmdMaintainer is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiEndOfSetupCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer", objHmiEndOfSetupCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiEndOfSetupCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiEndOfReadyCmdAPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfReadyCmdAPM

        This is a public method callback for message HmiEndOfReadyCmdAPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfReadyCmd = sHMI_END_OF_READY_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiEndOfReadyCmdRsp = sHMI_END_OF_READY_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd APM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd APM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd APM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfReadyCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd APM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfReadyCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfReadyCmd APM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfReadyCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmd APM validation failed")
            elif (objHmiEndOfReadyCmd.sMsgHeader.u2MsgLength.Value != (objHmiEndOfReadyCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmd APM length field is invalid - it is %d and should be %d bytes", objHmiEndOfReadyCmd.sMsgHeader.u2MsgLength.Value, objHmiEndOfReadyCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfReadyCmd/APM", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "acRole": "APM", "MsgObject": deepcopy(objHmiEndOfReadyCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfReadyCmd/APM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiEndOfReadyCmdAPM is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiEndOfReadyCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/APM", objHmiEndOfReadyCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiEndOfReadyCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiEndOfReadyCmdFCO(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfReadyCmdFCO

        This is a public method callback for message HmiEndOfReadyCmdFCO. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfReadyCmd = sHMI_END_OF_READY_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiEndOfReadyCmdRsp = sHMI_END_OF_READY_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd FCO objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd FCO objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd FCO objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfReadyCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd FCO length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfReadyCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfReadyCmd FCO - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfReadyCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmd FCO validation failed")
            elif (objHmiEndOfReadyCmd.sMsgHeader.u2MsgLength.Value != (objHmiEndOfReadyCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmd FCO length field is invalid - it is %d and should be %d bytes", objHmiEndOfReadyCmd.sMsgHeader.u2MsgLength.Value, objHmiEndOfReadyCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfReadyCmd/FCO", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "acRole": "FCO", "MsgObject": deepcopy(objHmiEndOfReadyCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfReadyCmd/FCO")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiEndOfReadyCmdFCO is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiEndOfReadyCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/FCO", objHmiEndOfReadyCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiEndOfReadyCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiEndOfReadyCmdAPM_FCO(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfReadyCmdAPM_FCO

        This is a public method callback for message HmiEndOfReadyCmdAPM_FCO. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfReadyCmd = sHMI_END_OF_READY_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiEndOfReadyCmdRsp = sHMI_END_OF_READY_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd APM_FCO objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd APM_FCO objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd APM_FCO objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfReadyCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd APM_FCO length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfReadyCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfReadyCmd APM_FCO - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfReadyCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmd APM_FCO validation failed")
            elif (objHmiEndOfReadyCmd.sMsgHeader.u2MsgLength.Value != (objHmiEndOfReadyCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmd APM_FCO length field is invalid - it is %d and should be %d bytes", objHmiEndOfReadyCmd.sMsgHeader.u2MsgLength.Value, objHmiEndOfReadyCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfReadyCmd/APM_FCO", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "acRole": "APM_FCO", "MsgObject": deepcopy(objHmiEndOfReadyCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfReadyCmd/APM_FCO")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiEndOfReadyCmdAPM_FCO is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiEndOfReadyCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO", objHmiEndOfReadyCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiEndOfReadyCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiEndOfReadyCmdSPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfReadyCmdSPM

        This is a public method callback for message HmiEndOfReadyCmdSPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfReadyCmd = sHMI_END_OF_READY_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiEndOfReadyCmdRsp = sHMI_END_OF_READY_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd SPM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd SPM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd SPM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfReadyCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd SPM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfReadyCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfReadyCmd SPM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfReadyCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmd SPM validation failed")
            elif (objHmiEndOfReadyCmd.sMsgHeader.u2MsgLength.Value != (objHmiEndOfReadyCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmd SPM length field is invalid - it is %d and should be %d bytes", objHmiEndOfReadyCmd.sMsgHeader.u2MsgLength.Value, objHmiEndOfReadyCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfReadyCmd/SPM", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "acRole": "SPM", "MsgObject": deepcopy(objHmiEndOfReadyCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfReadyCmd/SPM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiEndOfReadyCmdSPM is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiEndOfReadyCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM", objHmiEndOfReadyCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiEndOfReadyCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiEndOfReadyCmdFUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfReadyCmdFUFC

        This is a public method callback for message HmiEndOfReadyCmdFUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfReadyCmd = sHMI_END_OF_READY_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiEndOfReadyCmdRsp = sHMI_END_OF_READY_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfReadyCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfReadyCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfReadyCmd FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfReadyCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmd FUFC validation failed")
            elif (objHmiEndOfReadyCmd.sMsgHeader.u2MsgLength.Value != (objHmiEndOfReadyCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmd FUFC length field is invalid - it is %d and should be %d bytes", objHmiEndOfReadyCmd.sMsgHeader.u2MsgLength.Value, objHmiEndOfReadyCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfReadyCmd/FUFC", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "acRole": "FUFC", "MsgObject": deepcopy(objHmiEndOfReadyCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfReadyCmd/FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiEndOfReadyCmdFUFC is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiEndOfReadyCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC", objHmiEndOfReadyCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiEndOfReadyCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiEndOfReadyCmdSPM_FUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfReadyCmdSPM_FUFC

        This is a public method callback for message HmiEndOfReadyCmdSPM_FUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfReadyCmd = sHMI_END_OF_READY_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiEndOfReadyCmdRsp = sHMI_END_OF_READY_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd SPM_FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd SPM_FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd SPM_FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfReadyCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd SPM_FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfReadyCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfReadyCmd SPM_FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfReadyCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmd SPM_FUFC validation failed")
            elif (objHmiEndOfReadyCmd.sMsgHeader.u2MsgLength.Value != (objHmiEndOfReadyCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmd SPM_FUFC length field is invalid - it is %d and should be %d bytes", objHmiEndOfReadyCmd.sMsgHeader.u2MsgLength.Value, objHmiEndOfReadyCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "acRole": "SPM_FUFC", "MsgObject": deepcopy(objHmiEndOfReadyCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiEndOfReadyCmdSPM_FUFC is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiEndOfReadyCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC", objHmiEndOfReadyCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiEndOfReadyCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiEndOfReadyCmdOversight(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfReadyCmdOversight

        This is a public method callback for message HmiEndOfReadyCmdOversight. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfReadyCmd = sHMI_END_OF_READY_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiEndOfReadyCmdRsp = sHMI_END_OF_READY_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd Oversight objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd Oversight objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd Oversight objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfReadyCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd Oversight length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfReadyCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfReadyCmd Oversight - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfReadyCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmd Oversight validation failed")
            elif (objHmiEndOfReadyCmd.sMsgHeader.u2MsgLength.Value != (objHmiEndOfReadyCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmd Oversight length field is invalid - it is %d and should be %d bytes", objHmiEndOfReadyCmd.sMsgHeader.u2MsgLength.Value, objHmiEndOfReadyCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfReadyCmd/Oversight", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "acRole": "Oversight", "MsgObject": deepcopy(objHmiEndOfReadyCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfReadyCmd/Oversight")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiEndOfReadyCmdOversight is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiEndOfReadyCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight", objHmiEndOfReadyCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiEndOfReadyCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiEndOfReadyCmdMaintainer(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfReadyCmdMaintainer

        This is a public method callback for message HmiEndOfReadyCmdMaintainer. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfReadyCmd = sHMI_END_OF_READY_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiEndOfReadyCmdRsp = sHMI_END_OF_READY_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd Maintainer objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd Maintainer objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd Maintainer objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfReadyCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmd Maintainer length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfReadyCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfReadyCmd Maintainer - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfReadyCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmd Maintainer validation failed")
            elif (objHmiEndOfReadyCmd.sMsgHeader.u2MsgLength.Value != (objHmiEndOfReadyCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmd Maintainer length field is invalid - it is %d and should be %d bytes", objHmiEndOfReadyCmd.sMsgHeader.u2MsgLength.Value, objHmiEndOfReadyCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfReadyCmd/Maintainer", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "acRole": "Maintainer", "MsgObject": deepcopy(objHmiEndOfReadyCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfReadyCmd/Maintainer")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiEndOfReadyCmdMaintainer is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiEndOfReadyCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer", objHmiEndOfReadyCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiEndOfReadyCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiShutdownCmdAPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownCmdAPM

        This is a public method callback for message HmiShutdownCmdAPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownCmd = sHMI_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiShutdownCmdRsp = sHMI_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd APM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd APM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd APM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd APM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownCmd APM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmd APM validation failed")
            elif (objHmiShutdownCmd.sMsgHeader.u2MsgLength.Value != (objHmiShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmd APM length field is invalid - it is %d and should be %d bytes", objHmiShutdownCmd.sMsgHeader.u2MsgLength.Value, objHmiShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownCmd/APM", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "acRole": "APM", "MsgObject": deepcopy(objHmiShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownCmd/APM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiShutdownCmdAPM is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiShutdownCmdRsp/APM", objHmiShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiShutdownCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiShutdownCmdFCO(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownCmdFCO

        This is a public method callback for message HmiShutdownCmdFCO. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownCmd = sHMI_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiShutdownCmdRsp = sHMI_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd FCO objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd FCO objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd FCO objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd FCO length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownCmd FCO - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmd FCO validation failed")
            elif (objHmiShutdownCmd.sMsgHeader.u2MsgLength.Value != (objHmiShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmd FCO length field is invalid - it is %d and should be %d bytes", objHmiShutdownCmd.sMsgHeader.u2MsgLength.Value, objHmiShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownCmd/FCO", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "acRole": "FCO", "MsgObject": deepcopy(objHmiShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownCmd/FCO")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiShutdownCmdFCO is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiShutdownCmdRsp/FCO", objHmiShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiShutdownCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiShutdownCmdAPM_FCO(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownCmdAPM_FCO

        This is a public method callback for message HmiShutdownCmdAPM_FCO. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownCmd = sHMI_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiShutdownCmdRsp = sHMI_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd APM_FCO objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd APM_FCO objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd APM_FCO objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd APM_FCO length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownCmd APM_FCO - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmd APM_FCO validation failed")
            elif (objHmiShutdownCmd.sMsgHeader.u2MsgLength.Value != (objHmiShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmd APM_FCO length field is invalid - it is %d and should be %d bytes", objHmiShutdownCmd.sMsgHeader.u2MsgLength.Value, objHmiShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownCmd/APM_FCO", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "acRole": "APM_FCO", "MsgObject": deepcopy(objHmiShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownCmd/APM_FCO")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiShutdownCmdAPM_FCO is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiShutdownCmdRsp/APM_FCO", objHmiShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiShutdownCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiShutdownCmdSPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownCmdSPM

        This is a public method callback for message HmiShutdownCmdSPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownCmd = sHMI_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiShutdownCmdRsp = sHMI_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd SPM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd SPM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd SPM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd SPM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownCmd SPM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmd SPM validation failed")
            elif (objHmiShutdownCmd.sMsgHeader.u2MsgLength.Value != (objHmiShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmd SPM length field is invalid - it is %d and should be %d bytes", objHmiShutdownCmd.sMsgHeader.u2MsgLength.Value, objHmiShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownCmd/SPM", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "acRole": "SPM", "MsgObject": deepcopy(objHmiShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownCmd/SPM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiShutdownCmdSPM is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiShutdownCmdRsp/SPM", objHmiShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiShutdownCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiShutdownCmdFUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownCmdFUFC

        This is a public method callback for message HmiShutdownCmdFUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownCmd = sHMI_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiShutdownCmdRsp = sHMI_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownCmd FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmd FUFC validation failed")
            elif (objHmiShutdownCmd.sMsgHeader.u2MsgLength.Value != (objHmiShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmd FUFC length field is invalid - it is %d and should be %d bytes", objHmiShutdownCmd.sMsgHeader.u2MsgLength.Value, objHmiShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownCmd/FUFC", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "acRole": "FUFC", "MsgObject": deepcopy(objHmiShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownCmd/FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiShutdownCmdFUFC is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiShutdownCmdRsp/FUFC", objHmiShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiShutdownCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiShutdownCmdSPM_FUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownCmdSPM_FUFC

        This is a public method callback for message HmiShutdownCmdSPM_FUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownCmd = sHMI_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiShutdownCmdRsp = sHMI_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd SPM_FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd SPM_FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd SPM_FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd SPM_FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownCmd SPM_FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmd SPM_FUFC validation failed")
            elif (objHmiShutdownCmd.sMsgHeader.u2MsgLength.Value != (objHmiShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmd SPM_FUFC length field is invalid - it is %d and should be %d bytes", objHmiShutdownCmd.sMsgHeader.u2MsgLength.Value, objHmiShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownCmd/SPM_FUFC", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "acRole": "SPM_FUFC", "MsgObject": deepcopy(objHmiShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownCmd/SPM_FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiShutdownCmdSPM_FUFC is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC", objHmiShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiShutdownCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiShutdownCmdOversight(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownCmdOversight

        This is a public method callback for message HmiShutdownCmdOversight. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownCmd = sHMI_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiShutdownCmdRsp = sHMI_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd Oversight objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd Oversight objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd Oversight objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd Oversight length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownCmd Oversight - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmd Oversight validation failed")
            elif (objHmiShutdownCmd.sMsgHeader.u2MsgLength.Value != (objHmiShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmd Oversight length field is invalid - it is %d and should be %d bytes", objHmiShutdownCmd.sMsgHeader.u2MsgLength.Value, objHmiShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownCmd/Oversight", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "acRole": "Oversight", "MsgObject": deepcopy(objHmiShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownCmd/Oversight")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiShutdownCmdOversight is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiShutdownCmdRsp/Oversight", objHmiShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiShutdownCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiShutdownCmdMaintainer(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownCmdMaintainer

        This is a public method callback for message HmiShutdownCmdMaintainer. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownCmd = sHMI_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiShutdownCmdRsp = sHMI_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd Maintainer objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd Maintainer objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd Maintainer objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmd Maintainer length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownCmd Maintainer - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmd Maintainer validation failed")
            elif (objHmiShutdownCmd.sMsgHeader.u2MsgLength.Value != (objHmiShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmd Maintainer length field is invalid - it is %d and should be %d bytes", objHmiShutdownCmd.sMsgHeader.u2MsgLength.Value, objHmiShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownCmd/Maintainer", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "acRole": "Maintainer", "MsgObject": deepcopy(objHmiShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownCmd/Maintainer")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiShutdownCmdMaintainer is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiShutdownCmdRsp/Maintainer", objHmiShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiShutdownCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackOlhmAdcsHmiStatusUnsol(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message OlhmAdcsHmiStatusUnsol

        This is a public method callback for message OlhmAdcsHmiStatusUnsol. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objOlhmAdcsHmiStatusUnsol = sOLHM_ADCS_HMI_STATUS_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for OlhmAdcsHmiStatusUnsol  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for OlhmAdcsHmiStatusUnsol  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for OlhmAdcsHmiStatusUnsol  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objOlhmAdcsHmiStatusUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for OlhmAdcsHmiStatusUnsol  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objOlhmAdcsHmiStatusUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for OlhmAdcsHmiStatusUnsol  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objOlhmAdcsHmiStatusUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message OlhmAdcsHmiStatusUnsol  validation failed")
            elif (objOlhmAdcsHmiStatusUnsol.sMsgHeader.u2MsgLength.Value != (objOlhmAdcsHmiStatusUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message OlhmAdcsHmiStatusUnsol  length field is invalid - it is %d and should be %d bytes", objOlhmAdcsHmiStatusUnsol.sMsgHeader.u2MsgLength.Value, objOlhmAdcsHmiStatusUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/OlhmAdcsHmiStatusUnsol", "Class": sOLHM_ADCS_HMI_STATUS_UNSOL, "ClassName": "sOLHM_ADCS_HMI_STATUS_UNSOL", "acRole": "", "MsgObject": deepcopy(objOlhmAdcsHmiStatusUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/OlhmAdcsHmiStatusUnsol")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiAdcsShutdownCmdRspAPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiAdcsShutdownCmdRspAPM

        This is a public method callback for message HmiAdcsShutdownCmdRspAPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiAdcsShutdownCmdRsp = sHMI_ADCS_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp APM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp APM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp APM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiAdcsShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp APM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiAdcsShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiAdcsShutdownCmdRsp APM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiAdcsShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmdRsp APM validation failed")
            elif (objHmiAdcsShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiAdcsShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmdRsp APM length field is invalid - it is %d and should be %d bytes", objHmiAdcsShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiAdcsShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/APM", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "acRole": "APM", "MsgObject": deepcopy(objHmiAdcsShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiAdcsShutdownCmdRsp/APM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiAdcsShutdownCmdRspFCO(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiAdcsShutdownCmdRspFCO

        This is a public method callback for message HmiAdcsShutdownCmdRspFCO. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiAdcsShutdownCmdRsp = sHMI_ADCS_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp FCO objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp FCO objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp FCO objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiAdcsShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp FCO length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiAdcsShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiAdcsShutdownCmdRsp FCO - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiAdcsShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmdRsp FCO validation failed")
            elif (objHmiAdcsShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiAdcsShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmdRsp FCO length field is invalid - it is %d and should be %d bytes", objHmiAdcsShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiAdcsShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "acRole": "FCO", "MsgObject": deepcopy(objHmiAdcsShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiAdcsShutdownCmdRspAPM_FCO(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiAdcsShutdownCmdRspAPM_FCO

        This is a public method callback for message HmiAdcsShutdownCmdRspAPM_FCO. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiAdcsShutdownCmdRsp = sHMI_ADCS_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp APM_FCO objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp APM_FCO objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp APM_FCO objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiAdcsShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp APM_FCO length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiAdcsShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiAdcsShutdownCmdRsp APM_FCO - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiAdcsShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmdRsp APM_FCO validation failed")
            elif (objHmiAdcsShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiAdcsShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmdRsp APM_FCO length field is invalid - it is %d and should be %d bytes", objHmiAdcsShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiAdcsShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "acRole": "APM_FCO", "MsgObject": deepcopy(objHmiAdcsShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiAdcsShutdownCmdRspSPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiAdcsShutdownCmdRspSPM

        This is a public method callback for message HmiAdcsShutdownCmdRspSPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiAdcsShutdownCmdRsp = sHMI_ADCS_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp SPM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp SPM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp SPM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiAdcsShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp SPM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiAdcsShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiAdcsShutdownCmdRsp SPM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiAdcsShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmdRsp SPM validation failed")
            elif (objHmiAdcsShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiAdcsShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmdRsp SPM length field is invalid - it is %d and should be %d bytes", objHmiAdcsShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiAdcsShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "acRole": "SPM", "MsgObject": deepcopy(objHmiAdcsShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiAdcsShutdownCmdRspFUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiAdcsShutdownCmdRspFUFC

        This is a public method callback for message HmiAdcsShutdownCmdRspFUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiAdcsShutdownCmdRsp = sHMI_ADCS_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiAdcsShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiAdcsShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiAdcsShutdownCmdRsp FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiAdcsShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmdRsp FUFC validation failed")
            elif (objHmiAdcsShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiAdcsShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmdRsp FUFC length field is invalid - it is %d and should be %d bytes", objHmiAdcsShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiAdcsShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "acRole": "FUFC", "MsgObject": deepcopy(objHmiAdcsShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiAdcsShutdownCmdRspSPM_FUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiAdcsShutdownCmdRspSPM_FUFC

        This is a public method callback for message HmiAdcsShutdownCmdRspSPM_FUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiAdcsShutdownCmdRsp = sHMI_ADCS_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp SPM_FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp SPM_FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp SPM_FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiAdcsShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp SPM_FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiAdcsShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiAdcsShutdownCmdRsp SPM_FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiAdcsShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmdRsp SPM_FUFC validation failed")
            elif (objHmiAdcsShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiAdcsShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmdRsp SPM_FUFC length field is invalid - it is %d and should be %d bytes", objHmiAdcsShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiAdcsShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "acRole": "SPM_FUFC", "MsgObject": deepcopy(objHmiAdcsShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiAdcsShutdownCmdRspOversight(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiAdcsShutdownCmdRspOversight

        This is a public method callback for message HmiAdcsShutdownCmdRspOversight. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiAdcsShutdownCmdRsp = sHMI_ADCS_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp Oversight objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp Oversight objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp Oversight objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiAdcsShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp Oversight length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiAdcsShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiAdcsShutdownCmdRsp Oversight - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiAdcsShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmdRsp Oversight validation failed")
            elif (objHmiAdcsShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiAdcsShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmdRsp Oversight length field is invalid - it is %d and should be %d bytes", objHmiAdcsShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiAdcsShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "acRole": "Oversight", "MsgObject": deepcopy(objHmiAdcsShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiAdcsShutdownCmdRspMaintainer(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiAdcsShutdownCmdRspMaintainer

        This is a public method callback for message HmiAdcsShutdownCmdRspMaintainer. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiAdcsShutdownCmdRsp = sHMI_ADCS_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp Maintainer objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp Maintainer objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp Maintainer objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiAdcsShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmdRsp Maintainer length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiAdcsShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiAdcsShutdownCmdRsp Maintainer - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiAdcsShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmdRsp Maintainer validation failed")
            elif (objHmiAdcsShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiAdcsShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmdRsp Maintainer length field is invalid - it is %d and should be %d bytes", objHmiAdcsShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiAdcsShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "acRole": "Maintainer", "MsgObject": deepcopy(objHmiAdcsShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return
# ==========================================================
# MQTT CALLBACK METHODS STOP
# ==========================================================
# ==========================================================
# MQTT SUBSCRIPTION METHODS START
# ==========================================================

    def vSubscribeMessageHmiEndOfSetupCmdAPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfSetupCmdAPM.

        This is the auto generated method for subscribing message HmiEndOfSetupCmdAPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfSetupCmd APM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmd/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmd APM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfSetupCmdFCO(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfSetupCmdFCO.

        This is the auto generated method for subscribing message HmiEndOfSetupCmdFCO.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfSetupCmd FCO objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmd/FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmd FCO - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfSetupCmdAPM_FCO(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfSetupCmdAPM_FCO.

        This is the auto generated method for subscribing message HmiEndOfSetupCmdAPM_FCO.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfSetupCmd APM_FCO objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmd/APM_FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmd APM_FCO - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfSetupCmdSPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfSetupCmdSPM.

        This is the auto generated method for subscribing message HmiEndOfSetupCmdSPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfSetupCmd SPM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmd/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmd SPM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfSetupCmdFUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfSetupCmdFUFC.

        This is the auto generated method for subscribing message HmiEndOfSetupCmdFUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfSetupCmd FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmd/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmd FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfSetupCmdSPM_FUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfSetupCmdSPM_FUFC.

        This is the auto generated method for subscribing message HmiEndOfSetupCmdSPM_FUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfSetupCmd SPM_FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmd SPM_FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfSetupCmdOversight(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfSetupCmdOversight.

        This is the auto generated method for subscribing message HmiEndOfSetupCmdOversight.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfSetupCmd Oversight objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmd/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmd Oversight - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfSetupCmdMaintainer(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfSetupCmdMaintainer.

        This is the auto generated method for subscribing message HmiEndOfSetupCmdMaintainer.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfSetupCmd Maintainer objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmd/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmd Maintainer - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfReadyCmdAPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfReadyCmdAPM.

        This is the auto generated method for subscribing message HmiEndOfReadyCmdAPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfReadyCmd APM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmd/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmd APM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfReadyCmdFCO(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfReadyCmdFCO.

        This is the auto generated method for subscribing message HmiEndOfReadyCmdFCO.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfReadyCmd FCO objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmd/FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmd FCO - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfReadyCmdAPM_FCO(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfReadyCmdAPM_FCO.

        This is the auto generated method for subscribing message HmiEndOfReadyCmdAPM_FCO.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfReadyCmd APM_FCO objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmd/APM_FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmd APM_FCO - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfReadyCmdSPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfReadyCmdSPM.

        This is the auto generated method for subscribing message HmiEndOfReadyCmdSPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfReadyCmd SPM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmd/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmd SPM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfReadyCmdFUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfReadyCmdFUFC.

        This is the auto generated method for subscribing message HmiEndOfReadyCmdFUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfReadyCmd FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmd/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmd FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfReadyCmdSPM_FUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfReadyCmdSPM_FUFC.

        This is the auto generated method for subscribing message HmiEndOfReadyCmdSPM_FUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfReadyCmd SPM_FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmd SPM_FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfReadyCmdOversight(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfReadyCmdOversight.

        This is the auto generated method for subscribing message HmiEndOfReadyCmdOversight.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfReadyCmd Oversight objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmd/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmd Oversight - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfReadyCmdMaintainer(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfReadyCmdMaintainer.

        This is the auto generated method for subscribing message HmiEndOfReadyCmdMaintainer.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfReadyCmd Maintainer objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmd/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmd Maintainer - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownCmdAPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownCmdAPM.

        This is the auto generated method for subscribing message HmiShutdownCmdAPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownCmd APM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmd/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmd APM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownCmdFCO(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownCmdFCO.

        This is the auto generated method for subscribing message HmiShutdownCmdFCO.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownCmd FCO objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmd/FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmd FCO - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownCmdAPM_FCO(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownCmdAPM_FCO.

        This is the auto generated method for subscribing message HmiShutdownCmdAPM_FCO.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownCmd APM_FCO objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmd/APM_FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmd APM_FCO - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownCmdSPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownCmdSPM.

        This is the auto generated method for subscribing message HmiShutdownCmdSPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownCmd SPM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmd/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmd SPM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownCmdFUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownCmdFUFC.

        This is the auto generated method for subscribing message HmiShutdownCmdFUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownCmd FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmd/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmd FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownCmdSPM_FUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownCmdSPM_FUFC.

        This is the auto generated method for subscribing message HmiShutdownCmdSPM_FUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownCmd SPM_FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmd/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmd SPM_FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownCmdOversight(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownCmdOversight.

        This is the auto generated method for subscribing message HmiShutdownCmdOversight.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownCmd Oversight objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmd/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmd Oversight - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownCmdMaintainer(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownCmdMaintainer.

        This is the auto generated method for subscribing message HmiShutdownCmdMaintainer.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownCmd Maintainer objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmd/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmd Maintainer - Exception %s", str(E))

        return

    def vSubscribeMessageOlhmAdcsHmiStatusUnsol(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message OlhmAdcsHmiStatusUnsol.

        This is the auto generated method for subscribing message OlhmAdcsHmiStatusUnsol.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for OlhmAdcsHmiStatusUnsol  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/OlhmAdcsHmiStatusUnsol", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message OlhmAdcsHmiStatusUnsol  - Exception %s", str(E))

        return

    def vSubscribeMessageHmiAdcsShutdownCmdRspAPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiAdcsShutdownCmdRspAPM.

        This is the auto generated method for subscribing message HmiAdcsShutdownCmdRspAPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiAdcsShutdownCmdRsp APM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmdRsp/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmdRsp APM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiAdcsShutdownCmdRspFCO(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiAdcsShutdownCmdRspFCO.

        This is the auto generated method for subscribing message HmiAdcsShutdownCmdRspFCO.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiAdcsShutdownCmdRsp FCO objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmdRsp FCO - Exception %s", str(E))

        return

    def vSubscribeMessageHmiAdcsShutdownCmdRspAPM_FCO(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiAdcsShutdownCmdRspAPM_FCO.

        This is the auto generated method for subscribing message HmiAdcsShutdownCmdRspAPM_FCO.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiAdcsShutdownCmdRsp APM_FCO objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmdRsp APM_FCO - Exception %s", str(E))

        return

    def vSubscribeMessageHmiAdcsShutdownCmdRspSPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiAdcsShutdownCmdRspSPM.

        This is the auto generated method for subscribing message HmiAdcsShutdownCmdRspSPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiAdcsShutdownCmdRsp SPM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmdRsp SPM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiAdcsShutdownCmdRspFUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiAdcsShutdownCmdRspFUFC.

        This is the auto generated method for subscribing message HmiAdcsShutdownCmdRspFUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiAdcsShutdownCmdRsp FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmdRsp FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiAdcsShutdownCmdRspSPM_FUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiAdcsShutdownCmdRspSPM_FUFC.

        This is the auto generated method for subscribing message HmiAdcsShutdownCmdRspSPM_FUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiAdcsShutdownCmdRsp SPM_FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmdRsp SPM_FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiAdcsShutdownCmdRspOversight(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiAdcsShutdownCmdRspOversight.

        This is the auto generated method for subscribing message HmiAdcsShutdownCmdRspOversight.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiAdcsShutdownCmdRsp Oversight objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmdRsp Oversight - Exception %s", str(E))

        return

    def vSubscribeMessageHmiAdcsShutdownCmdRspMaintainer(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiAdcsShutdownCmdRspMaintainer.

        This is the auto generated method for subscribing message HmiAdcsShutdownCmdRspMaintainer.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiAdcsShutdownCmdRsp Maintainer objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmdRsp Maintainer - Exception %s", str(E))

        return

# ==========================================================
# MQTT SUBSCRIPTION METHODS START
# ==========================================================
# ==========================================================
# MQTT TEMPLATE CLASS STOP
# ==========================================================
# ==========================================================
# AUTOGEN STOP
# ==========================================================