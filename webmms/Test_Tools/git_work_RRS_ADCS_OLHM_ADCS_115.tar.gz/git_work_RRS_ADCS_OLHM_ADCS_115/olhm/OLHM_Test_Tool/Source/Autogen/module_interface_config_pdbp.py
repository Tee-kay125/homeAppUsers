#!/usr/bin/env python3.6
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:32:42 SAST
"""

from enum import Enum


class E_MESSAGE_FLOW_DIRECTION(Enum):
    MESSAGE_FLOW_DIRECTION_PUBLISH = 1
    MESSAGE_FLOW_DIRECTION_SUBSCRIBE = 2


class E_COMMS_PROTOCOL(Enum):
    COMMS_PROTOCOL_MQTT = 1
    COMMS_PROTOCOL_ZEROMQ = 2


class clsModuleInterfaceConfigPdbp():
    lstModInterConfTopicInfo = []
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "PDBP", "acMessagename": "PdbpStatusReportUnsol", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "PDBP", "acMessagename": "PdbpEndOfReadyCmdRsp", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "PDBP", "acMessagename": "PdbpShutdownCmdRsp", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "PDBP", "acMessagename": "PdbpSendOutModuleDbMessagesCmdRsp", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "PDBP", "acMessagename": "PdbpExportPdbToJsonFileCmdRsp", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "PDBP", "acMessagename": "PdbpStorageStateCmdRsp", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "PDBP", "acMessagename": "PdbpLoadFactoryPersistentParametersCmdRsp", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "PDBP", "acMessagename": "PdbpUploadJsonFileIntoPpdbCmdRsp", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "PDBP", "acMessagename": "PdbpEndOfReadyCmd", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "PDBP", "acMessagename": "PdbpShutdownCmd", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "PDBP", "acMessagename": "PdbpSendOutModuleDbMessagesCmd", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "PDBP", "acMessagename": "PdbpExportPdbToJsonFileCmd", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "PDBP", "acMessagename": "PdbpStorageStateCmd", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "PDBP", "acMessagename": "PdbpLoadFactoryPersistentParametersCmd", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "PDBP", "acMessagename": "PdbpUploadJsonFileIntoPpdbCmd", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE), "acRole": ""})
