#! /usr/bin/env python
# -*- coding: utf-8 -*-
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:32:41 SAST

    This module is the asyncio message processing class generated automatically from XML file(s). It is intended use is as a base class
    for a derived class which will be used in the asyncio event loop. The vProcessDictObj() method should only be called inside the
    asyncio event loop and using a create_task() call. Failure to do so might block the process currently running and should only be used
    as intended in a well designed asyncio implementation.

"""
# ==========================================================
# AUTOGEN START
# ==========================================================
import logging  # This is required to be able to log if there are problems
import asyncio  # This is required to concurrent operations in a single thread
import datetime  # This is needed to set a datetime result on a future
import time  # This is needed to get the time as time.CLOCK_MONOTONIC_RAW
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
from Autogen.mw_common_types import E2_MW_MESSAGE_STATUS
from Autogen.dsf_msg import *  # noqa: F401
from Autogen.tewa_msg import *  # noqa: F401
from Autogen.tm_msg import *  # noqa: F401
from Autogen.olhm_msg import *  # noqa: F401
from Autogen.hmi_msg import *  # noqa: F401

# ==========================================================
# MQTT TEMPLATE CLASS START
# ==========================================================


class clsPythonAsyncioMessageProcessing():
    """ This is the message asyncio processing autogen class

    This is the message processing asyncio autogen class. Inherit this class in order to
    override the methods if required.

    Args:
        objMqttClientPar (mqtt.Client): The first parameter. The MQTT client instance for sending to the broker.
        dctMessagesPar (dict): The second parameter. A dictionary containing all messages and futures for messages which were automatically processed by the autogen
        lstTasksAllowedForsimultaneousExecutionPar (list): The third parameter. A list of topics for which simultaneous task execution is allowed. An empty list means no topics are allowed to execute simultaneously.
        objAsyncioLoopPar (object): The fourth parameter. The asyncio loop passed in so tasks can be created and for other asyncio functionality
        bLoggingEnabledPar (bool): The fifth parameter. A boolean flag indicating if logging should be done or not.

    """
    def __init__(self, objMqttClientPar: mqtt.Client, dctMessagesPar: dict, lstTasksAllowedForsimultaneousExecutionPar: list, objAsyncioLoopPar: object, bLoggingEnabledPar: bool = True):
        super().__init__()
        self._objMqttClient = objMqttClientPar
        self._dctMessages = dctMessagesPar
        self._lstTasksAllowedForsimultaneousExecution = lstTasksAllowedForsimultaneousExecutionPar
        self._objAsyncioLoop = objAsyncioLoopPar
        self._bLoggingEnabled = bLoggingEnabledPar
        # When we mqtt publish the connection state is returned - This property stores the last state
        self._tplPublishConnectionStateLast = (mqtt.MQTT_ERR_SUCCESS, 0)
        # When we mqtt publish the connection state is returned - This property stores the first time it failed 
        self._tplPublishConnectionStateFirstFail = (mqtt.MQTT_ERR_SUCCESS, 0)

        # In the message dictionary we store the Topic, ClassName, Class, MsgObject, Future, UTC timestamp, monotonic raw timestamp and role
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"] = {"ClassName": "sHMI_STATUS_REPORT_UNSOL", "Class": sHMI_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"] = {"ClassName": "sHMI_STATUS_REPORT_UNSOL", "Class": sHMI_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"] = {"ClassName": "sHMI_STATUS_REPORT_UNSOL", "Class": sHMI_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"] = {"ClassName": "sHMI_STATUS_REPORT_UNSOL", "Class": sHMI_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"] = {"ClassName": "sHMI_STATUS_REPORT_UNSOL", "Class": sHMI_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"] = {"ClassName": "sHMI_STATUS_REPORT_UNSOL", "Class": sHMI_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"] = {"ClassName": "sHMI_STATUS_REPORT_UNSOL", "Class": sHMI_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"] = {"ClassName": "sHMI_STATUS_REPORT_UNSOL", "Class": sHMI_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"] = {"ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "Class": sHMI_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"] = {"ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "Class": sHMI_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FC"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"] = {"ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "Class": sHMI_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FC"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"] = {"ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "Class": sHMI_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"] = {"ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "Class": sHMI_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"] = {"ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "Class": sHMI_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"] = {"ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "Class": sHMI_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"] = {"ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "Class": sHMI_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"] = {"ClassName": "sHMI_END_OF_READY_CMD_RSP", "Class": sHMI_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"] = {"ClassName": "sHMI_END_OF_READY_CMD_RSP", "Class": sHMI_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"] = {"ClassName": "sHMI_END_OF_READY_CMD_RSP", "Class": sHMI_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"] = {"ClassName": "sHMI_END_OF_READY_CMD_RSP", "Class": sHMI_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"] = {"ClassName": "sHMI_END_OF_READY_CMD_RSP", "Class": sHMI_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"] = {"ClassName": "sHMI_END_OF_READY_CMD_RSP", "Class": sHMI_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"] = {"ClassName": "sHMI_END_OF_READY_CMD_RSP", "Class": sHMI_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"] = {"ClassName": "sHMI_END_OF_READY_CMD_RSP", "Class": sHMI_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"] = {"ClassName": "sHMI_SHUTDOWN_UNSOL", "Class": sHMI_SHUTDOWN_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"] = {"ClassName": "sHMI_SHUTDOWN_UNSOL", "Class": sHMI_SHUTDOWN_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"] = {"ClassName": "sHMI_SHUTDOWN_UNSOL", "Class": sHMI_SHUTDOWN_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"] = {"ClassName": "sHMI_SHUTDOWN_UNSOL", "Class": sHMI_SHUTDOWN_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"] = {"ClassName": "sHMI_SHUTDOWN_UNSOL", "Class": sHMI_SHUTDOWN_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"] = {"ClassName": "sHMI_SHUTDOWN_UNSOL", "Class": sHMI_SHUTDOWN_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"] = {"ClassName": "sHMI_SHUTDOWN_UNSOL", "Class": sHMI_SHUTDOWN_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"] = {"ClassName": "sHMI_SHUTDOWN_UNSOL", "Class": sHMI_SHUTDOWN_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"] = {"ClassName": "sHMI_SHUTDOWN_CMD_RSP", "Class": sHMI_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"] = {"ClassName": "sHMI_SHUTDOWN_CMD_RSP", "Class": sHMI_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"] = {"ClassName": "sHMI_SHUTDOWN_CMD_RSP", "Class": sHMI_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"] = {"ClassName": "sHMI_SHUTDOWN_CMD_RSP", "Class": sHMI_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"] = {"ClassName": "sHMI_SHUTDOWN_CMD_RSP", "Class": sHMI_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"] = {"ClassName": "sHMI_SHUTDOWN_CMD_RSP", "Class": sHMI_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"] = {"ClassName": "sHMI_SHUTDOWN_CMD_RSP", "Class": sHMI_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"] = {"ClassName": "sHMI_SHUTDOWN_CMD_RSP", "Class": sHMI_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "Class": sHMI_ADCS_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "Class": sHMI_ADCS_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "Class": sHMI_ADCS_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "Class": sHMI_ADCS_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "Class": sHMI_ADCS_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "Class": sHMI_ADCS_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "Class": sHMI_ADCS_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "Class": sHMI_ADCS_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM"] = {"ClassName": "sHMI_EMERGENCY_ERASE_UNSOL", "Class": sHMI_EMERGENCY_ERASE_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FCO"] = {"ClassName": "sHMI_EMERGENCY_ERASE_UNSOL", "Class": sHMI_EMERGENCY_ERASE_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM_FCO"] = {"ClassName": "sHMI_EMERGENCY_ERASE_UNSOL", "Class": sHMI_EMERGENCY_ERASE_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FUFC"] = {"ClassName": "sHMI_EMERGENCY_ERASE_UNSOL", "Class": sHMI_EMERGENCY_ERASE_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/SPM"] = {"ClassName": "sHMI_EMERGENCY_ERASE_UNSOL", "Class": sHMI_EMERGENCY_ERASE_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Oversight"] = {"ClassName": "sHMI_EMERGENCY_ERASE_UNSOL", "Class": sHMI_EMERGENCY_ERASE_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Maintainer"] = {"ClassName": "sHMI_EMERGENCY_ERASE_UNSOL", "Class": sHMI_EMERGENCY_ERASE_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"] = {"ClassName": "sHMI_END_OF_SETUP_CMD", "Class": sHMI_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"] = {"ClassName": "sHMI_END_OF_SETUP_CMD", "Class": sHMI_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"] = {"ClassName": "sHMI_END_OF_SETUP_CMD", "Class": sHMI_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"] = {"ClassName": "sHMI_END_OF_SETUP_CMD", "Class": sHMI_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"] = {"ClassName": "sHMI_END_OF_SETUP_CMD", "Class": sHMI_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"] = {"ClassName": "sHMI_END_OF_SETUP_CMD", "Class": sHMI_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"] = {"ClassName": "sHMI_END_OF_SETUP_CMD", "Class": sHMI_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"] = {"ClassName": "sHMI_END_OF_SETUP_CMD", "Class": sHMI_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"] = {"ClassName": "sHMI_END_OF_READY_CMD", "Class": sHMI_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"] = {"ClassName": "sHMI_END_OF_READY_CMD", "Class": sHMI_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"] = {"ClassName": "sHMI_END_OF_READY_CMD", "Class": sHMI_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"] = {"ClassName": "sHMI_END_OF_READY_CMD", "Class": sHMI_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"] = {"ClassName": "sHMI_END_OF_READY_CMD", "Class": sHMI_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"] = {"ClassName": "sHMI_END_OF_READY_CMD", "Class": sHMI_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"] = {"ClassName": "sHMI_END_OF_READY_CMD", "Class": sHMI_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"] = {"ClassName": "sHMI_END_OF_READY_CMD", "Class": sHMI_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"] = {"ClassName": "sHMI_SHUTDOWN_CMD", "Class": sHMI_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"] = {"ClassName": "sHMI_SHUTDOWN_CMD", "Class": sHMI_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"] = {"ClassName": "sHMI_SHUTDOWN_CMD", "Class": sHMI_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"] = {"ClassName": "sHMI_SHUTDOWN_CMD", "Class": sHMI_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"] = {"ClassName": "sHMI_SHUTDOWN_CMD", "Class": sHMI_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"] = {"ClassName": "sHMI_SHUTDOWN_CMD", "Class": sHMI_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"] = {"ClassName": "sHMI_SHUTDOWN_CMD", "Class": sHMI_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"] = {"ClassName": "sHMI_SHUTDOWN_CMD", "Class": sHMI_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/HMI/OlhmAdcsHmiStatusUnsol"] = {"ClassName": "sOLHM_ADCS_HMI_STATUS_UNSOL", "Class": sOLHM_ADCS_HMI_STATUS_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        # We have this dictionary to demux a topic into the processing method which should be called - it's more efficient than a long list of if statements
        self._dctDemuxTopicToMethod = {
            "ADCS/HMI/HmiStatusReportUnsol/APM": self.vProcessHmiStatusReportUnsolAPM,
            "ADCS/HMI/HmiStatusReportUnsol/FCO": self.vProcessHmiStatusReportUnsolFCO,
            "ADCS/HMI/HmiStatusReportUnsol/APM_FCO": self.vProcessHmiStatusReportUnsolAPM_FCO,
            "ADCS/HMI/HmiStatusReportUnsol/SPM": self.vProcessHmiStatusReportUnsolSPM,
            "ADCS/HMI/HmiStatusReportUnsol/FUFC": self.vProcessHmiStatusReportUnsolFUFC,
            "ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC": self.vProcessHmiStatusReportUnsolSPM_FUFC,
            "ADCS/HMI/HmiStatusReportUnsol/Oversight": self.vProcessHmiStatusReportUnsolOversight,
            "ADCS/HMI/HmiStatusReportUnsol/Maintainer": self.vProcessHmiStatusReportUnsolMaintainer,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/APM": self.vProcessHmiEndOfSetupCmdRspAPM,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/FC": self.vProcessHmiEndOfSetupCmdRspFC,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC": self.vProcessHmiEndOfSetupCmdRspAPM_FC,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/SPM": self.vProcessHmiEndOfSetupCmdRspSPM,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC": self.vProcessHmiEndOfSetupCmdRspFUFC,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC": self.vProcessHmiEndOfSetupCmdRspSPM_FUFC,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight": self.vProcessHmiEndOfSetupCmdRspOversight,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer": self.vProcessHmiEndOfSetupCmdRspMaintainer,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/APM": self.vProcessHmiEndOfReadyCmdRspAPM,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/FCO": self.vProcessHmiEndOfReadyCmdRspFCO,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO": self.vProcessHmiEndOfReadyCmdRspAPM_FCO,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/SPM": self.vProcessHmiEndOfReadyCmdRspSPM,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC": self.vProcessHmiEndOfReadyCmdRspFUFC,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC": self.vProcessHmiEndOfReadyCmdRspSPM_FUFC,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight": self.vProcessHmiEndOfReadyCmdRspOversight,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer": self.vProcessHmiEndOfReadyCmdRspMaintainer,
            "ADCS/HMI/HmiShutdownUnsol/APM": self.vProcessHmiShutdownUnsolAPM,
            "ADCS/HMI/HmiShutdownUnsol/FCO": self.vProcessHmiShutdownUnsolFCO,
            "ADCS/HMI/HmiShutdownUnsol/APM_FCO": self.vProcessHmiShutdownUnsolAPM_FCO,
            "ADCS/HMI/HmiShutdownUnsol/SPM": self.vProcessHmiShutdownUnsolSPM,
            "ADCS/HMI/HmiShutdownUnsol/FUFC": self.vProcessHmiShutdownUnsolFUFC,
            "ADCS/HMI/HmiShutdownUnsol/SPM_FUFC": self.vProcessHmiShutdownUnsolSPM_FUFC,
            "ADCS/HMI/HmiShutdownUnsol/Oversight": self.vProcessHmiShutdownUnsolOversight,
            "ADCS/HMI/HmiShutdownUnsol/Maintainer": self.vProcessHmiShutdownUnsolMaintainer,
            "ADCS/HMI/HmiShutdownCmdRsp/APM": self.vProcessHmiShutdownCmdRspAPM,
            "ADCS/HMI/HmiShutdownCmdRsp/FCO": self.vProcessHmiShutdownCmdRspFCO,
            "ADCS/HMI/HmiShutdownCmdRsp/APM_FCO": self.vProcessHmiShutdownCmdRspAPM_FCO,
            "ADCS/HMI/HmiShutdownCmdRsp/SPM": self.vProcessHmiShutdownCmdRspSPM,
            "ADCS/HMI/HmiShutdownCmdRsp/FUFC": self.vProcessHmiShutdownCmdRspFUFC,
            "ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC": self.vProcessHmiShutdownCmdRspSPM_FUFC,
            "ADCS/HMI/HmiShutdownCmdRsp/Oversight": self.vProcessHmiShutdownCmdRspOversight,
            "ADCS/HMI/HmiShutdownCmdRsp/Maintainer": self.vProcessHmiShutdownCmdRspMaintainer,
            "ADCS/HMI/HmiAdcsShutdownCmd/APM": self.vProcessHmiAdcsShutdownCmdAPM,
            "ADCS/HMI/HmiAdcsShutdownCmd/FCO": self.vProcessHmiAdcsShutdownCmdFCO,
            "ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO": self.vProcessHmiAdcsShutdownCmdAPM_FCO,
            "ADCS/HMI/HmiAdcsShutdownCmd/SPM": self.vProcessHmiAdcsShutdownCmdSPM,
            "ADCS/HMI/HmiAdcsShutdownCmd/FUFC": self.vProcessHmiAdcsShutdownCmdFUFC,
            "ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC": self.vProcessHmiAdcsShutdownCmdSPM_FUFC,
            "ADCS/HMI/HmiAdcsShutdownCmd/Oversight": self.vProcessHmiAdcsShutdownCmdOversight,
            "ADCS/HMI/HmiAdcsShutdownCmd/Maintainer": self.vProcessHmiAdcsShutdownCmdMaintainer,
            "ADCS/HMI/HmiEmergencyEraseUnsol/APM": self.vProcessHmiEmergencyEraseUnsolAPM,
            "ADCS/HMI/HmiEmergencyEraseUnsol/FCO": self.vProcessHmiEmergencyEraseUnsolFCO,
            "ADCS/HMI/HmiEmergencyEraseUnsol/APM_FCO": self.vProcessHmiEmergencyEraseUnsolAPM_FCO,
            "ADCS/HMI/HmiEmergencyEraseUnsol/FUFC": self.vProcessHmiEmergencyEraseUnsolFUFC,
            "ADCS/HMI/HmiEmergencyEraseUnsol/SPM": self.vProcessHmiEmergencyEraseUnsolSPM,
            "ADCS/HMI/HmiEmergencyEraseUnsol/Oversight": self.vProcessHmiEmergencyEraseUnsolOversight,
            "ADCS/HMI/HmiEmergencyEraseUnsol/Maintainer": self.vProcessHmiEmergencyEraseUnsolMaintainer,
            "ADCS/HMI/HmiEndOfSetupCmd/APM": self.vProcessHmiEndOfSetupCmdAPM,
            "ADCS/HMI/HmiEndOfSetupCmd/FCO": self.vProcessHmiEndOfSetupCmdFCO,
            "ADCS/HMI/HmiEndOfSetupCmd/APM_FCO": self.vProcessHmiEndOfSetupCmdAPM_FCO,
            "ADCS/HMI/HmiEndOfSetupCmd/SPM": self.vProcessHmiEndOfSetupCmdSPM,
            "ADCS/HMI/HmiEndOfSetupCmd/FUFC": self.vProcessHmiEndOfSetupCmdFUFC,
            "ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC": self.vProcessHmiEndOfSetupCmdSPM_FUFC,
            "ADCS/HMI/HmiEndOfSetupCmd/Oversight": self.vProcessHmiEndOfSetupCmdOversight,
            "ADCS/HMI/HmiEndOfSetupCmd/Maintainer": self.vProcessHmiEndOfSetupCmdMaintainer,
            "ADCS/HMI/HmiEndOfReadyCmd/APM": self.vProcessHmiEndOfReadyCmdAPM,
            "ADCS/HMI/HmiEndOfReadyCmd/FCO": self.vProcessHmiEndOfReadyCmdFCO,
            "ADCS/HMI/HmiEndOfReadyCmd/APM_FCO": self.vProcessHmiEndOfReadyCmdAPM_FCO,
            "ADCS/HMI/HmiEndOfReadyCmd/SPM": self.vProcessHmiEndOfReadyCmdSPM,
            "ADCS/HMI/HmiEndOfReadyCmd/FUFC": self.vProcessHmiEndOfReadyCmdFUFC,
            "ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC": self.vProcessHmiEndOfReadyCmdSPM_FUFC,
            "ADCS/HMI/HmiEndOfReadyCmd/Oversight": self.vProcessHmiEndOfReadyCmdOversight,
            "ADCS/HMI/HmiEndOfReadyCmd/Maintainer": self.vProcessHmiEndOfReadyCmdMaintainer,
            "ADCS/HMI/HmiShutdownCmd/APM": self.vProcessHmiShutdownCmdAPM,
            "ADCS/HMI/HmiShutdownCmd/FCO": self.vProcessHmiShutdownCmdFCO,
            "ADCS/HMI/HmiShutdownCmd/APM_FCO": self.vProcessHmiShutdownCmdAPM_FCO,
            "ADCS/HMI/HmiShutdownCmd/SPM": self.vProcessHmiShutdownCmdSPM,
            "ADCS/HMI/HmiShutdownCmd/FUFC": self.vProcessHmiShutdownCmdFUFC,
            "ADCS/HMI/HmiShutdownCmd/SPM_FUFC": self.vProcessHmiShutdownCmdSPM_FUFC,
            "ADCS/HMI/HmiShutdownCmd/Oversight": self.vProcessHmiShutdownCmdOversight,
            "ADCS/HMI/HmiShutdownCmd/Maintainer": self.vProcessHmiShutdownCmdMaintainer,
            "ADCS/HMI/OlhmAdcsHmiStatusUnsol": self.vProcessOlhmAdcsHmiStatusUnsol,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/APM": self.vProcessHmiAdcsShutdownCmdRspAPM,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO": self.vProcessHmiAdcsShutdownCmdRspFCO,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO": self.vProcessHmiAdcsShutdownCmdRspAPM_FCO,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM": self.vProcessHmiAdcsShutdownCmdRspSPM,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC": self.vProcessHmiAdcsShutdownCmdRspFUFC,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC": self.vProcessHmiAdcsShutdownCmdRspSPM_FUFC,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight": self.vProcessHmiAdcsShutdownCmdRspOversight,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer": self.vProcessHmiAdcsShutdownCmdRspMaintainer,
        }

        # This is a dictionary which keeps track of how many tasks are currently being executed per topic - for typical use this number will be either 0 or 1
        self._dctNumExecutingTasks = {
            "ADCS/HMI/HmiStatusReportUnsol/APM": 0,
            "ADCS/HMI/HmiStatusReportUnsol/FCO": 0,
            "ADCS/HMI/HmiStatusReportUnsol/APM_FCO": 0,
            "ADCS/HMI/HmiStatusReportUnsol/SPM": 0,
            "ADCS/HMI/HmiStatusReportUnsol/FUFC": 0,
            "ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC": 0,
            "ADCS/HMI/HmiStatusReportUnsol/Oversight": 0,
            "ADCS/HMI/HmiStatusReportUnsol/Maintainer": 0,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/APM": 0,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/FC": 0,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC": 0,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/SPM": 0,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC": 0,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC": 0,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight": 0,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer": 0,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/APM": 0,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/FCO": 0,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO": 0,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/SPM": 0,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC": 0,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC": 0,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight": 0,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer": 0,
            "ADCS/HMI/HmiShutdownUnsol/APM": 0,
            "ADCS/HMI/HmiShutdownUnsol/FCO": 0,
            "ADCS/HMI/HmiShutdownUnsol/APM_FCO": 0,
            "ADCS/HMI/HmiShutdownUnsol/SPM": 0,
            "ADCS/HMI/HmiShutdownUnsol/FUFC": 0,
            "ADCS/HMI/HmiShutdownUnsol/SPM_FUFC": 0,
            "ADCS/HMI/HmiShutdownUnsol/Oversight": 0,
            "ADCS/HMI/HmiShutdownUnsol/Maintainer": 0,
            "ADCS/HMI/HmiShutdownCmdRsp/APM": 0,
            "ADCS/HMI/HmiShutdownCmdRsp/FCO": 0,
            "ADCS/HMI/HmiShutdownCmdRsp/APM_FCO": 0,
            "ADCS/HMI/HmiShutdownCmdRsp/SPM": 0,
            "ADCS/HMI/HmiShutdownCmdRsp/FUFC": 0,
            "ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC": 0,
            "ADCS/HMI/HmiShutdownCmdRsp/Oversight": 0,
            "ADCS/HMI/HmiShutdownCmdRsp/Maintainer": 0,
            "ADCS/HMI/HmiAdcsShutdownCmd/APM": 0,
            "ADCS/HMI/HmiAdcsShutdownCmd/FCO": 0,
            "ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO": 0,
            "ADCS/HMI/HmiAdcsShutdownCmd/SPM": 0,
            "ADCS/HMI/HmiAdcsShutdownCmd/FUFC": 0,
            "ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC": 0,
            "ADCS/HMI/HmiAdcsShutdownCmd/Oversight": 0,
            "ADCS/HMI/HmiAdcsShutdownCmd/Maintainer": 0,
            "ADCS/HMI/HmiEmergencyEraseUnsol/APM": 0,
            "ADCS/HMI/HmiEmergencyEraseUnsol/FCO": 0,
            "ADCS/HMI/HmiEmergencyEraseUnsol/APM_FCO": 0,
            "ADCS/HMI/HmiEmergencyEraseUnsol/FUFC": 0,
            "ADCS/HMI/HmiEmergencyEraseUnsol/SPM": 0,
            "ADCS/HMI/HmiEmergencyEraseUnsol/Oversight": 0,
            "ADCS/HMI/HmiEmergencyEraseUnsol/Maintainer": 0,
            "ADCS/HMI/HmiEndOfSetupCmd/APM": 0,
            "ADCS/HMI/HmiEndOfSetupCmd/FCO": 0,
            "ADCS/HMI/HmiEndOfSetupCmd/APM_FCO": 0,
            "ADCS/HMI/HmiEndOfSetupCmd/SPM": 0,
            "ADCS/HMI/HmiEndOfSetupCmd/FUFC": 0,
            "ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC": 0,
            "ADCS/HMI/HmiEndOfSetupCmd/Oversight": 0,
            "ADCS/HMI/HmiEndOfSetupCmd/Maintainer": 0,
            "ADCS/HMI/HmiEndOfReadyCmd/APM": 0,
            "ADCS/HMI/HmiEndOfReadyCmd/FCO": 0,
            "ADCS/HMI/HmiEndOfReadyCmd/APM_FCO": 0,
            "ADCS/HMI/HmiEndOfReadyCmd/SPM": 0,
            "ADCS/HMI/HmiEndOfReadyCmd/FUFC": 0,
            "ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC": 0,
            "ADCS/HMI/HmiEndOfReadyCmd/Oversight": 0,
            "ADCS/HMI/HmiEndOfReadyCmd/Maintainer": 0,
            "ADCS/HMI/HmiShutdownCmd/APM": 0,
            "ADCS/HMI/HmiShutdownCmd/FCO": 0,
            "ADCS/HMI/HmiShutdownCmd/APM_FCO": 0,
            "ADCS/HMI/HmiShutdownCmd/SPM": 0,
            "ADCS/HMI/HmiShutdownCmd/FUFC": 0,
            "ADCS/HMI/HmiShutdownCmd/SPM_FUFC": 0,
            "ADCS/HMI/HmiShutdownCmd/Oversight": 0,
            "ADCS/HMI/HmiShutdownCmd/Maintainer": 0,
            "ADCS/HMI/OlhmAdcsHmiStatusUnsol": 0,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/APM": 0,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO": 0,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO": 0,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM": 0,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC": 0,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC": 0,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight": 0,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer": 0,
        }

    # ==========================================================
    # PROCESS DICTIONARY START
    # ==========================================================
    async def vProcessDictObj(self, dctObjectPar) -> None:
        """ This is a public method which demuxes messages from the python queue.

        This is a public method which demuxes messages from the python queue. It uses a dictionary as a lookup in
        order to determine which method to call. Unknown topics will be logged as an error.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """

        # Make sure our input parameter is not None
        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        # Make sure our input parameter dictionary does have a topic key
        if ("Topic" not in dctObjectPar):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar does not contain the key Topic")
            return

        # Use the demux dictionary to determine which method should be called
        if (dctObjectPar["Topic"] in self._dctDemuxTopicToMethod):
            if ((self._dctNumExecutingTasks[dctObjectPar["Topic"]] <= 0) or (dctObjectPar["Topic"] in self._lstTasksAllowedForsimultaneousExecution)):
                self._dctNumExecutingTasks[dctObjectPar["Topic"]] += 1
                await self._dctDemuxTopicToMethod[dctObjectPar["Topic"]](dctObjectPar)
                self._dctNumExecutingTasks[dctObjectPar["Topic"]] -= 1
            else:
                logging.warning("Incoming topic %s cannot be processed right now because there is already a task executing for it - the task counter is %d", dctObjectPar["Topic"], self._dctNumExecutingTasks[dctObjectPar["Topic"]])
        else:
            logging.error("Received message with topic %s does not have a corresponding processing method to call - demux failed because topic unknown", dctObjectPar["Topic"])

        return

    # ==========================================================
    # PROCESS DICTIONARY START
    # ==========================================================
    async def vProcessHmiStatusReportUnsolAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiStatusReportUnsol/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiStatusReportUnsolAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiStatusReportUnsolAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiStatusReportUnsol/APM", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiStatusReportUnsol/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiStatusReportUnsolFCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiStatusReportUnsol/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiStatusReportUnsolFCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiStatusReportUnsolFCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiStatusReportUnsol/FCO", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiStatusReportUnsol/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiStatusReportUnsolAPM_FCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiStatusReportUnsol/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/APM_FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiStatusReportUnsolAPM_FCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiStatusReportUnsolAPM_FCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiStatusReportUnsol/APM_FCO", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiStatusReportUnsol/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/APM_FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiStatusReportUnsolSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiStatusReportUnsol/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiStatusReportUnsolSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiStatusReportUnsolSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiStatusReportUnsol/SPM", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiStatusReportUnsol/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiStatusReportUnsolFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiStatusReportUnsol/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiStatusReportUnsolFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiStatusReportUnsolFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiStatusReportUnsol/FUFC", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiStatusReportUnsol/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiStatusReportUnsolSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiStatusReportUnsolSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiStatusReportUnsolSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiStatusReportUnsolOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiStatusReportUnsol/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiStatusReportUnsolOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiStatusReportUnsolOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiStatusReportUnsol/Oversight", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiStatusReportUnsol/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiStatusReportUnsolMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiStatusReportUnsol/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiStatusReportUnsolMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiStatusReportUnsolMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiStatusReportUnsol/Maintainer", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiStatusReportUnsol/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfSetupCmdRspAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdRspAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfSetupCmdRspAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/APM", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfSetupCmdRspFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/FC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/FC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdRspFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfSetupCmdRspFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/FC", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/FC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/FC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfSetupCmdRspAPM_FC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdRspAPM_FC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfSetupCmdRspAPM_FC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfSetupCmdRspSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdRspSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfSetupCmdRspSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/SPM", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfSetupCmdRspFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdRspFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfSetupCmdRspFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfSetupCmdRspSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdRspSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfSetupCmdRspSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfSetupCmdRspOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdRspOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfSetupCmdRspOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfSetupCmdRspMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdRspMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfSetupCmdRspMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfReadyCmdRspAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdRspAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfReadyCmdRspAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/APM", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfReadyCmdRspFCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdRspFCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfReadyCmdRspFCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/FCO", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfReadyCmdRspAPM_FCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdRspAPM_FCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfReadyCmdRspAPM_FCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfReadyCmdRspSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdRspSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfReadyCmdRspSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/SPM", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfReadyCmdRspFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdRspFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfReadyCmdRspFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfReadyCmdRspSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdRspSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfReadyCmdRspSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfReadyCmdRspOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdRspOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfReadyCmdRspOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfReadyCmdRspMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdRspMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfReadyCmdRspMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownUnsolAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownUnsol/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownUnsolAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownUnsolAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownUnsol/APM", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownUnsol/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownUnsolFCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownUnsol/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownUnsolFCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownUnsolFCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownUnsol/FCO", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownUnsol/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownUnsolAPM_FCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownUnsol/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/APM_FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownUnsolAPM_FCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownUnsolAPM_FCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownUnsol/APM_FCO", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownUnsol/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/APM_FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownUnsolSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownUnsol/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownUnsolSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownUnsolSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownUnsol/SPM", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownUnsol/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownUnsolFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownUnsol/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownUnsolFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownUnsolFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownUnsol/FUFC", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownUnsol/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownUnsolSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownUnsol/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownUnsolSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownUnsolSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownUnsol/SPM_FUFC", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownUnsol/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownUnsolOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownUnsol/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownUnsolOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownUnsolOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownUnsol/Oversight", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownUnsol/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownUnsolMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownUnsol/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownUnsolMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownUnsolMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownUnsol/Maintainer", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownUnsol/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownCmdRspAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmdRsp/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdRspAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownCmdRspAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmdRsp/APM", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmdRsp/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownCmdRspFCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmdRsp/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdRspFCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownCmdRspFCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmdRsp/FCO", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmdRsp/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownCmdRspAPM_FCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmdRsp/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/APM_FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdRspAPM_FCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownCmdRspAPM_FCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmdRsp/APM_FCO", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmdRsp/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/APM_FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownCmdRspSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmdRsp/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdRspSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownCmdRspSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmdRsp/SPM", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmdRsp/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownCmdRspFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmdRsp/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdRspFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownCmdRspFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmdRsp/FUFC", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmdRsp/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownCmdRspSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdRspSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownCmdRspSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownCmdRspOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmdRsp/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdRspOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownCmdRspOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmdRsp/Oversight", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmdRsp/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownCmdRspMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmdRsp/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdRspMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownCmdRspMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmdRsp/Maintainer", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmdRsp/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmd/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/APM", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmd/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmd's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdFCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmd/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdFCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdFCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/FCO", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmd/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmd's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdAPM_FCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdAPM_FCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdAPM_FCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmd's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmd/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/SPM", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmd/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmd's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmd/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/FUFC", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmd/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmd's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmd's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmd/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/Oversight", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmd/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmd's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmd/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/Maintainer", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmd/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmd's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEmergencyEraseUnsolAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEmergencyEraseUnsol/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEmergencyEraseUnsol/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEmergencyEraseUnsolAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEmergencyEraseUnsolAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEmergencyEraseUnsol/APM", "Class": sHMI_EMERGENCY_ERASE_UNSOL, "ClassName": "sHMI_EMERGENCY_ERASE_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEmergencyEraseUnsol/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEmergencyEraseUnsol/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEmergencyEraseUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEmergencyEraseUnsolFCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEmergencyEraseUnsol/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEmergencyEraseUnsol/FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEmergencyEraseUnsolFCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEmergencyEraseUnsolFCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEmergencyEraseUnsol/FCO", "Class": sHMI_EMERGENCY_ERASE_UNSOL, "ClassName": "sHMI_EMERGENCY_ERASE_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEmergencyEraseUnsol/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEmergencyEraseUnsol/FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEmergencyEraseUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEmergencyEraseUnsolAPM_FCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEmergencyEraseUnsol/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEmergencyEraseUnsol/APM_FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM_FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM_FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM_FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM_FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM_FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM_FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEmergencyEraseUnsolAPM_FCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEmergencyEraseUnsolAPM_FCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEmergencyEraseUnsol/APM_FCO", "Class": sHMI_EMERGENCY_ERASE_UNSOL, "ClassName": "sHMI_EMERGENCY_ERASE_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEmergencyEraseUnsol/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEmergencyEraseUnsol/APM_FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM_FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM_FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/APM_FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEmergencyEraseUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEmergencyEraseUnsolFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEmergencyEraseUnsol/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEmergencyEraseUnsol/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEmergencyEraseUnsolFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEmergencyEraseUnsolFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEmergencyEraseUnsol/FUFC", "Class": sHMI_EMERGENCY_ERASE_UNSOL, "ClassName": "sHMI_EMERGENCY_ERASE_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEmergencyEraseUnsol/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEmergencyEraseUnsol/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEmergencyEraseUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEmergencyEraseUnsolSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEmergencyEraseUnsol/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEmergencyEraseUnsol/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEmergencyEraseUnsolSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEmergencyEraseUnsolSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEmergencyEraseUnsol/SPM", "Class": sHMI_EMERGENCY_ERASE_UNSOL, "ClassName": "sHMI_EMERGENCY_ERASE_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEmergencyEraseUnsol/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEmergencyEraseUnsol/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEmergencyEraseUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEmergencyEraseUnsolOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEmergencyEraseUnsol/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEmergencyEraseUnsol/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEmergencyEraseUnsolOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEmergencyEraseUnsolOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEmergencyEraseUnsol/Oversight", "Class": sHMI_EMERGENCY_ERASE_UNSOL, "ClassName": "sHMI_EMERGENCY_ERASE_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEmergencyEraseUnsol/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEmergencyEraseUnsol/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEmergencyEraseUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEmergencyEraseUnsolMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEmergencyEraseUnsol/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEmergencyEraseUnsol/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEmergencyEraseUnsolMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEmergencyEraseUnsolMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEmergencyEraseUnsol/Maintainer", "Class": sHMI_EMERGENCY_ERASE_UNSOL, "ClassName": "sHMI_EMERGENCY_ERASE_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEmergencyEraseUnsol/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEmergencyEraseUnsol/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEmergencyEraseUnsol/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEmergencyEraseUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfSetupCmdAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmd/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfSetupCmdRspAPM(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfSetupCmdAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmd/APM", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmd/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmd's future -> %s", str(E))

        return(sHMI_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTHmiEndOfSetupCmdRspAPM(self, objHmiEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/APM", objHmiEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfSetupCmdFCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmd/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdFCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfSetupCmdRspFCO(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfSetupCmdFCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmd/FCO", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmd/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmd's future -> %s", str(E))

        return(sHMI_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTHmiEndOfSetupCmdRspFCO(self, objHmiEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/FCO", objHmiEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfSetupCmdAPM_FCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmd/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/APM_FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdAPM_FCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfSetupCmdRspAPM_FCO(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfSetupCmdAPM_FCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmd/APM_FCO", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmd/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/APM_FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmd's future -> %s", str(E))

        return(sHMI_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTHmiEndOfSetupCmdRspAPM_FCO(self, objHmiEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FCO", objHmiEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfSetupCmdSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmd/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfSetupCmdRspSPM(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfSetupCmdSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmd/SPM", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmd/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmd's future -> %s", str(E))

        return(sHMI_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTHmiEndOfSetupCmdRspSPM(self, objHmiEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM", objHmiEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfSetupCmdFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmd/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfSetupCmdRspFUFC(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfSetupCmdFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmd/FUFC", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmd/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmd's future -> %s", str(E))

        return(sHMI_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTHmiEndOfSetupCmdRspFUFC(self, objHmiEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC", objHmiEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfSetupCmdSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfSetupCmdRspSPM_FUFC(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfSetupCmdSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmd's future -> %s", str(E))

        return(sHMI_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTHmiEndOfSetupCmdRspSPM_FUFC(self, objHmiEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC", objHmiEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfSetupCmdOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmd/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfSetupCmdRspOversight(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfSetupCmdOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmd/Oversight", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmd/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmd's future -> %s", str(E))

        return(sHMI_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTHmiEndOfSetupCmdRspOversight(self, objHmiEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight", objHmiEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfSetupCmdMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmd/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfSetupCmdRspMaintainer(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfSetupCmdMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmd/Maintainer", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmd/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmd's future -> %s", str(E))

        return(sHMI_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTHmiEndOfSetupCmdRspMaintainer(self, objHmiEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer", objHmiEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfReadyCmdAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmd/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfReadyCmdRspAPM(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfReadyCmdAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmd/APM", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmd/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmd's future -> %s", str(E))

        return(sHMI_END_OF_READY_CMD_RSP())

    def vPublishToMQQTHmiEndOfReadyCmdRspAPM(self, objHmiEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/APM", objHmiEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfReadyCmdFCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmd/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdFCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfReadyCmdRspFCO(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfReadyCmdFCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmd/FCO", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmd/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmd's future -> %s", str(E))

        return(sHMI_END_OF_READY_CMD_RSP())

    def vPublishToMQQTHmiEndOfReadyCmdRspFCO(self, objHmiEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/FCO", objHmiEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfReadyCmdAPM_FCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmd/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/APM_FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdAPM_FCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfReadyCmdRspAPM_FCO(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfReadyCmdAPM_FCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmd/APM_FCO", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmd/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/APM_FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmd's future -> %s", str(E))

        return(sHMI_END_OF_READY_CMD_RSP())

    def vPublishToMQQTHmiEndOfReadyCmdRspAPM_FCO(self, objHmiEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO", objHmiEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfReadyCmdSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmd/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfReadyCmdRspSPM(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfReadyCmdSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmd/SPM", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmd/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmd's future -> %s", str(E))

        return(sHMI_END_OF_READY_CMD_RSP())

    def vPublishToMQQTHmiEndOfReadyCmdRspSPM(self, objHmiEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM", objHmiEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfReadyCmdFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmd/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfReadyCmdRspFUFC(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfReadyCmdFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmd/FUFC", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmd/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmd's future -> %s", str(E))

        return(sHMI_END_OF_READY_CMD_RSP())

    def vPublishToMQQTHmiEndOfReadyCmdRspFUFC(self, objHmiEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC", objHmiEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfReadyCmdSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfReadyCmdRspSPM_FUFC(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfReadyCmdSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmd's future -> %s", str(E))

        return(sHMI_END_OF_READY_CMD_RSP())

    def vPublishToMQQTHmiEndOfReadyCmdRspSPM_FUFC(self, objHmiEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC", objHmiEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfReadyCmdOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmd/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfReadyCmdRspOversight(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfReadyCmdOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmd/Oversight", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmd/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmd's future -> %s", str(E))

        return(sHMI_END_OF_READY_CMD_RSP())

    def vPublishToMQQTHmiEndOfReadyCmdRspOversight(self, objHmiEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight", objHmiEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfReadyCmdMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmd/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfReadyCmdRspMaintainer(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfReadyCmdMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmd/Maintainer", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmd/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmd's future -> %s", str(E))

        return(sHMI_END_OF_READY_CMD_RSP())

    def vPublishToMQQTHmiEndOfReadyCmdRspMaintainer(self, objHmiEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer", objHmiEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiShutdownCmdAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmd/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiShutdownCmdRspAPM(objReplyMessage)

        return

    async def objProcessPayloadHmiShutdownCmdAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmd/APM", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmd/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmd's future -> %s", str(E))

        return(sHMI_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTHmiShutdownCmdRspAPM(self, objHmiShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiShutdownCmdRsp/APM", objHmiShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiShutdownCmdFCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmd/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdFCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiShutdownCmdRspFCO(objReplyMessage)

        return

    async def objProcessPayloadHmiShutdownCmdFCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmd/FCO", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmd/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmd's future -> %s", str(E))

        return(sHMI_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTHmiShutdownCmdRspFCO(self, objHmiShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiShutdownCmdRsp/FCO", objHmiShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiShutdownCmdAPM_FCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmd/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/APM_FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdAPM_FCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiShutdownCmdRspAPM_FCO(objReplyMessage)

        return

    async def objProcessPayloadHmiShutdownCmdAPM_FCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmd/APM_FCO", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmd/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/APM_FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmd's future -> %s", str(E))

        return(sHMI_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTHmiShutdownCmdRspAPM_FCO(self, objHmiShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiShutdownCmdRsp/APM_FCO", objHmiShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiShutdownCmdSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmd/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiShutdownCmdRspSPM(objReplyMessage)

        return

    async def objProcessPayloadHmiShutdownCmdSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmd/SPM", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmd/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmd's future -> %s", str(E))

        return(sHMI_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTHmiShutdownCmdRspSPM(self, objHmiShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiShutdownCmdRsp/SPM", objHmiShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiShutdownCmdFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmd/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiShutdownCmdRspFUFC(objReplyMessage)

        return

    async def objProcessPayloadHmiShutdownCmdFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmd/FUFC", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmd/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmd's future -> %s", str(E))

        return(sHMI_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTHmiShutdownCmdRspFUFC(self, objHmiShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiShutdownCmdRsp/FUFC", objHmiShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiShutdownCmdSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmd/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiShutdownCmdRspSPM_FUFC(objReplyMessage)

        return

    async def objProcessPayloadHmiShutdownCmdSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmd/SPM_FUFC", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmd/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmd's future -> %s", str(E))

        return(sHMI_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTHmiShutdownCmdRspSPM_FUFC(self, objHmiShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC", objHmiShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiShutdownCmdOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmd/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiShutdownCmdRspOversight(objReplyMessage)

        return

    async def objProcessPayloadHmiShutdownCmdOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmd/Oversight", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmd/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmd's future -> %s", str(E))

        return(sHMI_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTHmiShutdownCmdRspOversight(self, objHmiShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiShutdownCmdRsp/Oversight", objHmiShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiShutdownCmdMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmd/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiShutdownCmdRspMaintainer(objReplyMessage)

        return

    async def objProcessPayloadHmiShutdownCmdMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmd/Maintainer", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmd/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmd's future -> %s", str(E))

        return(sHMI_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTHmiShutdownCmdRspMaintainer(self, objHmiShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiShutdownCmdRsp/Maintainer", objHmiShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessOlhmAdcsHmiStatusUnsol(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/OlhmAdcsHmiStatusUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/OlhmAdcsHmiStatusUnsol is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/OlhmAdcsHmiStatusUnsol"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/OlhmAdcsHmiStatusUnsol"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/OlhmAdcsHmiStatusUnsol"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/OlhmAdcsHmiStatusUnsol"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/OlhmAdcsHmiStatusUnsol"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/OlhmAdcsHmiStatusUnsol"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadOlhmAdcsHmiStatusUnsol(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadOlhmAdcsHmiStatusUnsol(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/OlhmAdcsHmiStatusUnsol", "Class": sOLHM_ADCS_HMI_STATUS_UNSOL, "ClassName": "sOLHM_ADCS_HMI_STATUS_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/OlhmAdcsHmiStatusUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/OlhmAdcsHmiStatusUnsol is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/OlhmAdcsHmiStatusUnsol"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/OlhmAdcsHmiStatusUnsol"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/OlhmAdcsHmiStatusUnsol"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("OlhmAdcsHmiStatusUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdRspAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdRspAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdRspAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/APM", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdRspFCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdRspFCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdRspFCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdRspAPM_FCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdRspAPM_FCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdRspAPM_FCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdRspSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdRspSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdRspSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdRspFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdRspFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdRspFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdRspSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdRspSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdRspSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdRspOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdRspOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdRspOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdRspMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdRspMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdRspMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    def vStorePublishConnectionState(self, tplPublishReturnStatePar):
        """ This is a public method which sets the connection state after a publish is done

        Args:
            tplPublishReturnStatePar (tuple): The first parameter. A tuple which came from the mqtt publish method. The items are (result, mid).

        Returns:

        Raises:
            Raises no exception.
        """
        # Store the current connection state
        self._tplPublishConnectionStateLast = tplPublishReturnStatePar
        if (self._tplPublishConnectionStateLast[0] != mqtt.MQTT_ERR_SUCCESS):
            self._tplPublishConnectionStateFirstFail = self._tplPublishConnectionStateLast

        return

    def vClearPublishConnectionState(self):
        """ This is a public method which sets the connection state to SUCCESS

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        # Set the current connection state
        self._tplPublishConnectionStateLast = (mqtt.MQTT_ERR_SUCCESS, 0)
        self._tplPublishConnectionStateFirstFail = (mqtt.MQTT_ERR_SUCCESS, 0)

        return

    def bMqttIsConnected(self):
        """ This is a public method which returns the mqtt broker connection state

        Args:

        Returns:
            (bool): Boolean value indicating if the mqtt broker connection is still active.

        Raises:
            Raises no exception.
        """
        # Store the current connection state
        return(self._tplPublishConnectionStateFirstFail[0] == mqtt.MQTT_ERR_SUCCESS)

# ==========================================================
# MQTT TEMPLATE CLASS STOP
# ==========================================================
# ==========================================================
# AUTOGEN STOP
# ==========================================================