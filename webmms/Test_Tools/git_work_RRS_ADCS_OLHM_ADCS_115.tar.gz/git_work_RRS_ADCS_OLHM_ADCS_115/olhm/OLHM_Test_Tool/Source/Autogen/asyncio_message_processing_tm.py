#! /usr/bin/env python
# -*- coding: utf-8 -*-
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:32:41 SAST

    This module is the asyncio message processing class generated automatically from XML file(s). It is intended use is as a base class
    for a derived class which will be used in the asyncio event loop. The vProcessDictObj() method should only be called inside the
    asyncio event loop and using a create_task() call. Failure to do so might block the process currently running and should only be used
    as intended in a well designed asyncio implementation.

"""
# ==========================================================
# AUTOGEN START
# ==========================================================
import logging  # This is required to be able to log if there are problems
import asyncio  # This is required to concurrent operations in a single thread
import datetime  # This is needed to set a datetime result on a future
import time  # This is needed to get the time as time.CLOCK_MONOTONIC_RAW
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
from Autogen.mw_common_types import E2_MW_MESSAGE_STATUS
from Autogen.tm_msg import *  # noqa: F401
from Autogen.dsf_msg import *  # noqa: F401
from Autogen.eiu_msg import *  # noqa: F401
from Autogen.hmi_msg import *  # noqa: F401

# ==========================================================
# MQTT TEMPLATE CLASS START
# ==========================================================


class clsPythonAsyncioMessageProcessing():
    """ This is the message asyncio processing autogen class

    This is the message processing asyncio autogen class. Inherit this class in order to
    override the methods if required.

    Args:
        objMqttClientPar (mqtt.Client): The first parameter. The MQTT client instance for sending to the broker.
        dctMessagesPar (dict): The second parameter. A dictionary containing all messages and futures for messages which were automatically processed by the autogen
        lstTasksAllowedForsimultaneousExecutionPar (list): The third parameter. A list of topics for which simultaneous task execution is allowed. An empty list means no topics are allowed to execute simultaneously.
        objAsyncioLoopPar (object): The fourth parameter. The asyncio loop passed in so tasks can be created and for other asyncio functionality
        bLoggingEnabledPar (bool): The fifth parameter. A boolean flag indicating if logging should be done or not.

    """
    def __init__(self, objMqttClientPar: mqtt.Client, dctMessagesPar: dict, lstTasksAllowedForsimultaneousExecutionPar: list, objAsyncioLoopPar: object, bLoggingEnabledPar: bool = True):
        super().__init__()
        self._objMqttClient = objMqttClientPar
        self._dctMessages = dctMessagesPar
        self._lstTasksAllowedForsimultaneousExecution = lstTasksAllowedForsimultaneousExecutionPar
        self._objAsyncioLoop = objAsyncioLoopPar
        self._bLoggingEnabled = bLoggingEnabledPar
        # When we mqtt publish the connection state is returned - This property stores the last state
        self._tplPublishConnectionStateLast = (mqtt.MQTT_ERR_SUCCESS, 0)
        # When we mqtt publish the connection state is returned - This property stores the first time it failed 
        self._tplPublishConnectionStateFirstFail = (mqtt.MQTT_ERR_SUCCESS, 0)

        # In the message dictionary we store the Topic, ClassName, Class, MsgObject, Future, UTC timestamp, monotonic raw timestamp and role
        self._dctMessages["ADCS/TM/TmStatusReportUnsol"] = {"ClassName": "sTM_STATUS_REPORT_UNSOL", "Class": sTM_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"] = {"ClassName": "sTM_END_OF_SETUP_CMD_RSP", "Class": sTM_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"] = {"ClassName": "sTM_END_OF_READY_CMD_RSP", "Class": sTM_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TM/TmShutdownCmdRsp"] = {"ClassName": "sTM_SHUTDOWN_CMD_RSP", "Class": sTM_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TM/TmEndOfSetupCmd"] = {"ClassName": "sTM_END_OF_SETUP_CMD", "Class": sTM_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TM/TmEndOfReadyCmd"] = {"ClassName": "sTM_END_OF_READY_CMD", "Class": sTM_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TM/TmShutdownCmd"] = {"ClassName": "sTM_SHUTDOWN_CMD", "Class": sTM_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        # We have this dictionary to demux a topic into the processing method which should be called - it's more efficient than a long list of if statements
        self._dctDemuxTopicToMethod = {
            "ADCS/TM/TmStatusReportUnsol": self.vProcessTmStatusReportUnsol,
            "ADCS/TM/TmEndOfSetupCmdRsp": self.vProcessTmEndOfSetupCmdRsp,
            "ADCS/TM/TmEndOfReadyCmdRsp": self.vProcessTmEndOfReadyCmdRsp,
            "ADCS/TM/TmShutdownCmdRsp": self.vProcessTmShutdownCmdRsp,
            "ADCS/TM/TmEndOfSetupCmd": self.vProcessTmEndOfSetupCmd,
            "ADCS/TM/TmEndOfReadyCmd": self.vProcessTmEndOfReadyCmd,
            "ADCS/TM/TmShutdownCmd": self.vProcessTmShutdownCmd,
        }

        # This is a dictionary which keeps track of how many tasks are currently being executed per topic - for typical use this number will be either 0 or 1
        self._dctNumExecutingTasks = {
            "ADCS/TM/TmStatusReportUnsol": 0,
            "ADCS/TM/TmEndOfSetupCmdRsp": 0,
            "ADCS/TM/TmEndOfReadyCmdRsp": 0,
            "ADCS/TM/TmShutdownCmdRsp": 0,
            "ADCS/TM/TmEndOfSetupCmd": 0,
            "ADCS/TM/TmEndOfReadyCmd": 0,
            "ADCS/TM/TmShutdownCmd": 0,
        }

    # ==========================================================
    # PROCESS DICTIONARY START
    # ==========================================================
    async def vProcessDictObj(self, dctObjectPar) -> None:
        """ This is a public method which demuxes messages from the python queue.

        This is a public method which demuxes messages from the python queue. It uses a dictionary as a lookup in
        order to determine which method to call. Unknown topics will be logged as an error.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """

        # Make sure our input parameter is not None
        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        # Make sure our input parameter dictionary does have a topic key
        if ("Topic" not in dctObjectPar):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar does not contain the key Topic")
            return

        # Use the demux dictionary to determine which method should be called
        if (dctObjectPar["Topic"] in self._dctDemuxTopicToMethod):
            if ((self._dctNumExecutingTasks[dctObjectPar["Topic"]] <= 0) or (dctObjectPar["Topic"] in self._lstTasksAllowedForsimultaneousExecution)):
                self._dctNumExecutingTasks[dctObjectPar["Topic"]] += 1
                await self._dctDemuxTopicToMethod[dctObjectPar["Topic"]](dctObjectPar)
                self._dctNumExecutingTasks[dctObjectPar["Topic"]] -= 1
            else:
                logging.warning("Incoming topic %s cannot be processed right now because there is already a task executing for it - the task counter is %d", dctObjectPar["Topic"], self._dctNumExecutingTasks[dctObjectPar["Topic"]])
        else:
            logging.error("Received message with topic %s does not have a corresponding processing method to call - demux failed because topic unknown", dctObjectPar["Topic"])

        return

    # ==========================================================
    # PROCESS DICTIONARY START
    # ==========================================================
    async def vProcessTmStatusReportUnsol(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TM/TmStatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmStatusReportUnsol is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TM/TmStatusReportUnsol"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TM/TmStatusReportUnsol"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TM/TmStatusReportUnsol"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TM/TmStatusReportUnsol"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TM/TmStatusReportUnsol"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TM/TmStatusReportUnsol"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTmStatusReportUnsol(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadTmStatusReportUnsol(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TM/TmStatusReportUnsol", "Class": sTM_STATUS_REPORT_UNSOL, "ClassName": "sTM_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TM/TmStatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmStatusReportUnsol is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TM/TmStatusReportUnsol"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TM/TmStatusReportUnsol"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TM/TmStatusReportUnsol"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TmStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessTmEndOfSetupCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TM/TmEndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmEndOfSetupCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTmEndOfSetupCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadTmEndOfSetupCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TM/TmEndOfSetupCmdRsp", "Class": sTM_END_OF_SETUP_CMD_RSP, "ClassName": "sTM_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TM/TmEndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmEndOfSetupCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TmEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessTmEndOfReadyCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TM/TmEndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmEndOfReadyCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTmEndOfReadyCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadTmEndOfReadyCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TM/TmEndOfReadyCmdRsp", "Class": sTM_END_OF_READY_CMD_RSP, "ClassName": "sTM_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TM/TmEndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmEndOfReadyCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TmEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessTmShutdownCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TM/TmShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmShutdownCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TM/TmShutdownCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TM/TmShutdownCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TM/TmShutdownCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TM/TmShutdownCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TM/TmShutdownCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TM/TmShutdownCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTmShutdownCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadTmShutdownCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TM/TmShutdownCmdRsp", "Class": sTM_SHUTDOWN_CMD_RSP, "ClassName": "sTM_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TM/TmShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmShutdownCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TM/TmShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TM/TmShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TM/TmShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TmShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessTmEndOfSetupCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TM/TmEndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmEndOfSetupCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TM/TmEndOfSetupCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TM/TmEndOfSetupCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TM/TmEndOfSetupCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TM/TmEndOfSetupCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TM/TmEndOfSetupCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TM/TmEndOfSetupCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTmEndOfSetupCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTTmEndOfSetupCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadTmEndOfSetupCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TM/TmEndOfSetupCmd", "Class": sTM_END_OF_SETUP_CMD, "ClassName": "sTM_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TM/TmEndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmEndOfSetupCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TM/TmEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TM/TmEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TM/TmEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TmEndOfSetupCmd's future -> %s", str(E))

        return(sTM_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTTmEndOfSetupCmdRsp(self, objTmEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objTmEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objTmEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objTmEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/TM/TmEndOfSetupCmdRsp", objTmEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessTmEndOfReadyCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TM/TmEndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmEndOfReadyCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TM/TmEndOfReadyCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TM/TmEndOfReadyCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TM/TmEndOfReadyCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TM/TmEndOfReadyCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TM/TmEndOfReadyCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TM/TmEndOfReadyCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTmEndOfReadyCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTTmEndOfReadyCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadTmEndOfReadyCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TM/TmEndOfReadyCmd", "Class": sTM_END_OF_READY_CMD, "ClassName": "sTM_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TM/TmEndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmEndOfReadyCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TM/TmEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TM/TmEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TM/TmEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TmEndOfReadyCmd's future -> %s", str(E))

        return(sTM_END_OF_READY_CMD_RSP())

    def vPublishToMQQTTmEndOfReadyCmdRsp(self, objTmEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objTmEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objTmEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objTmEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/TM/TmEndOfReadyCmdRsp", objTmEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessTmShutdownCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TM/TmShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmShutdownCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TM/TmShutdownCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TM/TmShutdownCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TM/TmShutdownCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TM/TmShutdownCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TM/TmShutdownCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TM/TmShutdownCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTmShutdownCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTTmShutdownCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadTmShutdownCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TM/TmShutdownCmd", "Class": sTM_SHUTDOWN_CMD, "ClassName": "sTM_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TM/TmShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmShutdownCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TM/TmShutdownCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TM/TmShutdownCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TM/TmShutdownCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TmShutdownCmd's future -> %s", str(E))

        return(sTM_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTTmShutdownCmdRsp(self, objTmShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objTmShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objTmShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objTmShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/TM/TmShutdownCmdRsp", objTmShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    def vStorePublishConnectionState(self, tplPublishReturnStatePar):
        """ This is a public method which sets the connection state after a publish is done

        Args:
            tplPublishReturnStatePar (tuple): The first parameter. A tuple which came from the mqtt publish method. The items are (result, mid).

        Returns:

        Raises:
            Raises no exception.
        """
        # Store the current connection state
        self._tplPublishConnectionStateLast = tplPublishReturnStatePar
        if (self._tplPublishConnectionStateLast[0] != mqtt.MQTT_ERR_SUCCESS):
            self._tplPublishConnectionStateFirstFail = self._tplPublishConnectionStateLast

        return

    def vClearPublishConnectionState(self):
        """ This is a public method which sets the connection state to SUCCESS

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        # Set the current connection state
        self._tplPublishConnectionStateLast = (mqtt.MQTT_ERR_SUCCESS, 0)
        self._tplPublishConnectionStateFirstFail = (mqtt.MQTT_ERR_SUCCESS, 0)

        return

    def bMqttIsConnected(self):
        """ This is a public method which returns the mqtt broker connection state

        Args:

        Returns:
            (bool): Boolean value indicating if the mqtt broker connection is still active.

        Raises:
            Raises no exception.
        """
        # Store the current connection state
        return(self._tplPublishConnectionStateFirstFail[0] == mqtt.MQTT_ERR_SUCCESS)

# ==========================================================
# MQTT TEMPLATE CLASS STOP
# ==========================================================
# ==========================================================
# AUTOGEN STOP
# ==========================================================