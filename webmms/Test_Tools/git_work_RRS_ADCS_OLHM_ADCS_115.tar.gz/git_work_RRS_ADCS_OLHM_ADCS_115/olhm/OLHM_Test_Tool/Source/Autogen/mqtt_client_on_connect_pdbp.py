#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:32:42 SAST

    This module is the mqtt client on connect class, generated automatically from XML file(s). Its intended use is as a class
    with mqtt callbacks for on_connect() and on_message(). This class should be instantiated before the mqtt connect. The mqtt 
    on_connect() callback should be redirected as -> client.on_connect = objClsMqttAutogenHandler.vOnConnect
    It should be noted that all operations inside this class will execute inside the mqtt thread. The processing methods in this class
    will validate the incoming messages and reply only if validation failed. Messages which passed validation will be placed in a queue provided to
    the constructor of the class. 

"""
# ==========================================================
# AUTOGEN START
# ==========================================================
import logging  # This is required to be able to log if there are problems
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
import queue  # This is required to put the received message in a queue to pass on to another non-mqtt thread
from copy import deepcopy  # This is required to make a deepcopy of the message before insertion in the queue - it ensures proper garbage collection
from Autogen.mw_common_types import E2_MW_MESSAGE_STATUS
from Autogen.pdbp_msg import *  # noqa: F401

# ==========================================================
# MQTT TEMPLATE CLASS START
# ==========================================================


class clsMqttAutogenHandler():
    """ This is the MQTT message handling autogen base class

    This is the MQTT message handling autogen base class. An instance of this class should be made before giving the mqtt client
    a on_connect() callback from this class.

    Args:
        objQueuePar (queue.Queue): The first parameter. The instance of the python queue into which we will push messages received
        bLoggingEnabledPar (bool): The second parameter. A boolean flag indicating if logging should be done or not. This parameter is by default True

    """
    def __init__(self, objQueuePar: queue.Queue, bLoggingEnabledPar: bool = True):
        super().__init__()
        self._bLoggingEnabled = bLoggingEnabledPar
        self._objQueue = objQueuePar
        # By default all subscriptions will auto reply if a ReplyMsg was specified
        self.bAutoReplyForSubscriptionPdbpEndOfReadyCmd = True
        self.bAutoReplyForSubscriptionPdbpShutdownCmd = True
        self.bAutoReplyForSubscriptionPdbpSendOutModuleDbMessagesCmd = True
        self.bAutoReplyForSubscriptionPdbpExportPdbToJsonFileCmd = True
        self.bAutoReplyForSubscriptionPdbpStorageStateCmd = True
        self.bAutoReplyForSubscriptionPdbpLoadFactoryPersistentParametersCmd = True
        self.bAutoReplyForSubscriptionPdbpUploadJsonFileIntoPpdbCmd = True

    def vOnConnect(self, objMqttClientPar: mqtt.Client, userDataPar, dctFlags, iConnectionResult: int) -> None:  # pylint: disable=W0613
        """ This is the callback method for when client receives a CONNACK response from the server

        This is the callback method for when client receives a CONNACK response from the server. This method subscribes
        and registers callback methods for all incoming messages. Messages from secondary XML files will not automatically be
        subscribed to. The on message callbacks will however all automatically be registered even for secondary XML files.

        Args:
            objMqttClientPar (obj): The first parameter. A MQTT client object
            userDataPar: The second parameter. The private user data as set in Client() or userdata_set()
            flags: The third parameter. flags is a dict that contains response flags from the broker:
            rc: The fourth parameter. The connection result

        Returns:

        Raises:
            Raises no exceptions
        """

        # Subscribing and adding callback for PdbpEndOfReadyCmd 
        # Subscribing and adding callback for PdbpEndOfReadyCmd 
        # Subscribing and adding callback for PdbpEndOfReadyCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message PdbpEndOfReadyCmd  with topic ADCS/PDBP/PdbpEndOfReadyCmd")

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpEndOfReadyCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpEndOfReadyCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for PdbpEndOfReadyCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/PDBP/PdbpEndOfReadyCmd", self.vOnMessageCallbackPdbpEndOfReadyCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for PdbpEndOfReadyCmd  - Exception %s", str(E))
        # Subscribing and adding callback for PdbpShutdownCmd 
        # Subscribing and adding callback for PdbpShutdownCmd 
        # Subscribing and adding callback for PdbpShutdownCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message PdbpShutdownCmd  with topic ADCS/PDBP/PdbpShutdownCmd")

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpShutdownCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpShutdownCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for PdbpShutdownCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/PDBP/PdbpShutdownCmd", self.vOnMessageCallbackPdbpShutdownCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for PdbpShutdownCmd  - Exception %s", str(E))
        # Subscribing and adding callback for PdbpSendOutModuleDbMessagesCmd 
        # Subscribing and adding callback for PdbpSendOutModuleDbMessagesCmd 
        # Subscribing and adding callback for PdbpSendOutModuleDbMessagesCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message PdbpSendOutModuleDbMessagesCmd  with topic ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd")

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpSendOutModuleDbMessagesCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for PdbpSendOutModuleDbMessagesCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd", self.vOnMessageCallbackPdbpSendOutModuleDbMessagesCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for PdbpSendOutModuleDbMessagesCmd  - Exception %s", str(E))
        # Subscribing and adding callback for PdbpExportPdbToJsonFileCmd 
        # Subscribing and adding callback for PdbpExportPdbToJsonFileCmd 
        # Subscribing and adding callback for PdbpExportPdbToJsonFileCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message PdbpExportPdbToJsonFileCmd  with topic ADCS/PDBP/PdbpExportPdbToJsonFileCmd")

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpExportPdbToJsonFileCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpExportPdbToJsonFileCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for PdbpExportPdbToJsonFileCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/PDBP/PdbpExportPdbToJsonFileCmd", self.vOnMessageCallbackPdbpExportPdbToJsonFileCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for PdbpExportPdbToJsonFileCmd  - Exception %s", str(E))
        # Subscribing and adding callback for PdbpStorageStateCmd 
        # Subscribing and adding callback for PdbpStorageStateCmd 
        # Subscribing and adding callback for PdbpStorageStateCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message PdbpStorageStateCmd  with topic ADCS/PDBP/PdbpStorageStateCmd")

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpStorageStateCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpStorageStateCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for PdbpStorageStateCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/PDBP/PdbpStorageStateCmd", self.vOnMessageCallbackPdbpStorageStateCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for PdbpStorageStateCmd  - Exception %s", str(E))
        # Subscribing and adding callback for PdbpLoadFactoryPersistentParametersCmd 
        # Subscribing and adding callback for PdbpLoadFactoryPersistentParametersCmd 
        # Subscribing and adding callback for PdbpLoadFactoryPersistentParametersCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message PdbpLoadFactoryPersistentParametersCmd  with topic ADCS/PDBP/PdbpLoadFactoryPersistentParametersCmd")

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpLoadFactoryPersistentParametersCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpLoadFactoryPersistentParametersCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for PdbpLoadFactoryPersistentParametersCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/PDBP/PdbpLoadFactoryPersistentParametersCmd", self.vOnMessageCallbackPdbpLoadFactoryPersistentParametersCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for PdbpLoadFactoryPersistentParametersCmd  - Exception %s", str(E))
        # Subscribing and adding callback for PdbpUploadJsonFileIntoPpdbCmd 
        # Subscribing and adding callback for PdbpUploadJsonFileIntoPpdbCmd 
        # Subscribing and adding callback for PdbpUploadJsonFileIntoPpdbCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message PdbpUploadJsonFileIntoPpdbCmd  with topic ADCS/PDBP/PdbpUploadJsonFileIntoPpdbCmd")

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpUploadJsonFileIntoPpdbCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpUploadJsonFileIntoPpdbCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for PdbpUploadJsonFileIntoPpdbCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/PDBP/PdbpUploadJsonFileIntoPpdbCmd", self.vOnMessageCallbackPdbpUploadJsonFileIntoPpdbCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for PdbpUploadJsonFileIntoPpdbCmd  - Exception %s", str(E))

        return

# =========================================================="
# MQTT CALLBACK METHODS START
# =========================================================="

    def vOnMessageCallbackPdbpEndOfReadyCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message PdbpEndOfReadyCmd

        This is a public method callback for message PdbpEndOfReadyCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objPdbpEndOfReadyCmd = sPDBP_END_OF_READY_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objPdbpEndOfReadyCmdRsp = sPDBP_END_OF_READY_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpEndOfReadyCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpEndOfReadyCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpEndOfReadyCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objPdbpEndOfReadyCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpEndOfReadyCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objPdbpEndOfReadyCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for PdbpEndOfReadyCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objPdbpEndOfReadyCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpEndOfReadyCmd  validation failed")
            elif (objPdbpEndOfReadyCmd.sMsgHeader.u2MsgLength.Value != (objPdbpEndOfReadyCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpEndOfReadyCmd  length field is invalid - it is %d and should be %d bytes", objPdbpEndOfReadyCmd.sMsgHeader.u2MsgLength.Value, objPdbpEndOfReadyCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/PDBP/PdbpEndOfReadyCmd", "Class": sPDBP_END_OF_READY_CMD, "ClassName": "sPDBP_END_OF_READY_CMD", "acRole": "", "MsgObject": deepcopy(objPdbpEndOfReadyCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/PDBP/PdbpEndOfReadyCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionPdbpEndOfReadyCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objPdbpEndOfReadyCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/PDBP/PdbpEndOfReadyCmdRsp", objPdbpEndOfReadyCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("PdbpEndOfReadyCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackPdbpShutdownCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message PdbpShutdownCmd

        This is a public method callback for message PdbpShutdownCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objPdbpShutdownCmd = sPDBP_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objPdbpShutdownCmdRsp = sPDBP_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpShutdownCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpShutdownCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpShutdownCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objPdbpShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpShutdownCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objPdbpShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for PdbpShutdownCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objPdbpShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpShutdownCmd  validation failed")
            elif (objPdbpShutdownCmd.sMsgHeader.u2MsgLength.Value != (objPdbpShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpShutdownCmd  length field is invalid - it is %d and should be %d bytes", objPdbpShutdownCmd.sMsgHeader.u2MsgLength.Value, objPdbpShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/PDBP/PdbpShutdownCmd", "Class": sPDBP_SHUTDOWN_CMD, "ClassName": "sPDBP_SHUTDOWN_CMD", "acRole": "", "MsgObject": deepcopy(objPdbpShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/PDBP/PdbpShutdownCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionPdbpShutdownCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objPdbpShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/PDBP/PdbpShutdownCmdRsp", objPdbpShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("PdbpShutdownCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackPdbpSendOutModuleDbMessagesCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message PdbpSendOutModuleDbMessagesCmd

        This is a public method callback for message PdbpSendOutModuleDbMessagesCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objPdbpSendOutModuleDbMessagesCmd = sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objPdbpSendOutModuleDbMessagesCmdRsp = sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpSendOutModuleDbMessagesCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpSendOutModuleDbMessagesCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpSendOutModuleDbMessagesCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objPdbpSendOutModuleDbMessagesCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpSendOutModuleDbMessagesCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objPdbpSendOutModuleDbMessagesCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for PdbpSendOutModuleDbMessagesCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objPdbpSendOutModuleDbMessagesCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpSendOutModuleDbMessagesCmd  validation failed")
            elif (objPdbpSendOutModuleDbMessagesCmd.sMsgHeader.u2MsgLength.Value != (objPdbpSendOutModuleDbMessagesCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpSendOutModuleDbMessagesCmd  length field is invalid - it is %d and should be %d bytes", objPdbpSendOutModuleDbMessagesCmd.sMsgHeader.u2MsgLength.Value, objPdbpSendOutModuleDbMessagesCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd", "Class": sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD, "ClassName": "sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD", "acRole": "", "MsgObject": deepcopy(objPdbpSendOutModuleDbMessagesCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionPdbpSendOutModuleDbMessagesCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objPdbpSendOutModuleDbMessagesCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp", objPdbpSendOutModuleDbMessagesCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("PdbpSendOutModuleDbMessagesCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackPdbpExportPdbToJsonFileCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message PdbpExportPdbToJsonFileCmd

        This is a public method callback for message PdbpExportPdbToJsonFileCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objPdbpExportPdbToJsonFileCmd = sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objPdbpExportPdbToJsonFileCmdRsp = sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpExportPdbToJsonFileCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpExportPdbToJsonFileCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpExportPdbToJsonFileCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objPdbpExportPdbToJsonFileCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpExportPdbToJsonFileCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objPdbpExportPdbToJsonFileCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for PdbpExportPdbToJsonFileCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objPdbpExportPdbToJsonFileCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpExportPdbToJsonFileCmd  validation failed")
            elif (objPdbpExportPdbToJsonFileCmd.sMsgHeader.u2MsgLength.Value != (objPdbpExportPdbToJsonFileCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpExportPdbToJsonFileCmd  length field is invalid - it is %d and should be %d bytes", objPdbpExportPdbToJsonFileCmd.sMsgHeader.u2MsgLength.Value, objPdbpExportPdbToJsonFileCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/PDBP/PdbpExportPdbToJsonFileCmd", "Class": sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD, "ClassName": "sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD", "acRole": "", "MsgObject": deepcopy(objPdbpExportPdbToJsonFileCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/PDBP/PdbpExportPdbToJsonFileCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionPdbpExportPdbToJsonFileCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objPdbpExportPdbToJsonFileCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/PDBP/PdbpExportPdbToJsonFileCmdRsp", objPdbpExportPdbToJsonFileCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("PdbpExportPdbToJsonFileCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackPdbpStorageStateCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message PdbpStorageStateCmd

        This is a public method callback for message PdbpStorageStateCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objPdbpStorageStateCmd = sPDBP_STORAGE_STATE_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objPdbpStorageStateCmdRsp = sPDBP_STORAGE_STATE_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpStorageStateCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpStorageStateCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpStorageStateCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objPdbpStorageStateCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpStorageStateCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objPdbpStorageStateCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for PdbpStorageStateCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objPdbpStorageStateCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpStorageStateCmd  validation failed")
            elif (objPdbpStorageStateCmd.sMsgHeader.u2MsgLength.Value != (objPdbpStorageStateCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpStorageStateCmd  length field is invalid - it is %d and should be %d bytes", objPdbpStorageStateCmd.sMsgHeader.u2MsgLength.Value, objPdbpStorageStateCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/PDBP/PdbpStorageStateCmd", "Class": sPDBP_STORAGE_STATE_CMD, "ClassName": "sPDBP_STORAGE_STATE_CMD", "acRole": "", "MsgObject": deepcopy(objPdbpStorageStateCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/PDBP/PdbpStorageStateCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionPdbpStorageStateCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objPdbpStorageStateCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/PDBP/PdbpStorageStateCmdRsp", objPdbpStorageStateCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("PdbpStorageStateCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackPdbpLoadFactoryPersistentParametersCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message PdbpLoadFactoryPersistentParametersCmd

        This is a public method callback for message PdbpLoadFactoryPersistentParametersCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objPdbpLoadFactoryPersistentParametersCmd = sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objPdbpLoadFactoryPersistentParametersCmdRsp = sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpLoadFactoryPersistentParametersCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpLoadFactoryPersistentParametersCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpLoadFactoryPersistentParametersCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objPdbpLoadFactoryPersistentParametersCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpLoadFactoryPersistentParametersCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objPdbpLoadFactoryPersistentParametersCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for PdbpLoadFactoryPersistentParametersCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objPdbpLoadFactoryPersistentParametersCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpLoadFactoryPersistentParametersCmd  validation failed")
            elif (objPdbpLoadFactoryPersistentParametersCmd.sMsgHeader.u2MsgLength.Value != (objPdbpLoadFactoryPersistentParametersCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpLoadFactoryPersistentParametersCmd  length field is invalid - it is %d and should be %d bytes", objPdbpLoadFactoryPersistentParametersCmd.sMsgHeader.u2MsgLength.Value, objPdbpLoadFactoryPersistentParametersCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/PDBP/PdbpLoadFactoryPersistentParametersCmd", "Class": sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD, "ClassName": "sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD", "acRole": "", "MsgObject": deepcopy(objPdbpLoadFactoryPersistentParametersCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/PDBP/PdbpLoadFactoryPersistentParametersCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionPdbpLoadFactoryPersistentParametersCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objPdbpLoadFactoryPersistentParametersCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/PDBP/PdbpLoadFactoryPersistentParametersCmdRsp", objPdbpLoadFactoryPersistentParametersCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("PdbpLoadFactoryPersistentParametersCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackPdbpUploadJsonFileIntoPpdbCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message PdbpUploadJsonFileIntoPpdbCmd

        This is a public method callback for message PdbpUploadJsonFileIntoPpdbCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objPdbpUploadJsonFileIntoPpdbCmd = sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objPdbpUploadJsonFileIntoPpdbCmdRsp = sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpUploadJsonFileIntoPpdbCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpUploadJsonFileIntoPpdbCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpUploadJsonFileIntoPpdbCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objPdbpUploadJsonFileIntoPpdbCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpUploadJsonFileIntoPpdbCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objPdbpUploadJsonFileIntoPpdbCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for PdbpUploadJsonFileIntoPpdbCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objPdbpUploadJsonFileIntoPpdbCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpUploadJsonFileIntoPpdbCmd  validation failed")
            elif (objPdbpUploadJsonFileIntoPpdbCmd.sMsgHeader.u2MsgLength.Value != (objPdbpUploadJsonFileIntoPpdbCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpUploadJsonFileIntoPpdbCmd  length field is invalid - it is %d and should be %d bytes", objPdbpUploadJsonFileIntoPpdbCmd.sMsgHeader.u2MsgLength.Value, objPdbpUploadJsonFileIntoPpdbCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/PDBP/PdbpUploadJsonFileIntoPpdbCmd", "Class": sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD, "ClassName": "sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD", "acRole": "", "MsgObject": deepcopy(objPdbpUploadJsonFileIntoPpdbCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/PDBP/PdbpUploadJsonFileIntoPpdbCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionPdbpUploadJsonFileIntoPpdbCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objPdbpUploadJsonFileIntoPpdbCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/PDBP/PdbpUploadJsonFileIntoPpdbCmdRsp", objPdbpUploadJsonFileIntoPpdbCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("PdbpUploadJsonFileIntoPpdbCmd's publish threw exception - %s", str(E))

        return
# ==========================================================
# MQTT CALLBACK METHODS STOP
# ==========================================================
# ==========================================================
# MQTT SUBSCRIPTION METHODS START
# ==========================================================

    def vSubscribeMessagePdbpEndOfReadyCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message PdbpEndOfReadyCmd.

        This is the auto generated method for subscribing message PdbpEndOfReadyCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for PdbpEndOfReadyCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpEndOfReadyCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpEndOfReadyCmd  - Exception %s", str(E))

        return

    def vSubscribeMessagePdbpShutdownCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message PdbpShutdownCmd.

        This is the auto generated method for subscribing message PdbpShutdownCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for PdbpShutdownCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpShutdownCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpShutdownCmd  - Exception %s", str(E))

        return

    def vSubscribeMessagePdbpSendOutModuleDbMessagesCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message PdbpSendOutModuleDbMessagesCmd.

        This is the auto generated method for subscribing message PdbpSendOutModuleDbMessagesCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for PdbpSendOutModuleDbMessagesCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpSendOutModuleDbMessagesCmd  - Exception %s", str(E))

        return

    def vSubscribeMessagePdbpExportPdbToJsonFileCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message PdbpExportPdbToJsonFileCmd.

        This is the auto generated method for subscribing message PdbpExportPdbToJsonFileCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for PdbpExportPdbToJsonFileCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpExportPdbToJsonFileCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpExportPdbToJsonFileCmd  - Exception %s", str(E))

        return

    def vSubscribeMessagePdbpStorageStateCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message PdbpStorageStateCmd.

        This is the auto generated method for subscribing message PdbpStorageStateCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for PdbpStorageStateCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpStorageStateCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpStorageStateCmd  - Exception %s", str(E))

        return

    def vSubscribeMessagePdbpLoadFactoryPersistentParametersCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message PdbpLoadFactoryPersistentParametersCmd.

        This is the auto generated method for subscribing message PdbpLoadFactoryPersistentParametersCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for PdbpLoadFactoryPersistentParametersCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpLoadFactoryPersistentParametersCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpLoadFactoryPersistentParametersCmd  - Exception %s", str(E))

        return

    def vSubscribeMessagePdbpUploadJsonFileIntoPpdbCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message PdbpUploadJsonFileIntoPpdbCmd.

        This is the auto generated method for subscribing message PdbpUploadJsonFileIntoPpdbCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for PdbpUploadJsonFileIntoPpdbCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpUploadJsonFileIntoPpdbCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpUploadJsonFileIntoPpdbCmd  - Exception %s", str(E))

        return

# ==========================================================
# MQTT SUBSCRIPTION METHODS START
# ==========================================================
# ==========================================================
# MQTT TEMPLATE CLASS STOP
# ==========================================================
# ==========================================================
# AUTOGEN STOP
# ==========================================================