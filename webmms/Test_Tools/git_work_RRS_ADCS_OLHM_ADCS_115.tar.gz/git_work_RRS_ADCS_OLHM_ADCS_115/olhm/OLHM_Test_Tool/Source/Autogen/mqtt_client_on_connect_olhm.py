#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:32:42 SAST

    This module is the mqtt client on connect class, generated automatically from XML file(s). Its intended use is as a class
    with mqtt callbacks for on_connect() and on_message(). This class should be instantiated before the mqtt connect. The mqtt 
    on_connect() callback should be redirected as -> client.on_connect = objClsMqttAutogenHandler.vOnConnect
    It should be noted that all operations inside this class will execute inside the mqtt thread. The processing methods in this class
    will validate the incoming messages and reply only if validation failed. Messages which passed validation will be placed in a queue provided to
    the constructor of the class. 

"""
# ==========================================================
# AUTOGEN START
# ==========================================================
import logging  # This is required to be able to log if there are problems
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
import queue  # This is required to put the received message in a queue to pass on to another non-mqtt thread
from copy import deepcopy  # This is required to make a deepcopy of the message before insertion in the queue - it ensures proper garbage collection
from Autogen.mw_common_types import E2_MW_MESSAGE_STATUS
from Autogen.sf3_msg import *  # noqa: F401
from Autogen.tewa_msg import *  # noqa: F401
from Autogen.pdbp_msg import *  # noqa: F401
from Autogen.mms_msg import *  # noqa: F401
from Autogen.tm_msg import *  # noqa: F401
from Autogen.sf2_msg import *  # noqa: F401
from Autogen.olhm_msg import *  # noqa: F401
from Autogen.eiu_msg import *  # noqa: F401
from Autogen.dr_msg import *  # noqa: F401
from Autogen.sf1_msg import *  # noqa: F401
from Autogen.hmi_msg import *  # noqa: F401

# ==========================================================
# MQTT TEMPLATE CLASS START
# ==========================================================


class clsMqttAutogenHandler():
    """ This is the MQTT message handling autogen base class

    This is the MQTT message handling autogen base class. An instance of this class should be made before giving the mqtt client
    a on_connect() callback from this class.

    Args:
        objQueuePar (queue.Queue): The first parameter. The instance of the python queue into which we will push messages received
        bLoggingEnabledPar (bool): The second parameter. A boolean flag indicating if logging should be done or not. This parameter is by default True

    """
    def __init__(self, objQueuePar: queue.Queue, bLoggingEnabledPar: bool = True):
        super().__init__()
        self._bLoggingEnabled = bLoggingEnabledPar
        self._objQueue = objQueuePar
        # By default all subscriptions will auto reply if a ReplyMsg was specified
        self.bAutoReplyForSubscriptionOlhmEndOfReadyCmd = True
        self.bAutoReplyForSubscriptionOlhmAdcsShutdownCmd = True
        self.bAutoReplyForSubscriptionTewaStatusReportUnsol = True
        self.bAutoReplyForSubscriptionTewaEndOfSetupCmdRsp = True
        self.bAutoReplyForSubscriptionTewaEndOfReadyCmdRsp = True
        self.bAutoReplyForSubscriptionTewaShutdownCmdRsp = True
        self.bAutoReplyForSubscriptionTmStatusReportUnsol = True
        self.bAutoReplyForSubscriptionTmEndOfSetupCmdRsp = True
        self.bAutoReplyForSubscriptionTmEndOfReadyCmdRsp = True
        self.bAutoReplyForSubscriptionTmShutdownCmdRsp = True
        self.bAutoReplyForSubscriptionPdbpStatusReportUnsol = True
        self.bAutoReplyForSubscriptionPdbpEndOfReadyCmdRsp = True
        self.bAutoReplyForSubscriptionPdbpShutdownCmdRsp = True
        self.bAutoReplyForSubscriptionPdbpSendOutModuleDbMessagesCmdRsp = True
        self.bAutoReplyForSubscriptionDrStatusReportUnsol = True
        self.bAutoReplyForSubscriptionDrEndOfSetupCmdRsp = True
        self.bAutoReplyForSubscriptionDrEndOfReadyCmdRsp = True
        self.bAutoReplyForSubscriptionDrShutdownCmdRsp = True
        self.bAutoReplyForSubscriptionHmiStatusReportUnsolAPM = True
        self.bAutoReplyForSubscriptionHmiStatusReportUnsolFCO = True
        self.bAutoReplyForSubscriptionHmiStatusReportUnsolAPM_FCO = True
        self.bAutoReplyForSubscriptionHmiStatusReportUnsolSPM = True
        self.bAutoReplyForSubscriptionHmiStatusReportUnsolFUFC = True
        self.bAutoReplyForSubscriptionHmiStatusReportUnsolSPM_FUFC = True
        self.bAutoReplyForSubscriptionHmiStatusReportUnsolOversight = True
        self.bAutoReplyForSubscriptionHmiStatusReportUnsolMaintainer = True
        self.bAutoReplyForSubscriptionHmiEndOfSetupCmdRspAPM = True
        self.bAutoReplyForSubscriptionHmiEndOfSetupCmdRspFC = True
        self.bAutoReplyForSubscriptionHmiEndOfSetupCmdRspAPM_FC = True
        self.bAutoReplyForSubscriptionHmiEndOfSetupCmdRspSPM = True
        self.bAutoReplyForSubscriptionHmiEndOfSetupCmdRspFUFC = True
        self.bAutoReplyForSubscriptionHmiEndOfSetupCmdRspSPM_FUFC = True
        self.bAutoReplyForSubscriptionHmiEndOfSetupCmdRspOversight = True
        self.bAutoReplyForSubscriptionHmiEndOfSetupCmdRspMaintainer = True
        self.bAutoReplyForSubscriptionHmiEndOfReadyCmdRspAPM = True
        self.bAutoReplyForSubscriptionHmiEndOfReadyCmdRspFCO = True
        self.bAutoReplyForSubscriptionHmiEndOfReadyCmdRspAPM_FCO = True
        self.bAutoReplyForSubscriptionHmiEndOfReadyCmdRspSPM = True
        self.bAutoReplyForSubscriptionHmiEndOfReadyCmdRspFUFC = True
        self.bAutoReplyForSubscriptionHmiEndOfReadyCmdRspSPM_FUFC = True
        self.bAutoReplyForSubscriptionHmiEndOfReadyCmdRspOversight = True
        self.bAutoReplyForSubscriptionHmiEndOfReadyCmdRspMaintainer = True
        self.bAutoReplyForSubscriptionHmiShutdownCmdRspAPM = True
        self.bAutoReplyForSubscriptionHmiShutdownCmdRspFCO = True
        self.bAutoReplyForSubscriptionHmiShutdownCmdRspAPM_FCO = True
        self.bAutoReplyForSubscriptionHmiShutdownCmdRspSPM = True
        self.bAutoReplyForSubscriptionHmiShutdownCmdRspFUFC = True
        self.bAutoReplyForSubscriptionHmiShutdownCmdRspSPM_FUFC = True
        self.bAutoReplyForSubscriptionHmiShutdownCmdRspOversight = True
        self.bAutoReplyForSubscriptionHmiShutdownCmdRspMaintainer = True
        self.bAutoReplyForSubscriptionHmiShutdownUnsolAPM = True
        self.bAutoReplyForSubscriptionHmiShutdownUnsolFCO = True
        self.bAutoReplyForSubscriptionHmiShutdownUnsolAPM_FCO = True
        self.bAutoReplyForSubscriptionHmiShutdownUnsolSPM = True
        self.bAutoReplyForSubscriptionHmiShutdownUnsolFUFC = True
        self.bAutoReplyForSubscriptionHmiShutdownUnsolSPM_FUFC = True
        self.bAutoReplyForSubscriptionHmiShutdownUnsolOversight = True
        self.bAutoReplyForSubscriptionHmiShutdownUnsolMaintainer = True
        self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdAPM = True
        self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdFCO = True
        self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdAPM_FCO = True
        self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdSPM = True
        self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdFUFC = True
        self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdSPM_FUFC = True
        self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdOversight = True
        self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdMaintainer = True
        self.bAutoReplyForSubscriptionEiuStatusReportUnsol = True
        self.bAutoReplyForSubscriptionEiuEndOfSetupCmdRsp = True
        self.bAutoReplyForSubscriptionEiuEndOfReadyCmdRsp = True
        self.bAutoReplyForSubscriptionEiuShutdownCmdRsp = True
        self.bAutoReplyForSubscriptionSf1StatusReportUnsol = True
        self.bAutoReplyForSubscriptionSf1EndOfSetupCmdRsp = True
        self.bAutoReplyForSubscriptionSf1EndOfReadyCmdRsp = True
        self.bAutoReplyForSubscriptionSf1ShutdownCmdRsp = True
        self.bAutoReplyForSubscriptionSf1ModeCmd = True
        self.bAutoReplyForSubscriptionSf2StatusReportUnsol = True
        self.bAutoReplyForSubscriptionSf2EndOfSetupCmdRsp = True
        self.bAutoReplyForSubscriptionSf2EndOfReadyCmdRsp = True
        self.bAutoReplyForSubscriptionSf2ShutdownCmdRsp = True
        self.bAutoReplyForSubscriptionSf3StatusReportUnsol = True
        self.bAutoReplyForSubscriptionSf3EndOfSetupCmdRsp = True
        self.bAutoReplyForSubscriptionSf3EndOfReadyCmdRsp = True
        self.bAutoReplyForSubscriptionSf3ShutdownCmdRsp = True
        self.bAutoReplyForSubscriptionMmsShutdownCmd = True

    def vOnConnect(self, objMqttClientPar: mqtt.Client, userDataPar, dctFlags, iConnectionResult: int) -> None:  # pylint: disable=W0613
        """ This is the callback method for when client receives a CONNACK response from the server

        This is the callback method for when client receives a CONNACK response from the server. This method subscribes
        and registers callback methods for all incoming messages. Messages from secondary XML files will not automatically be
        subscribed to. The on message callbacks will however all automatically be registered even for secondary XML files.

        Args:
            objMqttClientPar (obj): The first parameter. A MQTT client object
            userDataPar: The second parameter. The private user data as set in Client() or userdata_set()
            flags: The third parameter. flags is a dict that contains response flags from the broker:
            rc: The fourth parameter. The connection result

        Returns:

        Raises:
            Raises no exceptions
        """

        # Subscribing and adding callback for OlhmEndOfReadyCmd 
        # Subscribing and adding callback for OlhmEndOfReadyCmd 
        # Subscribing and adding callback for OlhmEndOfReadyCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message OlhmEndOfReadyCmd  with topic ADCS/OLHM/OlhmEndOfReadyCmd")

        try:
            objMqttClientPar.subscribe("ADCS/OLHM/OlhmEndOfReadyCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message OlhmEndOfReadyCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for OlhmEndOfReadyCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/OLHM/OlhmEndOfReadyCmd", self.vOnMessageCallbackOlhmEndOfReadyCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for OlhmEndOfReadyCmd  - Exception %s", str(E))
        # Subscribing and adding callback for OlhmAdcsShutdownCmd 
        # Subscribing and adding callback for OlhmAdcsShutdownCmd 
        # Subscribing and adding callback for OlhmAdcsShutdownCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message OlhmAdcsShutdownCmd  with topic ADCS/OLHM/OlhmAdcsShutdownCmd")

        try:
            objMqttClientPar.subscribe("ADCS/OLHM/OlhmAdcsShutdownCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message OlhmAdcsShutdownCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for OlhmAdcsShutdownCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/OLHM/OlhmAdcsShutdownCmd", self.vOnMessageCallbackOlhmAdcsShutdownCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for OlhmAdcsShutdownCmd  - Exception %s", str(E))
        # Subscribing and adding callback for TewaStatusReportUnsol 
        # Subscribing and adding callback for TewaStatusReportUnsol 
        # Subscribing and adding callback for TewaStatusReportUnsol 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message TewaStatusReportUnsol  with topic ADCS/TEWA/TewaStatusReportUnsol")

        try:
            objMqttClientPar.subscribe("ADCS/TEWA/TewaStatusReportUnsol", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TewaStatusReportUnsol  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for TewaStatusReportUnsol ")

        try:
            objMqttClientPar.message_callback_add("ADCS/TEWA/TewaStatusReportUnsol", self.vOnMessageCallbackTewaStatusReportUnsol)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for TewaStatusReportUnsol  - Exception %s", str(E))
        # Subscribing and adding callback for TewaEndOfSetupCmdRsp 
        # Subscribing and adding callback for TewaEndOfSetupCmdRsp 
        # Subscribing and adding callback for TewaEndOfSetupCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message TewaEndOfSetupCmdRsp  with topic ADCS/TEWA/TewaEndOfSetupCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/TEWA/TewaEndOfSetupCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TewaEndOfSetupCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for TewaEndOfSetupCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/TEWA/TewaEndOfSetupCmdRsp", self.vOnMessageCallbackTewaEndOfSetupCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for TewaEndOfSetupCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for TewaEndOfReadyCmdRsp 
        # Subscribing and adding callback for TewaEndOfReadyCmdRsp 
        # Subscribing and adding callback for TewaEndOfReadyCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message TewaEndOfReadyCmdRsp  with topic ADCS/TEWA/TewaEndOfReadyCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/TEWA/TewaEndOfReadyCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TewaEndOfReadyCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for TewaEndOfReadyCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/TEWA/TewaEndOfReadyCmdRsp", self.vOnMessageCallbackTewaEndOfReadyCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for TewaEndOfReadyCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for TewaShutdownCmdRsp 
        # Subscribing and adding callback for TewaShutdownCmdRsp 
        # Subscribing and adding callback for TewaShutdownCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message TewaShutdownCmdRsp  with topic ADCS/TEWA/TewaShutdownCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/TEWA/TewaShutdownCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TewaShutdownCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for TewaShutdownCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/TEWA/TewaShutdownCmdRsp", self.vOnMessageCallbackTewaShutdownCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for TewaShutdownCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for TmStatusReportUnsol 
        # Subscribing and adding callback for TmStatusReportUnsol 
        # Subscribing and adding callback for TmStatusReportUnsol 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message TmStatusReportUnsol  with topic ADCS/TM/TmStatusReportUnsol")

        try:
            objMqttClientPar.subscribe("ADCS/TM/TmStatusReportUnsol", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TmStatusReportUnsol  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for TmStatusReportUnsol ")

        try:
            objMqttClientPar.message_callback_add("ADCS/TM/TmStatusReportUnsol", self.vOnMessageCallbackTmStatusReportUnsol)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for TmStatusReportUnsol  - Exception %s", str(E))
        # Subscribing and adding callback for TmEndOfSetupCmdRsp 
        # Subscribing and adding callback for TmEndOfSetupCmdRsp 
        # Subscribing and adding callback for TmEndOfSetupCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message TmEndOfSetupCmdRsp  with topic ADCS/TM/TmEndOfSetupCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/TM/TmEndOfSetupCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TmEndOfSetupCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for TmEndOfSetupCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/TM/TmEndOfSetupCmdRsp", self.vOnMessageCallbackTmEndOfSetupCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for TmEndOfSetupCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for TmEndOfReadyCmdRsp 
        # Subscribing and adding callback for TmEndOfReadyCmdRsp 
        # Subscribing and adding callback for TmEndOfReadyCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message TmEndOfReadyCmdRsp  with topic ADCS/TM/TmEndOfReadyCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/TM/TmEndOfReadyCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TmEndOfReadyCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for TmEndOfReadyCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/TM/TmEndOfReadyCmdRsp", self.vOnMessageCallbackTmEndOfReadyCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for TmEndOfReadyCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for TmShutdownCmdRsp 
        # Subscribing and adding callback for TmShutdownCmdRsp 
        # Subscribing and adding callback for TmShutdownCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message TmShutdownCmdRsp  with topic ADCS/TM/TmShutdownCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/TM/TmShutdownCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TmShutdownCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for TmShutdownCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/TM/TmShutdownCmdRsp", self.vOnMessageCallbackTmShutdownCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for TmShutdownCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for PdbpStatusReportUnsol 
        # Subscribing and adding callback for PdbpStatusReportUnsol 
        # Subscribing and adding callback for PdbpStatusReportUnsol 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message PdbpStatusReportUnsol  with topic ADCS/PDBP/PdbpStatusReportUnsol")

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpStatusReportUnsol", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpStatusReportUnsol  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for PdbpStatusReportUnsol ")

        try:
            objMqttClientPar.message_callback_add("ADCS/PDBP/PdbpStatusReportUnsol", self.vOnMessageCallbackPdbpStatusReportUnsol)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for PdbpStatusReportUnsol  - Exception %s", str(E))
        # Subscribing and adding callback for PdbpEndOfReadyCmdRsp 
        # Subscribing and adding callback for PdbpEndOfReadyCmdRsp 
        # Subscribing and adding callback for PdbpEndOfReadyCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message PdbpEndOfReadyCmdRsp  with topic ADCS/PDBP/PdbpEndOfReadyCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpEndOfReadyCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpEndOfReadyCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for PdbpEndOfReadyCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/PDBP/PdbpEndOfReadyCmdRsp", self.vOnMessageCallbackPdbpEndOfReadyCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for PdbpEndOfReadyCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for PdbpShutdownCmdRsp 
        # Subscribing and adding callback for PdbpShutdownCmdRsp 
        # Subscribing and adding callback for PdbpShutdownCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message PdbpShutdownCmdRsp  with topic ADCS/PDBP/PdbpShutdownCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpShutdownCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpShutdownCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for PdbpShutdownCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/PDBP/PdbpShutdownCmdRsp", self.vOnMessageCallbackPdbpShutdownCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for PdbpShutdownCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for PdbpSendOutModuleDbMessagesCmdRsp 
        # Subscribing and adding callback for PdbpSendOutModuleDbMessagesCmdRsp 
        # Subscribing and adding callback for PdbpSendOutModuleDbMessagesCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message PdbpSendOutModuleDbMessagesCmdRsp  with topic ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpSendOutModuleDbMessagesCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for PdbpSendOutModuleDbMessagesCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp", self.vOnMessageCallbackPdbpSendOutModuleDbMessagesCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for PdbpSendOutModuleDbMessagesCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for DrStatusReportUnsol 
        # Subscribing and adding callback for DrStatusReportUnsol 
        # Subscribing and adding callback for DrStatusReportUnsol 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message DrStatusReportUnsol  with topic ADCS/DR/DrStatusReportUnsol")

        try:
            objMqttClientPar.subscribe("ADCS/DR/DrStatusReportUnsol", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message DrStatusReportUnsol  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for DrStatusReportUnsol ")

        try:
            objMqttClientPar.message_callback_add("ADCS/DR/DrStatusReportUnsol", self.vOnMessageCallbackDrStatusReportUnsol)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for DrStatusReportUnsol  - Exception %s", str(E))
        # Subscribing and adding callback for DrEndOfSetupCmdRsp 
        # Subscribing and adding callback for DrEndOfSetupCmdRsp 
        # Subscribing and adding callback for DrEndOfSetupCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message DrEndOfSetupCmdRsp  with topic ADCS/DR/DrEndOfSetupCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/DR/DrEndOfSetupCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message DrEndOfSetupCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for DrEndOfSetupCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/DR/DrEndOfSetupCmdRsp", self.vOnMessageCallbackDrEndOfSetupCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for DrEndOfSetupCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for DrEndOfReadyCmdRsp 
        # Subscribing and adding callback for DrEndOfReadyCmdRsp 
        # Subscribing and adding callback for DrEndOfReadyCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message DrEndOfReadyCmdRsp  with topic ADCS/DR/DrEndOfReadyCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/DR/DrEndOfReadyCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message DrEndOfReadyCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for DrEndOfReadyCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/DR/DrEndOfReadyCmdRsp", self.vOnMessageCallbackDrEndOfReadyCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for DrEndOfReadyCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for DrShutdownCmdRsp 
        # Subscribing and adding callback for DrShutdownCmdRsp 
        # Subscribing and adding callback for DrShutdownCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message DrShutdownCmdRsp  with topic ADCS/DR/DrShutdownCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/DR/DrShutdownCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message DrShutdownCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for DrShutdownCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/DR/DrShutdownCmdRsp", self.vOnMessageCallbackDrShutdownCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for DrShutdownCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for HmiStatusReportUnsol APM
        # Subscribing and adding callback for HmiStatusReportUnsol APM
        # Subscribing and adding callback for HmiStatusReportUnsol APM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiStatusReportUnsol APM with topic ADCS/HMI/HmiStatusReportUnsol/APM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiStatusReportUnsol/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiStatusReportUnsol APM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiStatusReportUnsol APM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiStatusReportUnsol/APM", self.vOnMessageCallbackHmiStatusReportUnsolAPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiStatusReportUnsol APM - Exception %s", str(E))
        # Subscribing and adding callback for HmiStatusReportUnsol FCO
        # Subscribing and adding callback for HmiStatusReportUnsol FCO
        # Subscribing and adding callback for HmiStatusReportUnsol FCO

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiStatusReportUnsol FCO with topic ADCS/HMI/HmiStatusReportUnsol/FCO")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiStatusReportUnsol/FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiStatusReportUnsol FCO - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiStatusReportUnsol FCO")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiStatusReportUnsol/FCO", self.vOnMessageCallbackHmiStatusReportUnsolFCO)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiStatusReportUnsol FCO - Exception %s", str(E))
        # Subscribing and adding callback for HmiStatusReportUnsol APM_FCO
        # Subscribing and adding callback for HmiStatusReportUnsol APM_FCO
        # Subscribing and adding callback for HmiStatusReportUnsol APM_FCO

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiStatusReportUnsol APM_FCO with topic ADCS/HMI/HmiStatusReportUnsol/APM_FCO")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiStatusReportUnsol/APM_FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiStatusReportUnsol APM_FCO - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiStatusReportUnsol APM_FCO")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiStatusReportUnsol/APM_FCO", self.vOnMessageCallbackHmiStatusReportUnsolAPM_FCO)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiStatusReportUnsol APM_FCO - Exception %s", str(E))
        # Subscribing and adding callback for HmiStatusReportUnsol SPM
        # Subscribing and adding callback for HmiStatusReportUnsol SPM
        # Subscribing and adding callback for HmiStatusReportUnsol SPM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiStatusReportUnsol SPM with topic ADCS/HMI/HmiStatusReportUnsol/SPM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiStatusReportUnsol/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiStatusReportUnsol SPM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiStatusReportUnsol SPM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiStatusReportUnsol/SPM", self.vOnMessageCallbackHmiStatusReportUnsolSPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiStatusReportUnsol SPM - Exception %s", str(E))
        # Subscribing and adding callback for HmiStatusReportUnsol FUFC
        # Subscribing and adding callback for HmiStatusReportUnsol FUFC
        # Subscribing and adding callback for HmiStatusReportUnsol FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiStatusReportUnsol FUFC with topic ADCS/HMI/HmiStatusReportUnsol/FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiStatusReportUnsol/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiStatusReportUnsol FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiStatusReportUnsol FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiStatusReportUnsol/FUFC", self.vOnMessageCallbackHmiStatusReportUnsolFUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiStatusReportUnsol FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiStatusReportUnsol SPM_FUFC
        # Subscribing and adding callback for HmiStatusReportUnsol SPM_FUFC
        # Subscribing and adding callback for HmiStatusReportUnsol SPM_FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiStatusReportUnsol SPM_FUFC with topic ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiStatusReportUnsol SPM_FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiStatusReportUnsol SPM_FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC", self.vOnMessageCallbackHmiStatusReportUnsolSPM_FUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiStatusReportUnsol SPM_FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiStatusReportUnsol Oversight
        # Subscribing and adding callback for HmiStatusReportUnsol Oversight
        # Subscribing and adding callback for HmiStatusReportUnsol Oversight

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiStatusReportUnsol Oversight with topic ADCS/HMI/HmiStatusReportUnsol/Oversight")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiStatusReportUnsol/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiStatusReportUnsol Oversight - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiStatusReportUnsol Oversight")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiStatusReportUnsol/Oversight", self.vOnMessageCallbackHmiStatusReportUnsolOversight)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiStatusReportUnsol Oversight - Exception %s", str(E))
        # Subscribing and adding callback for HmiStatusReportUnsol Maintainer
        # Subscribing and adding callback for HmiStatusReportUnsol Maintainer
        # Subscribing and adding callback for HmiStatusReportUnsol Maintainer

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiStatusReportUnsol Maintainer with topic ADCS/HMI/HmiStatusReportUnsol/Maintainer")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiStatusReportUnsol/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiStatusReportUnsol Maintainer - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiStatusReportUnsol Maintainer")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiStatusReportUnsol/Maintainer", self.vOnMessageCallbackHmiStatusReportUnsolMaintainer)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiStatusReportUnsol Maintainer - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp APM
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp APM
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp APM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfSetupCmdRsp APM with topic ADCS/HMI/HmiEndOfSetupCmdRsp/APM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmdRsp/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmdRsp APM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfSetupCmdRsp APM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfSetupCmdRsp/APM", self.vOnMessageCallbackHmiEndOfSetupCmdRspAPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfSetupCmdRsp APM - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp FC
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp FC
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp FC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfSetupCmdRsp FC with topic ADCS/HMI/HmiEndOfSetupCmdRsp/FC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmdRsp/FC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmdRsp FC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfSetupCmdRsp FC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfSetupCmdRsp/FC", self.vOnMessageCallbackHmiEndOfSetupCmdRspFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfSetupCmdRsp FC - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp APM_FC
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp APM_FC
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp APM_FC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfSetupCmdRsp APM_FC with topic ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmdRsp APM_FC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfSetupCmdRsp APM_FC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC", self.vOnMessageCallbackHmiEndOfSetupCmdRspAPM_FC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfSetupCmdRsp APM_FC - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp SPM
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp SPM
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp SPM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfSetupCmdRsp SPM with topic ADCS/HMI/HmiEndOfSetupCmdRsp/SPM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmdRsp SPM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfSetupCmdRsp SPM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM", self.vOnMessageCallbackHmiEndOfSetupCmdRspSPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfSetupCmdRsp SPM - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp FUFC
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp FUFC
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfSetupCmdRsp FUFC with topic ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmdRsp FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfSetupCmdRsp FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC", self.vOnMessageCallbackHmiEndOfSetupCmdRspFUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfSetupCmdRsp FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp SPM_FUFC
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp SPM_FUFC
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp SPM_FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfSetupCmdRsp SPM_FUFC with topic ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmdRsp SPM_FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfSetupCmdRsp SPM_FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC", self.vOnMessageCallbackHmiEndOfSetupCmdRspSPM_FUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfSetupCmdRsp SPM_FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp Oversight
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp Oversight
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp Oversight

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfSetupCmdRsp Oversight with topic ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmdRsp Oversight - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfSetupCmdRsp Oversight")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight", self.vOnMessageCallbackHmiEndOfSetupCmdRspOversight)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfSetupCmdRsp Oversight - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp Maintainer
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp Maintainer
        # Subscribing and adding callback for HmiEndOfSetupCmdRsp Maintainer

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfSetupCmdRsp Maintainer with topic ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmdRsp Maintainer - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfSetupCmdRsp Maintainer")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer", self.vOnMessageCallbackHmiEndOfSetupCmdRspMaintainer)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfSetupCmdRsp Maintainer - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp APM
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp APM
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp APM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfReadyCmdRsp APM with topic ADCS/HMI/HmiEndOfReadyCmdRsp/APM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmdRsp/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmdRsp APM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfReadyCmdRsp APM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfReadyCmdRsp/APM", self.vOnMessageCallbackHmiEndOfReadyCmdRspAPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfReadyCmdRsp APM - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp FCO
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp FCO
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp FCO

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfReadyCmdRsp FCO with topic ADCS/HMI/HmiEndOfReadyCmdRsp/FCO")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmdRsp/FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmdRsp FCO - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfReadyCmdRsp FCO")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfReadyCmdRsp/FCO", self.vOnMessageCallbackHmiEndOfReadyCmdRspFCO)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfReadyCmdRsp FCO - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp APM_FCO
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp APM_FCO
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp APM_FCO

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfReadyCmdRsp APM_FCO with topic ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmdRsp APM_FCO - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfReadyCmdRsp APM_FCO")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO", self.vOnMessageCallbackHmiEndOfReadyCmdRspAPM_FCO)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfReadyCmdRsp APM_FCO - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp SPM
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp SPM
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp SPM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfReadyCmdRsp SPM with topic ADCS/HMI/HmiEndOfReadyCmdRsp/SPM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmdRsp SPM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfReadyCmdRsp SPM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM", self.vOnMessageCallbackHmiEndOfReadyCmdRspSPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfReadyCmdRsp SPM - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp FUFC
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp FUFC
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfReadyCmdRsp FUFC with topic ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmdRsp FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfReadyCmdRsp FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC", self.vOnMessageCallbackHmiEndOfReadyCmdRspFUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfReadyCmdRsp FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp SPM_FUFC
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp SPM_FUFC
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp SPM_FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfReadyCmdRsp SPM_FUFC with topic ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmdRsp SPM_FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfReadyCmdRsp SPM_FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC", self.vOnMessageCallbackHmiEndOfReadyCmdRspSPM_FUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfReadyCmdRsp SPM_FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp Oversight
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp Oversight
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp Oversight

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfReadyCmdRsp Oversight with topic ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmdRsp Oversight - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfReadyCmdRsp Oversight")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight", self.vOnMessageCallbackHmiEndOfReadyCmdRspOversight)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfReadyCmdRsp Oversight - Exception %s", str(E))
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp Maintainer
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp Maintainer
        # Subscribing and adding callback for HmiEndOfReadyCmdRsp Maintainer

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiEndOfReadyCmdRsp Maintainer with topic ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmdRsp Maintainer - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiEndOfReadyCmdRsp Maintainer")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer", self.vOnMessageCallbackHmiEndOfReadyCmdRspMaintainer)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiEndOfReadyCmdRsp Maintainer - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownCmdRsp APM
        # Subscribing and adding callback for HmiShutdownCmdRsp APM
        # Subscribing and adding callback for HmiShutdownCmdRsp APM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownCmdRsp APM with topic ADCS/HMI/HmiShutdownCmdRsp/APM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmdRsp/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmdRsp APM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownCmdRsp APM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownCmdRsp/APM", self.vOnMessageCallbackHmiShutdownCmdRspAPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownCmdRsp APM - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownCmdRsp FCO
        # Subscribing and adding callback for HmiShutdownCmdRsp FCO
        # Subscribing and adding callback for HmiShutdownCmdRsp FCO

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownCmdRsp FCO with topic ADCS/HMI/HmiShutdownCmdRsp/FCO")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmdRsp/FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmdRsp FCO - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownCmdRsp FCO")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownCmdRsp/FCO", self.vOnMessageCallbackHmiShutdownCmdRspFCO)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownCmdRsp FCO - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownCmdRsp APM_FCO
        # Subscribing and adding callback for HmiShutdownCmdRsp APM_FCO
        # Subscribing and adding callback for HmiShutdownCmdRsp APM_FCO

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownCmdRsp APM_FCO with topic ADCS/HMI/HmiShutdownCmdRsp/APM_FCO")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmdRsp/APM_FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmdRsp APM_FCO - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownCmdRsp APM_FCO")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownCmdRsp/APM_FCO", self.vOnMessageCallbackHmiShutdownCmdRspAPM_FCO)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownCmdRsp APM_FCO - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownCmdRsp SPM
        # Subscribing and adding callback for HmiShutdownCmdRsp SPM
        # Subscribing and adding callback for HmiShutdownCmdRsp SPM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownCmdRsp SPM with topic ADCS/HMI/HmiShutdownCmdRsp/SPM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmdRsp/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmdRsp SPM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownCmdRsp SPM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownCmdRsp/SPM", self.vOnMessageCallbackHmiShutdownCmdRspSPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownCmdRsp SPM - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownCmdRsp FUFC
        # Subscribing and adding callback for HmiShutdownCmdRsp FUFC
        # Subscribing and adding callback for HmiShutdownCmdRsp FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownCmdRsp FUFC with topic ADCS/HMI/HmiShutdownCmdRsp/FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmdRsp/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmdRsp FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownCmdRsp FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownCmdRsp/FUFC", self.vOnMessageCallbackHmiShutdownCmdRspFUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownCmdRsp FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownCmdRsp SPM_FUFC
        # Subscribing and adding callback for HmiShutdownCmdRsp SPM_FUFC
        # Subscribing and adding callback for HmiShutdownCmdRsp SPM_FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownCmdRsp SPM_FUFC with topic ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmdRsp SPM_FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownCmdRsp SPM_FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC", self.vOnMessageCallbackHmiShutdownCmdRspSPM_FUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownCmdRsp SPM_FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownCmdRsp Oversight
        # Subscribing and adding callback for HmiShutdownCmdRsp Oversight
        # Subscribing and adding callback for HmiShutdownCmdRsp Oversight

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownCmdRsp Oversight with topic ADCS/HMI/HmiShutdownCmdRsp/Oversight")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmdRsp/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmdRsp Oversight - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownCmdRsp Oversight")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownCmdRsp/Oversight", self.vOnMessageCallbackHmiShutdownCmdRspOversight)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownCmdRsp Oversight - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownCmdRsp Maintainer
        # Subscribing and adding callback for HmiShutdownCmdRsp Maintainer
        # Subscribing and adding callback for HmiShutdownCmdRsp Maintainer

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownCmdRsp Maintainer with topic ADCS/HMI/HmiShutdownCmdRsp/Maintainer")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmdRsp/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmdRsp Maintainer - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownCmdRsp Maintainer")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownCmdRsp/Maintainer", self.vOnMessageCallbackHmiShutdownCmdRspMaintainer)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownCmdRsp Maintainer - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownUnsol APM
        # Subscribing and adding callback for HmiShutdownUnsol APM
        # Subscribing and adding callback for HmiShutdownUnsol APM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownUnsol APM with topic ADCS/HMI/HmiShutdownUnsol/APM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownUnsol/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownUnsol APM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownUnsol APM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownUnsol/APM", self.vOnMessageCallbackHmiShutdownUnsolAPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownUnsol APM - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownUnsol FCO
        # Subscribing and adding callback for HmiShutdownUnsol FCO
        # Subscribing and adding callback for HmiShutdownUnsol FCO

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownUnsol FCO with topic ADCS/HMI/HmiShutdownUnsol/FCO")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownUnsol/FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownUnsol FCO - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownUnsol FCO")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownUnsol/FCO", self.vOnMessageCallbackHmiShutdownUnsolFCO)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownUnsol FCO - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownUnsol APM_FCO
        # Subscribing and adding callback for HmiShutdownUnsol APM_FCO
        # Subscribing and adding callback for HmiShutdownUnsol APM_FCO

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownUnsol APM_FCO with topic ADCS/HMI/HmiShutdownUnsol/APM_FCO")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownUnsol/APM_FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownUnsol APM_FCO - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownUnsol APM_FCO")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownUnsol/APM_FCO", self.vOnMessageCallbackHmiShutdownUnsolAPM_FCO)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownUnsol APM_FCO - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownUnsol SPM
        # Subscribing and adding callback for HmiShutdownUnsol SPM
        # Subscribing and adding callback for HmiShutdownUnsol SPM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownUnsol SPM with topic ADCS/HMI/HmiShutdownUnsol/SPM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownUnsol/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownUnsol SPM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownUnsol SPM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownUnsol/SPM", self.vOnMessageCallbackHmiShutdownUnsolSPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownUnsol SPM - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownUnsol FUFC
        # Subscribing and adding callback for HmiShutdownUnsol FUFC
        # Subscribing and adding callback for HmiShutdownUnsol FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownUnsol FUFC with topic ADCS/HMI/HmiShutdownUnsol/FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownUnsol/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownUnsol FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownUnsol FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownUnsol/FUFC", self.vOnMessageCallbackHmiShutdownUnsolFUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownUnsol FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownUnsol SPM_FUFC
        # Subscribing and adding callback for HmiShutdownUnsol SPM_FUFC
        # Subscribing and adding callback for HmiShutdownUnsol SPM_FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownUnsol SPM_FUFC with topic ADCS/HMI/HmiShutdownUnsol/SPM_FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownUnsol/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownUnsol SPM_FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownUnsol SPM_FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownUnsol/SPM_FUFC", self.vOnMessageCallbackHmiShutdownUnsolSPM_FUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownUnsol SPM_FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownUnsol Oversight
        # Subscribing and adding callback for HmiShutdownUnsol Oversight
        # Subscribing and adding callback for HmiShutdownUnsol Oversight

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownUnsol Oversight with topic ADCS/HMI/HmiShutdownUnsol/Oversight")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownUnsol/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownUnsol Oversight - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownUnsol Oversight")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownUnsol/Oversight", self.vOnMessageCallbackHmiShutdownUnsolOversight)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownUnsol Oversight - Exception %s", str(E))
        # Subscribing and adding callback for HmiShutdownUnsol Maintainer
        # Subscribing and adding callback for HmiShutdownUnsol Maintainer
        # Subscribing and adding callback for HmiShutdownUnsol Maintainer

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiShutdownUnsol Maintainer with topic ADCS/HMI/HmiShutdownUnsol/Maintainer")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownUnsol/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownUnsol Maintainer - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiShutdownUnsol Maintainer")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiShutdownUnsol/Maintainer", self.vOnMessageCallbackHmiShutdownUnsolMaintainer)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiShutdownUnsol Maintainer - Exception %s", str(E))
        # Subscribing and adding callback for HmiAdcsShutdownCmd APM
        # Subscribing and adding callback for HmiAdcsShutdownCmd APM
        # Subscribing and adding callback for HmiAdcsShutdownCmd APM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiAdcsShutdownCmd APM with topic ADCS/HMI/HmiAdcsShutdownCmd/APM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmd/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmd APM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiAdcsShutdownCmd APM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiAdcsShutdownCmd/APM", self.vOnMessageCallbackHmiAdcsShutdownCmdAPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiAdcsShutdownCmd APM - Exception %s", str(E))
        # Subscribing and adding callback for HmiAdcsShutdownCmd FCO
        # Subscribing and adding callback for HmiAdcsShutdownCmd FCO
        # Subscribing and adding callback for HmiAdcsShutdownCmd FCO

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiAdcsShutdownCmd FCO with topic ADCS/HMI/HmiAdcsShutdownCmd/FCO")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmd/FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmd FCO - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiAdcsShutdownCmd FCO")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiAdcsShutdownCmd/FCO", self.vOnMessageCallbackHmiAdcsShutdownCmdFCO)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiAdcsShutdownCmd FCO - Exception %s", str(E))
        # Subscribing and adding callback for HmiAdcsShutdownCmd APM_FCO
        # Subscribing and adding callback for HmiAdcsShutdownCmd APM_FCO
        # Subscribing and adding callback for HmiAdcsShutdownCmd APM_FCO

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiAdcsShutdownCmd APM_FCO with topic ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmd APM_FCO - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiAdcsShutdownCmd APM_FCO")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO", self.vOnMessageCallbackHmiAdcsShutdownCmdAPM_FCO)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiAdcsShutdownCmd APM_FCO - Exception %s", str(E))
        # Subscribing and adding callback for HmiAdcsShutdownCmd SPM
        # Subscribing and adding callback for HmiAdcsShutdownCmd SPM
        # Subscribing and adding callback for HmiAdcsShutdownCmd SPM

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiAdcsShutdownCmd SPM with topic ADCS/HMI/HmiAdcsShutdownCmd/SPM")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmd/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmd SPM - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiAdcsShutdownCmd SPM")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiAdcsShutdownCmd/SPM", self.vOnMessageCallbackHmiAdcsShutdownCmdSPM)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiAdcsShutdownCmd SPM - Exception %s", str(E))
        # Subscribing and adding callback for HmiAdcsShutdownCmd FUFC
        # Subscribing and adding callback for HmiAdcsShutdownCmd FUFC
        # Subscribing and adding callback for HmiAdcsShutdownCmd FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiAdcsShutdownCmd FUFC with topic ADCS/HMI/HmiAdcsShutdownCmd/FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmd/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmd FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiAdcsShutdownCmd FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiAdcsShutdownCmd/FUFC", self.vOnMessageCallbackHmiAdcsShutdownCmdFUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiAdcsShutdownCmd FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiAdcsShutdownCmd SPM_FUFC
        # Subscribing and adding callback for HmiAdcsShutdownCmd SPM_FUFC
        # Subscribing and adding callback for HmiAdcsShutdownCmd SPM_FUFC

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiAdcsShutdownCmd SPM_FUFC with topic ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmd SPM_FUFC - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiAdcsShutdownCmd SPM_FUFC")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC", self.vOnMessageCallbackHmiAdcsShutdownCmdSPM_FUFC)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiAdcsShutdownCmd SPM_FUFC - Exception %s", str(E))
        # Subscribing and adding callback for HmiAdcsShutdownCmd Oversight
        # Subscribing and adding callback for HmiAdcsShutdownCmd Oversight
        # Subscribing and adding callback for HmiAdcsShutdownCmd Oversight

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiAdcsShutdownCmd Oversight with topic ADCS/HMI/HmiAdcsShutdownCmd/Oversight")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmd/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmd Oversight - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiAdcsShutdownCmd Oversight")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiAdcsShutdownCmd/Oversight", self.vOnMessageCallbackHmiAdcsShutdownCmdOversight)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiAdcsShutdownCmd Oversight - Exception %s", str(E))
        # Subscribing and adding callback for HmiAdcsShutdownCmd Maintainer
        # Subscribing and adding callback for HmiAdcsShutdownCmd Maintainer
        # Subscribing and adding callback for HmiAdcsShutdownCmd Maintainer

        if self._bLoggingEnabled:
            logging.info("Subscribed to message HmiAdcsShutdownCmd Maintainer with topic ADCS/HMI/HmiAdcsShutdownCmd/Maintainer")

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmd/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmd Maintainer - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for HmiAdcsShutdownCmd Maintainer")

        try:
            objMqttClientPar.message_callback_add("ADCS/HMI/HmiAdcsShutdownCmd/Maintainer", self.vOnMessageCallbackHmiAdcsShutdownCmdMaintainer)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for HmiAdcsShutdownCmd Maintainer - Exception %s", str(E))
        # Subscribing and adding callback for EiuStatusReportUnsol 
        # Subscribing and adding callback for EiuStatusReportUnsol 
        # Subscribing and adding callback for EiuStatusReportUnsol 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message EiuStatusReportUnsol  with topic ADCS/EIU/EiuStatusReportUnsol")

        try:
            objMqttClientPar.subscribe("ADCS/EIU/EiuStatusReportUnsol", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message EiuStatusReportUnsol  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for EiuStatusReportUnsol ")

        try:
            objMqttClientPar.message_callback_add("ADCS/EIU/EiuStatusReportUnsol", self.vOnMessageCallbackEiuStatusReportUnsol)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for EiuStatusReportUnsol  - Exception %s", str(E))
        # Subscribing and adding callback for EiuEndOfSetupCmdRsp 
        # Subscribing and adding callback for EiuEndOfSetupCmdRsp 
        # Subscribing and adding callback for EiuEndOfSetupCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message EiuEndOfSetupCmdRsp  with topic ADCS/EIU/EiuEndOfSetupCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/EIU/EiuEndOfSetupCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message EiuEndOfSetupCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for EiuEndOfSetupCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/EIU/EiuEndOfSetupCmdRsp", self.vOnMessageCallbackEiuEndOfSetupCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for EiuEndOfSetupCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for EiuEndOfReadyCmdRsp 
        # Subscribing and adding callback for EiuEndOfReadyCmdRsp 
        # Subscribing and adding callback for EiuEndOfReadyCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message EiuEndOfReadyCmdRsp  with topic ADCS/EIU/EiuEndOfReadyCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/EIU/EiuEndOfReadyCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message EiuEndOfReadyCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for EiuEndOfReadyCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/EIU/EiuEndOfReadyCmdRsp", self.vOnMessageCallbackEiuEndOfReadyCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for EiuEndOfReadyCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for EiuShutdownCmdRsp 
        # Subscribing and adding callback for EiuShutdownCmdRsp 
        # Subscribing and adding callback for EiuShutdownCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message EiuShutdownCmdRsp  with topic ADCS/EIU/EiuShutdownCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/EIU/EiuShutdownCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message EiuShutdownCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for EiuShutdownCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/EIU/EiuShutdownCmdRsp", self.vOnMessageCallbackEiuShutdownCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for EiuShutdownCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for Sf1StatusReportUnsol 
        # Subscribing and adding callback for Sf1StatusReportUnsol 
        # Subscribing and adding callback for Sf1StatusReportUnsol 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message Sf1StatusReportUnsol  with topic ADCS/SF1/Sf1StatusReportUnsol")

        try:
            objMqttClientPar.subscribe("ADCS/SF1/Sf1StatusReportUnsol", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf1StatusReportUnsol  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for Sf1StatusReportUnsol ")

        try:
            objMqttClientPar.message_callback_add("ADCS/SF1/Sf1StatusReportUnsol", self.vOnMessageCallbackSf1StatusReportUnsol)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for Sf1StatusReportUnsol  - Exception %s", str(E))
        # Subscribing and adding callback for Sf1EndOfSetupCmdRsp 
        # Subscribing and adding callback for Sf1EndOfSetupCmdRsp 
        # Subscribing and adding callback for Sf1EndOfSetupCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message Sf1EndOfSetupCmdRsp  with topic ADCS/SF1/Sf1EndOfSetupCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/SF1/Sf1EndOfSetupCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf1EndOfSetupCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for Sf1EndOfSetupCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/SF1/Sf1EndOfSetupCmdRsp", self.vOnMessageCallbackSf1EndOfSetupCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for Sf1EndOfSetupCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for Sf1EndOfReadyCmdRsp 
        # Subscribing and adding callback for Sf1EndOfReadyCmdRsp 
        # Subscribing and adding callback for Sf1EndOfReadyCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message Sf1EndOfReadyCmdRsp  with topic ADCS/SF1/Sf1EndOfReadyCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/SF1/Sf1EndOfReadyCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf1EndOfReadyCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for Sf1EndOfReadyCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/SF1/Sf1EndOfReadyCmdRsp", self.vOnMessageCallbackSf1EndOfReadyCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for Sf1EndOfReadyCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for Sf1ShutdownCmdRsp 
        # Subscribing and adding callback for Sf1ShutdownCmdRsp 
        # Subscribing and adding callback for Sf1ShutdownCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message Sf1ShutdownCmdRsp  with topic ADCS/SF1/Sf1ShutdownCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/SF1/Sf1ShutdownCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf1ShutdownCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for Sf1ShutdownCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/SF1/Sf1ShutdownCmdRsp", self.vOnMessageCallbackSf1ShutdownCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for Sf1ShutdownCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for Sf1ModeCmd 
        # Subscribing and adding callback for Sf1ModeCmd 
        # Subscribing and adding callback for Sf1ModeCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message Sf1ModeCmd  with topic ADCS/SF1/Sf1ModeCmd")

        try:
            objMqttClientPar.subscribe("ADCS/SF1/Sf1ModeCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf1ModeCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for Sf1ModeCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/SF1/Sf1ModeCmd", self.vOnMessageCallbackSf1ModeCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for Sf1ModeCmd  - Exception %s", str(E))
        # Subscribing and adding callback for Sf2StatusReportUnsol 
        # Subscribing and adding callback for Sf2StatusReportUnsol 
        # Subscribing and adding callback for Sf2StatusReportUnsol 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message Sf2StatusReportUnsol  with topic ADCS/SF2/Sf2StatusReportUnsol")

        try:
            objMqttClientPar.subscribe("ADCS/SF2/Sf2StatusReportUnsol", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf2StatusReportUnsol  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for Sf2StatusReportUnsol ")

        try:
            objMqttClientPar.message_callback_add("ADCS/SF2/Sf2StatusReportUnsol", self.vOnMessageCallbackSf2StatusReportUnsol)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for Sf2StatusReportUnsol  - Exception %s", str(E))
        # Subscribing and adding callback for Sf2EndOfSetupCmdRsp 
        # Subscribing and adding callback for Sf2EndOfSetupCmdRsp 
        # Subscribing and adding callback for Sf2EndOfSetupCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message Sf2EndOfSetupCmdRsp  with topic ADCS/SF2/Sf2EndOfSetupCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/SF2/Sf2EndOfSetupCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf2EndOfSetupCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for Sf2EndOfSetupCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/SF2/Sf2EndOfSetupCmdRsp", self.vOnMessageCallbackSf2EndOfSetupCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for Sf2EndOfSetupCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for Sf2EndOfReadyCmdRsp 
        # Subscribing and adding callback for Sf2EndOfReadyCmdRsp 
        # Subscribing and adding callback for Sf2EndOfReadyCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message Sf2EndOfReadyCmdRsp  with topic ADCS/SF2/Sf2EndOfReadyCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/SF2/Sf2EndOfReadyCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf2EndOfReadyCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for Sf2EndOfReadyCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/SF2/Sf2EndOfReadyCmdRsp", self.vOnMessageCallbackSf2EndOfReadyCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for Sf2EndOfReadyCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for Sf2ShutdownCmdRsp 
        # Subscribing and adding callback for Sf2ShutdownCmdRsp 
        # Subscribing and adding callback for Sf2ShutdownCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message Sf2ShutdownCmdRsp  with topic ADCS/SF2/Sf2ShutdownCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/SF2/Sf2ShutdownCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf2ShutdownCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for Sf2ShutdownCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/SF2/Sf2ShutdownCmdRsp", self.vOnMessageCallbackSf2ShutdownCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for Sf2ShutdownCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for Sf3StatusReportUnsol 
        # Subscribing and adding callback for Sf3StatusReportUnsol 
        # Subscribing and adding callback for Sf3StatusReportUnsol 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message Sf3StatusReportUnsol  with topic ADCS/SF3/Sf3StatusReportUnsol")

        try:
            objMqttClientPar.subscribe("ADCS/SF3/Sf3StatusReportUnsol", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf3StatusReportUnsol  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for Sf3StatusReportUnsol ")

        try:
            objMqttClientPar.message_callback_add("ADCS/SF3/Sf3StatusReportUnsol", self.vOnMessageCallbackSf3StatusReportUnsol)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for Sf3StatusReportUnsol  - Exception %s", str(E))
        # Subscribing and adding callback for Sf3EndOfSetupCmdRsp 
        # Subscribing and adding callback for Sf3EndOfSetupCmdRsp 
        # Subscribing and adding callback for Sf3EndOfSetupCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message Sf3EndOfSetupCmdRsp  with topic ADCS/SF3/Sf3EndOfSetupCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/SF3/Sf3EndOfSetupCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf3EndOfSetupCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for Sf3EndOfSetupCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/SF3/Sf3EndOfSetupCmdRsp", self.vOnMessageCallbackSf3EndOfSetupCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for Sf3EndOfSetupCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for Sf3EndOfReadyCmdRsp 
        # Subscribing and adding callback for Sf3EndOfReadyCmdRsp 
        # Subscribing and adding callback for Sf3EndOfReadyCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message Sf3EndOfReadyCmdRsp  with topic ADCS/SF3/Sf3EndOfReadyCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/SF3/Sf3EndOfReadyCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf3EndOfReadyCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for Sf3EndOfReadyCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/SF3/Sf3EndOfReadyCmdRsp", self.vOnMessageCallbackSf3EndOfReadyCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for Sf3EndOfReadyCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for Sf3ShutdownCmdRsp 
        # Subscribing and adding callback for Sf3ShutdownCmdRsp 
        # Subscribing and adding callback for Sf3ShutdownCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message Sf3ShutdownCmdRsp  with topic ADCS/SF3/Sf3ShutdownCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/SF3/Sf3ShutdownCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf3ShutdownCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for Sf3ShutdownCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/SF3/Sf3ShutdownCmdRsp", self.vOnMessageCallbackSf3ShutdownCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for Sf3ShutdownCmdRsp  - Exception %s", str(E))
        # Subscribing and adding callback for MmsShutdownCmd 
        # Subscribing and adding callback for MmsShutdownCmd 
        # Subscribing and adding callback for MmsShutdownCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message MmsShutdownCmd  with topic ADCS/MMS/MmsShutdownCmd")

        try:
            objMqttClientPar.subscribe("ADCS/MMS/MmsShutdownCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message MmsShutdownCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for MmsShutdownCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/MMS/MmsShutdownCmd", self.vOnMessageCallbackMmsShutdownCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for MmsShutdownCmd  - Exception %s", str(E))

        return

# =========================================================="
# MQTT CALLBACK METHODS START
# =========================================================="

    def vOnMessageCallbackOlhmEndOfReadyCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message OlhmEndOfReadyCmd

        This is a public method callback for message OlhmEndOfReadyCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objOlhmEndOfReadyCmd = sOLHM_END_OF_READY_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objOlhmEndOfReadyCmdRsp = sOLHM_END_OF_READY_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for OlhmEndOfReadyCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for OlhmEndOfReadyCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for OlhmEndOfReadyCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objOlhmEndOfReadyCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for OlhmEndOfReadyCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objOlhmEndOfReadyCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for OlhmEndOfReadyCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objOlhmEndOfReadyCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message OlhmEndOfReadyCmd  validation failed")
            elif (objOlhmEndOfReadyCmd.sMsgHeader.u2MsgLength.Value != (objOlhmEndOfReadyCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message OlhmEndOfReadyCmd  length field is invalid - it is %d and should be %d bytes", objOlhmEndOfReadyCmd.sMsgHeader.u2MsgLength.Value, objOlhmEndOfReadyCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/OLHM/OlhmEndOfReadyCmd", "Class": sOLHM_END_OF_READY_CMD, "ClassName": "sOLHM_END_OF_READY_CMD", "acRole": "", "MsgObject": deepcopy(objOlhmEndOfReadyCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/OLHM/OlhmEndOfReadyCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionOlhmEndOfReadyCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objOlhmEndOfReadyCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/OLHM/OlhmEndOfReadyCmdRsp", objOlhmEndOfReadyCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("OlhmEndOfReadyCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackOlhmAdcsShutdownCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message OlhmAdcsShutdownCmd

        This is a public method callback for message OlhmAdcsShutdownCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objOlhmAdcsShutdownCmd = sOLHM_ADCS_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objOlhmAdcsShutdownCmdRsp = sOLHM_ADCS_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for OlhmAdcsShutdownCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for OlhmAdcsShutdownCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for OlhmAdcsShutdownCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objOlhmAdcsShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for OlhmAdcsShutdownCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objOlhmAdcsShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for OlhmAdcsShutdownCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objOlhmAdcsShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message OlhmAdcsShutdownCmd  validation failed")
            elif (objOlhmAdcsShutdownCmd.sMsgHeader.u2MsgLength.Value != (objOlhmAdcsShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message OlhmAdcsShutdownCmd  length field is invalid - it is %d and should be %d bytes", objOlhmAdcsShutdownCmd.sMsgHeader.u2MsgLength.Value, objOlhmAdcsShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/OLHM/OlhmAdcsShutdownCmd", "Class": sOLHM_ADCS_SHUTDOWN_CMD, "ClassName": "sOLHM_ADCS_SHUTDOWN_CMD", "acRole": "", "MsgObject": deepcopy(objOlhmAdcsShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/OLHM/OlhmAdcsShutdownCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionOlhmAdcsShutdownCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objOlhmAdcsShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/OLHM/OlhmAdcsShutdownCmdRsp", objOlhmAdcsShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("OlhmAdcsShutdownCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackTewaStatusReportUnsol(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message TewaStatusReportUnsol

        This is a public method callback for message TewaStatusReportUnsol. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objTewaStatusReportUnsol = sTEWA_STATUS_REPORT_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaStatusReportUnsol  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaStatusReportUnsol  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaStatusReportUnsol  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objTewaStatusReportUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaStatusReportUnsol  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objTewaStatusReportUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for TewaStatusReportUnsol  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objTewaStatusReportUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TewaStatusReportUnsol  validation failed")
            elif (objTewaStatusReportUnsol.sMsgHeader.u2MsgLength.Value != (objTewaStatusReportUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TewaStatusReportUnsol  length field is invalid - it is %d and should be %d bytes", objTewaStatusReportUnsol.sMsgHeader.u2MsgLength.Value, objTewaStatusReportUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/TEWA/TewaStatusReportUnsol", "Class": sTEWA_STATUS_REPORT_UNSOL, "ClassName": "sTEWA_STATUS_REPORT_UNSOL", "acRole": "", "MsgObject": deepcopy(objTewaStatusReportUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/TEWA/TewaStatusReportUnsol")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackTewaEndOfSetupCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message TewaEndOfSetupCmdRsp

        This is a public method callback for message TewaEndOfSetupCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objTewaEndOfSetupCmdRsp = sTEWA_END_OF_SETUP_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaEndOfSetupCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaEndOfSetupCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaEndOfSetupCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objTewaEndOfSetupCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaEndOfSetupCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objTewaEndOfSetupCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for TewaEndOfSetupCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objTewaEndOfSetupCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TewaEndOfSetupCmdRsp  validation failed")
            elif (objTewaEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value != (objTewaEndOfSetupCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TewaEndOfSetupCmdRsp  length field is invalid - it is %d and should be %d bytes", objTewaEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value, objTewaEndOfSetupCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/TEWA/TewaEndOfSetupCmdRsp", "Class": sTEWA_END_OF_SETUP_CMD_RSP, "ClassName": "sTEWA_END_OF_SETUP_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objTewaEndOfSetupCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/TEWA/TewaEndOfSetupCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackTewaEndOfReadyCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message TewaEndOfReadyCmdRsp

        This is a public method callback for message TewaEndOfReadyCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objTewaEndOfReadyCmdRsp = sTEWA_END_OF_READY_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaEndOfReadyCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaEndOfReadyCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaEndOfReadyCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objTewaEndOfReadyCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaEndOfReadyCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objTewaEndOfReadyCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for TewaEndOfReadyCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objTewaEndOfReadyCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TewaEndOfReadyCmdRsp  validation failed")
            elif (objTewaEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value != (objTewaEndOfReadyCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TewaEndOfReadyCmdRsp  length field is invalid - it is %d and should be %d bytes", objTewaEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value, objTewaEndOfReadyCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/TEWA/TewaEndOfReadyCmdRsp", "Class": sTEWA_END_OF_READY_CMD_RSP, "ClassName": "sTEWA_END_OF_READY_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objTewaEndOfReadyCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/TEWA/TewaEndOfReadyCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackTewaShutdownCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message TewaShutdownCmdRsp

        This is a public method callback for message TewaShutdownCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objTewaShutdownCmdRsp = sTEWA_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaShutdownCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaShutdownCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaShutdownCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objTewaShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaShutdownCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objTewaShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for TewaShutdownCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objTewaShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TewaShutdownCmdRsp  validation failed")
            elif (objTewaShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objTewaShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TewaShutdownCmdRsp  length field is invalid - it is %d and should be %d bytes", objTewaShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objTewaShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/TEWA/TewaShutdownCmdRsp", "Class": sTEWA_SHUTDOWN_CMD_RSP, "ClassName": "sTEWA_SHUTDOWN_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objTewaShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/TEWA/TewaShutdownCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackTmStatusReportUnsol(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message TmStatusReportUnsol

        This is a public method callback for message TmStatusReportUnsol. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objTmStatusReportUnsol = sTM_STATUS_REPORT_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for TmStatusReportUnsol  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TmStatusReportUnsol  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TmStatusReportUnsol  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objTmStatusReportUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for TmStatusReportUnsol  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objTmStatusReportUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for TmStatusReportUnsol  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objTmStatusReportUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TmStatusReportUnsol  validation failed")
            elif (objTmStatusReportUnsol.sMsgHeader.u2MsgLength.Value != (objTmStatusReportUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TmStatusReportUnsol  length field is invalid - it is %d and should be %d bytes", objTmStatusReportUnsol.sMsgHeader.u2MsgLength.Value, objTmStatusReportUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/TM/TmStatusReportUnsol", "Class": sTM_STATUS_REPORT_UNSOL, "ClassName": "sTM_STATUS_REPORT_UNSOL", "acRole": "", "MsgObject": deepcopy(objTmStatusReportUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/TM/TmStatusReportUnsol")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackTmEndOfSetupCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message TmEndOfSetupCmdRsp

        This is a public method callback for message TmEndOfSetupCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objTmEndOfSetupCmdRsp = sTM_END_OF_SETUP_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for TmEndOfSetupCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TmEndOfSetupCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TmEndOfSetupCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objTmEndOfSetupCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for TmEndOfSetupCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objTmEndOfSetupCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for TmEndOfSetupCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objTmEndOfSetupCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TmEndOfSetupCmdRsp  validation failed")
            elif (objTmEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value != (objTmEndOfSetupCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TmEndOfSetupCmdRsp  length field is invalid - it is %d and should be %d bytes", objTmEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value, objTmEndOfSetupCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/TM/TmEndOfSetupCmdRsp", "Class": sTM_END_OF_SETUP_CMD_RSP, "ClassName": "sTM_END_OF_SETUP_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objTmEndOfSetupCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/TM/TmEndOfSetupCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackTmEndOfReadyCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message TmEndOfReadyCmdRsp

        This is a public method callback for message TmEndOfReadyCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objTmEndOfReadyCmdRsp = sTM_END_OF_READY_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for TmEndOfReadyCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TmEndOfReadyCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TmEndOfReadyCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objTmEndOfReadyCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for TmEndOfReadyCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objTmEndOfReadyCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for TmEndOfReadyCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objTmEndOfReadyCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TmEndOfReadyCmdRsp  validation failed")
            elif (objTmEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value != (objTmEndOfReadyCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TmEndOfReadyCmdRsp  length field is invalid - it is %d and should be %d bytes", objTmEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value, objTmEndOfReadyCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/TM/TmEndOfReadyCmdRsp", "Class": sTM_END_OF_READY_CMD_RSP, "ClassName": "sTM_END_OF_READY_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objTmEndOfReadyCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/TM/TmEndOfReadyCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackTmShutdownCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message TmShutdownCmdRsp

        This is a public method callback for message TmShutdownCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objTmShutdownCmdRsp = sTM_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for TmShutdownCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TmShutdownCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TmShutdownCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objTmShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for TmShutdownCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objTmShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for TmShutdownCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objTmShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TmShutdownCmdRsp  validation failed")
            elif (objTmShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objTmShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TmShutdownCmdRsp  length field is invalid - it is %d and should be %d bytes", objTmShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objTmShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/TM/TmShutdownCmdRsp", "Class": sTM_SHUTDOWN_CMD_RSP, "ClassName": "sTM_SHUTDOWN_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objTmShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/TM/TmShutdownCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackPdbpStatusReportUnsol(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message PdbpStatusReportUnsol

        This is a public method callback for message PdbpStatusReportUnsol. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objPdbpStatusReportUnsol = sPDBP_STATUS_REPORT_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpStatusReportUnsol  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpStatusReportUnsol  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpStatusReportUnsol  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objPdbpStatusReportUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpStatusReportUnsol  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objPdbpStatusReportUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for PdbpStatusReportUnsol  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objPdbpStatusReportUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpStatusReportUnsol  validation failed")
            elif (objPdbpStatusReportUnsol.sMsgHeader.u2MsgLength.Value != (objPdbpStatusReportUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpStatusReportUnsol  length field is invalid - it is %d and should be %d bytes", objPdbpStatusReportUnsol.sMsgHeader.u2MsgLength.Value, objPdbpStatusReportUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/PDBP/PdbpStatusReportUnsol", "Class": sPDBP_STATUS_REPORT_UNSOL, "ClassName": "sPDBP_STATUS_REPORT_UNSOL", "acRole": "", "MsgObject": deepcopy(objPdbpStatusReportUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/PDBP/PdbpStatusReportUnsol")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackPdbpEndOfReadyCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message PdbpEndOfReadyCmdRsp

        This is a public method callback for message PdbpEndOfReadyCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objPdbpEndOfReadyCmdRsp = sPDBP_END_OF_READY_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpEndOfReadyCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpEndOfReadyCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpEndOfReadyCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objPdbpEndOfReadyCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpEndOfReadyCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objPdbpEndOfReadyCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for PdbpEndOfReadyCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objPdbpEndOfReadyCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpEndOfReadyCmdRsp  validation failed")
            elif (objPdbpEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value != (objPdbpEndOfReadyCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpEndOfReadyCmdRsp  length field is invalid - it is %d and should be %d bytes", objPdbpEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value, objPdbpEndOfReadyCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/PDBP/PdbpEndOfReadyCmdRsp", "Class": sPDBP_END_OF_READY_CMD_RSP, "ClassName": "sPDBP_END_OF_READY_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objPdbpEndOfReadyCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/PDBP/PdbpEndOfReadyCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackPdbpShutdownCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message PdbpShutdownCmdRsp

        This is a public method callback for message PdbpShutdownCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objPdbpShutdownCmdRsp = sPDBP_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpShutdownCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpShutdownCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpShutdownCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objPdbpShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpShutdownCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objPdbpShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for PdbpShutdownCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objPdbpShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpShutdownCmdRsp  validation failed")
            elif (objPdbpShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objPdbpShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpShutdownCmdRsp  length field is invalid - it is %d and should be %d bytes", objPdbpShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objPdbpShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/PDBP/PdbpShutdownCmdRsp", "Class": sPDBP_SHUTDOWN_CMD_RSP, "ClassName": "sPDBP_SHUTDOWN_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objPdbpShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/PDBP/PdbpShutdownCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackPdbpSendOutModuleDbMessagesCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message PdbpSendOutModuleDbMessagesCmdRsp

        This is a public method callback for message PdbpSendOutModuleDbMessagesCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objPdbpSendOutModuleDbMessagesCmdRsp = sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpSendOutModuleDbMessagesCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpSendOutModuleDbMessagesCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpSendOutModuleDbMessagesCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objPdbpSendOutModuleDbMessagesCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for PdbpSendOutModuleDbMessagesCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objPdbpSendOutModuleDbMessagesCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for PdbpSendOutModuleDbMessagesCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objPdbpSendOutModuleDbMessagesCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpSendOutModuleDbMessagesCmdRsp  validation failed")
            elif (objPdbpSendOutModuleDbMessagesCmdRsp.sMsgHeader.u2MsgLength.Value != (objPdbpSendOutModuleDbMessagesCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message PdbpSendOutModuleDbMessagesCmdRsp  length field is invalid - it is %d and should be %d bytes", objPdbpSendOutModuleDbMessagesCmdRsp.sMsgHeader.u2MsgLength.Value, objPdbpSendOutModuleDbMessagesCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp", "Class": sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP, "ClassName": "sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objPdbpSendOutModuleDbMessagesCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackDrStatusReportUnsol(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message DrStatusReportUnsol

        This is a public method callback for message DrStatusReportUnsol. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objDrStatusReportUnsol = sDR_STATUS_REPORT_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for DrStatusReportUnsol  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for DrStatusReportUnsol  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for DrStatusReportUnsol  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objDrStatusReportUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for DrStatusReportUnsol  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objDrStatusReportUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for DrStatusReportUnsol  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objDrStatusReportUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message DrStatusReportUnsol  validation failed")
            elif (objDrStatusReportUnsol.sMsgHeader.u2MsgLength.Value != (objDrStatusReportUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message DrStatusReportUnsol  length field is invalid - it is %d and should be %d bytes", objDrStatusReportUnsol.sMsgHeader.u2MsgLength.Value, objDrStatusReportUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/DR/DrStatusReportUnsol", "Class": sDR_STATUS_REPORT_UNSOL, "ClassName": "sDR_STATUS_REPORT_UNSOL", "acRole": "", "MsgObject": deepcopy(objDrStatusReportUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/DR/DrStatusReportUnsol")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackDrEndOfSetupCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message DrEndOfSetupCmdRsp

        This is a public method callback for message DrEndOfSetupCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objDrEndOfSetupCmdRsp = sDR_END_OF_SETUP_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for DrEndOfSetupCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for DrEndOfSetupCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for DrEndOfSetupCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objDrEndOfSetupCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for DrEndOfSetupCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objDrEndOfSetupCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for DrEndOfSetupCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objDrEndOfSetupCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message DrEndOfSetupCmdRsp  validation failed")
            elif (objDrEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value != (objDrEndOfSetupCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message DrEndOfSetupCmdRsp  length field is invalid - it is %d and should be %d bytes", objDrEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value, objDrEndOfSetupCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/DR/DrEndOfSetupCmdRsp", "Class": sDR_END_OF_SETUP_CMD_RSP, "ClassName": "sDR_END_OF_SETUP_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objDrEndOfSetupCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/DR/DrEndOfSetupCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackDrEndOfReadyCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message DrEndOfReadyCmdRsp

        This is a public method callback for message DrEndOfReadyCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objDrEndOfReadyCmdRsp = sDR_END_OF_READY_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for DrEndOfReadyCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for DrEndOfReadyCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for DrEndOfReadyCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objDrEndOfReadyCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for DrEndOfReadyCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objDrEndOfReadyCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for DrEndOfReadyCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objDrEndOfReadyCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message DrEndOfReadyCmdRsp  validation failed")
            elif (objDrEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value != (objDrEndOfReadyCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message DrEndOfReadyCmdRsp  length field is invalid - it is %d and should be %d bytes", objDrEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value, objDrEndOfReadyCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/DR/DrEndOfReadyCmdRsp", "Class": sDR_END_OF_READY_CMD_RSP, "ClassName": "sDR_END_OF_READY_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objDrEndOfReadyCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/DR/DrEndOfReadyCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackDrShutdownCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message DrShutdownCmdRsp

        This is a public method callback for message DrShutdownCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objDrShutdownCmdRsp = sDR_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for DrShutdownCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for DrShutdownCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for DrShutdownCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objDrShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for DrShutdownCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objDrShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for DrShutdownCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objDrShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message DrShutdownCmdRsp  validation failed")
            elif (objDrShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objDrShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message DrShutdownCmdRsp  length field is invalid - it is %d and should be %d bytes", objDrShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objDrShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/DR/DrShutdownCmdRsp", "Class": sDR_SHUTDOWN_CMD_RSP, "ClassName": "sDR_SHUTDOWN_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objDrShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/DR/DrShutdownCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiStatusReportUnsolAPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiStatusReportUnsolAPM

        This is a public method callback for message HmiStatusReportUnsolAPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiStatusReportUnsol = sHMI_STATUS_REPORT_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol APM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol APM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol APM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiStatusReportUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol APM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiStatusReportUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiStatusReportUnsol APM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiStatusReportUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiStatusReportUnsol APM validation failed")
            elif (objHmiStatusReportUnsol.sMsgHeader.u2MsgLength.Value != (objHmiStatusReportUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiStatusReportUnsol APM length field is invalid - it is %d and should be %d bytes", objHmiStatusReportUnsol.sMsgHeader.u2MsgLength.Value, objHmiStatusReportUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiStatusReportUnsol/APM", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "acRole": "APM", "MsgObject": deepcopy(objHmiStatusReportUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiStatusReportUnsol/APM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiStatusReportUnsolFCO(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiStatusReportUnsolFCO

        This is a public method callback for message HmiStatusReportUnsolFCO. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiStatusReportUnsol = sHMI_STATUS_REPORT_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol FCO objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol FCO objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol FCO objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiStatusReportUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol FCO length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiStatusReportUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiStatusReportUnsol FCO - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiStatusReportUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiStatusReportUnsol FCO validation failed")
            elif (objHmiStatusReportUnsol.sMsgHeader.u2MsgLength.Value != (objHmiStatusReportUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiStatusReportUnsol FCO length field is invalid - it is %d and should be %d bytes", objHmiStatusReportUnsol.sMsgHeader.u2MsgLength.Value, objHmiStatusReportUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiStatusReportUnsol/FCO", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "acRole": "FCO", "MsgObject": deepcopy(objHmiStatusReportUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiStatusReportUnsol/FCO")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiStatusReportUnsolAPM_FCO(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiStatusReportUnsolAPM_FCO

        This is a public method callback for message HmiStatusReportUnsolAPM_FCO. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiStatusReportUnsol = sHMI_STATUS_REPORT_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol APM_FCO objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol APM_FCO objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol APM_FCO objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiStatusReportUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol APM_FCO length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiStatusReportUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiStatusReportUnsol APM_FCO - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiStatusReportUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiStatusReportUnsol APM_FCO validation failed")
            elif (objHmiStatusReportUnsol.sMsgHeader.u2MsgLength.Value != (objHmiStatusReportUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiStatusReportUnsol APM_FCO length field is invalid - it is %d and should be %d bytes", objHmiStatusReportUnsol.sMsgHeader.u2MsgLength.Value, objHmiStatusReportUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiStatusReportUnsol/APM_FCO", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "acRole": "APM_FCO", "MsgObject": deepcopy(objHmiStatusReportUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiStatusReportUnsol/APM_FCO")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiStatusReportUnsolSPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiStatusReportUnsolSPM

        This is a public method callback for message HmiStatusReportUnsolSPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiStatusReportUnsol = sHMI_STATUS_REPORT_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol SPM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol SPM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol SPM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiStatusReportUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol SPM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiStatusReportUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiStatusReportUnsol SPM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiStatusReportUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiStatusReportUnsol SPM validation failed")
            elif (objHmiStatusReportUnsol.sMsgHeader.u2MsgLength.Value != (objHmiStatusReportUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiStatusReportUnsol SPM length field is invalid - it is %d and should be %d bytes", objHmiStatusReportUnsol.sMsgHeader.u2MsgLength.Value, objHmiStatusReportUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiStatusReportUnsol/SPM", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "acRole": "SPM", "MsgObject": deepcopy(objHmiStatusReportUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiStatusReportUnsol/SPM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiStatusReportUnsolFUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiStatusReportUnsolFUFC

        This is a public method callback for message HmiStatusReportUnsolFUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiStatusReportUnsol = sHMI_STATUS_REPORT_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiStatusReportUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiStatusReportUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiStatusReportUnsol FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiStatusReportUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiStatusReportUnsol FUFC validation failed")
            elif (objHmiStatusReportUnsol.sMsgHeader.u2MsgLength.Value != (objHmiStatusReportUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiStatusReportUnsol FUFC length field is invalid - it is %d and should be %d bytes", objHmiStatusReportUnsol.sMsgHeader.u2MsgLength.Value, objHmiStatusReportUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiStatusReportUnsol/FUFC", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "acRole": "FUFC", "MsgObject": deepcopy(objHmiStatusReportUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiStatusReportUnsol/FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiStatusReportUnsolSPM_FUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiStatusReportUnsolSPM_FUFC

        This is a public method callback for message HmiStatusReportUnsolSPM_FUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiStatusReportUnsol = sHMI_STATUS_REPORT_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol SPM_FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol SPM_FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol SPM_FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiStatusReportUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol SPM_FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiStatusReportUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiStatusReportUnsol SPM_FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiStatusReportUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiStatusReportUnsol SPM_FUFC validation failed")
            elif (objHmiStatusReportUnsol.sMsgHeader.u2MsgLength.Value != (objHmiStatusReportUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiStatusReportUnsol SPM_FUFC length field is invalid - it is %d and should be %d bytes", objHmiStatusReportUnsol.sMsgHeader.u2MsgLength.Value, objHmiStatusReportUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "acRole": "SPM_FUFC", "MsgObject": deepcopy(objHmiStatusReportUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiStatusReportUnsolOversight(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiStatusReportUnsolOversight

        This is a public method callback for message HmiStatusReportUnsolOversight. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiStatusReportUnsol = sHMI_STATUS_REPORT_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol Oversight objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol Oversight objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol Oversight objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiStatusReportUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol Oversight length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiStatusReportUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiStatusReportUnsol Oversight - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiStatusReportUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiStatusReportUnsol Oversight validation failed")
            elif (objHmiStatusReportUnsol.sMsgHeader.u2MsgLength.Value != (objHmiStatusReportUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiStatusReportUnsol Oversight length field is invalid - it is %d and should be %d bytes", objHmiStatusReportUnsol.sMsgHeader.u2MsgLength.Value, objHmiStatusReportUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiStatusReportUnsol/Oversight", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "acRole": "Oversight", "MsgObject": deepcopy(objHmiStatusReportUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiStatusReportUnsol/Oversight")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiStatusReportUnsolMaintainer(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiStatusReportUnsolMaintainer

        This is a public method callback for message HmiStatusReportUnsolMaintainer. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiStatusReportUnsol = sHMI_STATUS_REPORT_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol Maintainer objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol Maintainer objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol Maintainer objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiStatusReportUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiStatusReportUnsol Maintainer length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiStatusReportUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiStatusReportUnsol Maintainer - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiStatusReportUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiStatusReportUnsol Maintainer validation failed")
            elif (objHmiStatusReportUnsol.sMsgHeader.u2MsgLength.Value != (objHmiStatusReportUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiStatusReportUnsol Maintainer length field is invalid - it is %d and should be %d bytes", objHmiStatusReportUnsol.sMsgHeader.u2MsgLength.Value, objHmiStatusReportUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiStatusReportUnsol/Maintainer", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "acRole": "Maintainer", "MsgObject": deepcopy(objHmiStatusReportUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiStatusReportUnsol/Maintainer")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiEndOfSetupCmdRspAPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfSetupCmdRspAPM

        This is a public method callback for message HmiEndOfSetupCmdRspAPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfSetupCmdRsp = sHMI_END_OF_SETUP_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp APM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp APM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp APM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfSetupCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp APM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfSetupCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfSetupCmdRsp APM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfSetupCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmdRsp APM validation failed")
            elif (objHmiEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiEndOfSetupCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmdRsp APM length field is invalid - it is %d and should be %d bytes", objHmiEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiEndOfSetupCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/APM", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "acRole": "APM", "MsgObject": deepcopy(objHmiEndOfSetupCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfSetupCmdRsp/APM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiEndOfSetupCmdRspFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfSetupCmdRspFC

        This is a public method callback for message HmiEndOfSetupCmdRspFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfSetupCmdRsp = sHMI_END_OF_SETUP_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp FC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp FC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp FC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfSetupCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp FC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfSetupCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfSetupCmdRsp FC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfSetupCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmdRsp FC validation failed")
            elif (objHmiEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiEndOfSetupCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmdRsp FC length field is invalid - it is %d and should be %d bytes", objHmiEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiEndOfSetupCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/FC", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "acRole": "FC", "MsgObject": deepcopy(objHmiEndOfSetupCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfSetupCmdRsp/FC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiEndOfSetupCmdRspAPM_FC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfSetupCmdRspAPM_FC

        This is a public method callback for message HmiEndOfSetupCmdRspAPM_FC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfSetupCmdRsp = sHMI_END_OF_SETUP_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp APM_FC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp APM_FC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp APM_FC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfSetupCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp APM_FC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfSetupCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfSetupCmdRsp APM_FC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfSetupCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmdRsp APM_FC validation failed")
            elif (objHmiEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiEndOfSetupCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmdRsp APM_FC length field is invalid - it is %d and should be %d bytes", objHmiEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiEndOfSetupCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "acRole": "APM_FC", "MsgObject": deepcopy(objHmiEndOfSetupCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiEndOfSetupCmdRspSPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfSetupCmdRspSPM

        This is a public method callback for message HmiEndOfSetupCmdRspSPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfSetupCmdRsp = sHMI_END_OF_SETUP_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp SPM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp SPM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp SPM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfSetupCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp SPM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfSetupCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfSetupCmdRsp SPM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfSetupCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmdRsp SPM validation failed")
            elif (objHmiEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiEndOfSetupCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmdRsp SPM length field is invalid - it is %d and should be %d bytes", objHmiEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiEndOfSetupCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/SPM", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "acRole": "SPM", "MsgObject": deepcopy(objHmiEndOfSetupCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfSetupCmdRsp/SPM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiEndOfSetupCmdRspFUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfSetupCmdRspFUFC

        This is a public method callback for message HmiEndOfSetupCmdRspFUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfSetupCmdRsp = sHMI_END_OF_SETUP_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfSetupCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfSetupCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfSetupCmdRsp FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfSetupCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmdRsp FUFC validation failed")
            elif (objHmiEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiEndOfSetupCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmdRsp FUFC length field is invalid - it is %d and should be %d bytes", objHmiEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiEndOfSetupCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "acRole": "FUFC", "MsgObject": deepcopy(objHmiEndOfSetupCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiEndOfSetupCmdRspSPM_FUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfSetupCmdRspSPM_FUFC

        This is a public method callback for message HmiEndOfSetupCmdRspSPM_FUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfSetupCmdRsp = sHMI_END_OF_SETUP_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp SPM_FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp SPM_FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp SPM_FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfSetupCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp SPM_FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfSetupCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfSetupCmdRsp SPM_FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfSetupCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmdRsp SPM_FUFC validation failed")
            elif (objHmiEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiEndOfSetupCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmdRsp SPM_FUFC length field is invalid - it is %d and should be %d bytes", objHmiEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiEndOfSetupCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "acRole": "SPM_FUFC", "MsgObject": deepcopy(objHmiEndOfSetupCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiEndOfSetupCmdRspOversight(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfSetupCmdRspOversight

        This is a public method callback for message HmiEndOfSetupCmdRspOversight. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfSetupCmdRsp = sHMI_END_OF_SETUP_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp Oversight objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp Oversight objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp Oversight objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfSetupCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp Oversight length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfSetupCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfSetupCmdRsp Oversight - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfSetupCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmdRsp Oversight validation failed")
            elif (objHmiEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiEndOfSetupCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmdRsp Oversight length field is invalid - it is %d and should be %d bytes", objHmiEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiEndOfSetupCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "acRole": "Oversight", "MsgObject": deepcopy(objHmiEndOfSetupCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiEndOfSetupCmdRspMaintainer(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfSetupCmdRspMaintainer

        This is a public method callback for message HmiEndOfSetupCmdRspMaintainer. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfSetupCmdRsp = sHMI_END_OF_SETUP_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp Maintainer objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp Maintainer objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp Maintainer objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfSetupCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfSetupCmdRsp Maintainer length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfSetupCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfSetupCmdRsp Maintainer - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfSetupCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmdRsp Maintainer validation failed")
            elif (objHmiEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiEndOfSetupCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfSetupCmdRsp Maintainer length field is invalid - it is %d and should be %d bytes", objHmiEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiEndOfSetupCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "acRole": "Maintainer", "MsgObject": deepcopy(objHmiEndOfSetupCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiEndOfReadyCmdRspAPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfReadyCmdRspAPM

        This is a public method callback for message HmiEndOfReadyCmdRspAPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfReadyCmdRsp = sHMI_END_OF_READY_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp APM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp APM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp APM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfReadyCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp APM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfReadyCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfReadyCmdRsp APM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfReadyCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmdRsp APM validation failed")
            elif (objHmiEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiEndOfReadyCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmdRsp APM length field is invalid - it is %d and should be %d bytes", objHmiEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiEndOfReadyCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/APM", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "acRole": "APM", "MsgObject": deepcopy(objHmiEndOfReadyCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfReadyCmdRsp/APM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiEndOfReadyCmdRspFCO(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfReadyCmdRspFCO

        This is a public method callback for message HmiEndOfReadyCmdRspFCO. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfReadyCmdRsp = sHMI_END_OF_READY_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp FCO objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp FCO objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp FCO objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfReadyCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp FCO length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfReadyCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfReadyCmdRsp FCO - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfReadyCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmdRsp FCO validation failed")
            elif (objHmiEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiEndOfReadyCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmdRsp FCO length field is invalid - it is %d and should be %d bytes", objHmiEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiEndOfReadyCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/FCO", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "acRole": "FCO", "MsgObject": deepcopy(objHmiEndOfReadyCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfReadyCmdRsp/FCO")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiEndOfReadyCmdRspAPM_FCO(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfReadyCmdRspAPM_FCO

        This is a public method callback for message HmiEndOfReadyCmdRspAPM_FCO. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfReadyCmdRsp = sHMI_END_OF_READY_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp APM_FCO objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp APM_FCO objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp APM_FCO objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfReadyCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp APM_FCO length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfReadyCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfReadyCmdRsp APM_FCO - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfReadyCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmdRsp APM_FCO validation failed")
            elif (objHmiEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiEndOfReadyCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmdRsp APM_FCO length field is invalid - it is %d and should be %d bytes", objHmiEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiEndOfReadyCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "acRole": "APM_FCO", "MsgObject": deepcopy(objHmiEndOfReadyCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiEndOfReadyCmdRspSPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfReadyCmdRspSPM

        This is a public method callback for message HmiEndOfReadyCmdRspSPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfReadyCmdRsp = sHMI_END_OF_READY_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp SPM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp SPM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp SPM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfReadyCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp SPM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfReadyCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfReadyCmdRsp SPM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfReadyCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmdRsp SPM validation failed")
            elif (objHmiEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiEndOfReadyCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmdRsp SPM length field is invalid - it is %d and should be %d bytes", objHmiEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiEndOfReadyCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/SPM", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "acRole": "SPM", "MsgObject": deepcopy(objHmiEndOfReadyCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfReadyCmdRsp/SPM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiEndOfReadyCmdRspFUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfReadyCmdRspFUFC

        This is a public method callback for message HmiEndOfReadyCmdRspFUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfReadyCmdRsp = sHMI_END_OF_READY_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfReadyCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfReadyCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfReadyCmdRsp FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfReadyCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmdRsp FUFC validation failed")
            elif (objHmiEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiEndOfReadyCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmdRsp FUFC length field is invalid - it is %d and should be %d bytes", objHmiEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiEndOfReadyCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "acRole": "FUFC", "MsgObject": deepcopy(objHmiEndOfReadyCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiEndOfReadyCmdRspSPM_FUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfReadyCmdRspSPM_FUFC

        This is a public method callback for message HmiEndOfReadyCmdRspSPM_FUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfReadyCmdRsp = sHMI_END_OF_READY_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp SPM_FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp SPM_FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp SPM_FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfReadyCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp SPM_FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfReadyCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfReadyCmdRsp SPM_FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfReadyCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmdRsp SPM_FUFC validation failed")
            elif (objHmiEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiEndOfReadyCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmdRsp SPM_FUFC length field is invalid - it is %d and should be %d bytes", objHmiEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiEndOfReadyCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "acRole": "SPM_FUFC", "MsgObject": deepcopy(objHmiEndOfReadyCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiEndOfReadyCmdRspOversight(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfReadyCmdRspOversight

        This is a public method callback for message HmiEndOfReadyCmdRspOversight. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfReadyCmdRsp = sHMI_END_OF_READY_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp Oversight objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp Oversight objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp Oversight objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfReadyCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp Oversight length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfReadyCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfReadyCmdRsp Oversight - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfReadyCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmdRsp Oversight validation failed")
            elif (objHmiEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiEndOfReadyCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmdRsp Oversight length field is invalid - it is %d and should be %d bytes", objHmiEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiEndOfReadyCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "acRole": "Oversight", "MsgObject": deepcopy(objHmiEndOfReadyCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiEndOfReadyCmdRspMaintainer(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiEndOfReadyCmdRspMaintainer

        This is a public method callback for message HmiEndOfReadyCmdRspMaintainer. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiEndOfReadyCmdRsp = sHMI_END_OF_READY_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp Maintainer objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp Maintainer objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp Maintainer objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiEndOfReadyCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiEndOfReadyCmdRsp Maintainer length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiEndOfReadyCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiEndOfReadyCmdRsp Maintainer - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiEndOfReadyCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmdRsp Maintainer validation failed")
            elif (objHmiEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiEndOfReadyCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiEndOfReadyCmdRsp Maintainer length field is invalid - it is %d and should be %d bytes", objHmiEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiEndOfReadyCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "acRole": "Maintainer", "MsgObject": deepcopy(objHmiEndOfReadyCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiShutdownCmdRspAPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownCmdRspAPM

        This is a public method callback for message HmiShutdownCmdRspAPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownCmdRsp = sHMI_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp APM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp APM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp APM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp APM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownCmdRsp APM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmdRsp APM validation failed")
            elif (objHmiShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmdRsp APM length field is invalid - it is %d and should be %d bytes", objHmiShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownCmdRsp/APM", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "acRole": "APM", "MsgObject": deepcopy(objHmiShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownCmdRsp/APM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiShutdownCmdRspFCO(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownCmdRspFCO

        This is a public method callback for message HmiShutdownCmdRspFCO. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownCmdRsp = sHMI_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp FCO objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp FCO objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp FCO objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp FCO length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownCmdRsp FCO - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmdRsp FCO validation failed")
            elif (objHmiShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmdRsp FCO length field is invalid - it is %d and should be %d bytes", objHmiShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownCmdRsp/FCO", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "acRole": "FCO", "MsgObject": deepcopy(objHmiShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownCmdRsp/FCO")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiShutdownCmdRspAPM_FCO(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownCmdRspAPM_FCO

        This is a public method callback for message HmiShutdownCmdRspAPM_FCO. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownCmdRsp = sHMI_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp APM_FCO objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp APM_FCO objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp APM_FCO objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp APM_FCO length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownCmdRsp APM_FCO - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmdRsp APM_FCO validation failed")
            elif (objHmiShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmdRsp APM_FCO length field is invalid - it is %d and should be %d bytes", objHmiShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownCmdRsp/APM_FCO", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "acRole": "APM_FCO", "MsgObject": deepcopy(objHmiShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownCmdRsp/APM_FCO")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiShutdownCmdRspSPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownCmdRspSPM

        This is a public method callback for message HmiShutdownCmdRspSPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownCmdRsp = sHMI_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp SPM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp SPM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp SPM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp SPM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownCmdRsp SPM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmdRsp SPM validation failed")
            elif (objHmiShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmdRsp SPM length field is invalid - it is %d and should be %d bytes", objHmiShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownCmdRsp/SPM", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "acRole": "SPM", "MsgObject": deepcopy(objHmiShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownCmdRsp/SPM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiShutdownCmdRspFUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownCmdRspFUFC

        This is a public method callback for message HmiShutdownCmdRspFUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownCmdRsp = sHMI_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownCmdRsp FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmdRsp FUFC validation failed")
            elif (objHmiShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmdRsp FUFC length field is invalid - it is %d and should be %d bytes", objHmiShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownCmdRsp/FUFC", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "acRole": "FUFC", "MsgObject": deepcopy(objHmiShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownCmdRsp/FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiShutdownCmdRspSPM_FUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownCmdRspSPM_FUFC

        This is a public method callback for message HmiShutdownCmdRspSPM_FUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownCmdRsp = sHMI_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp SPM_FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp SPM_FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp SPM_FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp SPM_FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownCmdRsp SPM_FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmdRsp SPM_FUFC validation failed")
            elif (objHmiShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmdRsp SPM_FUFC length field is invalid - it is %d and should be %d bytes", objHmiShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "acRole": "SPM_FUFC", "MsgObject": deepcopy(objHmiShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiShutdownCmdRspOversight(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownCmdRspOversight

        This is a public method callback for message HmiShutdownCmdRspOversight. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownCmdRsp = sHMI_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp Oversight objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp Oversight objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp Oversight objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp Oversight length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownCmdRsp Oversight - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmdRsp Oversight validation failed")
            elif (objHmiShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmdRsp Oversight length field is invalid - it is %d and should be %d bytes", objHmiShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownCmdRsp/Oversight", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "acRole": "Oversight", "MsgObject": deepcopy(objHmiShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownCmdRsp/Oversight")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiShutdownCmdRspMaintainer(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownCmdRspMaintainer

        This is a public method callback for message HmiShutdownCmdRspMaintainer. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownCmdRsp = sHMI_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp Maintainer objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp Maintainer objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp Maintainer objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownCmdRsp Maintainer length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownCmdRsp Maintainer - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmdRsp Maintainer validation failed")
            elif (objHmiShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objHmiShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownCmdRsp Maintainer length field is invalid - it is %d and should be %d bytes", objHmiShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objHmiShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownCmdRsp/Maintainer", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "acRole": "Maintainer", "MsgObject": deepcopy(objHmiShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownCmdRsp/Maintainer")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiShutdownUnsolAPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownUnsolAPM

        This is a public method callback for message HmiShutdownUnsolAPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownUnsol = sHMI_SHUTDOWN_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol APM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol APM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol APM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol APM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownUnsol APM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownUnsol APM validation failed")
            elif (objHmiShutdownUnsol.sMsgHeader.u2MsgLength.Value != (objHmiShutdownUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownUnsol APM length field is invalid - it is %d and should be %d bytes", objHmiShutdownUnsol.sMsgHeader.u2MsgLength.Value, objHmiShutdownUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownUnsol/APM", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "acRole": "APM", "MsgObject": deepcopy(objHmiShutdownUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownUnsol/APM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiShutdownUnsolFCO(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownUnsolFCO

        This is a public method callback for message HmiShutdownUnsolFCO. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownUnsol = sHMI_SHUTDOWN_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol FCO objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol FCO objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol FCO objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol FCO length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownUnsol FCO - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownUnsol FCO validation failed")
            elif (objHmiShutdownUnsol.sMsgHeader.u2MsgLength.Value != (objHmiShutdownUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownUnsol FCO length field is invalid - it is %d and should be %d bytes", objHmiShutdownUnsol.sMsgHeader.u2MsgLength.Value, objHmiShutdownUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownUnsol/FCO", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "acRole": "FCO", "MsgObject": deepcopy(objHmiShutdownUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownUnsol/FCO")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiShutdownUnsolAPM_FCO(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownUnsolAPM_FCO

        This is a public method callback for message HmiShutdownUnsolAPM_FCO. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownUnsol = sHMI_SHUTDOWN_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol APM_FCO objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol APM_FCO objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol APM_FCO objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol APM_FCO length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownUnsol APM_FCO - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownUnsol APM_FCO validation failed")
            elif (objHmiShutdownUnsol.sMsgHeader.u2MsgLength.Value != (objHmiShutdownUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownUnsol APM_FCO length field is invalid - it is %d and should be %d bytes", objHmiShutdownUnsol.sMsgHeader.u2MsgLength.Value, objHmiShutdownUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownUnsol/APM_FCO", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "acRole": "APM_FCO", "MsgObject": deepcopy(objHmiShutdownUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownUnsol/APM_FCO")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiShutdownUnsolSPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownUnsolSPM

        This is a public method callback for message HmiShutdownUnsolSPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownUnsol = sHMI_SHUTDOWN_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol SPM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol SPM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol SPM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol SPM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownUnsol SPM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownUnsol SPM validation failed")
            elif (objHmiShutdownUnsol.sMsgHeader.u2MsgLength.Value != (objHmiShutdownUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownUnsol SPM length field is invalid - it is %d and should be %d bytes", objHmiShutdownUnsol.sMsgHeader.u2MsgLength.Value, objHmiShutdownUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownUnsol/SPM", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "acRole": "SPM", "MsgObject": deepcopy(objHmiShutdownUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownUnsol/SPM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiShutdownUnsolFUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownUnsolFUFC

        This is a public method callback for message HmiShutdownUnsolFUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownUnsol = sHMI_SHUTDOWN_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownUnsol FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownUnsol FUFC validation failed")
            elif (objHmiShutdownUnsol.sMsgHeader.u2MsgLength.Value != (objHmiShutdownUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownUnsol FUFC length field is invalid - it is %d and should be %d bytes", objHmiShutdownUnsol.sMsgHeader.u2MsgLength.Value, objHmiShutdownUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownUnsol/FUFC", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "acRole": "FUFC", "MsgObject": deepcopy(objHmiShutdownUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownUnsol/FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiShutdownUnsolSPM_FUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownUnsolSPM_FUFC

        This is a public method callback for message HmiShutdownUnsolSPM_FUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownUnsol = sHMI_SHUTDOWN_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol SPM_FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol SPM_FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol SPM_FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol SPM_FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownUnsol SPM_FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownUnsol SPM_FUFC validation failed")
            elif (objHmiShutdownUnsol.sMsgHeader.u2MsgLength.Value != (objHmiShutdownUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownUnsol SPM_FUFC length field is invalid - it is %d and should be %d bytes", objHmiShutdownUnsol.sMsgHeader.u2MsgLength.Value, objHmiShutdownUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownUnsol/SPM_FUFC", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "acRole": "SPM_FUFC", "MsgObject": deepcopy(objHmiShutdownUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownUnsol/SPM_FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiShutdownUnsolOversight(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownUnsolOversight

        This is a public method callback for message HmiShutdownUnsolOversight. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownUnsol = sHMI_SHUTDOWN_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol Oversight objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol Oversight objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol Oversight objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol Oversight length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownUnsol Oversight - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownUnsol Oversight validation failed")
            elif (objHmiShutdownUnsol.sMsgHeader.u2MsgLength.Value != (objHmiShutdownUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownUnsol Oversight length field is invalid - it is %d and should be %d bytes", objHmiShutdownUnsol.sMsgHeader.u2MsgLength.Value, objHmiShutdownUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownUnsol/Oversight", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "acRole": "Oversight", "MsgObject": deepcopy(objHmiShutdownUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownUnsol/Oversight")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiShutdownUnsolMaintainer(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiShutdownUnsolMaintainer

        This is a public method callback for message HmiShutdownUnsolMaintainer. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiShutdownUnsol = sHMI_SHUTDOWN_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol Maintainer objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol Maintainer objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol Maintainer objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiShutdownUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiShutdownUnsol Maintainer length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiShutdownUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiShutdownUnsol Maintainer - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiShutdownUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownUnsol Maintainer validation failed")
            elif (objHmiShutdownUnsol.sMsgHeader.u2MsgLength.Value != (objHmiShutdownUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiShutdownUnsol Maintainer length field is invalid - it is %d and should be %d bytes", objHmiShutdownUnsol.sMsgHeader.u2MsgLength.Value, objHmiShutdownUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiShutdownUnsol/Maintainer", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "acRole": "Maintainer", "MsgObject": deepcopy(objHmiShutdownUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiShutdownUnsol/Maintainer")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackHmiAdcsShutdownCmdAPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiAdcsShutdownCmdAPM

        This is a public method callback for message HmiAdcsShutdownCmdAPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiAdcsShutdownCmd = sHMI_ADCS_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiAdcsShutdownCmdRsp = sHMI_ADCS_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd APM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd APM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd APM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiAdcsShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd APM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiAdcsShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiAdcsShutdownCmd APM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiAdcsShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmd APM validation failed")
            elif (objHmiAdcsShutdownCmd.sMsgHeader.u2MsgLength.Value != (objHmiAdcsShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmd APM length field is invalid - it is %d and should be %d bytes", objHmiAdcsShutdownCmd.sMsgHeader.u2MsgLength.Value, objHmiAdcsShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/APM", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "acRole": "APM", "MsgObject": deepcopy(objHmiAdcsShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiAdcsShutdownCmd/APM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdAPM is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiAdcsShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiAdcsShutdownCmdRsp/APM", objHmiAdcsShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiAdcsShutdownCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiAdcsShutdownCmdFCO(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiAdcsShutdownCmdFCO

        This is a public method callback for message HmiAdcsShutdownCmdFCO. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiAdcsShutdownCmd = sHMI_ADCS_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiAdcsShutdownCmdRsp = sHMI_ADCS_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd FCO objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd FCO objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd FCO objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiAdcsShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd FCO length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiAdcsShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiAdcsShutdownCmd FCO - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiAdcsShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmd FCO validation failed")
            elif (objHmiAdcsShutdownCmd.sMsgHeader.u2MsgLength.Value != (objHmiAdcsShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmd FCO length field is invalid - it is %d and should be %d bytes", objHmiAdcsShutdownCmd.sMsgHeader.u2MsgLength.Value, objHmiAdcsShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/FCO", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "acRole": "FCO", "MsgObject": deepcopy(objHmiAdcsShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiAdcsShutdownCmd/FCO")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdFCO is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiAdcsShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO", objHmiAdcsShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiAdcsShutdownCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiAdcsShutdownCmdAPM_FCO(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiAdcsShutdownCmdAPM_FCO

        This is a public method callback for message HmiAdcsShutdownCmdAPM_FCO. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiAdcsShutdownCmd = sHMI_ADCS_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiAdcsShutdownCmdRsp = sHMI_ADCS_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd APM_FCO objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd APM_FCO objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd APM_FCO objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiAdcsShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd APM_FCO length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiAdcsShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiAdcsShutdownCmd APM_FCO - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiAdcsShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmd APM_FCO validation failed")
            elif (objHmiAdcsShutdownCmd.sMsgHeader.u2MsgLength.Value != (objHmiAdcsShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmd APM_FCO length field is invalid - it is %d and should be %d bytes", objHmiAdcsShutdownCmd.sMsgHeader.u2MsgLength.Value, objHmiAdcsShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "acRole": "APM_FCO", "MsgObject": deepcopy(objHmiAdcsShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdAPM_FCO is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiAdcsShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO", objHmiAdcsShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiAdcsShutdownCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiAdcsShutdownCmdSPM(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiAdcsShutdownCmdSPM

        This is a public method callback for message HmiAdcsShutdownCmdSPM. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiAdcsShutdownCmd = sHMI_ADCS_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiAdcsShutdownCmdRsp = sHMI_ADCS_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd SPM objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd SPM objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd SPM objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiAdcsShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd SPM length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiAdcsShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiAdcsShutdownCmd SPM - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiAdcsShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmd SPM validation failed")
            elif (objHmiAdcsShutdownCmd.sMsgHeader.u2MsgLength.Value != (objHmiAdcsShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmd SPM length field is invalid - it is %d and should be %d bytes", objHmiAdcsShutdownCmd.sMsgHeader.u2MsgLength.Value, objHmiAdcsShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/SPM", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "acRole": "SPM", "MsgObject": deepcopy(objHmiAdcsShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiAdcsShutdownCmd/SPM")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdSPM is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiAdcsShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM", objHmiAdcsShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiAdcsShutdownCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiAdcsShutdownCmdFUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiAdcsShutdownCmdFUFC

        This is a public method callback for message HmiAdcsShutdownCmdFUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiAdcsShutdownCmd = sHMI_ADCS_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiAdcsShutdownCmdRsp = sHMI_ADCS_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiAdcsShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiAdcsShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiAdcsShutdownCmd FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiAdcsShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmd FUFC validation failed")
            elif (objHmiAdcsShutdownCmd.sMsgHeader.u2MsgLength.Value != (objHmiAdcsShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmd FUFC length field is invalid - it is %d and should be %d bytes", objHmiAdcsShutdownCmd.sMsgHeader.u2MsgLength.Value, objHmiAdcsShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/FUFC", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "acRole": "FUFC", "MsgObject": deepcopy(objHmiAdcsShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiAdcsShutdownCmd/FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdFUFC is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiAdcsShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC", objHmiAdcsShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiAdcsShutdownCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiAdcsShutdownCmdSPM_FUFC(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiAdcsShutdownCmdSPM_FUFC

        This is a public method callback for message HmiAdcsShutdownCmdSPM_FUFC. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiAdcsShutdownCmd = sHMI_ADCS_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiAdcsShutdownCmdRsp = sHMI_ADCS_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd SPM_FUFC objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd SPM_FUFC objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd SPM_FUFC objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiAdcsShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd SPM_FUFC length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiAdcsShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiAdcsShutdownCmd SPM_FUFC - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiAdcsShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmd SPM_FUFC validation failed")
            elif (objHmiAdcsShutdownCmd.sMsgHeader.u2MsgLength.Value != (objHmiAdcsShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmd SPM_FUFC length field is invalid - it is %d and should be %d bytes", objHmiAdcsShutdownCmd.sMsgHeader.u2MsgLength.Value, objHmiAdcsShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "acRole": "SPM_FUFC", "MsgObject": deepcopy(objHmiAdcsShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdSPM_FUFC is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiAdcsShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC", objHmiAdcsShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiAdcsShutdownCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiAdcsShutdownCmdOversight(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiAdcsShutdownCmdOversight

        This is a public method callback for message HmiAdcsShutdownCmdOversight. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiAdcsShutdownCmd = sHMI_ADCS_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiAdcsShutdownCmdRsp = sHMI_ADCS_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd Oversight objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd Oversight objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd Oversight objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiAdcsShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd Oversight length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiAdcsShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiAdcsShutdownCmd Oversight - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiAdcsShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmd Oversight validation failed")
            elif (objHmiAdcsShutdownCmd.sMsgHeader.u2MsgLength.Value != (objHmiAdcsShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmd Oversight length field is invalid - it is %d and should be %d bytes", objHmiAdcsShutdownCmd.sMsgHeader.u2MsgLength.Value, objHmiAdcsShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/Oversight", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "acRole": "Oversight", "MsgObject": deepcopy(objHmiAdcsShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiAdcsShutdownCmd/Oversight")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdOversight is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiAdcsShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight", objHmiAdcsShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiAdcsShutdownCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackHmiAdcsShutdownCmdMaintainer(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message HmiAdcsShutdownCmdMaintainer

        This is a public method callback for message HmiAdcsShutdownCmdMaintainer. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objHmiAdcsShutdownCmd = sHMI_ADCS_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objHmiAdcsShutdownCmdRsp = sHMI_ADCS_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd Maintainer objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd Maintainer objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd Maintainer objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objHmiAdcsShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for HmiAdcsShutdownCmd Maintainer length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objHmiAdcsShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for HmiAdcsShutdownCmd Maintainer - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objHmiAdcsShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmd Maintainer validation failed")
            elif (objHmiAdcsShutdownCmd.sMsgHeader.u2MsgLength.Value != (objHmiAdcsShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message HmiAdcsShutdownCmd Maintainer length field is invalid - it is %d and should be %d bytes", objHmiAdcsShutdownCmd.sMsgHeader.u2MsgLength.Value, objHmiAdcsShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/Maintainer", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "acRole": "Maintainer", "MsgObject": deepcopy(objHmiAdcsShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/HMI/HmiAdcsShutdownCmd/Maintainer")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionHmiAdcsShutdownCmdMaintainer is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objHmiAdcsShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer", objHmiAdcsShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("HmiAdcsShutdownCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackEiuStatusReportUnsol(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message EiuStatusReportUnsol

        This is a public method callback for message EiuStatusReportUnsol. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objEiuStatusReportUnsol = sEIU_STATUS_REPORT_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuStatusReportUnsol  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuStatusReportUnsol  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuStatusReportUnsol  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objEiuStatusReportUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuStatusReportUnsol  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objEiuStatusReportUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for EiuStatusReportUnsol  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objEiuStatusReportUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message EiuStatusReportUnsol  validation failed")
            elif (objEiuStatusReportUnsol.sMsgHeader.u2MsgLength.Value != (objEiuStatusReportUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message EiuStatusReportUnsol  length field is invalid - it is %d and should be %d bytes", objEiuStatusReportUnsol.sMsgHeader.u2MsgLength.Value, objEiuStatusReportUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/EIU/EiuStatusReportUnsol", "Class": sEIU_STATUS_REPORT_UNSOL, "ClassName": "sEIU_STATUS_REPORT_UNSOL", "acRole": "", "MsgObject": deepcopy(objEiuStatusReportUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/EIU/EiuStatusReportUnsol")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackEiuEndOfSetupCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message EiuEndOfSetupCmdRsp

        This is a public method callback for message EiuEndOfSetupCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objEiuEndOfSetupCmdRsp = sEIU_END_OF_SETUP_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuEndOfSetupCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuEndOfSetupCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuEndOfSetupCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objEiuEndOfSetupCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuEndOfSetupCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objEiuEndOfSetupCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for EiuEndOfSetupCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objEiuEndOfSetupCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message EiuEndOfSetupCmdRsp  validation failed")
            elif (objEiuEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value != (objEiuEndOfSetupCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message EiuEndOfSetupCmdRsp  length field is invalid - it is %d and should be %d bytes", objEiuEndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value, objEiuEndOfSetupCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/EIU/EiuEndOfSetupCmdRsp", "Class": sEIU_END_OF_SETUP_CMD_RSP, "ClassName": "sEIU_END_OF_SETUP_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objEiuEndOfSetupCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/EIU/EiuEndOfSetupCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackEiuEndOfReadyCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message EiuEndOfReadyCmdRsp

        This is a public method callback for message EiuEndOfReadyCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objEiuEndOfReadyCmdRsp = sEIU_END_OF_READY_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuEndOfReadyCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuEndOfReadyCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuEndOfReadyCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objEiuEndOfReadyCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuEndOfReadyCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objEiuEndOfReadyCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for EiuEndOfReadyCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objEiuEndOfReadyCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message EiuEndOfReadyCmdRsp  validation failed")
            elif (objEiuEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value != (objEiuEndOfReadyCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message EiuEndOfReadyCmdRsp  length field is invalid - it is %d and should be %d bytes", objEiuEndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value, objEiuEndOfReadyCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/EIU/EiuEndOfReadyCmdRsp", "Class": sEIU_END_OF_READY_CMD_RSP, "ClassName": "sEIU_END_OF_READY_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objEiuEndOfReadyCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/EIU/EiuEndOfReadyCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackEiuShutdownCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message EiuShutdownCmdRsp

        This is a public method callback for message EiuShutdownCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objEiuShutdownCmdRsp = sEIU_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuShutdownCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuShutdownCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuShutdownCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objEiuShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for EiuShutdownCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objEiuShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for EiuShutdownCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objEiuShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message EiuShutdownCmdRsp  validation failed")
            elif (objEiuShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objEiuShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message EiuShutdownCmdRsp  length field is invalid - it is %d and should be %d bytes", objEiuShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objEiuShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/EIU/EiuShutdownCmdRsp", "Class": sEIU_SHUTDOWN_CMD_RSP, "ClassName": "sEIU_SHUTDOWN_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objEiuShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/EIU/EiuShutdownCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackSf1StatusReportUnsol(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message Sf1StatusReportUnsol

        This is a public method callback for message Sf1StatusReportUnsol. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objSf1StatusReportUnsol = sSF1_STATUS_REPORT_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1StatusReportUnsol  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1StatusReportUnsol  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1StatusReportUnsol  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objSf1StatusReportUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1StatusReportUnsol  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objSf1StatusReportUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for Sf1StatusReportUnsol  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objSf1StatusReportUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf1StatusReportUnsol  validation failed")
            elif (objSf1StatusReportUnsol.sMsgHeader.u2MsgLength.Value != (objSf1StatusReportUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf1StatusReportUnsol  length field is invalid - it is %d and should be %d bytes", objSf1StatusReportUnsol.sMsgHeader.u2MsgLength.Value, objSf1StatusReportUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/SF1/Sf1StatusReportUnsol", "Class": sSF1_STATUS_REPORT_UNSOL, "ClassName": "sSF1_STATUS_REPORT_UNSOL", "acRole": "", "MsgObject": deepcopy(objSf1StatusReportUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/SF1/Sf1StatusReportUnsol")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackSf1EndOfSetupCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message Sf1EndOfSetupCmdRsp

        This is a public method callback for message Sf1EndOfSetupCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objSf1EndOfSetupCmdRsp = sSF1_END_OF_SETUP_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1EndOfSetupCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1EndOfSetupCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1EndOfSetupCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objSf1EndOfSetupCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1EndOfSetupCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objSf1EndOfSetupCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for Sf1EndOfSetupCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objSf1EndOfSetupCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf1EndOfSetupCmdRsp  validation failed")
            elif (objSf1EndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value != (objSf1EndOfSetupCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf1EndOfSetupCmdRsp  length field is invalid - it is %d and should be %d bytes", objSf1EndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value, objSf1EndOfSetupCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/SF1/Sf1EndOfSetupCmdRsp", "Class": sSF1_END_OF_SETUP_CMD_RSP, "ClassName": "sSF1_END_OF_SETUP_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objSf1EndOfSetupCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/SF1/Sf1EndOfSetupCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackSf1EndOfReadyCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message Sf1EndOfReadyCmdRsp

        This is a public method callback for message Sf1EndOfReadyCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objSf1EndOfReadyCmdRsp = sSF1_END_OF_READY_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1EndOfReadyCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1EndOfReadyCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1EndOfReadyCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objSf1EndOfReadyCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1EndOfReadyCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objSf1EndOfReadyCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for Sf1EndOfReadyCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objSf1EndOfReadyCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf1EndOfReadyCmdRsp  validation failed")
            elif (objSf1EndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value != (objSf1EndOfReadyCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf1EndOfReadyCmdRsp  length field is invalid - it is %d and should be %d bytes", objSf1EndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value, objSf1EndOfReadyCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/SF1/Sf1EndOfReadyCmdRsp", "Class": sSF1_END_OF_READY_CMD_RSP, "ClassName": "sSF1_END_OF_READY_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objSf1EndOfReadyCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/SF1/Sf1EndOfReadyCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackSf1ShutdownCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message Sf1ShutdownCmdRsp

        This is a public method callback for message Sf1ShutdownCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objSf1ShutdownCmdRsp = sSF1_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1ShutdownCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1ShutdownCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1ShutdownCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objSf1ShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1ShutdownCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objSf1ShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for Sf1ShutdownCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objSf1ShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf1ShutdownCmdRsp  validation failed")
            elif (objSf1ShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objSf1ShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf1ShutdownCmdRsp  length field is invalid - it is %d and should be %d bytes", objSf1ShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objSf1ShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/SF1/Sf1ShutdownCmdRsp", "Class": sSF1_SHUTDOWN_CMD_RSP, "ClassName": "sSF1_SHUTDOWN_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objSf1ShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/SF1/Sf1ShutdownCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackSf1ModeCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message Sf1ModeCmd

        This is a public method callback for message Sf1ModeCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objSf1ModeCmd = sSF1_MODE_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objSf1ModeCmdRsp = sSF1_MODE_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1ModeCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1ModeCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1ModeCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objSf1ModeCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1ModeCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objSf1ModeCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for Sf1ModeCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objSf1ModeCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf1ModeCmd  validation failed")
            elif (objSf1ModeCmd.sMsgHeader.u2MsgLength.Value != (objSf1ModeCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf1ModeCmd  length field is invalid - it is %d and should be %d bytes", objSf1ModeCmd.sMsgHeader.u2MsgLength.Value, objSf1ModeCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/SF1/Sf1ModeCmd", "Class": sSF1_MODE_CMD, "ClassName": "sSF1_MODE_CMD", "acRole": "", "MsgObject": deepcopy(objSf1ModeCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/SF1/Sf1ModeCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionSf1ModeCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objSf1ModeCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/SF1/Sf1ModeCmdRsp", objSf1ModeCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("Sf1ModeCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackSf2StatusReportUnsol(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message Sf2StatusReportUnsol

        This is a public method callback for message Sf2StatusReportUnsol. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objSf2StatusReportUnsol = sSF2_STATUS_REPORT_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf2StatusReportUnsol  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf2StatusReportUnsol  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf2StatusReportUnsol  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objSf2StatusReportUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf2StatusReportUnsol  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objSf2StatusReportUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for Sf2StatusReportUnsol  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objSf2StatusReportUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf2StatusReportUnsol  validation failed")
            elif (objSf2StatusReportUnsol.sMsgHeader.u2MsgLength.Value != (objSf2StatusReportUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf2StatusReportUnsol  length field is invalid - it is %d and should be %d bytes", objSf2StatusReportUnsol.sMsgHeader.u2MsgLength.Value, objSf2StatusReportUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/SF2/Sf2StatusReportUnsol", "Class": sSF2_STATUS_REPORT_UNSOL, "ClassName": "sSF2_STATUS_REPORT_UNSOL", "acRole": "", "MsgObject": deepcopy(objSf2StatusReportUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/SF2/Sf2StatusReportUnsol")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackSf2EndOfSetupCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message Sf2EndOfSetupCmdRsp

        This is a public method callback for message Sf2EndOfSetupCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objSf2EndOfSetupCmdRsp = sSF2_END_OF_SETUP_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf2EndOfSetupCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf2EndOfSetupCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf2EndOfSetupCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objSf2EndOfSetupCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf2EndOfSetupCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objSf2EndOfSetupCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for Sf2EndOfSetupCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objSf2EndOfSetupCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf2EndOfSetupCmdRsp  validation failed")
            elif (objSf2EndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value != (objSf2EndOfSetupCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf2EndOfSetupCmdRsp  length field is invalid - it is %d and should be %d bytes", objSf2EndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value, objSf2EndOfSetupCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/SF2/Sf2EndOfSetupCmdRsp", "Class": sSF2_END_OF_SETUP_CMD_RSP, "ClassName": "sSF2_END_OF_SETUP_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objSf2EndOfSetupCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/SF2/Sf2EndOfSetupCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackSf2EndOfReadyCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message Sf2EndOfReadyCmdRsp

        This is a public method callback for message Sf2EndOfReadyCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objSf2EndOfReadyCmdRsp = sSF2_END_OF_READY_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf2EndOfReadyCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf2EndOfReadyCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf2EndOfReadyCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objSf2EndOfReadyCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf2EndOfReadyCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objSf2EndOfReadyCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for Sf2EndOfReadyCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objSf2EndOfReadyCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf2EndOfReadyCmdRsp  validation failed")
            elif (objSf2EndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value != (objSf2EndOfReadyCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf2EndOfReadyCmdRsp  length field is invalid - it is %d and should be %d bytes", objSf2EndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value, objSf2EndOfReadyCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/SF2/Sf2EndOfReadyCmdRsp", "Class": sSF2_END_OF_READY_CMD_RSP, "ClassName": "sSF2_END_OF_READY_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objSf2EndOfReadyCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/SF2/Sf2EndOfReadyCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackSf2ShutdownCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message Sf2ShutdownCmdRsp

        This is a public method callback for message Sf2ShutdownCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objSf2ShutdownCmdRsp = sSF2_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf2ShutdownCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf2ShutdownCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf2ShutdownCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objSf2ShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf2ShutdownCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objSf2ShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for Sf2ShutdownCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objSf2ShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf2ShutdownCmdRsp  validation failed")
            elif (objSf2ShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objSf2ShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf2ShutdownCmdRsp  length field is invalid - it is %d and should be %d bytes", objSf2ShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objSf2ShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/SF2/Sf2ShutdownCmdRsp", "Class": sSF2_SHUTDOWN_CMD_RSP, "ClassName": "sSF2_SHUTDOWN_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objSf2ShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/SF2/Sf2ShutdownCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackSf3StatusReportUnsol(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message Sf3StatusReportUnsol

        This is a public method callback for message Sf3StatusReportUnsol. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objSf3StatusReportUnsol = sSF3_STATUS_REPORT_UNSOL()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf3StatusReportUnsol  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf3StatusReportUnsol  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf3StatusReportUnsol  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objSf3StatusReportUnsol.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf3StatusReportUnsol  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objSf3StatusReportUnsol.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for Sf3StatusReportUnsol  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objSf3StatusReportUnsol.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf3StatusReportUnsol  validation failed")
            elif (objSf3StatusReportUnsol.sMsgHeader.u2MsgLength.Value != (objSf3StatusReportUnsol.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf3StatusReportUnsol  length field is invalid - it is %d and should be %d bytes", objSf3StatusReportUnsol.sMsgHeader.u2MsgLength.Value, objSf3StatusReportUnsol.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/SF3/Sf3StatusReportUnsol", "Class": sSF3_STATUS_REPORT_UNSOL, "ClassName": "sSF3_STATUS_REPORT_UNSOL", "acRole": "", "MsgObject": deepcopy(objSf3StatusReportUnsol)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/SF3/Sf3StatusReportUnsol")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackSf3EndOfSetupCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message Sf3EndOfSetupCmdRsp

        This is a public method callback for message Sf3EndOfSetupCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objSf3EndOfSetupCmdRsp = sSF3_END_OF_SETUP_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf3EndOfSetupCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf3EndOfSetupCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf3EndOfSetupCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objSf3EndOfSetupCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf3EndOfSetupCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objSf3EndOfSetupCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for Sf3EndOfSetupCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objSf3EndOfSetupCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf3EndOfSetupCmdRsp  validation failed")
            elif (objSf3EndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value != (objSf3EndOfSetupCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf3EndOfSetupCmdRsp  length field is invalid - it is %d and should be %d bytes", objSf3EndOfSetupCmdRsp.sMsgHeader.u2MsgLength.Value, objSf3EndOfSetupCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/SF3/Sf3EndOfSetupCmdRsp", "Class": sSF3_END_OF_SETUP_CMD_RSP, "ClassName": "sSF3_END_OF_SETUP_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objSf3EndOfSetupCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/SF3/Sf3EndOfSetupCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackSf3EndOfReadyCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message Sf3EndOfReadyCmdRsp

        This is a public method callback for message Sf3EndOfReadyCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objSf3EndOfReadyCmdRsp = sSF3_END_OF_READY_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf3EndOfReadyCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf3EndOfReadyCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf3EndOfReadyCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objSf3EndOfReadyCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf3EndOfReadyCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objSf3EndOfReadyCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for Sf3EndOfReadyCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objSf3EndOfReadyCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf3EndOfReadyCmdRsp  validation failed")
            elif (objSf3EndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value != (objSf3EndOfReadyCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf3EndOfReadyCmdRsp  length field is invalid - it is %d and should be %d bytes", objSf3EndOfReadyCmdRsp.sMsgHeader.u2MsgLength.Value, objSf3EndOfReadyCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/SF3/Sf3EndOfReadyCmdRsp", "Class": sSF3_END_OF_READY_CMD_RSP, "ClassName": "sSF3_END_OF_READY_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objSf3EndOfReadyCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/SF3/Sf3EndOfReadyCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackSf3ShutdownCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message Sf3ShutdownCmdRsp

        This is a public method callback for message Sf3ShutdownCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objSf3ShutdownCmdRsp = sSF3_SHUTDOWN_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf3ShutdownCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf3ShutdownCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf3ShutdownCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objSf3ShutdownCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf3ShutdownCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objSf3ShutdownCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for Sf3ShutdownCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objSf3ShutdownCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf3ShutdownCmdRsp  validation failed")
            elif (objSf3ShutdownCmdRsp.sMsgHeader.u2MsgLength.Value != (objSf3ShutdownCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf3ShutdownCmdRsp  length field is invalid - it is %d and should be %d bytes", objSf3ShutdownCmdRsp.sMsgHeader.u2MsgLength.Value, objSf3ShutdownCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/SF3/Sf3ShutdownCmdRsp", "Class": sSF3_SHUTDOWN_CMD_RSP, "ClassName": "sSF3_SHUTDOWN_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objSf3ShutdownCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/SF3/Sf3ShutdownCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return

    def vOnMessageCallbackMmsShutdownCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message MmsShutdownCmd

        This is a public method callback for message MmsShutdownCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objMmsShutdownCmd = sMMS_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objMmsShutdownCmdRsp = sMMS_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for MmsShutdownCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for MmsShutdownCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for MmsShutdownCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objMmsShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for MmsShutdownCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objMmsShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for MmsShutdownCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objMmsShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message MmsShutdownCmd  validation failed")
            elif (objMmsShutdownCmd.sMsgHeader.u2MsgLength.Value != (objMmsShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message MmsShutdownCmd  length field is invalid - it is %d and should be %d bytes", objMmsShutdownCmd.sMsgHeader.u2MsgLength.Value, objMmsShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/MMS/MmsShutdownCmd", "Class": sMMS_SHUTDOWN_CMD, "ClassName": "sMMS_SHUTDOWN_CMD", "acRole": "", "MsgObject": deepcopy(objMmsShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/MMS/MmsShutdownCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionMmsShutdownCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objMmsShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/MMS/MmsShutdownCmdRsp", objMmsShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("MmsShutdownCmd's publish threw exception - %s", str(E))

        return
# ==========================================================
# MQTT CALLBACK METHODS STOP
# ==========================================================
# ==========================================================
# MQTT SUBSCRIPTION METHODS START
# ==========================================================

    def vSubscribeMessageOlhmEndOfReadyCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message OlhmEndOfReadyCmd.

        This is the auto generated method for subscribing message OlhmEndOfReadyCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for OlhmEndOfReadyCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/OLHM/OlhmEndOfReadyCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message OlhmEndOfReadyCmd  - Exception %s", str(E))

        return

    def vSubscribeMessageOlhmAdcsShutdownCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message OlhmAdcsShutdownCmd.

        This is the auto generated method for subscribing message OlhmAdcsShutdownCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for OlhmAdcsShutdownCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/OLHM/OlhmAdcsShutdownCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message OlhmAdcsShutdownCmd  - Exception %s", str(E))

        return

    def vSubscribeMessageTewaStatusReportUnsol(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message TewaStatusReportUnsol.

        This is the auto generated method for subscribing message TewaStatusReportUnsol.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for TewaStatusReportUnsol  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/TEWA/TewaStatusReportUnsol", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TewaStatusReportUnsol  - Exception %s", str(E))

        return

    def vSubscribeMessageTewaEndOfSetupCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message TewaEndOfSetupCmdRsp.

        This is the auto generated method for subscribing message TewaEndOfSetupCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for TewaEndOfSetupCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/TEWA/TewaEndOfSetupCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TewaEndOfSetupCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageTewaEndOfReadyCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message TewaEndOfReadyCmdRsp.

        This is the auto generated method for subscribing message TewaEndOfReadyCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for TewaEndOfReadyCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/TEWA/TewaEndOfReadyCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TewaEndOfReadyCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageTewaShutdownCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message TewaShutdownCmdRsp.

        This is the auto generated method for subscribing message TewaShutdownCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for TewaShutdownCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/TEWA/TewaShutdownCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TewaShutdownCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageTmStatusReportUnsol(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message TmStatusReportUnsol.

        This is the auto generated method for subscribing message TmStatusReportUnsol.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for TmStatusReportUnsol  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/TM/TmStatusReportUnsol", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TmStatusReportUnsol  - Exception %s", str(E))

        return

    def vSubscribeMessageTmEndOfSetupCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message TmEndOfSetupCmdRsp.

        This is the auto generated method for subscribing message TmEndOfSetupCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for TmEndOfSetupCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/TM/TmEndOfSetupCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TmEndOfSetupCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageTmEndOfReadyCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message TmEndOfReadyCmdRsp.

        This is the auto generated method for subscribing message TmEndOfReadyCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for TmEndOfReadyCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/TM/TmEndOfReadyCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TmEndOfReadyCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageTmShutdownCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message TmShutdownCmdRsp.

        This is the auto generated method for subscribing message TmShutdownCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for TmShutdownCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/TM/TmShutdownCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TmShutdownCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessagePdbpStatusReportUnsol(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message PdbpStatusReportUnsol.

        This is the auto generated method for subscribing message PdbpStatusReportUnsol.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for PdbpStatusReportUnsol  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpStatusReportUnsol", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpStatusReportUnsol  - Exception %s", str(E))

        return

    def vSubscribeMessagePdbpEndOfReadyCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message PdbpEndOfReadyCmdRsp.

        This is the auto generated method for subscribing message PdbpEndOfReadyCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for PdbpEndOfReadyCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpEndOfReadyCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpEndOfReadyCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessagePdbpShutdownCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message PdbpShutdownCmdRsp.

        This is the auto generated method for subscribing message PdbpShutdownCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for PdbpShutdownCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpShutdownCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpShutdownCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessagePdbpSendOutModuleDbMessagesCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message PdbpSendOutModuleDbMessagesCmdRsp.

        This is the auto generated method for subscribing message PdbpSendOutModuleDbMessagesCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for PdbpSendOutModuleDbMessagesCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message PdbpSendOutModuleDbMessagesCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageDrStatusReportUnsol(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message DrStatusReportUnsol.

        This is the auto generated method for subscribing message DrStatusReportUnsol.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for DrStatusReportUnsol  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/DR/DrStatusReportUnsol", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message DrStatusReportUnsol  - Exception %s", str(E))

        return

    def vSubscribeMessageDrEndOfSetupCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message DrEndOfSetupCmdRsp.

        This is the auto generated method for subscribing message DrEndOfSetupCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for DrEndOfSetupCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/DR/DrEndOfSetupCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message DrEndOfSetupCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageDrEndOfReadyCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message DrEndOfReadyCmdRsp.

        This is the auto generated method for subscribing message DrEndOfReadyCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for DrEndOfReadyCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/DR/DrEndOfReadyCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message DrEndOfReadyCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageDrShutdownCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message DrShutdownCmdRsp.

        This is the auto generated method for subscribing message DrShutdownCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for DrShutdownCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/DR/DrShutdownCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message DrShutdownCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageHmiStatusReportUnsolAPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiStatusReportUnsolAPM.

        This is the auto generated method for subscribing message HmiStatusReportUnsolAPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiStatusReportUnsol APM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiStatusReportUnsol/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiStatusReportUnsol APM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiStatusReportUnsolFCO(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiStatusReportUnsolFCO.

        This is the auto generated method for subscribing message HmiStatusReportUnsolFCO.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiStatusReportUnsol FCO objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiStatusReportUnsol/FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiStatusReportUnsol FCO - Exception %s", str(E))

        return

    def vSubscribeMessageHmiStatusReportUnsolAPM_FCO(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiStatusReportUnsolAPM_FCO.

        This is the auto generated method for subscribing message HmiStatusReportUnsolAPM_FCO.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiStatusReportUnsol APM_FCO objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiStatusReportUnsol/APM_FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiStatusReportUnsol APM_FCO - Exception %s", str(E))

        return

    def vSubscribeMessageHmiStatusReportUnsolSPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiStatusReportUnsolSPM.

        This is the auto generated method for subscribing message HmiStatusReportUnsolSPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiStatusReportUnsol SPM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiStatusReportUnsol/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiStatusReportUnsol SPM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiStatusReportUnsolFUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiStatusReportUnsolFUFC.

        This is the auto generated method for subscribing message HmiStatusReportUnsolFUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiStatusReportUnsol FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiStatusReportUnsol/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiStatusReportUnsol FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiStatusReportUnsolSPM_FUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiStatusReportUnsolSPM_FUFC.

        This is the auto generated method for subscribing message HmiStatusReportUnsolSPM_FUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiStatusReportUnsol SPM_FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiStatusReportUnsol SPM_FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiStatusReportUnsolOversight(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiStatusReportUnsolOversight.

        This is the auto generated method for subscribing message HmiStatusReportUnsolOversight.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiStatusReportUnsol Oversight objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiStatusReportUnsol/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiStatusReportUnsol Oversight - Exception %s", str(E))

        return

    def vSubscribeMessageHmiStatusReportUnsolMaintainer(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiStatusReportUnsolMaintainer.

        This is the auto generated method for subscribing message HmiStatusReportUnsolMaintainer.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiStatusReportUnsol Maintainer objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiStatusReportUnsol/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiStatusReportUnsol Maintainer - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfSetupCmdRspAPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfSetupCmdRspAPM.

        This is the auto generated method for subscribing message HmiEndOfSetupCmdRspAPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfSetupCmdRsp APM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmdRsp/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmdRsp APM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfSetupCmdRspFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfSetupCmdRspFC.

        This is the auto generated method for subscribing message HmiEndOfSetupCmdRspFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfSetupCmdRsp FC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmdRsp/FC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmdRsp FC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfSetupCmdRspAPM_FC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfSetupCmdRspAPM_FC.

        This is the auto generated method for subscribing message HmiEndOfSetupCmdRspAPM_FC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfSetupCmdRsp APM_FC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmdRsp APM_FC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfSetupCmdRspSPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfSetupCmdRspSPM.

        This is the auto generated method for subscribing message HmiEndOfSetupCmdRspSPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfSetupCmdRsp SPM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmdRsp SPM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfSetupCmdRspFUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfSetupCmdRspFUFC.

        This is the auto generated method for subscribing message HmiEndOfSetupCmdRspFUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfSetupCmdRsp FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmdRsp FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfSetupCmdRspSPM_FUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfSetupCmdRspSPM_FUFC.

        This is the auto generated method for subscribing message HmiEndOfSetupCmdRspSPM_FUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfSetupCmdRsp SPM_FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmdRsp SPM_FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfSetupCmdRspOversight(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfSetupCmdRspOversight.

        This is the auto generated method for subscribing message HmiEndOfSetupCmdRspOversight.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfSetupCmdRsp Oversight objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmdRsp Oversight - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfSetupCmdRspMaintainer(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfSetupCmdRspMaintainer.

        This is the auto generated method for subscribing message HmiEndOfSetupCmdRspMaintainer.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfSetupCmdRsp Maintainer objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfSetupCmdRsp Maintainer - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfReadyCmdRspAPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfReadyCmdRspAPM.

        This is the auto generated method for subscribing message HmiEndOfReadyCmdRspAPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfReadyCmdRsp APM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmdRsp/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmdRsp APM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfReadyCmdRspFCO(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfReadyCmdRspFCO.

        This is the auto generated method for subscribing message HmiEndOfReadyCmdRspFCO.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfReadyCmdRsp FCO objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmdRsp/FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmdRsp FCO - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfReadyCmdRspAPM_FCO(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfReadyCmdRspAPM_FCO.

        This is the auto generated method for subscribing message HmiEndOfReadyCmdRspAPM_FCO.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfReadyCmdRsp APM_FCO objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmdRsp APM_FCO - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfReadyCmdRspSPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfReadyCmdRspSPM.

        This is the auto generated method for subscribing message HmiEndOfReadyCmdRspSPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfReadyCmdRsp SPM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmdRsp SPM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfReadyCmdRspFUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfReadyCmdRspFUFC.

        This is the auto generated method for subscribing message HmiEndOfReadyCmdRspFUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfReadyCmdRsp FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmdRsp FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfReadyCmdRspSPM_FUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfReadyCmdRspSPM_FUFC.

        This is the auto generated method for subscribing message HmiEndOfReadyCmdRspSPM_FUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfReadyCmdRsp SPM_FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmdRsp SPM_FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfReadyCmdRspOversight(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfReadyCmdRspOversight.

        This is the auto generated method for subscribing message HmiEndOfReadyCmdRspOversight.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfReadyCmdRsp Oversight objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmdRsp Oversight - Exception %s", str(E))

        return

    def vSubscribeMessageHmiEndOfReadyCmdRspMaintainer(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiEndOfReadyCmdRspMaintainer.

        This is the auto generated method for subscribing message HmiEndOfReadyCmdRspMaintainer.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiEndOfReadyCmdRsp Maintainer objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiEndOfReadyCmdRsp Maintainer - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownCmdRspAPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownCmdRspAPM.

        This is the auto generated method for subscribing message HmiShutdownCmdRspAPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownCmdRsp APM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmdRsp/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmdRsp APM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownCmdRspFCO(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownCmdRspFCO.

        This is the auto generated method for subscribing message HmiShutdownCmdRspFCO.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownCmdRsp FCO objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmdRsp/FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmdRsp FCO - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownCmdRspAPM_FCO(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownCmdRspAPM_FCO.

        This is the auto generated method for subscribing message HmiShutdownCmdRspAPM_FCO.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownCmdRsp APM_FCO objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmdRsp/APM_FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmdRsp APM_FCO - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownCmdRspSPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownCmdRspSPM.

        This is the auto generated method for subscribing message HmiShutdownCmdRspSPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownCmdRsp SPM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmdRsp/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmdRsp SPM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownCmdRspFUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownCmdRspFUFC.

        This is the auto generated method for subscribing message HmiShutdownCmdRspFUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownCmdRsp FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmdRsp/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmdRsp FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownCmdRspSPM_FUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownCmdRspSPM_FUFC.

        This is the auto generated method for subscribing message HmiShutdownCmdRspSPM_FUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownCmdRsp SPM_FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmdRsp SPM_FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownCmdRspOversight(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownCmdRspOversight.

        This is the auto generated method for subscribing message HmiShutdownCmdRspOversight.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownCmdRsp Oversight objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmdRsp/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmdRsp Oversight - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownCmdRspMaintainer(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownCmdRspMaintainer.

        This is the auto generated method for subscribing message HmiShutdownCmdRspMaintainer.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownCmdRsp Maintainer objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownCmdRsp/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownCmdRsp Maintainer - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownUnsolAPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownUnsolAPM.

        This is the auto generated method for subscribing message HmiShutdownUnsolAPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownUnsol APM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownUnsol/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownUnsol APM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownUnsolFCO(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownUnsolFCO.

        This is the auto generated method for subscribing message HmiShutdownUnsolFCO.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownUnsol FCO objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownUnsol/FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownUnsol FCO - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownUnsolAPM_FCO(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownUnsolAPM_FCO.

        This is the auto generated method for subscribing message HmiShutdownUnsolAPM_FCO.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownUnsol APM_FCO objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownUnsol/APM_FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownUnsol APM_FCO - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownUnsolSPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownUnsolSPM.

        This is the auto generated method for subscribing message HmiShutdownUnsolSPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownUnsol SPM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownUnsol/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownUnsol SPM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownUnsolFUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownUnsolFUFC.

        This is the auto generated method for subscribing message HmiShutdownUnsolFUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownUnsol FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownUnsol/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownUnsol FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownUnsolSPM_FUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownUnsolSPM_FUFC.

        This is the auto generated method for subscribing message HmiShutdownUnsolSPM_FUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownUnsol SPM_FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownUnsol/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownUnsol SPM_FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownUnsolOversight(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownUnsolOversight.

        This is the auto generated method for subscribing message HmiShutdownUnsolOversight.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownUnsol Oversight objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownUnsol/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownUnsol Oversight - Exception %s", str(E))

        return

    def vSubscribeMessageHmiShutdownUnsolMaintainer(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiShutdownUnsolMaintainer.

        This is the auto generated method for subscribing message HmiShutdownUnsolMaintainer.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiShutdownUnsol Maintainer objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiShutdownUnsol/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiShutdownUnsol Maintainer - Exception %s", str(E))

        return

    def vSubscribeMessageHmiAdcsShutdownCmdAPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiAdcsShutdownCmdAPM.

        This is the auto generated method for subscribing message HmiAdcsShutdownCmdAPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiAdcsShutdownCmd APM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmd/APM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmd APM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiAdcsShutdownCmdFCO(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiAdcsShutdownCmdFCO.

        This is the auto generated method for subscribing message HmiAdcsShutdownCmdFCO.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiAdcsShutdownCmd FCO objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmd/FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmd FCO - Exception %s", str(E))

        return

    def vSubscribeMessageHmiAdcsShutdownCmdAPM_FCO(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiAdcsShutdownCmdAPM_FCO.

        This is the auto generated method for subscribing message HmiAdcsShutdownCmdAPM_FCO.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiAdcsShutdownCmd APM_FCO objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmd APM_FCO - Exception %s", str(E))

        return

    def vSubscribeMessageHmiAdcsShutdownCmdSPM(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiAdcsShutdownCmdSPM.

        This is the auto generated method for subscribing message HmiAdcsShutdownCmdSPM.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiAdcsShutdownCmd SPM objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmd/SPM", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmd SPM - Exception %s", str(E))

        return

    def vSubscribeMessageHmiAdcsShutdownCmdFUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiAdcsShutdownCmdFUFC.

        This is the auto generated method for subscribing message HmiAdcsShutdownCmdFUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiAdcsShutdownCmd FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmd/FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmd FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiAdcsShutdownCmdSPM_FUFC(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiAdcsShutdownCmdSPM_FUFC.

        This is the auto generated method for subscribing message HmiAdcsShutdownCmdSPM_FUFC.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiAdcsShutdownCmd SPM_FUFC objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmd SPM_FUFC - Exception %s", str(E))

        return

    def vSubscribeMessageHmiAdcsShutdownCmdOversight(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiAdcsShutdownCmdOversight.

        This is the auto generated method for subscribing message HmiAdcsShutdownCmdOversight.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiAdcsShutdownCmd Oversight objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmd/Oversight", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmd Oversight - Exception %s", str(E))

        return

    def vSubscribeMessageHmiAdcsShutdownCmdMaintainer(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message HmiAdcsShutdownCmdMaintainer.

        This is the auto generated method for subscribing message HmiAdcsShutdownCmdMaintainer.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for HmiAdcsShutdownCmd Maintainer objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/HMI/HmiAdcsShutdownCmd/Maintainer", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message HmiAdcsShutdownCmd Maintainer - Exception %s", str(E))

        return

    def vSubscribeMessageEiuStatusReportUnsol(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message EiuStatusReportUnsol.

        This is the auto generated method for subscribing message EiuStatusReportUnsol.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for EiuStatusReportUnsol  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/EIU/EiuStatusReportUnsol", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message EiuStatusReportUnsol  - Exception %s", str(E))

        return

    def vSubscribeMessageEiuEndOfSetupCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message EiuEndOfSetupCmdRsp.

        This is the auto generated method for subscribing message EiuEndOfSetupCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for EiuEndOfSetupCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/EIU/EiuEndOfSetupCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message EiuEndOfSetupCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageEiuEndOfReadyCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message EiuEndOfReadyCmdRsp.

        This is the auto generated method for subscribing message EiuEndOfReadyCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for EiuEndOfReadyCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/EIU/EiuEndOfReadyCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message EiuEndOfReadyCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageEiuShutdownCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message EiuShutdownCmdRsp.

        This is the auto generated method for subscribing message EiuShutdownCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for EiuShutdownCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/EIU/EiuShutdownCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message EiuShutdownCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageSf1StatusReportUnsol(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message Sf1StatusReportUnsol.

        This is the auto generated method for subscribing message Sf1StatusReportUnsol.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for Sf1StatusReportUnsol  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/SF1/Sf1StatusReportUnsol", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf1StatusReportUnsol  - Exception %s", str(E))

        return

    def vSubscribeMessageSf1EndOfSetupCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message Sf1EndOfSetupCmdRsp.

        This is the auto generated method for subscribing message Sf1EndOfSetupCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for Sf1EndOfSetupCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/SF1/Sf1EndOfSetupCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf1EndOfSetupCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageSf1EndOfReadyCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message Sf1EndOfReadyCmdRsp.

        This is the auto generated method for subscribing message Sf1EndOfReadyCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for Sf1EndOfReadyCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/SF1/Sf1EndOfReadyCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf1EndOfReadyCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageSf1ShutdownCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message Sf1ShutdownCmdRsp.

        This is the auto generated method for subscribing message Sf1ShutdownCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for Sf1ShutdownCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/SF1/Sf1ShutdownCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf1ShutdownCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageSf1ModeCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message Sf1ModeCmd.

        This is the auto generated method for subscribing message Sf1ModeCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for Sf1ModeCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/SF1/Sf1ModeCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf1ModeCmd  - Exception %s", str(E))

        return

    def vSubscribeMessageSf2StatusReportUnsol(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message Sf2StatusReportUnsol.

        This is the auto generated method for subscribing message Sf2StatusReportUnsol.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for Sf2StatusReportUnsol  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/SF2/Sf2StatusReportUnsol", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf2StatusReportUnsol  - Exception %s", str(E))

        return

    def vSubscribeMessageSf2EndOfSetupCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message Sf2EndOfSetupCmdRsp.

        This is the auto generated method for subscribing message Sf2EndOfSetupCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for Sf2EndOfSetupCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/SF2/Sf2EndOfSetupCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf2EndOfSetupCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageSf2EndOfReadyCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message Sf2EndOfReadyCmdRsp.

        This is the auto generated method for subscribing message Sf2EndOfReadyCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for Sf2EndOfReadyCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/SF2/Sf2EndOfReadyCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf2EndOfReadyCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageSf2ShutdownCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message Sf2ShutdownCmdRsp.

        This is the auto generated method for subscribing message Sf2ShutdownCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for Sf2ShutdownCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/SF2/Sf2ShutdownCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf2ShutdownCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageSf3StatusReportUnsol(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message Sf3StatusReportUnsol.

        This is the auto generated method for subscribing message Sf3StatusReportUnsol.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for Sf3StatusReportUnsol  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/SF3/Sf3StatusReportUnsol", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf3StatusReportUnsol  - Exception %s", str(E))

        return

    def vSubscribeMessageSf3EndOfSetupCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message Sf3EndOfSetupCmdRsp.

        This is the auto generated method for subscribing message Sf3EndOfSetupCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for Sf3EndOfSetupCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/SF3/Sf3EndOfSetupCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf3EndOfSetupCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageSf3EndOfReadyCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message Sf3EndOfReadyCmdRsp.

        This is the auto generated method for subscribing message Sf3EndOfReadyCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for Sf3EndOfReadyCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/SF3/Sf3EndOfReadyCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf3EndOfReadyCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageSf3ShutdownCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message Sf3ShutdownCmdRsp.

        This is the auto generated method for subscribing message Sf3ShutdownCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for Sf3ShutdownCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/SF3/Sf3ShutdownCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf3ShutdownCmdRsp  - Exception %s", str(E))

        return

    def vSubscribeMessageMmsShutdownCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message MmsShutdownCmd.

        This is the auto generated method for subscribing message MmsShutdownCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for MmsShutdownCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/MMS/MmsShutdownCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message MmsShutdownCmd  - Exception %s", str(E))

        return

# ==========================================================
# MQTT SUBSCRIPTION METHODS START
# ==========================================================
# ==========================================================
# MQTT TEMPLATE CLASS STOP
# ==========================================================
# ==========================================================
# AUTOGEN STOP
# ==========================================================