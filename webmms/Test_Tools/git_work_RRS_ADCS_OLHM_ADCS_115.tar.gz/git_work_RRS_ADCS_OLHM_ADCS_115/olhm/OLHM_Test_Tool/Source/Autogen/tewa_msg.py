#!/usr/bin/env python3.6
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:32:32 SAST
"""


from Autogen.adcs_base_types import clsAdcsBaseType
from Autogen.adcs_base_types import clsAdcsEnumType
from Autogen.adcs_base_types import clsAdcsEnumArrayType
from Autogen.adcs_base_types import clsAdcsStructType
from Autogen.adcs_base_types import clsAdcsStructArrayType
from Autogen.adcs_base_types import clsAdcsMessageType
from Autogen.adcs_base_types import vAddEnum
from Autogen.adcs_base_types import vAddClass
from Autogen.adcs_base_types import vAddMessage
from Autogen.adcs_base_types import clsAdcsHeaderStructType
from Autogen.adcs_base_types import clsAdcsMessageStructType

# IMPORT CODE START
from Autogen.mw_common_types import *
from Autogen.adcs_common_types import *
# IMPORT CODE END

# TYPEDEFS START
class E1_TEWA_ENGAGEABILITY(clsAdcsEnumType):
    """Public class definition of type E1_TEWA_ENGAGEABILITY
    """
    def __init__(self, defaultValue=0):
        super().__init__("U1", defaultValue)
    NOTENGAGEABLE_E = 0x00
    ENGAGEABLE_E = 0x01


vAddEnum("E1_TEWA_ENGAGEABILITY", E1_TEWA_ENGAGEABILITY)


class E1_TEWA_THREAT_FLAG_TYPE(clsAdcsEnumType):
    """Public class definition of type E1_TEWA_THREAT_FLAG_TYPE
    """
    def __init__(self, defaultValue=0):
        super().__init__("U1", defaultValue)
    ABSOLUTE_SPEED = 0x00
    RELATIVE_SPEED = 0x01
    ABSOLUTE_COURSE = 0x02
    RELATIVE_COURSE = 0x03
    ABSOLUTE_BEARING = 0x04
    RELATIVE_BEARING = 0x05
    COMPOUND_SPEED = 0x06
    COMPOUND_COURSE = 0x07
    COMPOUND_BEARING = 0x08
    COMPOUND_COURSE_BEARING = 0x09
    LATE_UNMASKING = 0x0A
    THREAT_DETACHMENT = 0x0B


vAddEnum("E1_TEWA_THREAT_FLAG_TYPE", E1_TEWA_THREAT_FLAG_TYPE)


class E1_TEWA_ENGAGMENT_FLAG_TYPE(clsAdcsEnumType):
    """Public class definition of type E1_TEWA_ENGAGMENT_FLAG_TYPE
    """
    def __init__(self, defaultValue=0):
        super().__init__("U1", defaultValue)
    EO_TIMEOUT = 0x00
    THREAT_IN_RANGE = 0x01
    PLANNED_HOSTILITY_INCONSISTENT = 0x02
    PLANNED_IN_NO_FIRE_ARC = 0x03
    PLANNED_ON_RECEDING = 0x04


vAddEnum("E1_TEWA_ENGAGMENT_FLAG_TYPE", E1_TEWA_ENGAGMENT_FLAG_TYPE)


class sTEWA_ENGAGEMENT_TIME_AND_POSITION(clsAdcsStructType):
    """Public class definition of type sTEWA_ENGAGEMENT_TIME_AND_POSITION
    """
    def __init__(self, defaultValue=0):
        super().__init__("sTEWA_ENGAGEMENT_TIME_AND_POSITION")
        self.f8TimeDelayMs = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8TimeDelayMs")
        self.sThreatTrackPosition = sADCS_POINT_POSITION()
        self.vAddType("sThreatTrackPosition")


vAddClass("sTEWA_ENGAGEMENT_TIME_AND_POSITION",sTEWA_ENGAGEMENT_TIME_AND_POSITION)


class sTEWA_ENGAGEMENT_WINDOW(clsAdcsStructType):
    """Public class definition of type sTEWA_ENGAGEMENT_WINDOW
    """
    def __init__(self, defaultValue=0):
        super().__init__("sTEWA_ENGAGEMENT_WINDOW")
        self.sStart = sTEWA_ENGAGEMENT_TIME_AND_POSITION()
        self.vAddType("sStart")
        self.sRecommended = sTEWA_ENGAGEMENT_TIME_AND_POSITION()
        self.vAddType("sRecommended")
        self.sEnd = sTEWA_ENGAGEMENT_TIME_AND_POSITION()
        self.vAddType("sEnd")


vAddClass("sTEWA_ENGAGEMENT_WINDOW",sTEWA_ENGAGEMENT_WINDOW)


class sTEWA_LWO(clsAdcsStructType):
    """Public class definition of type sTEWA_LWO
    """
    def __init__(self, defaultValue=0):
        super().__init__("sTEWA_LWO")
        self.u4LwoId = clsAdcsBaseType("U4", 0)
        self.vAddType("u4LwoId")
        self.u4ThreatTrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4ThreatTrackNumber")
        self.u4EffectorTrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4EffectorTrackNumber")
        self.e1Delete = E1_MW_BOOLEAN_ENUM(E1_MW_BOOLEAN_ENUM.MW_BOOLEAN_FALSE)
        self.vAddType("e1Delete")


vAddClass("sTEWA_LWO",sTEWA_LWO)


class sTEWA_ENGAGEMENT(clsAdcsStructType):
    """Public class definition of type sTEWA_ENGAGEMENT
    """
    def __init__(self, defaultValue=0):
        super().__init__("sTEWA_ENGAGEMENT")
        self.u4EngagementId = clsAdcsBaseType("U4", 1)
        self.vAddType("u4EngagementId")
        self.u4ThreatTrackNumber = clsAdcsBaseType("U4", 1)
        self.vAddType("u4ThreatTrackNumber")
        self.u4EffectorTrackNumber = clsAdcsBaseType("U4", 1)
        self.vAddType("u4EffectorTrackNumber")
        self.u4AssetTrackNumber = clsAdcsBaseType("U4", 1)
        self.vAddType("u4AssetTrackNumber")
        self.e1EngagementType = E1_ADCS_ENGAGEMENT_TYPE(E1_ADCS_ENGAGEMENT_TYPE.PROPOSED_ET)
        self.vAddType("e1EngagementType")
        self.e1EngagementStatus = E1_ADCS_ENGAGEMENT_STATUS(E1_ADCS_ENGAGEMENT_STATUS.UNKNOWN_ES)
        self.vAddType("e1EngagementStatus")
        self.e1FeedbackStatus = E1_ADCS_FEEDBACK_STATUS(E1_ADCS_FEEDBACK_STATUS.NOFEEDBACK_FB)
        self.vAddType("e1FeedbackStatus")
        self.sFireWindow = sTEWA_ENGAGEMENT_WINDOW()
        self.vAddType("sFireWindow")
        self.sFireWindowTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sFireWindowTimestamp")
        self.sExclusionBoundary = sTEWA_ENGAGEMENT_TIME_AND_POSITION()
        self.vAddType("sExclusionBoundary")
        self.e1Engageability = E1_TEWA_ENGAGEABILITY(E1_TEWA_ENGAGEABILITY.NOTENGAGEABLE_E)
        self.vAddType("e1Engageability")


vAddClass("sTEWA_ENGAGEMENT",sTEWA_ENGAGEMENT)


# TYPEDEFS END

# MESSAGE HEADERS START
class sTEWA_STATUS_REPORT_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sTEWA_STATUS_REPORT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_TEWA)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0000)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sTEWA_STATUS_REPORT_UNSOL_MESSAGE_HEADER", sTEWA_STATUS_REPORT_UNSOL_MESSAGE_HEADER)


class sTEWA_END_OF_SETUP_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sTEWA_END_OF_SETUP_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_TEWA)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0001)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sTEWA_END_OF_SETUP_CMD_MESSAGE_HEADER", sTEWA_END_OF_SETUP_CMD_MESSAGE_HEADER)


class sTEWA_END_OF_SETUP_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sTEWA_END_OF_SETUP_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_TEWA)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0001)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sTEWA_END_OF_SETUP_CMD_RSP_MESSAGE_HEADER", sTEWA_END_OF_SETUP_CMD_RSP_MESSAGE_HEADER)


class sTEWA_END_OF_READY_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sTEWA_END_OF_READY_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_TEWA)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0002)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sTEWA_END_OF_READY_CMD_MESSAGE_HEADER", sTEWA_END_OF_READY_CMD_MESSAGE_HEADER)


class sTEWA_END_OF_READY_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sTEWA_END_OF_READY_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_TEWA)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0002)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sTEWA_END_OF_READY_CMD_RSP_MESSAGE_HEADER", sTEWA_END_OF_READY_CMD_RSP_MESSAGE_HEADER)


class sTEWA_SHUTDOWN_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sTEWA_SHUTDOWN_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_TEWA)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0003)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sTEWA_SHUTDOWN_CMD_MESSAGE_HEADER", sTEWA_SHUTDOWN_CMD_MESSAGE_HEADER)


class sTEWA_SHUTDOWN_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sTEWA_SHUTDOWN_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_TEWA)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0003)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sTEWA_SHUTDOWN_CMD_RSP_MESSAGE_HEADER", sTEWA_SHUTDOWN_CMD_RSP_MESSAGE_HEADER)


class sTEWA_THREAT_LIST_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sTEWA_THREAT_LIST_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_TEWA)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0010)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sTEWA_THREAT_LIST_UNSOL_MESSAGE_HEADER", sTEWA_THREAT_LIST_UNSOL_MESSAGE_HEADER)


class sTEWA_THREAT_FLAGS_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sTEWA_THREAT_FLAGS_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_TEWA)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0011)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sTEWA_THREAT_FLAGS_UNSOL_MESSAGE_HEADER", sTEWA_THREAT_FLAGS_UNSOL_MESSAGE_HEADER)


class sTEWA_ENGAGEMENT_FLAGS_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sTEWA_ENGAGEMENT_FLAGS_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_TEWA)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0011)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sTEWA_ENGAGEMENT_FLAGS_UNSOL_MESSAGE_HEADER", sTEWA_ENGAGEMENT_FLAGS_UNSOL_MESSAGE_HEADER)


class sTEWA_ENGAGEMENT_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sTEWA_ENGAGEMENT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_TEWA)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0020)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sTEWA_ENGAGEMENT_UNSOL_MESSAGE_HEADER", sTEWA_ENGAGEMENT_UNSOL_MESSAGE_HEADER)


class sTEWA_LWO_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sTEWA_LWO_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_TEWA)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0021)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sTEWA_LWO_UNSOL_MESSAGE_HEADER", sTEWA_LWO_UNSOL_MESSAGE_HEADER)


class sTEWA_SYSTEM_TRACK_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sTEWA_SYSTEM_TRACK_ENGINEERING_DATA_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_TEWA)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0040)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sTEWA_SYSTEM_TRACK_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER", sTEWA_SYSTEM_TRACK_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER)


class sTEWA_TOA_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sTEWA_TOA_ENGINEERING_DATA_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_TEWA)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0041)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sTEWA_TOA_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER", sTEWA_TOA_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER)


class sTEWA_TE_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sTEWA_TE_ENGINEERING_DATA_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_TEWA)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0042)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sTEWA_TE_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER", sTEWA_TE_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER)


class sTEWA_ALW_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sTEWA_ALW_ENGINEERING_DATA_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_TEWA)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0043)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sTEWA_ALW_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER", sTEWA_ALW_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER)


class sTEWA_UV_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sTEWA_UV_ENGINEERING_DATA_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_TEWA)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0044)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sTEWA_UV_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER", sTEWA_UV_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER)


class sTEWA_OCS_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sTEWA_OCS_ENGINEERING_DATA_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_TEWA)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0045)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sTEWA_OCS_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER", sTEWA_OCS_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER)


# MESSAGE HEADERS END

# PAYLOADS START
class sTEWA_STATUS_REPORT_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sTEWA_STATUS_REPORT_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sModuleInfo = sADCS_MODULE_INFO()
        self.vAddType("sModuleInfo")
        self.sModuleState = sADCS_MODULE_STATE()
        self.vAddType("sModuleState")


vAddClass("sTEWA_STATUS_REPORT_UNSOL_PL", sTEWA_STATUS_REPORT_UNSOL_PL)


class sTEWA_THREAT_LIST_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sTEWA_THREAT_LIST_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4ThreatCount = clsAdcsBaseType("U4", 1)
        self.vAddType("u4ThreatCount")
        self.asThreatInfo = clsAdcsStructArrayType("sADCS_THREATINFO:100")
        self.vAddType("asThreatInfo")


vAddClass("sTEWA_THREAT_LIST_UNSOL_PL", sTEWA_THREAT_LIST_UNSOL_PL)


class sTEWA_THREAT_FLAGS_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sTEWA_THREAT_FLAGS_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4ThreatTrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4ThreatTrackNumber")
        self.e1FlagType = E1_TEWA_THREAT_FLAG_TYPE(E1_TEWA_THREAT_FLAG_TYPE.ABSOLUTE_SPEED)
        self.vAddType("e1FlagType")


vAddClass("sTEWA_THREAT_FLAGS_UNSOL_PL", sTEWA_THREAT_FLAGS_UNSOL_PL)


class sTEWA_ENGAGEMENT_FLAGS_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sTEWA_ENGAGEMENT_FLAGS_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4EngagementId = clsAdcsBaseType("U4", 0)
        self.vAddType("u4EngagementId")
        self.e1FlagType = E1_TEWA_ENGAGMENT_FLAG_TYPE(E1_TEWA_ENGAGMENT_FLAG_TYPE.EO_TIMEOUT)
        self.vAddType("e1FlagType")


vAddClass("sTEWA_ENGAGEMENT_FLAGS_UNSOL_PL", sTEWA_ENGAGEMENT_FLAGS_UNSOL_PL)


class sTEWA_ENGAGEMENT_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sTEWA_ENGAGEMENT_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4EngagementCount = clsAdcsBaseType("U4", 1)
        self.vAddType("u4EngagementCount")
        self.asEngagements = clsAdcsStructArrayType("sTEWA_ENGAGEMENT:100")
        self.vAddType("asEngagements")


vAddClass("sTEWA_ENGAGEMENT_UNSOL_PL", sTEWA_ENGAGEMENT_UNSOL_PL)


class sTEWA_LWO_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sTEWA_LWO_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4LwoCount = clsAdcsBaseType("U4", 1)
        self.vAddType("u4LwoCount")
        self.asLocalWarningOrders = clsAdcsStructArrayType("sTEWA_LWO:100")
        self.vAddType("asLocalWarningOrders")


vAddClass("sTEWA_LWO_UNSOL_PL", sTEWA_LWO_UNSOL_PL)


class sTEWA_SYSTEM_TRACK_ENGINEERING_DATA_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sTEWA_SYSTEM_TRACK_ENGINEERING_DATA_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.f8RCS = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8RCS")
        self.f8VSigLength = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8VSigLength")
        self.f8VSigWidth = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8VSigWidth")
        self.f8VSigHeight = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8VSigHeight")
        self.f8Health = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8Health")
        self.f8HealthThreshold = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8HealthThreshold")
        self.f8WrlDistance = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8WrlDistance")
        self.f8EcefPositionE = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8EcefPositionE")
        self.f8EcefPositionN = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8EcefPositionN")
        self.f8EcefPositionU = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8EcefPositionU")
        self.f8OrientationHeading = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8OrientationHeading")
        self.f8OrientationPitch = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8OrientationPitch")
        self.f8OrientationRoll = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8OrientationRoll")


vAddClass("sTEWA_SYSTEM_TRACK_ENGINEERING_DATA_UNSOL_PL", sTEWA_SYSTEM_TRACK_ENGINEERING_DATA_UNSOL_PL)


class sTEWA_TOA_ENGINEERING_DATA_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sTEWA_TOA_ENGINEERING_DATA_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.f8AmplifiedTrackNr = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8AmplifiedTrackNr")
        self.f8AssociatedDaTrackNr = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8AssociatedDaTrackNr")
        self.f8ThreatApproachOrientation = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8ThreatApproachOrientation")
        self.f8SlantRangeToDa = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8SlantRangeToDa")
        self.f8DirectionValueAgility = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8DirectionValueAgility")
        self.f8NumberOfDAs = clsAdcsBaseType("F8", 0.0)
        self.f8NumberOfDAs.vSetMin(1)
        self.f8NumberOfDAs.vSetMax(8)
        self.vAddType("f8NumberOfDAs")
        self.af8DaTrackNr = clsAdcsBaseType("F8:8", 0.0)
        self.vAddType("af8DaTrackNr")
        self.af8DirectionValueBearing = clsAdcsBaseType("F8:8", 0.0)
        self.af8DirectionValueBearing.vSetMin(0)
        self.af8DirectionValueBearing.vSetMax(90)
        self.vAddType("af8DirectionValueBearing")
        self.af8RelationshipValue = clsAdcsBaseType("F8:8", 0.0)
        self.af8RelationshipValue.vSetMin(0)
        self.af8RelationshipValue.vSetMax(15)
        self.vAddType("af8RelationshipValue")
        self.af8ThreatApproachOrientation = clsAdcsBaseType("F8:8", 0.0)
        self.vAddType("af8ThreatApproachOrientation")
        self.af8SlantRangeToDa = clsAdcsBaseType("F8:8", 0.0)
        self.af8SlantRangeToDa.vSetMin(0)
        self.af8SlantRangeToDa.vSetMax(80000)
        self.vAddType("af8SlantRangeToDa")


vAddClass("sTEWA_TOA_ENGINEERING_DATA_UNSOL_PL", sTEWA_TOA_ENGINEERING_DATA_UNSOL_PL)


class sTEWA_TE_ENGINEERING_DATA_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sTEWA_TE_ENGINEERING_DATA_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.f8NumberOfThreats = clsAdcsBaseType("F8", 0.0)
        self.f8NumberOfThreats.vSetMin(0)
        self.f8NumberOfThreats.vSetMax(100)
        self.vAddType("f8NumberOfThreats")
        self.af8TrackNr = clsAdcsBaseType("F8:100", 0.0)
        self.vAddType("af8TrackNr")
        self.af8ThreatValue = clsAdcsBaseType("F8:100", 0.0)
        self.af8ThreatValue.vSetMin(0)
        self.af8ThreatValue.vSetMax(100)
        self.vAddType("af8ThreatValue")
        self.af8InherentThreatValue = clsAdcsBaseType("F8:100", 0.0)
        self.af8InherentThreatValue.vSetMin(0)
        self.af8InherentThreatValue.vSetMax(100)
        self.vAddType("af8InherentThreatValue")
        self.af8AssociatedDaValue = clsAdcsBaseType("F8:100", 0.0)
        self.af8AssociatedDaValue.vSetMin(2)
        self.af8AssociatedDaValue.vSetMax(14)
        self.vAddType("af8AssociatedDaValue")
        self.af8ThreatVelocityValue = clsAdcsBaseType("F8:100", 0.0)
        self.af8ThreatVelocityValue.vSetMin(1)
        self.af8ThreatVelocityValue.vSetMax(8)
        self.vAddType("af8ThreatVelocityValue")
        self.af8ThreatApproachOrientation = clsAdcsBaseType("F8:100", 0.0)
        self.vAddType("af8ThreatApproachOrientation")
        self.af8ThreatAltitudeValue = clsAdcsBaseType("F8:100", 0.0)
        self.af8ThreatAltitudeValue.vSetMin(0)
        self.af8ThreatAltitudeValue.vSetMax(1)
        self.vAddType("af8ThreatAltitudeValue")
        self.af8ThreatRaidSize = clsAdcsBaseType("F8:100", 0.0)
        self.vAddType("af8ThreatRaidSize")
        self.af8TimeToWrl = clsAdcsBaseType("F8:100", 0.0)
        self.vAddType("af8TimeToWrl")
        self.af8SlantRangeToDa = clsAdcsBaseType("F8:100", 0.0)
        self.af8SlantRangeToDa.vSetMin(0)
        self.af8SlantRangeToDa.vSetMax(80000)
        self.vAddType("af8SlantRangeToDa")


vAddClass("sTEWA_TE_ENGINEERING_DATA_UNSOL_PL", sTEWA_TE_ENGINEERING_DATA_UNSOL_PL)


class sTEWA_ALW_ENGINEERING_DATA_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sTEWA_ALW_ENGINEERING_DATA_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.f8ThreatTrackNr = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8ThreatTrackNr")
        self.f8AssociatedDaTrackNr = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8AssociatedDaTrackNr")
        self.f8NumberOfWSs = clsAdcsBaseType("F8", 0.0)
        self.f8NumberOfWSs.vSetMin(1)
        self.f8NumberOfWSs.vSetMax(32)
        self.vAddType("f8NumberOfWSs")
        self.af8WsTrackNr = clsAdcsBaseType("F8:32", 0.0)
        self.vAddType("af8WsTrackNr")
        self.f8Availability = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8Availability")
        self.af8AvailableLaunchWindow = clsAdcsBaseType("F8:32", 0.0)
        self.vAddType("af8AvailableLaunchWindow")


vAddClass("sTEWA_ALW_ENGINEERING_DATA_UNSOL_PL", sTEWA_ALW_ENGINEERING_DATA_UNSOL_PL)


class sTEWA_UV_ENGINEERING_DATA_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sTEWA_UV_ENGINEERING_DATA_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.f8ThreatTrackNr = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8ThreatTrackNr")
        self.f8NumberOfWs = clsAdcsBaseType("F8", 0.0)
        self.f8NumberOfWs.vSetMin(1)
        self.f8NumberOfWs.vSetMax(32)
        self.vAddType("f8NumberOfWs")
        self.af8WsTrackNr = clsAdcsBaseType("F8:32", 0.0)
        self.vAddType("af8WsTrackNr")
        self.af8WsUtilityValue = clsAdcsBaseType("F8:32", 0.0)
        self.vAddType("af8WsUtilityValue")
        self.af8AvailableLaunchWindow = clsAdcsBaseType("F8:32", 0.0)
        self.vAddType("af8AvailableLaunchWindow")
        self.af8AveragePkill = clsAdcsBaseType("F8:32", 0.0)
        self.vAddType("af8AveragePkill")
        self.af8RangeOfInterceptBeforeWrl = clsAdcsBaseType("F8:32", 0.0)
        self.vAddType("af8RangeOfInterceptBeforeWrl")
        self.af8TimeToImpact = clsAdcsBaseType("F8:32", 0.0)
        self.vAddType("af8TimeToImpact")
        self.af8ThreatTypeWsPreference = clsAdcsBaseType("F8:32", 0.0)
        self.vAddType("af8ThreatTypeWsPreference")
        self.af8AmmoLevelProtectionLevel = clsAdcsBaseType("F8:32", 0.0)
        self.vAddType("af8AmmoLevelProtectionLevel")
        self.af8LosDropOuts = clsAdcsBaseType("F8:32", 0.0)
        self.vAddType("af8LosDropOuts")
        self.af8PredictedInterceptAngle = clsAdcsBaseType("F8:32", 0.0)
        self.vAddType("af8PredictedInterceptAngle")
        self.af8UserCost = clsAdcsBaseType("F8:32", 0.0)
        self.vAddType("af8UserCost")


vAddClass("sTEWA_UV_ENGINEERING_DATA_UNSOL_PL", sTEWA_UV_ENGINEERING_DATA_UNSOL_PL)


class sTEWA_OCS_ENGINEERING_DATA_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sTEWA_OCS_ENGINEERING_DATA_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.f8ThreatTrackNr = clsAdcsBaseType("F8", 0.0)
        self.vAddType("f8ThreatTrackNr")
        self.f8NumberOfWSs = clsAdcsBaseType("F8", 0.0)
        self.f8NumberOfWSs.vSetMin(1)
        self.f8NumberOfWSs.vSetMax(32)
        self.vAddType("f8NumberOfWSs")
        self.af8WsTrackNr = clsAdcsBaseType("F8:32", 0.0)
        self.vAddType("af8WsTrackNr")
        self.af8OcsValue = clsAdcsBaseType("F8:32", 0.0)
        self.vAddType("af8OcsValue")


vAddClass("sTEWA_OCS_ENGINEERING_DATA_UNSOL_PL", sTEWA_OCS_ENGINEERING_DATA_UNSOL_PL)


# PAYLOADS END

# MESSAGES START
class sTEWA_STATUS_REPORT_UNSOL(clsAdcsMessageType):
    """Public class definition of type sTEWA_STATUS_REPORT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sTEWA_STATUS_REPORT_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sTEWA_STATUS_REPORT_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sTEWA_STATUS_REPORT_UNSOL", sTEWA_STATUS_REPORT_UNSOL)


class sTEWA_END_OF_SETUP_CMD(clsAdcsMessageType):
    """Public class definition of type sTEWA_END_OF_SETUP_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sTEWA_END_OF_SETUP_CMD_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sTEWA_END_OF_SETUP_CMD", sTEWA_END_OF_SETUP_CMD)


class sTEWA_END_OF_SETUP_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sTEWA_END_OF_SETUP_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sTEWA_END_OF_SETUP_CMD_RSP_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sTEWA_END_OF_SETUP_CMD_RSP", sTEWA_END_OF_SETUP_CMD_RSP)


class sTEWA_END_OF_READY_CMD(clsAdcsMessageType):
    """Public class definition of type sTEWA_END_OF_READY_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sTEWA_END_OF_READY_CMD_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sTEWA_END_OF_READY_CMD", sTEWA_END_OF_READY_CMD)


class sTEWA_END_OF_READY_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sTEWA_END_OF_READY_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sTEWA_END_OF_READY_CMD_RSP_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sTEWA_END_OF_READY_CMD_RSP", sTEWA_END_OF_READY_CMD_RSP)


class sTEWA_SHUTDOWN_CMD(clsAdcsMessageType):
    """Public class definition of type sTEWA_SHUTDOWN_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sTEWA_SHUTDOWN_CMD_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sTEWA_SHUTDOWN_CMD", sTEWA_SHUTDOWN_CMD)


class sTEWA_SHUTDOWN_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sTEWA_SHUTDOWN_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sTEWA_SHUTDOWN_CMD_RSP_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sTEWA_SHUTDOWN_CMD_RSP", sTEWA_SHUTDOWN_CMD_RSP)


class sTEWA_THREAT_LIST_UNSOL(clsAdcsMessageType):
    """Public class definition of type sTEWA_THREAT_LIST_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sTEWA_THREAT_LIST_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sTEWA_THREAT_LIST_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sTEWA_THREAT_LIST_UNSOL", sTEWA_THREAT_LIST_UNSOL)


class sTEWA_THREAT_FLAGS_UNSOL(clsAdcsMessageType):
    """Public class definition of type sTEWA_THREAT_FLAGS_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sTEWA_THREAT_FLAGS_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sTEWA_THREAT_FLAGS_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sTEWA_THREAT_FLAGS_UNSOL", sTEWA_THREAT_FLAGS_UNSOL)


class sTEWA_ENGAGEMENT_FLAGS_UNSOL(clsAdcsMessageType):
    """Public class definition of type sTEWA_ENGAGEMENT_FLAGS_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sTEWA_ENGAGEMENT_FLAGS_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sTEWA_ENGAGEMENT_FLAGS_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sTEWA_ENGAGEMENT_FLAGS_UNSOL", sTEWA_ENGAGEMENT_FLAGS_UNSOL)


class sTEWA_ENGAGEMENT_UNSOL(clsAdcsMessageType):
    """Public class definition of type sTEWA_ENGAGEMENT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sTEWA_ENGAGEMENT_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sTEWA_ENGAGEMENT_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sTEWA_ENGAGEMENT_UNSOL", sTEWA_ENGAGEMENT_UNSOL)


class sTEWA_LWO_UNSOL(clsAdcsMessageType):
    """Public class definition of type sTEWA_LWO_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sTEWA_LWO_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sTEWA_LWO_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sTEWA_LWO_UNSOL", sTEWA_LWO_UNSOL)


class sTEWA_SYSTEM_TRACK_ENGINEERING_DATA_UNSOL(clsAdcsMessageType):
    """Public class definition of type sTEWA_SYSTEM_TRACK_ENGINEERING_DATA_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sTEWA_SYSTEM_TRACK_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sTEWA_SYSTEM_TRACK_ENGINEERING_DATA_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sTEWA_SYSTEM_TRACK_ENGINEERING_DATA_UNSOL", sTEWA_SYSTEM_TRACK_ENGINEERING_DATA_UNSOL)


class sTEWA_TOA_ENGINEERING_DATA_UNSOL(clsAdcsMessageType):
    """Public class definition of type sTEWA_TOA_ENGINEERING_DATA_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sTEWA_TOA_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sTEWA_TOA_ENGINEERING_DATA_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sTEWA_TOA_ENGINEERING_DATA_UNSOL", sTEWA_TOA_ENGINEERING_DATA_UNSOL)


class sTEWA_TE_ENGINEERING_DATA_UNSOL(clsAdcsMessageType):
    """Public class definition of type sTEWA_TE_ENGINEERING_DATA_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sTEWA_TE_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sTEWA_TE_ENGINEERING_DATA_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sTEWA_TE_ENGINEERING_DATA_UNSOL", sTEWA_TE_ENGINEERING_DATA_UNSOL)


class sTEWA_ALW_ENGINEERING_DATA_UNSOL(clsAdcsMessageType):
    """Public class definition of type sTEWA_ALW_ENGINEERING_DATA_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sTEWA_ALW_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sTEWA_ALW_ENGINEERING_DATA_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sTEWA_ALW_ENGINEERING_DATA_UNSOL", sTEWA_ALW_ENGINEERING_DATA_UNSOL)


class sTEWA_UV_ENGINEERING_DATA_UNSOL(clsAdcsMessageType):
    """Public class definition of type sTEWA_UV_ENGINEERING_DATA_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sTEWA_UV_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sTEWA_UV_ENGINEERING_DATA_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sTEWA_UV_ENGINEERING_DATA_UNSOL", sTEWA_UV_ENGINEERING_DATA_UNSOL)


class sTEWA_OCS_ENGINEERING_DATA_UNSOL(clsAdcsMessageType):
    """Public class definition of type sTEWA_OCS_ENGINEERING_DATA_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sTEWA_OCS_ENGINEERING_DATA_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sTEWA_OCS_ENGINEERING_DATA_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sTEWA_OCS_ENGINEERING_DATA_UNSOL", sTEWA_OCS_ENGINEERING_DATA_UNSOL)


# MESSAGES END




