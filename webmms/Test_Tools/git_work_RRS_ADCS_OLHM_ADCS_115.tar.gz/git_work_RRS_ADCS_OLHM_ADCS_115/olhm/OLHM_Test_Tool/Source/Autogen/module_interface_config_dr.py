#!/usr/bin/env python3.6
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:32:42 SAST
"""

from enum import Enum


class E_MESSAGE_FLOW_DIRECTION(Enum):
    MESSAGE_FLOW_DIRECTION_PUBLISH = 1
    MESSAGE_FLOW_DIRECTION_SUBSCRIBE = 2


class E_COMMS_PROTOCOL(Enum):
    COMMS_PROTOCOL_MQTT = 1
    COMMS_PROTOCOL_ZEROMQ = 2


class clsModuleInterfaceConfigDr():
    lstModInterConfTopicInfo = []
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "DR", "acMessagename": "DrStatusReportUnsol", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "DR", "acMessagename": "DrEndOfSetupCmdRsp", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "DR", "acMessagename": "DrEndOfReadyCmdRsp", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "DR", "acMessagename": "DrShutdownCmdRsp", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "DR", "acMessagename": "DrRecordingStateCmdRsp", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "DR", "acMessagename": "DrClearRecordingDatabaseCmdRsp", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "DR", "acMessagename": "DrEndOfSetupCmd", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "DR", "acMessagename": "DrEndOfReadyCmd", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "DR", "acMessagename": "DrShutdownCmd", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "DR", "acMessagename": "DrRecordingStateCmd", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE), "acRole": ""})
    lstModInterConfTopicInfo.append({"acSystem": "ADCS", "acModule": "DR", "acMessagename": "DrClearRecordingDatabaseCmd", "eCommsProtocol": E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT), "eMessageFlowDirection": E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE), "acRole": ""})
