#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:32:42 SAST

    This module is the mqtt client on connect class, generated automatically from XML file(s). Its intended use is as a class
    with mqtt callbacks for on_connect() and on_message(). This class should be instantiated before the mqtt connect. The mqtt 
    on_connect() callback should be redirected as -> client.on_connect = objClsMqttAutogenHandler.vOnConnect
    It should be noted that all operations inside this class will execute inside the mqtt thread. The processing methods in this class
    will validate the incoming messages and reply only if validation failed. Messages which passed validation will be placed in a queue provided to
    the constructor of the class. 

"""
# ==========================================================
# AUTOGEN START
# ==========================================================
import logging  # This is required to be able to log if there are problems
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
import queue  # This is required to put the received message in a queue to pass on to another non-mqtt thread
from copy import deepcopy  # This is required to make a deepcopy of the message before insertion in the queue - it ensures proper garbage collection
from Autogen.mw_common_types import E2_MW_MESSAGE_STATUS
from Autogen.tm_msg import *  # noqa: F401
from Autogen.dsf_msg import *  # noqa: F401
from Autogen.tewa_msg import *  # noqa: F401
from Autogen.hmi_msg import *  # noqa: F401

# ==========================================================
# MQTT TEMPLATE CLASS START
# ==========================================================


class clsMqttAutogenHandler():
    """ This is the MQTT message handling autogen base class

    This is the MQTT message handling autogen base class. An instance of this class should be made before giving the mqtt client
    a on_connect() callback from this class.

    Args:
        objQueuePar (queue.Queue): The first parameter. The instance of the python queue into which we will push messages received
        bLoggingEnabledPar (bool): The second parameter. A boolean flag indicating if logging should be done or not. This parameter is by default True

    """
    def __init__(self, objQueuePar: queue.Queue, bLoggingEnabledPar: bool = True):
        super().__init__()
        self._bLoggingEnabled = bLoggingEnabledPar
        self._objQueue = objQueuePar
        # By default all subscriptions will auto reply if a ReplyMsg was specified
        self.bAutoReplyForSubscriptionTewaEndOfSetupCmd = True
        self.bAutoReplyForSubscriptionTewaEndOfReadyCmd = True
        self.bAutoReplyForSubscriptionTewaShutdownCmd = True

    def vOnConnect(self, objMqttClientPar: mqtt.Client, userDataPar, dctFlags, iConnectionResult: int) -> None:  # pylint: disable=W0613
        """ This is the callback method for when client receives a CONNACK response from the server

        This is the callback method for when client receives a CONNACK response from the server. This method subscribes
        and registers callback methods for all incoming messages. Messages from secondary XML files will not automatically be
        subscribed to. The on message callbacks will however all automatically be registered even for secondary XML files.

        Args:
            objMqttClientPar (obj): The first parameter. A MQTT client object
            userDataPar: The second parameter. The private user data as set in Client() or userdata_set()
            flags: The third parameter. flags is a dict that contains response flags from the broker:
            rc: The fourth parameter. The connection result

        Returns:

        Raises:
            Raises no exceptions
        """

        # Subscribing and adding callback for TewaEndOfSetupCmd 
        # Subscribing and adding callback for TewaEndOfSetupCmd 
        # Subscribing and adding callback for TewaEndOfSetupCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message TewaEndOfSetupCmd  with topic ADCS/TEWA/TewaEndOfSetupCmd")

        try:
            objMqttClientPar.subscribe("ADCS/TEWA/TewaEndOfSetupCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TewaEndOfSetupCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for TewaEndOfSetupCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/TEWA/TewaEndOfSetupCmd", self.vOnMessageCallbackTewaEndOfSetupCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for TewaEndOfSetupCmd  - Exception %s", str(E))
        # Subscribing and adding callback for TewaEndOfReadyCmd 
        # Subscribing and adding callback for TewaEndOfReadyCmd 
        # Subscribing and adding callback for TewaEndOfReadyCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message TewaEndOfReadyCmd  with topic ADCS/TEWA/TewaEndOfReadyCmd")

        try:
            objMqttClientPar.subscribe("ADCS/TEWA/TewaEndOfReadyCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TewaEndOfReadyCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for TewaEndOfReadyCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/TEWA/TewaEndOfReadyCmd", self.vOnMessageCallbackTewaEndOfReadyCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for TewaEndOfReadyCmd  - Exception %s", str(E))
        # Subscribing and adding callback for TewaShutdownCmd 
        # Subscribing and adding callback for TewaShutdownCmd 
        # Subscribing and adding callback for TewaShutdownCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message TewaShutdownCmd  with topic ADCS/TEWA/TewaShutdownCmd")

        try:
            objMqttClientPar.subscribe("ADCS/TEWA/TewaShutdownCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TewaShutdownCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for TewaShutdownCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/TEWA/TewaShutdownCmd", self.vOnMessageCallbackTewaShutdownCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for TewaShutdownCmd  - Exception %s", str(E))

        return

# =========================================================="
# MQTT CALLBACK METHODS START
# =========================================================="

    def vOnMessageCallbackTewaEndOfSetupCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message TewaEndOfSetupCmd

        This is a public method callback for message TewaEndOfSetupCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objTewaEndOfSetupCmd = sTEWA_END_OF_SETUP_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objTewaEndOfSetupCmdRsp = sTEWA_END_OF_SETUP_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaEndOfSetupCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaEndOfSetupCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaEndOfSetupCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objTewaEndOfSetupCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaEndOfSetupCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objTewaEndOfSetupCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for TewaEndOfSetupCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objTewaEndOfSetupCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TewaEndOfSetupCmd  validation failed")
            elif (objTewaEndOfSetupCmd.sMsgHeader.u2MsgLength.Value != (objTewaEndOfSetupCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TewaEndOfSetupCmd  length field is invalid - it is %d and should be %d bytes", objTewaEndOfSetupCmd.sMsgHeader.u2MsgLength.Value, objTewaEndOfSetupCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/TEWA/TewaEndOfSetupCmd", "Class": sTEWA_END_OF_SETUP_CMD, "ClassName": "sTEWA_END_OF_SETUP_CMD", "acRole": "", "MsgObject": deepcopy(objTewaEndOfSetupCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/TEWA/TewaEndOfSetupCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionTewaEndOfSetupCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objTewaEndOfSetupCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/TEWA/TewaEndOfSetupCmdRsp", objTewaEndOfSetupCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("TewaEndOfSetupCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackTewaEndOfReadyCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message TewaEndOfReadyCmd

        This is a public method callback for message TewaEndOfReadyCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objTewaEndOfReadyCmd = sTEWA_END_OF_READY_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objTewaEndOfReadyCmdRsp = sTEWA_END_OF_READY_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaEndOfReadyCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaEndOfReadyCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaEndOfReadyCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objTewaEndOfReadyCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaEndOfReadyCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objTewaEndOfReadyCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for TewaEndOfReadyCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objTewaEndOfReadyCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TewaEndOfReadyCmd  validation failed")
            elif (objTewaEndOfReadyCmd.sMsgHeader.u2MsgLength.Value != (objTewaEndOfReadyCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TewaEndOfReadyCmd  length field is invalid - it is %d and should be %d bytes", objTewaEndOfReadyCmd.sMsgHeader.u2MsgLength.Value, objTewaEndOfReadyCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/TEWA/TewaEndOfReadyCmd", "Class": sTEWA_END_OF_READY_CMD, "ClassName": "sTEWA_END_OF_READY_CMD", "acRole": "", "MsgObject": deepcopy(objTewaEndOfReadyCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/TEWA/TewaEndOfReadyCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionTewaEndOfReadyCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objTewaEndOfReadyCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/TEWA/TewaEndOfReadyCmdRsp", objTewaEndOfReadyCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("TewaEndOfReadyCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackTewaShutdownCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message TewaShutdownCmd

        This is a public method callback for message TewaShutdownCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objTewaShutdownCmd = sTEWA_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objTewaShutdownCmdRsp = sTEWA_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaShutdownCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaShutdownCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaShutdownCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objTewaShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for TewaShutdownCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objTewaShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for TewaShutdownCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objTewaShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TewaShutdownCmd  validation failed")
            elif (objTewaShutdownCmd.sMsgHeader.u2MsgLength.Value != (objTewaShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message TewaShutdownCmd  length field is invalid - it is %d and should be %d bytes", objTewaShutdownCmd.sMsgHeader.u2MsgLength.Value, objTewaShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/TEWA/TewaShutdownCmd", "Class": sTEWA_SHUTDOWN_CMD, "ClassName": "sTEWA_SHUTDOWN_CMD", "acRole": "", "MsgObject": deepcopy(objTewaShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/TEWA/TewaShutdownCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionTewaShutdownCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objTewaShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/TEWA/TewaShutdownCmdRsp", objTewaShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("TewaShutdownCmd's publish threw exception - %s", str(E))

        return
# ==========================================================
# MQTT CALLBACK METHODS STOP
# ==========================================================
# ==========================================================
# MQTT SUBSCRIPTION METHODS START
# ==========================================================

    def vSubscribeMessageTewaEndOfSetupCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message TewaEndOfSetupCmd.

        This is the auto generated method for subscribing message TewaEndOfSetupCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for TewaEndOfSetupCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/TEWA/TewaEndOfSetupCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TewaEndOfSetupCmd  - Exception %s", str(E))

        return

    def vSubscribeMessageTewaEndOfReadyCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message TewaEndOfReadyCmd.

        This is the auto generated method for subscribing message TewaEndOfReadyCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for TewaEndOfReadyCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/TEWA/TewaEndOfReadyCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TewaEndOfReadyCmd  - Exception %s", str(E))

        return

    def vSubscribeMessageTewaShutdownCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message TewaShutdownCmd.

        This is the auto generated method for subscribing message TewaShutdownCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for TewaShutdownCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/TEWA/TewaShutdownCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message TewaShutdownCmd  - Exception %s", str(E))

        return

# ==========================================================
# MQTT SUBSCRIPTION METHODS START
# ==========================================================
# ==========================================================
# MQTT TEMPLATE CLASS STOP
# ==========================================================
# ==========================================================
# AUTOGEN STOP
# ==========================================================