#!/usr/bin/env python3.6
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:32:30 SAST
"""


from Autogen.adcs_base_types import clsAdcsBaseType
from Autogen.adcs_base_types import clsAdcsEnumType
from Autogen.adcs_base_types import clsAdcsEnumArrayType
from Autogen.adcs_base_types import clsAdcsStructType
from Autogen.adcs_base_types import clsAdcsStructArrayType
from Autogen.adcs_base_types import clsAdcsMessageType
from Autogen.adcs_base_types import vAddEnum
from Autogen.adcs_base_types import vAddClass
from Autogen.adcs_base_types import vAddMessage
from Autogen.adcs_base_types import clsAdcsHeaderStructType
from Autogen.adcs_base_types import clsAdcsMessageStructType

# IMPORT CODE START
from Autogen.mw_common_types import *
from Autogen.adcs_common_types import *
# IMPORT CODE END

# TYPEDEFS START
class E1_DR_RECORDING_STATE(clsAdcsEnumType):
    """Public class definition of type E1_DR_RECORDING_STATE
    """
    def __init__(self, defaultValue=0):
        super().__init__("U1", defaultValue)
    DR_RECORDING_STATE_RECORDING_ACTIVE = 0x00
    DR_RECORDING_STATE_RECORDING_INACTIVE = 0x01


vAddEnum("E1_DR_RECORDING_STATE", E1_DR_RECORDING_STATE)


class E1_DR_STATUS(clsAdcsEnumType):
    """Public class definition of type E1_DR_STATUS
    """
    def __init__(self, defaultValue=0):
        super().__init__("U1", defaultValue)
    DR_STATUS_FAILED = 0x00
    DR_STATUS_PASSED = 0x01


vAddEnum("E1_DR_STATUS", E1_DR_STATUS)


class E1_DR_DISK_UTILISATION_STATUS(clsAdcsEnumType):
    """Public class definition of type E1_DR_DISK_UTILISATION_STATUS
    """
    def __init__(self, defaultValue=0):
        super().__init__("U1", defaultValue)
    DISK_STORAGE_MAX_CAPACITY_REACHED = 0x00
    DISK_STORAGE_MAX_CAPACITY_NOT_REACHED = 0x01


vAddEnum("E1_DR_DISK_UTILISATION_STATUS", E1_DR_DISK_UTILISATION_STATUS)


# TYPEDEFS END

# MESSAGE HEADERS START
class sDR_STATUS_REPORT_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sDR_STATUS_REPORT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_DR)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0000)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sDR_STATUS_REPORT_UNSOL_MESSAGE_HEADER", sDR_STATUS_REPORT_UNSOL_MESSAGE_HEADER)


class sDR_END_OF_SETUP_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sDR_END_OF_SETUP_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_DR)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0001)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sDR_END_OF_SETUP_CMD_MESSAGE_HEADER", sDR_END_OF_SETUP_CMD_MESSAGE_HEADER)


class sDR_END_OF_SETUP_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sDR_END_OF_SETUP_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_DR)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0001)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sDR_END_OF_SETUP_CMD_RSP_MESSAGE_HEADER", sDR_END_OF_SETUP_CMD_RSP_MESSAGE_HEADER)


class sDR_END_OF_READY_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sDR_END_OF_READY_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_DR)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0002)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sDR_END_OF_READY_CMD_MESSAGE_HEADER", sDR_END_OF_READY_CMD_MESSAGE_HEADER)


class sDR_END_OF_READY_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sDR_END_OF_READY_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_DR)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0002)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sDR_END_OF_READY_CMD_RSP_MESSAGE_HEADER", sDR_END_OF_READY_CMD_RSP_MESSAGE_HEADER)


class sDR_SHUTDOWN_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sDR_SHUTDOWN_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_DR)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0003)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sDR_SHUTDOWN_CMD_MESSAGE_HEADER", sDR_SHUTDOWN_CMD_MESSAGE_HEADER)


class sDR_SHUTDOWN_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sDR_SHUTDOWN_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_DR)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0003)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sDR_SHUTDOWN_CMD_RSP_MESSAGE_HEADER", sDR_SHUTDOWN_CMD_RSP_MESSAGE_HEADER)


class sDR_RECORDING_STATE_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sDR_RECORDING_STATE_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_DR)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0010)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sDR_RECORDING_STATE_CMD_MESSAGE_HEADER", sDR_RECORDING_STATE_CMD_MESSAGE_HEADER)


class sDR_RECORDING_STATE_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sDR_RECORDING_STATE_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_DR)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0010)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sDR_RECORDING_STATE_CMD_RSP_MESSAGE_HEADER", sDR_RECORDING_STATE_CMD_RSP_MESSAGE_HEADER)


class sDR_CLEAR_RECORDING_DATABASE_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sDR_CLEAR_RECORDING_DATABASE_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_DR)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0011)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sDR_CLEAR_RECORDING_DATABASE_CMD_MESSAGE_HEADER", sDR_CLEAR_RECORDING_DATABASE_CMD_MESSAGE_HEADER)


class sDR_CLEAR_RECORDING_DATABASE_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sDR_CLEAR_RECORDING_DATABASE_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_DR)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0011)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sDR_CLEAR_RECORDING_DATABASE_CMD_RSP_MESSAGE_HEADER", sDR_CLEAR_RECORDING_DATABASE_CMD_RSP_MESSAGE_HEADER)


# MESSAGE HEADERS END

# PAYLOADS START
class sDR_STATUS_REPORT_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sDR_STATUS_REPORT_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sModuleInfo = sADCS_MODULE_INFO()
        self.vAddType("sModuleInfo")
        self.sModuleState = sADCS_MODULE_STATE()
        self.vAddType("sModuleState")
        self.e1OverallStatus = E1_DR_STATUS(E1_DR_STATUS.DR_STATUS_FAILED)
        self.vAddType("e1OverallStatus")
        self.e1RecordingState = E1_DR_RECORDING_STATE(E1_DR_RECORDING_STATE.DR_RECORDING_STATE_RECORDING_ACTIVE)
        self.vAddType("e1RecordingState")
        self.e1DiskUtilisationStatus = E1_DR_DISK_UTILISATION_STATUS(E1_DR_DISK_UTILISATION_STATUS.DISK_STORAGE_MAX_CAPACITY_NOT_REACHED)
        self.vAddType("e1DiskUtilisationStatus")
        self.u1DiskStorageUtilisationPercentage = clsAdcsBaseType("U1", 0)
        self.vAddType("u1DiskStorageUtilisationPercentage")


vAddClass("sDR_STATUS_REPORT_UNSOL_PL", sDR_STATUS_REPORT_UNSOL_PL)


class sDR_RECORDING_STATE_CMD_PL(clsAdcsMessageStructType):
    """Public class definition of type sDR_RECORDING_STATE_CMD_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.e1RecordingState = E1_DR_RECORDING_STATE(E1_DR_RECORDING_STATE.DR_RECORDING_STATE_RECORDING_ACTIVE)
        self.vAddType("e1RecordingState")


vAddClass("sDR_RECORDING_STATE_CMD_PL", sDR_RECORDING_STATE_CMD_PL)


class sDR_RECORDING_STATE_CMD_RSP_PL(clsAdcsMessageStructType):
    """Public class definition of type sDR_RECORDING_STATE_CMD_RSP_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.e1RecordingState = E1_DR_RECORDING_STATE(E1_DR_RECORDING_STATE.DR_RECORDING_STATE_RECORDING_ACTIVE)
        self.vAddType("e1RecordingState")


vAddClass("sDR_RECORDING_STATE_CMD_RSP_PL", sDR_RECORDING_STATE_CMD_RSP_PL)


# PAYLOADS END

# MESSAGES START
class sDR_STATUS_REPORT_UNSOL(clsAdcsMessageType):
    """Public class definition of type sDR_STATUS_REPORT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sDR_STATUS_REPORT_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sDR_STATUS_REPORT_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sDR_STATUS_REPORT_UNSOL", sDR_STATUS_REPORT_UNSOL)


class sDR_END_OF_SETUP_CMD(clsAdcsMessageType):
    """Public class definition of type sDR_END_OF_SETUP_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sDR_END_OF_SETUP_CMD_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sDR_END_OF_SETUP_CMD", sDR_END_OF_SETUP_CMD)


class sDR_END_OF_SETUP_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sDR_END_OF_SETUP_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sDR_END_OF_SETUP_CMD_RSP_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sDR_END_OF_SETUP_CMD_RSP", sDR_END_OF_SETUP_CMD_RSP)


class sDR_END_OF_READY_CMD(clsAdcsMessageType):
    """Public class definition of type sDR_END_OF_READY_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sDR_END_OF_READY_CMD_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sDR_END_OF_READY_CMD", sDR_END_OF_READY_CMD)


class sDR_END_OF_READY_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sDR_END_OF_READY_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sDR_END_OF_READY_CMD_RSP_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sDR_END_OF_READY_CMD_RSP", sDR_END_OF_READY_CMD_RSP)


class sDR_SHUTDOWN_CMD(clsAdcsMessageType):
    """Public class definition of type sDR_SHUTDOWN_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sDR_SHUTDOWN_CMD_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sDR_SHUTDOWN_CMD", sDR_SHUTDOWN_CMD)


class sDR_SHUTDOWN_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sDR_SHUTDOWN_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sDR_SHUTDOWN_CMD_RSP_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sDR_SHUTDOWN_CMD_RSP", sDR_SHUTDOWN_CMD_RSP)


class sDR_RECORDING_STATE_CMD(clsAdcsMessageType):
    """Public class definition of type sDR_RECORDING_STATE_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sDR_RECORDING_STATE_CMD_MESSAGE_HEADER()
        self.sMsgPayload = sDR_RECORDING_STATE_CMD_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sDR_RECORDING_STATE_CMD", sDR_RECORDING_STATE_CMD)


class sDR_RECORDING_STATE_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sDR_RECORDING_STATE_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sDR_RECORDING_STATE_CMD_RSP_MESSAGE_HEADER()
        self.sMsgPayload = sDR_RECORDING_STATE_CMD_RSP_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sDR_RECORDING_STATE_CMD_RSP", sDR_RECORDING_STATE_CMD_RSP)


class sDR_CLEAR_RECORDING_DATABASE_CMD(clsAdcsMessageType):
    """Public class definition of type sDR_CLEAR_RECORDING_DATABASE_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sDR_CLEAR_RECORDING_DATABASE_CMD_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sDR_CLEAR_RECORDING_DATABASE_CMD", sDR_CLEAR_RECORDING_DATABASE_CMD)


class sDR_CLEAR_RECORDING_DATABASE_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sDR_CLEAR_RECORDING_DATABASE_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sDR_CLEAR_RECORDING_DATABASE_CMD_RSP_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sDR_CLEAR_RECORDING_DATABASE_CMD_RSP", sDR_CLEAR_RECORDING_DATABASE_CMD_RSP)


# MESSAGES END




