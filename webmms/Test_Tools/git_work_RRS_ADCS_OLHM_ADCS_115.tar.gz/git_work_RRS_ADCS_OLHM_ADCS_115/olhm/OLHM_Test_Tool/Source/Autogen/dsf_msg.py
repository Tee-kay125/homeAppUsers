#!/usr/bin/env python3.6
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:32:28 SAST
"""


from Autogen.adcs_base_types import clsAdcsBaseType
from Autogen.adcs_base_types import clsAdcsEnumType
from Autogen.adcs_base_types import clsAdcsEnumArrayType
from Autogen.adcs_base_types import clsAdcsStructType
from Autogen.adcs_base_types import clsAdcsStructArrayType
from Autogen.adcs_base_types import clsAdcsMessageType
from Autogen.adcs_base_types import vAddEnum
from Autogen.adcs_base_types import vAddClass
from Autogen.adcs_base_types import vAddMessage
from Autogen.adcs_base_types import clsAdcsHeaderStructType
from Autogen.adcs_base_types import clsAdcsMessageStructType

# IMPORT CODE START
from Autogen.mw_common_types import *
from Autogen.adcs_common_types import *
# IMPORT CODE END


# MESSAGE HEADERS START
class sDSF_STATUS_REPORT_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sDSF_STATUS_REPORT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_DSF)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0000)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sDSF_STATUS_REPORT_UNSOL_MESSAGE_HEADER", sDSF_STATUS_REPORT_UNSOL_MESSAGE_HEADER)


class sADCS_REMOTE_SENSOR_POINT_TRACK_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sADCS_REMOTE_SENSOR_POINT_TRACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_DSF)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0010)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sADCS_REMOTE_SENSOR_POINT_TRACK_UNSOL_MESSAGE_HEADER", sADCS_REMOTE_SENSOR_POINT_TRACK_UNSOL_MESSAGE_HEADER)


class sADCS_REMOTE_SENSOR_BEARING_TRACK_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sADCS_REMOTE_SENSOR_BEARING_TRACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_DSF)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0011)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sADCS_REMOTE_SENSOR_BEARING_TRACK_UNSOL_MESSAGE_HEADER", sADCS_REMOTE_SENSOR_BEARING_TRACK_UNSOL_MESSAGE_HEADER)


class sADCS_ENGAGEMENT_FEEDBACK_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sADCS_ENGAGEMENT_FEEDBACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_DSF)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0050)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sADCS_ENGAGEMENT_FEEDBACK_UNSOL_MESSAGE_HEADER", sADCS_ENGAGEMENT_FEEDBACK_UNSOL_MESSAGE_HEADER)


class sADCS_ENGAGEMENT_VETO_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sADCS_ENGAGEMENT_VETO_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_DSF)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0051)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sADCS_ENGAGEMENT_VETO_UNSOL_MESSAGE_HEADER", sADCS_ENGAGEMENT_VETO_UNSOL_MESSAGE_HEADER)


class sADCS_CONSOLIDATED_DEPLOYMENT_DATA_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sADCS_CONSOLIDATED_DEPLOYMENT_DATA_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_DSF)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0060)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sADCS_CONSOLIDATED_DEPLOYMENT_DATA_UNSOL_MESSAGE_HEADER", sADCS_CONSOLIDATED_DEPLOYMENT_DATA_UNSOL_MESSAGE_HEADER)


class sADCS_CONSOLIDATED_AIR_ZONES_AND_LANES_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sADCS_CONSOLIDATED_AIR_ZONES_AND_LANES_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_DSF)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0061)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sADCS_CONSOLIDATED_AIR_ZONES_AND_LANES_UNSOL_MESSAGE_HEADER", sADCS_CONSOLIDATED_AIR_ZONES_AND_LANES_UNSOL_MESSAGE_HEADER)


class sADCS_CONSOLIDATED_ADCM_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sADCS_CONSOLIDATED_ADCM_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_DSF)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0062)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sADCS_CONSOLIDATED_ADCM_UNSOL_MESSAGE_HEADER", sADCS_CONSOLIDATED_ADCM_UNSOL_MESSAGE_HEADER)


# MESSAGE HEADERS END

# PAYLOADS START
class sDSF_STATUS_REPORT_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sDSF_STATUS_REPORT_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sModuleInfo = sADCS_MODULE_INFO()
        self.vAddType("sModuleInfo")
        self.sModuleState = sADCS_MODULE_STATE()
        self.vAddType("sModuleState")


vAddClass("sDSF_STATUS_REPORT_UNSOL_PL", sDSF_STATUS_REPORT_UNSOL_PL)


class sADCS_REMOTE_SENSOR_POINT_TRACK_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sADCS_REMOTE_SENSOR_POINT_TRACK_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4TrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4TrackNumber")
        self.sDescription = sADCS_STRING24()
        self.vAddType("sDescription")
        self.u4OriginTrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4OriginTrackNumber")
        self.sKinematics = sADCS_SENSOR_TRACK_KINEMATICS()
        self.vAddType("sKinematics")
        self.sClassification = sADCS_CLASSIFICATION()
        self.vAddType("sClassification")
        self.sIdentification = sADCS_IDENTIFICATION()
        self.vAddType("sIdentification")
        self.sTrackQuality = sADCS_QVALUE()
        self.vAddType("sTrackQuality")
        self.e1Delete = E1_MW_BOOLEAN_ENUM(E1_MW_BOOLEAN_ENUM.MW_BOOLEAN_FALSE)
        self.vAddType("e1Delete")


vAddClass("sADCS_REMOTE_SENSOR_POINT_TRACK_UNSOL_PL", sADCS_REMOTE_SENSOR_POINT_TRACK_UNSOL_PL)


class sADCS_REMOTE_SENSOR_BEARING_TRACK_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sADCS_REMOTE_SENSOR_BEARING_TRACK_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4TrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4TrackNumber")
        self.sDescription = sADCS_STRING24()
        self.vAddType("sDescription")
        self.u4OriginTrackNumber = clsAdcsBaseType("U4", 0)
        self.vAddType("u4OriginTrackNumber")
        self.sKinematics = sADCS_SENSOR_TRACK_KINEMATICS()
        self.vAddType("sKinematics")
        self.sClassification = sADCS_CLASSIFICATION()
        self.vAddType("sClassification")
        self.sIdentification = sADCS_IDENTIFICATION()
        self.vAddType("sIdentification")
        self.sTrackQuality = sADCS_QVALUE()
        self.vAddType("sTrackQuality")
        self.e1Delete = E1_MW_BOOLEAN_ENUM(E1_MW_BOOLEAN_ENUM.MW_BOOLEAN_FALSE)
        self.vAddType("e1Delete")


vAddClass("sADCS_REMOTE_SENSOR_BEARING_TRACK_UNSOL_PL", sADCS_REMOTE_SENSOR_BEARING_TRACK_UNSOL_PL)


class sADCS_ENGAGEMENT_FEEDBACK_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sADCS_ENGAGEMENT_FEEDBACK_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4EngagementId = clsAdcsBaseType("U4", 0)
        self.vAddType("u4EngagementId")
        self.e1FeedbackStatus = E1_ADCS_FEEDBACK_STATUS(E1_ADCS_FEEDBACK_STATUS.NOFEEDBACK_FB)
        self.vAddType("e1FeedbackStatus")


vAddClass("sADCS_ENGAGEMENT_FEEDBACK_UNSOL_PL", sADCS_ENGAGEMENT_FEEDBACK_UNSOL_PL)


class sADCS_ENGAGEMENT_VETO_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sADCS_ENGAGEMENT_VETO_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4EngagementId = clsAdcsBaseType("U4", 0)
        self.vAddType("u4EngagementId")


vAddClass("sADCS_ENGAGEMENT_VETO_UNSOL_PL", sADCS_ENGAGEMENT_VETO_UNSOL_PL)


class sADCS_CONSOLIDATED_DEPLOYMENT_DATA_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sADCS_CONSOLIDATED_DEPLOYMENT_DATA_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.sAorCentre = sADCS_AOR_CENTRE()
        self.vAddType("sAorCentre")
        self.u4EffectorCount = clsAdcsBaseType("U4", 0)
        self.u4EffectorCount.vSetMax(100)
        self.vAddType("u4EffectorCount")
        self.asEffector = clsAdcsStructArrayType("sADCS_EFFECTOR:100")
        self.vAddType("asEffector")
        self.u4AssetCount = clsAdcsBaseType("U4", 0)
        self.u4AssetCount.vSetMax(100)
        self.vAddType("u4AssetCount")
        self.asAsset = clsAdcsStructArrayType("sADCS_ASSET:100")
        self.vAddType("asAsset")
        self.u4SensorCount = clsAdcsBaseType("U4", 0)
        self.u4SensorCount.vSetMax(100)
        self.vAddType("u4SensorCount")
        self.asSensor = clsAdcsStructArrayType("sADCS_SENSOR:100")
        self.vAddType("asSensor")
        self.u4OpCount = clsAdcsBaseType("U4", 0)
        self.u4OpCount.vSetMax(100)
        self.vAddType("u4OpCount")
        self.asOp = clsAdcsStructArrayType("sADCS_OBSERVATION_POST:100")
        self.vAddType("asOp")
        self.u4PhysicalElementCount = clsAdcsBaseType("U4", 0)
        self.u4PhysicalElementCount.vSetMax(100)
        self.vAddType("u4PhysicalElementCount")
        self.asPhysicalElement = clsAdcsStructArrayType("sADCS_PHYSICAL_ELEMENT:100")
        self.vAddType("asPhysicalElement")


vAddClass("sADCS_CONSOLIDATED_DEPLOYMENT_DATA_UNSOL_PL", sADCS_CONSOLIDATED_DEPLOYMENT_DATA_UNSOL_PL)


class sADCS_CONSOLIDATED_AIR_ZONES_AND_LANES_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sADCS_CONSOLIDATED_AIR_ZONES_AND_LANES_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.u4AscmCircularCount = clsAdcsBaseType("U4", 0)
        self.u4AscmCircularCount.vSetMax(100)
        self.vAddType("u4AscmCircularCount")
        self.asAscmCircular = clsAdcsStructArrayType("sADCS_AIR_ZONE_CIRCULAR:100")
        self.vAddType("asAscmCircular")
        self.u4AscmPolygonCount = clsAdcsBaseType("U4", 0)
        self.u4AscmPolygonCount.vSetMax(100)
        self.vAddType("u4AscmPolygonCount")
        self.asAscmPolygon = clsAdcsStructArrayType("sADCS_AIR_ZONE_POLYGON:100")
        self.vAddType("asAscmPolygon")
        self.u4AscmFlightLaneCount = clsAdcsBaseType("U4", 0)
        self.u4AscmFlightLaneCount.vSetMax(100)
        self.vAddType("u4AscmFlightLaneCount")
        self.asAscmFlightLane = clsAdcsStructArrayType("sADCS_AIR_LANE:100")
        self.vAddType("asAscmFlightLane")
        self.u4AscmIffLineCount = clsAdcsBaseType("U4", 0)
        self.u4AscmIffLineCount.vSetMax(100)
        self.vAddType("u4AscmIffLineCount")
        self.asAscmIffLine = clsAdcsStructArrayType("sADCS_IFF_LINE:100")
        self.vAddType("asAscmIffLine")
        self.u4FscmSafeFlyingTunnelCount = clsAdcsBaseType("U4", 0)
        self.u4FscmSafeFlyingTunnelCount.vSetMax(100)
        self.vAddType("u4FscmSafeFlyingTunnelCount")
        self.asFscmSafeFlyingTunnel = clsAdcsStructArrayType("sADCS_AIR_LANE:100")
        self.vAddType("asFscmSafeFlyingTunnel")
        self.u4FscmSafeFlyingZoneCount = clsAdcsBaseType("U4", 0)
        self.u4FscmSafeFlyingZoneCount.vSetMax(100)
        self.vAddType("u4FscmSafeFlyingZoneCount")
        self.asFscmSafeFlyingZone = clsAdcsStructArrayType("sADCS_AIR_LANE:100")
        self.vAddType("asFscmSafeFlyingZone")
        self.u4FlightPlanCount = clsAdcsBaseType("U4", 0)
        self.u4FlightPlanCount.vSetMax(100)
        self.vAddType("u4FlightPlanCount")
        self.asFlightPlan = clsAdcsStructArrayType("sADCS_FLIGHT_PLAN:100")
        self.vAddType("asFlightPlan")


vAddClass("sADCS_CONSOLIDATED_AIR_ZONES_AND_LANES_UNSOL_PL", sADCS_CONSOLIDATED_AIR_ZONES_AND_LANES_UNSOL_PL)


class sADCS_CONSOLIDATED_ADCM_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sADCS_CONSOLIDATED_ADCM_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sTimestamp = sADCS_TIMESTAMP()
        self.vAddType("sTimestamp")
        self.sWco = sADCS_WCO()
        self.vAddType("sWco")
        self.sAdrs = sADCS_ADRS()
        self.vAddType("sAdrs")
        self.sArws = sADCS_ARWS()
        self.vAddType("sArws")


vAddClass("sADCS_CONSOLIDATED_ADCM_UNSOL_PL", sADCS_CONSOLIDATED_ADCM_UNSOL_PL)


# PAYLOADS END

# MESSAGES START
class sDSF_STATUS_REPORT_UNSOL(clsAdcsMessageType):
    """Public class definition of type sDSF_STATUS_REPORT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sDSF_STATUS_REPORT_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sDSF_STATUS_REPORT_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sDSF_STATUS_REPORT_UNSOL", sDSF_STATUS_REPORT_UNSOL)


class sADCS_REMOTE_SENSOR_POINT_TRACK_UNSOL(clsAdcsMessageType):
    """Public class definition of type sADCS_REMOTE_SENSOR_POINT_TRACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sADCS_REMOTE_SENSOR_POINT_TRACK_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sADCS_REMOTE_SENSOR_POINT_TRACK_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sADCS_REMOTE_SENSOR_POINT_TRACK_UNSOL", sADCS_REMOTE_SENSOR_POINT_TRACK_UNSOL)


class sADCS_REMOTE_SENSOR_BEARING_TRACK_UNSOL(clsAdcsMessageType):
    """Public class definition of type sADCS_REMOTE_SENSOR_BEARING_TRACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sADCS_REMOTE_SENSOR_BEARING_TRACK_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sADCS_REMOTE_SENSOR_BEARING_TRACK_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sADCS_REMOTE_SENSOR_BEARING_TRACK_UNSOL", sADCS_REMOTE_SENSOR_BEARING_TRACK_UNSOL)


class sADCS_ENGAGEMENT_FEEDBACK_UNSOL(clsAdcsMessageType):
    """Public class definition of type sADCS_ENGAGEMENT_FEEDBACK_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sADCS_ENGAGEMENT_FEEDBACK_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sADCS_ENGAGEMENT_FEEDBACK_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sADCS_ENGAGEMENT_FEEDBACK_UNSOL", sADCS_ENGAGEMENT_FEEDBACK_UNSOL)


class sADCS_ENGAGEMENT_VETO_UNSOL(clsAdcsMessageType):
    """Public class definition of type sADCS_ENGAGEMENT_VETO_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sADCS_ENGAGEMENT_VETO_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sADCS_ENGAGEMENT_VETO_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sADCS_ENGAGEMENT_VETO_UNSOL", sADCS_ENGAGEMENT_VETO_UNSOL)


class sADCS_CONSOLIDATED_DEPLOYMENT_DATA_UNSOL(clsAdcsMessageType):
    """Public class definition of type sADCS_CONSOLIDATED_DEPLOYMENT_DATA_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sADCS_CONSOLIDATED_DEPLOYMENT_DATA_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sADCS_CONSOLIDATED_DEPLOYMENT_DATA_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sADCS_CONSOLIDATED_DEPLOYMENT_DATA_UNSOL", sADCS_CONSOLIDATED_DEPLOYMENT_DATA_UNSOL)


class sADCS_CONSOLIDATED_AIR_ZONES_AND_LANES_UNSOL(clsAdcsMessageType):
    """Public class definition of type sADCS_CONSOLIDATED_AIR_ZONES_AND_LANES_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sADCS_CONSOLIDATED_AIR_ZONES_AND_LANES_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sADCS_CONSOLIDATED_AIR_ZONES_AND_LANES_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sADCS_CONSOLIDATED_AIR_ZONES_AND_LANES_UNSOL", sADCS_CONSOLIDATED_AIR_ZONES_AND_LANES_UNSOL)


class sADCS_CONSOLIDATED_ADCM_UNSOL(clsAdcsMessageType):
    """Public class definition of type sADCS_CONSOLIDATED_ADCM_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sADCS_CONSOLIDATED_ADCM_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sADCS_CONSOLIDATED_ADCM_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sADCS_CONSOLIDATED_ADCM_UNSOL", sADCS_CONSOLIDATED_ADCM_UNSOL)


# MESSAGES END




