#!/usr/bin/env python3.6
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:32:28 SAST
"""


from Autogen.adcs_base_types import clsAdcsBaseType
from Autogen.adcs_base_types import clsAdcsEnumType
from Autogen.adcs_base_types import clsAdcsEnumArrayType
from Autogen.adcs_base_types import clsAdcsStructType
from Autogen.adcs_base_types import clsAdcsStructArrayType
from Autogen.adcs_base_types import clsAdcsMessageType
from Autogen.adcs_base_types import vAddEnum
from Autogen.adcs_base_types import vAddClass
from Autogen.adcs_base_types import vAddMessage
from Autogen.adcs_base_types import clsAdcsHeaderStructType
from Autogen.adcs_base_types import clsAdcsMessageStructType

# IMPORT CODE START
from Autogen.mw_common_types import *
from Autogen.adcs_common_types import *
# IMPORT CODE END

# TYPEDEFS START
class E1_PDBP_STORAGE_STATE(clsAdcsEnumType):
    """Public class definition of type E1_PDBP_STORAGE_STATE
    """
    def __init__(self, defaultValue=0):
        super().__init__("U1", defaultValue)
    PDBP_STORAGE_STATE_STORE_MESSAGES = 0x00
    PDBP_STORAGE_STATE_DO_NOT_STORE_MESSAGES = 0x01


vAddEnum("E1_PDBP_STORAGE_STATE", E1_PDBP_STORAGE_STATE)


class E1_PDBP_STATUS(clsAdcsEnumType):
    """Public class definition of type E1_PDBP_STATUS
    """
    def __init__(self, defaultValue=0):
        super().__init__("U1", defaultValue)
    PDBP_STATUS_FAILED = 0x00
    PDBP_STATUS_PASSED = 0x01


vAddEnum("E1_PDBP_STATUS", E1_PDBP_STATUS)


# TYPEDEFS END

# MESSAGE HEADERS START
class sPDBP_STATUS_REPORT_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sPDBP_STATUS_REPORT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_PDBP)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0000)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sPDBP_STATUS_REPORT_UNSOL_MESSAGE_HEADER", sPDBP_STATUS_REPORT_UNSOL_MESSAGE_HEADER)


class sPDBP_END_OF_READY_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sPDBP_END_OF_READY_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_PDBP)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0002)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sPDBP_END_OF_READY_CMD_MESSAGE_HEADER", sPDBP_END_OF_READY_CMD_MESSAGE_HEADER)


class sPDBP_END_OF_READY_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sPDBP_END_OF_READY_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_PDBP)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0002)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sPDBP_END_OF_READY_CMD_RSP_MESSAGE_HEADER", sPDBP_END_OF_READY_CMD_RSP_MESSAGE_HEADER)


class sPDBP_SHUTDOWN_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sPDBP_SHUTDOWN_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_PDBP)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0003)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sPDBP_SHUTDOWN_CMD_MESSAGE_HEADER", sPDBP_SHUTDOWN_CMD_MESSAGE_HEADER)


class sPDBP_SHUTDOWN_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sPDBP_SHUTDOWN_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_PDBP)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0003)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sPDBP_SHUTDOWN_CMD_RSP_MESSAGE_HEADER", sPDBP_SHUTDOWN_CMD_RSP_MESSAGE_HEADER)


class sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_PDBP)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0010)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_MESSAGE_HEADER", sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_MESSAGE_HEADER)


class sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_PDBP)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0010)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP_MESSAGE_HEADER", sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP_MESSAGE_HEADER)


class sPDBP_STORAGE_STATE_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sPDBP_STORAGE_STATE_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_PDBP)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0011)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sPDBP_STORAGE_STATE_CMD_MESSAGE_HEADER", sPDBP_STORAGE_STATE_CMD_MESSAGE_HEADER)


class sPDBP_STORAGE_STATE_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sPDBP_STORAGE_STATE_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_PDBP)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0011)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sPDBP_STORAGE_STATE_CMD_RSP_MESSAGE_HEADER", sPDBP_STORAGE_STATE_CMD_RSP_MESSAGE_HEADER)


class sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_PDBP)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0012)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD_MESSAGE_HEADER", sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD_MESSAGE_HEADER)


class sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_PDBP)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0012)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD_RSP_MESSAGE_HEADER", sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD_RSP_MESSAGE_HEADER)


class sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_PDBP)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0013)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_MESSAGE_HEADER", sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_MESSAGE_HEADER)


class sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_PDBP)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0013)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_RSP_MESSAGE_HEADER", sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_RSP_MESSAGE_HEADER)


class sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_PDBP)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0014)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_MESSAGE_HEADER", sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_MESSAGE_HEADER)


class sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_PDBP)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0014)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_RSP_MESSAGE_HEADER", sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_RSP_MESSAGE_HEADER)


# MESSAGE HEADERS END

# PAYLOADS START
class sPDBP_STATUS_REPORT_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sPDBP_STATUS_REPORT_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sModuleInfo = sADCS_MODULE_INFO()
        self.vAddType("sModuleInfo")
        self.sModuleState = sADCS_MODULE_STATE()
        self.vAddType("sModuleState")
        self.e1OverallStatus = E1_PDBP_STATUS(E1_PDBP_STATUS.PDBP_STATUS_FAILED)
        self.vAddType("e1OverallStatus")
        self.acLatestMessageValidationError = clsAdcsBaseType("CH:256","")
        self.vAddType("acLatestMessageValidationError")


vAddClass("sPDBP_STATUS_REPORT_UNSOL_PL", sPDBP_STATUS_REPORT_UNSOL_PL)


class sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_PL(clsAdcsMessageStructType):
    """Public class definition of type sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.acModuleName = clsAdcsBaseType("CH:64","")
        self.vAddType("acModuleName")
        self.e1CompletedSuccessfully = E1_ADCS_BOOLEAN(E1_ADCS_BOOLEAN.ADCS_BOOLEAN_FALSE)
        self.vAddType("e1CompletedSuccessfully")


vAddClass("sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_PL", sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_PL)


class sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP_PL(clsAdcsMessageStructType):
    """Public class definition of type sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.acModuleName = clsAdcsBaseType("CH:64","")
        self.vAddType("acModuleName")
        self.e1CompletedSuccessfully = E1_ADCS_BOOLEAN(E1_ADCS_BOOLEAN.ADCS_BOOLEAN_FALSE)
        self.vAddType("e1CompletedSuccessfully")


vAddClass("sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP_PL", sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP_PL)


class sPDBP_STORAGE_STATE_CMD_PL(clsAdcsMessageStructType):
    """Public class definition of type sPDBP_STORAGE_STATE_CMD_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.e1StorageState = E1_PDBP_STORAGE_STATE(E1_PDBP_STORAGE_STATE.PDBP_STORAGE_STATE_STORE_MESSAGES)
        self.vAddType("e1StorageState")


vAddClass("sPDBP_STORAGE_STATE_CMD_PL", sPDBP_STORAGE_STATE_CMD_PL)


class sPDBP_STORAGE_STATE_CMD_RSP_PL(clsAdcsMessageStructType):
    """Public class definition of type sPDBP_STORAGE_STATE_CMD_RSP_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.e1StorageState = E1_PDBP_STORAGE_STATE(E1_PDBP_STORAGE_STATE.PDBP_STORAGE_STATE_STORE_MESSAGES)
        self.vAddType("e1StorageState")


vAddClass("sPDBP_STORAGE_STATE_CMD_RSP_PL", sPDBP_STORAGE_STATE_CMD_RSP_PL)


class sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_PL(clsAdcsMessageStructType):
    """Public class definition of type sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.acJsonExportFilename = clsAdcsBaseType("CH:256","")
        self.vAddType("acJsonExportFilename")
        self.e1CompletedSuccessfully = E1_ADCS_BOOLEAN(E1_ADCS_BOOLEAN.ADCS_BOOLEAN_FALSE)
        self.vAddType("e1CompletedSuccessfully")


vAddClass("sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_PL", sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_PL)


class sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_RSP_PL(clsAdcsMessageStructType):
    """Public class definition of type sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_RSP_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.acJsonExportFilename = clsAdcsBaseType("CH:256","")
        self.vAddType("acJsonExportFilename")
        self.e1CompletedSuccessfully = E1_ADCS_BOOLEAN(E1_ADCS_BOOLEAN.ADCS_BOOLEAN_FALSE)
        self.vAddType("e1CompletedSuccessfully")


vAddClass("sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_RSP_PL", sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_RSP_PL)


class sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_PL(clsAdcsMessageStructType):
    """Public class definition of type sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.acJsonFilenameToUpload = clsAdcsBaseType("CH:256","")
        self.vAddType("acJsonFilenameToUpload")
        self.e1CompletedSuccessfully = E1_ADCS_BOOLEAN(E1_ADCS_BOOLEAN.ADCS_BOOLEAN_FALSE)
        self.vAddType("e1CompletedSuccessfully")


vAddClass("sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_PL", sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_PL)


class sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_RSP_PL(clsAdcsMessageStructType):
    """Public class definition of type sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_RSP_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.acJsonFilenameToUpload = clsAdcsBaseType("CH:256","")
        self.vAddType("acJsonFilenameToUpload")
        self.e1CompletedSuccessfully = E1_ADCS_BOOLEAN(E1_ADCS_BOOLEAN.ADCS_BOOLEAN_FALSE)
        self.vAddType("e1CompletedSuccessfully")


vAddClass("sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_RSP_PL", sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_RSP_PL)


# PAYLOADS END

# MESSAGES START
class sPDBP_STATUS_REPORT_UNSOL(clsAdcsMessageType):
    """Public class definition of type sPDBP_STATUS_REPORT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sPDBP_STATUS_REPORT_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sPDBP_STATUS_REPORT_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sPDBP_STATUS_REPORT_UNSOL", sPDBP_STATUS_REPORT_UNSOL)


class sPDBP_END_OF_READY_CMD(clsAdcsMessageType):
    """Public class definition of type sPDBP_END_OF_READY_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sPDBP_END_OF_READY_CMD_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sPDBP_END_OF_READY_CMD", sPDBP_END_OF_READY_CMD)


class sPDBP_END_OF_READY_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sPDBP_END_OF_READY_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sPDBP_END_OF_READY_CMD_RSP_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sPDBP_END_OF_READY_CMD_RSP", sPDBP_END_OF_READY_CMD_RSP)


class sPDBP_SHUTDOWN_CMD(clsAdcsMessageType):
    """Public class definition of type sPDBP_SHUTDOWN_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sPDBP_SHUTDOWN_CMD_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sPDBP_SHUTDOWN_CMD", sPDBP_SHUTDOWN_CMD)


class sPDBP_SHUTDOWN_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sPDBP_SHUTDOWN_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sPDBP_SHUTDOWN_CMD_RSP_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sPDBP_SHUTDOWN_CMD_RSP", sPDBP_SHUTDOWN_CMD_RSP)


class sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD(clsAdcsMessageType):
    """Public class definition of type sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_MESSAGE_HEADER()
        self.sMsgPayload = sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD", sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD)


class sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP_MESSAGE_HEADER()
        self.sMsgPayload = sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP", sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP)


class sPDBP_STORAGE_STATE_CMD(clsAdcsMessageType):
    """Public class definition of type sPDBP_STORAGE_STATE_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sPDBP_STORAGE_STATE_CMD_MESSAGE_HEADER()
        self.sMsgPayload = sPDBP_STORAGE_STATE_CMD_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sPDBP_STORAGE_STATE_CMD", sPDBP_STORAGE_STATE_CMD)


class sPDBP_STORAGE_STATE_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sPDBP_STORAGE_STATE_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sPDBP_STORAGE_STATE_CMD_RSP_MESSAGE_HEADER()
        self.sMsgPayload = sPDBP_STORAGE_STATE_CMD_RSP_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sPDBP_STORAGE_STATE_CMD_RSP", sPDBP_STORAGE_STATE_CMD_RSP)


class sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD(clsAdcsMessageType):
    """Public class definition of type sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD", sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD)


class sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD_RSP_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD_RSP", sPDBP_LOAD_FACTORY_PERSISTENT_PARAMETERS_CMD_RSP)


class sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD(clsAdcsMessageType):
    """Public class definition of type sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_MESSAGE_HEADER()
        self.sMsgPayload = sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD", sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD)


class sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_RSP_MESSAGE_HEADER()
        self.sMsgPayload = sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_RSP_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_RSP", sPDBP_EXPORT_PDB_TO_JSON_FILE_CMD_RSP)


class sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD(clsAdcsMessageType):
    """Public class definition of type sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_MESSAGE_HEADER()
        self.sMsgPayload = sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD", sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD)


class sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_RSP_MESSAGE_HEADER()
        self.sMsgPayload = sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_RSP_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_RSP", sPDBP_UPLOAD_JSON_FILE_INTO_PPDB_CMD_RSP)


# MESSAGES END




