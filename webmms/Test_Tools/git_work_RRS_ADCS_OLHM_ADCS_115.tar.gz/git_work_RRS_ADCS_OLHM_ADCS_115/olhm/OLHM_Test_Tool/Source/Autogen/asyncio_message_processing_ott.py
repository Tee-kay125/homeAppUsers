#! /usr/bin/env python
# -*- coding: utf-8 -*-
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:29:15 SAST

    This module is the asyncio message processing class generated automatically from XML file(s). It is intended use is as a base class
    for a derived class which will be used in the asyncio event loop. The vProcessDictObj() method should only be called inside the
    asyncio event loop and using a create_task() call. Failure to do so might block the process currently running and should only be used
    as intended in a well designed asyncio implementation.

"""
# ==========================================================
# AUTOGEN START
# ==========================================================
import logging  # This is required to be able to log if there are problems
import asyncio  # This is required to concurrent operations in a single thread
import datetime  # This is needed to set a datetime result on a future
import time  # This is needed to get the time as time.CLOCK_MONOTONIC_RAW
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
from Autogen.mw_common_types import E2_MW_MESSAGE_STATUS
from Autogen.mms_msg import *  # noqa: F401
from Autogen.olhm_msg import *  # noqa: F401
from Autogen.dr_msg import *  # noqa: F401
from Autogen.sf3_msg import *  # noqa: F401
from Autogen.dsf_msg import *  # noqa: F401
from Autogen.tewa_msg import *  # noqa: F401
from Autogen.pdbp_msg import *  # noqa: F401
from Autogen.sf2_msg import *  # noqa: F401
from Autogen.hmi_msg import *  # noqa: F401
from Autogen.eiu_msg import *  # noqa: F401
from Autogen.tm_msg import *  # noqa: F401
from Autogen.sf1_msg import *  # noqa: F401

# ==========================================================
# MQTT TEMPLATE CLASS START
# ==========================================================


class clsPythonAsyncioMessageProcessing():
    """ This is the message asyncio processing autogen class

    This is the message processing asyncio autogen class. Inherit this class in order to
    override the methods if required.

    Args:
        objMqttClientPar (mqtt.Client): The first parameter. The MQTT client instance for sending to the broker.
        dctMessagesPar (dict): The second parameter. A dictionary containing all messages and futures for messages which were automatically processed by the autogen
        lstTasksAllowedForsimultaneousExecutionPar (list): The third parameter. A list of topics for which simultaneous task execution is allowed. An empty list means no topics are allowed to execute simultaneously.
        objAsyncioLoopPar (object): The fourth parameter. The asyncio loop passed in so tasks can be created and for other asyncio functionality
        bLoggingEnabledPar (bool): The fifth parameter. A boolean flag indicating if logging should be done or not.

    """
    def __init__(self, objMqttClientPar: mqtt.Client, dctMessagesPar: dict, lstTasksAllowedForsimultaneousExecutionPar: list, objAsyncioLoopPar: object, bLoggingEnabledPar: bool = True):
        super().__init__()
        self._objMqttClient = objMqttClientPar
        self._dctMessages = dctMessagesPar
        self._lstTasksAllowedForsimultaneousExecution = lstTasksAllowedForsimultaneousExecutionPar
        self._objAsyncioLoop = objAsyncioLoopPar
        self._bLoggingEnabled = bLoggingEnabledPar
        # When we mqtt publish the connection state is returned - This property stores the last state
        self._tplPublishConnectionStateLast = (mqtt.MQTT_ERR_SUCCESS, 0)
        # When we mqtt publish the connection state is returned - This property stores the first time it failed 
        self._tplPublishConnectionStateFirstFail = (mqtt.MQTT_ERR_SUCCESS, 0)

        # In the message dictionary we store the Topic, ClassName, Class, MsgObject, Future, UTC timestamp, monotonic raw timestamp and role
        self._dctMessages["ADCS/DR/DrStatusReportUnsol"] = {"ClassName": "sDR_STATUS_REPORT_UNSOL", "Class": sDR_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"] = {"ClassName": "sDR_END_OF_SETUP_CMD_RSP", "Class": sDR_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"] = {"ClassName": "sDR_END_OF_READY_CMD_RSP", "Class": sDR_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/DR/DrShutdownCmdRsp"] = {"ClassName": "sDR_SHUTDOWN_CMD_RSP", "Class": sDR_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/PDBP/PdbpStatusReportUnsol"] = {"ClassName": "sPDBP_STATUS_REPORT_UNSOL", "Class": sPDBP_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmdRsp"] = {"ClassName": "sPDBP_END_OF_READY_CMD_RSP", "Class": sPDBP_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/PDBP/PdbpShutdownCmdRsp"] = {"ClassName": "sPDBP_SHUTDOWN_CMD_RSP", "Class": sPDBP_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp"] = {"ClassName": "sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP", "Class": sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"] = {"ClassName": "sEIU_STATUS_REPORT_UNSOL", "Class": sEIU_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"] = {"ClassName": "sEIU_END_OF_SETUP_CMD_RSP", "Class": sEIU_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"] = {"ClassName": "sEIU_END_OF_READY_CMD_RSP", "Class": sEIU_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"] = {"ClassName": "sEIU_SHUTDOWN_CMD_RSP", "Class": sEIU_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TM/TmStatusReportUnsol"] = {"ClassName": "sTM_STATUS_REPORT_UNSOL", "Class": sTM_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"] = {"ClassName": "sTM_END_OF_SETUP_CMD_RSP", "Class": sTM_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"] = {"ClassName": "sTM_END_OF_READY_CMD_RSP", "Class": sTM_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TM/TmShutdownCmdRsp"] = {"ClassName": "sTM_SHUTDOWN_CMD_RSP", "Class": sTM_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TEWA/TewaStatusReportUnsol"] = {"ClassName": "sTEWA_STATUS_REPORT_UNSOL", "Class": sTEWA_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmdRsp"] = {"ClassName": "sTEWA_END_OF_SETUP_CMD_RSP", "Class": sTEWA_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmdRsp"] = {"ClassName": "sTEWA_END_OF_READY_CMD_RSP", "Class": sTEWA_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TEWA/TewaShutdownCmdRsp"] = {"ClassName": "sTEWA_SHUTDOWN_CMD_RSP", "Class": sTEWA_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF1/Sf1StatusReportUnsol"] = {"ClassName": "sSF1_STATUS_REPORT_UNSOL", "Class": sSF1_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmdRsp"] = {"ClassName": "sSF1_END_OF_SETUP_CMD_RSP", "Class": sSF1_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmdRsp"] = {"ClassName": "sSF1_END_OF_READY_CMD_RSP", "Class": sSF1_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF1/Sf1ShutdownCmdRsp"] = {"ClassName": "sSF1_SHUTDOWN_CMD_RSP", "Class": sSF1_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF1/Sf1ModeCmd"] = {"ClassName": "sSF1_MODE_CMD", "Class": sSF1_MODE_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF2/Sf2StatusReportUnsol"] = {"ClassName": "sSF2_STATUS_REPORT_UNSOL", "Class": sSF2_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmdRsp"] = {"ClassName": "sSF2_END_OF_SETUP_CMD_RSP", "Class": sSF2_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmdRsp"] = {"ClassName": "sSF2_END_OF_READY_CMD_RSP", "Class": sSF2_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF2/Sf2ShutdownCmdRsp"] = {"ClassName": "sSF2_SHUTDOWN_CMD_RSP", "Class": sSF2_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF3/Sf3StatusReportUnsol"] = {"ClassName": "sSF3_STATUS_REPORT_UNSOL", "Class": sSF3_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmdRsp"] = {"ClassName": "sSF3_END_OF_SETUP_CMD_RSP", "Class": sSF3_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmdRsp"] = {"ClassName": "sSF3_END_OF_READY_CMD_RSP", "Class": sSF3_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF3/Sf3ShutdownCmdRsp"] = {"ClassName": "sSF3_SHUTDOWN_CMD_RSP", "Class": sSF3_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"] = {"ClassName": "sHMI_STATUS_REPORT_UNSOL", "Class": sHMI_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"] = {"ClassName": "sHMI_STATUS_REPORT_UNSOL", "Class": sHMI_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"] = {"ClassName": "sHMI_STATUS_REPORT_UNSOL", "Class": sHMI_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"] = {"ClassName": "sHMI_STATUS_REPORT_UNSOL", "Class": sHMI_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"] = {"ClassName": "sHMI_STATUS_REPORT_UNSOL", "Class": sHMI_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"] = {"ClassName": "sHMI_STATUS_REPORT_UNSOL", "Class": sHMI_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"] = {"ClassName": "sHMI_STATUS_REPORT_UNSOL", "Class": sHMI_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"] = {"ClassName": "sHMI_STATUS_REPORT_UNSOL", "Class": sHMI_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"] = {"ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "Class": sHMI_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"] = {"ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "Class": sHMI_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FC"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"] = {"ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "Class": sHMI_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FC"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"] = {"ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "Class": sHMI_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"] = {"ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "Class": sHMI_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"] = {"ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "Class": sHMI_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"] = {"ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "Class": sHMI_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"] = {"ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "Class": sHMI_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"] = {"ClassName": "sHMI_END_OF_READY_CMD_RSP", "Class": sHMI_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"] = {"ClassName": "sHMI_END_OF_READY_CMD_RSP", "Class": sHMI_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"] = {"ClassName": "sHMI_END_OF_READY_CMD_RSP", "Class": sHMI_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"] = {"ClassName": "sHMI_END_OF_READY_CMD_RSP", "Class": sHMI_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"] = {"ClassName": "sHMI_END_OF_READY_CMD_RSP", "Class": sHMI_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"] = {"ClassName": "sHMI_END_OF_READY_CMD_RSP", "Class": sHMI_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"] = {"ClassName": "sHMI_END_OF_READY_CMD_RSP", "Class": sHMI_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"] = {"ClassName": "sHMI_END_OF_READY_CMD_RSP", "Class": sHMI_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"] = {"ClassName": "sHMI_SHUTDOWN_CMD_RSP", "Class": sHMI_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"] = {"ClassName": "sHMI_SHUTDOWN_CMD_RSP", "Class": sHMI_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"] = {"ClassName": "sHMI_SHUTDOWN_CMD_RSP", "Class": sHMI_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"] = {"ClassName": "sHMI_SHUTDOWN_CMD_RSP", "Class": sHMI_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"] = {"ClassName": "sHMI_SHUTDOWN_CMD_RSP", "Class": sHMI_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"] = {"ClassName": "sHMI_SHUTDOWN_CMD_RSP", "Class": sHMI_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"] = {"ClassName": "sHMI_SHUTDOWN_CMD_RSP", "Class": sHMI_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"] = {"ClassName": "sHMI_SHUTDOWN_CMD_RSP", "Class": sHMI_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"] = {"ClassName": "sHMI_SHUTDOWN_UNSOL", "Class": sHMI_SHUTDOWN_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"] = {"ClassName": "sHMI_SHUTDOWN_UNSOL", "Class": sHMI_SHUTDOWN_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"] = {"ClassName": "sHMI_SHUTDOWN_UNSOL", "Class": sHMI_SHUTDOWN_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"] = {"ClassName": "sHMI_SHUTDOWN_UNSOL", "Class": sHMI_SHUTDOWN_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"] = {"ClassName": "sHMI_SHUTDOWN_UNSOL", "Class": sHMI_SHUTDOWN_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"] = {"ClassName": "sHMI_SHUTDOWN_UNSOL", "Class": sHMI_SHUTDOWN_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"] = {"ClassName": "sHMI_SHUTDOWN_UNSOL", "Class": sHMI_SHUTDOWN_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"] = {"ClassName": "sHMI_SHUTDOWN_UNSOL", "Class": sHMI_SHUTDOWN_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "Class": sHMI_ADCS_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "Class": sHMI_ADCS_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "Class": sHMI_ADCS_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "Class": sHMI_ADCS_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "Class": sHMI_ADCS_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "Class": sHMI_ADCS_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "Class": sHMI_ADCS_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "Class": sHMI_ADCS_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmd"] = {"ClassName": "sOLHM_ADCS_SHUTDOWN_CMD", "Class": sOLHM_ADCS_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/MMS/MmsShutdownCmd"] = {"ClassName": "sMMS_SHUTDOWN_CMD", "Class": sMMS_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/DSF/AdcsConsolidatedAdcmUnsol"] = {"ClassName": "sADCS_CONSOLIDATED_ADCM_UNSOL", "Class": sADCS_CONSOLIDATED_ADCM_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/DR/DrEndOfSetupCmd"] = {"ClassName": "sDR_END_OF_SETUP_CMD", "Class": sDR_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/DR/DrEndOfReadyCmd"] = {"ClassName": "sDR_END_OF_READY_CMD", "Class": sDR_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/DR/DrShutdownCmd"] = {"ClassName": "sDR_SHUTDOWN_CMD", "Class": sDR_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmd"] = {"ClassName": "sPDBP_END_OF_READY_CMD", "Class": sPDBP_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/PDBP/PdbpShutdownCmd"] = {"ClassName": "sPDBP_SHUTDOWN_CMD", "Class": sPDBP_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd"] = {"ClassName": "sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD", "Class": sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"] = {"ClassName": "sEIU_END_OF_SETUP_CMD", "Class": sEIU_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"] = {"ClassName": "sEIU_END_OF_READY_CMD", "Class": sEIU_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/EIU/EiuShutdownCmd"] = {"ClassName": "sEIU_SHUTDOWN_CMD", "Class": sEIU_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TM/TmEndOfSetupCmd"] = {"ClassName": "sTM_END_OF_SETUP_CMD", "Class": sTM_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TM/TmEndOfReadyCmd"] = {"ClassName": "sTM_END_OF_READY_CMD", "Class": sTM_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TM/TmShutdownCmd"] = {"ClassName": "sTM_SHUTDOWN_CMD", "Class": sTM_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmd"] = {"ClassName": "sTEWA_END_OF_SETUP_CMD", "Class": sTEWA_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmd"] = {"ClassName": "sTEWA_END_OF_READY_CMD", "Class": sTEWA_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/TEWA/TewaShutdownCmd"] = {"ClassName": "sTEWA_SHUTDOWN_CMD", "Class": sTEWA_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmd"] = {"ClassName": "sSF1_END_OF_SETUP_CMD", "Class": sSF1_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmd"] = {"ClassName": "sSF1_END_OF_READY_CMD", "Class": sSF1_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF1/Sf1ShutdownCmd"] = {"ClassName": "sSF1_SHUTDOWN_CMD", "Class": sSF1_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF1/Sf1ModeCmdRsp"] = {"ClassName": "sSF1_MODE_CMD_RSP", "Class": sSF1_MODE_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmd"] = {"ClassName": "sSF2_END_OF_SETUP_CMD", "Class": sSF2_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmd"] = {"ClassName": "sSF2_END_OF_READY_CMD", "Class": sSF2_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF2/Sf2ShutdownCmd"] = {"ClassName": "sSF2_SHUTDOWN_CMD", "Class": sSF2_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmd"] = {"ClassName": "sSF3_END_OF_SETUP_CMD", "Class": sSF3_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmd"] = {"ClassName": "sSF3_END_OF_READY_CMD", "Class": sSF3_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/SF3/Sf3ShutdownCmd"] = {"ClassName": "sSF3_SHUTDOWN_CMD", "Class": sSF3_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"] = {"ClassName": "sHMI_END_OF_SETUP_CMD", "Class": sHMI_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"] = {"ClassName": "sHMI_END_OF_SETUP_CMD", "Class": sHMI_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"] = {"ClassName": "sHMI_END_OF_SETUP_CMD", "Class": sHMI_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"] = {"ClassName": "sHMI_END_OF_SETUP_CMD", "Class": sHMI_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"] = {"ClassName": "sHMI_END_OF_SETUP_CMD", "Class": sHMI_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"] = {"ClassName": "sHMI_END_OF_SETUP_CMD", "Class": sHMI_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"] = {"ClassName": "sHMI_END_OF_SETUP_CMD", "Class": sHMI_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"] = {"ClassName": "sHMI_END_OF_SETUP_CMD", "Class": sHMI_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"] = {"ClassName": "sHMI_END_OF_READY_CMD", "Class": sHMI_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"] = {"ClassName": "sHMI_END_OF_READY_CMD", "Class": sHMI_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"] = {"ClassName": "sHMI_END_OF_READY_CMD", "Class": sHMI_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"] = {"ClassName": "sHMI_END_OF_READY_CMD", "Class": sHMI_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"] = {"ClassName": "sHMI_END_OF_READY_CMD", "Class": sHMI_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"] = {"ClassName": "sHMI_END_OF_READY_CMD", "Class": sHMI_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"] = {"ClassName": "sHMI_END_OF_READY_CMD", "Class": sHMI_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"] = {"ClassName": "sHMI_END_OF_READY_CMD", "Class": sHMI_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"] = {"ClassName": "sHMI_SHUTDOWN_CMD", "Class": sHMI_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"] = {"ClassName": "sHMI_SHUTDOWN_CMD", "Class": sHMI_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"] = {"ClassName": "sHMI_SHUTDOWN_CMD", "Class": sHMI_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"] = {"ClassName": "sHMI_SHUTDOWN_CMD", "Class": sHMI_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"] = {"ClassName": "sHMI_SHUTDOWN_CMD", "Class": sHMI_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"] = {"ClassName": "sHMI_SHUTDOWN_CMD", "Class": sHMI_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"] = {"ClassName": "sHMI_SHUTDOWN_CMD", "Class": sHMI_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"] = {"ClassName": "sHMI_SHUTDOWN_CMD", "Class": sHMI_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"] = {"ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}
        self._dctMessages["ADCS/OLHM/OlhmAdcsStatusUnsol"] = {"ClassName": "sOLHM_ADCS_STATUS_UNSOL", "Class": sOLHM_ADCS_STATUS_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/OLHM/OlhmAdcsHmiStatusUnsol"] = {"ClassName": "sOLHM_ADCS_HMI_STATUS_UNSOL", "Class": sOLHM_ADCS_HMI_STATUS_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmdRsp"] = {"ClassName": "sOLHM_ADCS_SHUTDOWN_CMD_RSP", "Class": sOLHM_ADCS_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/MMS/MmsShutdownCmdRsp"] = {"ClassName": "sMMS_SHUTDOWN_CMD_RSP", "Class": sMMS_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        # We have this dictionary to demux a topic into the processing method which should be called - it's more efficient than a long list of if statements
        self._dctDemuxTopicToMethod = {
            "ADCS/DR/DrStatusReportUnsol": self.vProcessDrStatusReportUnsol,
            "ADCS/DR/DrEndOfSetupCmdRsp": self.vProcessDrEndOfSetupCmdRsp,
            "ADCS/DR/DrEndOfReadyCmdRsp": self.vProcessDrEndOfReadyCmdRsp,
            "ADCS/DR/DrShutdownCmdRsp": self.vProcessDrShutdownCmdRsp,
            "ADCS/PDBP/PdbpStatusReportUnsol": self.vProcessPdbpStatusReportUnsol,
            "ADCS/PDBP/PdbpEndOfReadyCmdRsp": self.vProcessPdbpEndOfReadyCmdRsp,
            "ADCS/PDBP/PdbpShutdownCmdRsp": self.vProcessPdbpShutdownCmdRsp,
            "ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp": self.vProcessPdbpSendOutModuleDbMessagesCmdRsp,
            "ADCS/EIU/EiuStatusReportUnsol": self.vProcessEiuStatusReportUnsol,
            "ADCS/EIU/EiuEndOfSetupCmdRsp": self.vProcessEiuEndOfSetupCmdRsp,
            "ADCS/EIU/EiuEndOfReadyCmdRsp": self.vProcessEiuEndOfReadyCmdRsp,
            "ADCS/EIU/EiuShutdownCmdRsp": self.vProcessEiuShutdownCmdRsp,
            "ADCS/TM/TmStatusReportUnsol": self.vProcessTmStatusReportUnsol,
            "ADCS/TM/TmEndOfSetupCmdRsp": self.vProcessTmEndOfSetupCmdRsp,
            "ADCS/TM/TmEndOfReadyCmdRsp": self.vProcessTmEndOfReadyCmdRsp,
            "ADCS/TM/TmShutdownCmdRsp": self.vProcessTmShutdownCmdRsp,
            "ADCS/TEWA/TewaStatusReportUnsol": self.vProcessTewaStatusReportUnsol,
            "ADCS/TEWA/TewaEndOfSetupCmdRsp": self.vProcessTewaEndOfSetupCmdRsp,
            "ADCS/TEWA/TewaEndOfReadyCmdRsp": self.vProcessTewaEndOfReadyCmdRsp,
            "ADCS/TEWA/TewaShutdownCmdRsp": self.vProcessTewaShutdownCmdRsp,
            "ADCS/SF1/Sf1StatusReportUnsol": self.vProcessSf1StatusReportUnsol,
            "ADCS/SF1/Sf1EndOfSetupCmdRsp": self.vProcessSf1EndOfSetupCmdRsp,
            "ADCS/SF1/Sf1EndOfReadyCmdRsp": self.vProcessSf1EndOfReadyCmdRsp,
            "ADCS/SF1/Sf1ShutdownCmdRsp": self.vProcessSf1ShutdownCmdRsp,
            "ADCS/SF1/Sf1ModeCmd": self.vProcessSf1ModeCmd,
            "ADCS/SF2/Sf2StatusReportUnsol": self.vProcessSf2StatusReportUnsol,
            "ADCS/SF2/Sf2EndOfSetupCmdRsp": self.vProcessSf2EndOfSetupCmdRsp,
            "ADCS/SF2/Sf2EndOfReadyCmdRsp": self.vProcessSf2EndOfReadyCmdRsp,
            "ADCS/SF2/Sf2ShutdownCmdRsp": self.vProcessSf2ShutdownCmdRsp,
            "ADCS/SF3/Sf3StatusReportUnsol": self.vProcessSf3StatusReportUnsol,
            "ADCS/SF3/Sf3EndOfSetupCmdRsp": self.vProcessSf3EndOfSetupCmdRsp,
            "ADCS/SF3/Sf3EndOfReadyCmdRsp": self.vProcessSf3EndOfReadyCmdRsp,
            "ADCS/SF3/Sf3ShutdownCmdRsp": self.vProcessSf3ShutdownCmdRsp,
            "ADCS/HMI/HmiStatusReportUnsol/APM": self.vProcessHmiStatusReportUnsolAPM,
            "ADCS/HMI/HmiStatusReportUnsol/FCO": self.vProcessHmiStatusReportUnsolFCO,
            "ADCS/HMI/HmiStatusReportUnsol/APM_FCO": self.vProcessHmiStatusReportUnsolAPM_FCO,
            "ADCS/HMI/HmiStatusReportUnsol/SPM": self.vProcessHmiStatusReportUnsolSPM,
            "ADCS/HMI/HmiStatusReportUnsol/FUFC": self.vProcessHmiStatusReportUnsolFUFC,
            "ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC": self.vProcessHmiStatusReportUnsolSPM_FUFC,
            "ADCS/HMI/HmiStatusReportUnsol/Oversight": self.vProcessHmiStatusReportUnsolOversight,
            "ADCS/HMI/HmiStatusReportUnsol/Maintainer": self.vProcessHmiStatusReportUnsolMaintainer,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/APM": self.vProcessHmiEndOfSetupCmdRspAPM,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/FC": self.vProcessHmiEndOfSetupCmdRspFC,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC": self.vProcessHmiEndOfSetupCmdRspAPM_FC,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/SPM": self.vProcessHmiEndOfSetupCmdRspSPM,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC": self.vProcessHmiEndOfSetupCmdRspFUFC,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC": self.vProcessHmiEndOfSetupCmdRspSPM_FUFC,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight": self.vProcessHmiEndOfSetupCmdRspOversight,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer": self.vProcessHmiEndOfSetupCmdRspMaintainer,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/APM": self.vProcessHmiEndOfReadyCmdRspAPM,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/FCO": self.vProcessHmiEndOfReadyCmdRspFCO,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO": self.vProcessHmiEndOfReadyCmdRspAPM_FCO,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/SPM": self.vProcessHmiEndOfReadyCmdRspSPM,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC": self.vProcessHmiEndOfReadyCmdRspFUFC,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC": self.vProcessHmiEndOfReadyCmdRspSPM_FUFC,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight": self.vProcessHmiEndOfReadyCmdRspOversight,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer": self.vProcessHmiEndOfReadyCmdRspMaintainer,
            "ADCS/HMI/HmiShutdownCmdRsp/APM": self.vProcessHmiShutdownCmdRspAPM,
            "ADCS/HMI/HmiShutdownCmdRsp/FCO": self.vProcessHmiShutdownCmdRspFCO,
            "ADCS/HMI/HmiShutdownCmdRsp/APM_FCO": self.vProcessHmiShutdownCmdRspAPM_FCO,
            "ADCS/HMI/HmiShutdownCmdRsp/SPM": self.vProcessHmiShutdownCmdRspSPM,
            "ADCS/HMI/HmiShutdownCmdRsp/FUFC": self.vProcessHmiShutdownCmdRspFUFC,
            "ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC": self.vProcessHmiShutdownCmdRspSPM_FUFC,
            "ADCS/HMI/HmiShutdownCmdRsp/Oversight": self.vProcessHmiShutdownCmdRspOversight,
            "ADCS/HMI/HmiShutdownCmdRsp/Maintainer": self.vProcessHmiShutdownCmdRspMaintainer,
            "ADCS/HMI/HmiShutdownUnsol/APM": self.vProcessHmiShutdownUnsolAPM,
            "ADCS/HMI/HmiShutdownUnsol/FCO": self.vProcessHmiShutdownUnsolFCO,
            "ADCS/HMI/HmiShutdownUnsol/APM_FCO": self.vProcessHmiShutdownUnsolAPM_FCO,
            "ADCS/HMI/HmiShutdownUnsol/SPM": self.vProcessHmiShutdownUnsolSPM,
            "ADCS/HMI/HmiShutdownUnsol/FUFC": self.vProcessHmiShutdownUnsolFUFC,
            "ADCS/HMI/HmiShutdownUnsol/SPM_FUFC": self.vProcessHmiShutdownUnsolSPM_FUFC,
            "ADCS/HMI/HmiShutdownUnsol/Oversight": self.vProcessHmiShutdownUnsolOversight,
            "ADCS/HMI/HmiShutdownUnsol/Maintainer": self.vProcessHmiShutdownUnsolMaintainer,
            "ADCS/HMI/HmiAdcsShutdownCmd/APM": self.vProcessHmiAdcsShutdownCmdAPM,
            "ADCS/HMI/HmiAdcsShutdownCmd/FCO": self.vProcessHmiAdcsShutdownCmdFCO,
            "ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO": self.vProcessHmiAdcsShutdownCmdAPM_FCO,
            "ADCS/HMI/HmiAdcsShutdownCmd/SPM": self.vProcessHmiAdcsShutdownCmdSPM,
            "ADCS/HMI/HmiAdcsShutdownCmd/FUFC": self.vProcessHmiAdcsShutdownCmdFUFC,
            "ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC": self.vProcessHmiAdcsShutdownCmdSPM_FUFC,
            "ADCS/HMI/HmiAdcsShutdownCmd/Oversight": self.vProcessHmiAdcsShutdownCmdOversight,
            "ADCS/HMI/HmiAdcsShutdownCmd/Maintainer": self.vProcessHmiAdcsShutdownCmdMaintainer,
            "ADCS/OLHM/OlhmAdcsShutdownCmd": self.vProcessOlhmAdcsShutdownCmd,
            "ADCS/MMS/MmsShutdownCmd": self.vProcessMmsShutdownCmd,
            "ADCS/DSF/AdcsConsolidatedAdcmUnsol": self.vProcessAdcsConsolidatedAdcmUnsol,
            "ADCS/DR/DrEndOfSetupCmd": self.vProcessDrEndOfSetupCmd,
            "ADCS/DR/DrEndOfReadyCmd": self.vProcessDrEndOfReadyCmd,
            "ADCS/DR/DrShutdownCmd": self.vProcessDrShutdownCmd,
            "ADCS/PDBP/PdbpEndOfReadyCmd": self.vProcessPdbpEndOfReadyCmd,
            "ADCS/PDBP/PdbpShutdownCmd": self.vProcessPdbpShutdownCmd,
            "ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd": self.vProcessPdbpSendOutModuleDbMessagesCmd,
            "ADCS/EIU/EiuEndOfSetupCmd": self.vProcessEiuEndOfSetupCmd,
            "ADCS/EIU/EiuEndOfReadyCmd": self.vProcessEiuEndOfReadyCmd,
            "ADCS/EIU/EiuShutdownCmd": self.vProcessEiuShutdownCmd,
            "ADCS/TM/TmEndOfSetupCmd": self.vProcessTmEndOfSetupCmd,
            "ADCS/TM/TmEndOfReadyCmd": self.vProcessTmEndOfReadyCmd,
            "ADCS/TM/TmShutdownCmd": self.vProcessTmShutdownCmd,
            "ADCS/TEWA/TewaEndOfSetupCmd": self.vProcessTewaEndOfSetupCmd,
            "ADCS/TEWA/TewaEndOfReadyCmd": self.vProcessTewaEndOfReadyCmd,
            "ADCS/TEWA/TewaShutdownCmd": self.vProcessTewaShutdownCmd,
            "ADCS/SF1/Sf1EndOfSetupCmd": self.vProcessSf1EndOfSetupCmd,
            "ADCS/SF1/Sf1EndOfReadyCmd": self.vProcessSf1EndOfReadyCmd,
            "ADCS/SF1/Sf1ShutdownCmd": self.vProcessSf1ShutdownCmd,
            "ADCS/SF1/Sf1ModeCmdRsp": self.vProcessSf1ModeCmdRsp,
            "ADCS/SF2/Sf2EndOfSetupCmd": self.vProcessSf2EndOfSetupCmd,
            "ADCS/SF2/Sf2EndOfReadyCmd": self.vProcessSf2EndOfReadyCmd,
            "ADCS/SF2/Sf2ShutdownCmd": self.vProcessSf2ShutdownCmd,
            "ADCS/SF3/Sf3EndOfSetupCmd": self.vProcessSf3EndOfSetupCmd,
            "ADCS/SF3/Sf3EndOfReadyCmd": self.vProcessSf3EndOfReadyCmd,
            "ADCS/SF3/Sf3ShutdownCmd": self.vProcessSf3ShutdownCmd,
            "ADCS/HMI/HmiEndOfSetupCmd/APM": self.vProcessHmiEndOfSetupCmdAPM,
            "ADCS/HMI/HmiEndOfSetupCmd/FCO": self.vProcessHmiEndOfSetupCmdFCO,
            "ADCS/HMI/HmiEndOfSetupCmd/APM_FCO": self.vProcessHmiEndOfSetupCmdAPM_FCO,
            "ADCS/HMI/HmiEndOfSetupCmd/SPM": self.vProcessHmiEndOfSetupCmdSPM,
            "ADCS/HMI/HmiEndOfSetupCmd/FUFC": self.vProcessHmiEndOfSetupCmdFUFC,
            "ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC": self.vProcessHmiEndOfSetupCmdSPM_FUFC,
            "ADCS/HMI/HmiEndOfSetupCmd/Oversight": self.vProcessHmiEndOfSetupCmdOversight,
            "ADCS/HMI/HmiEndOfSetupCmd/Maintainer": self.vProcessHmiEndOfSetupCmdMaintainer,
            "ADCS/HMI/HmiEndOfReadyCmd/APM": self.vProcessHmiEndOfReadyCmdAPM,
            "ADCS/HMI/HmiEndOfReadyCmd/FCO": self.vProcessHmiEndOfReadyCmdFCO,
            "ADCS/HMI/HmiEndOfReadyCmd/APM_FCO": self.vProcessHmiEndOfReadyCmdAPM_FCO,
            "ADCS/HMI/HmiEndOfReadyCmd/SPM": self.vProcessHmiEndOfReadyCmdSPM,
            "ADCS/HMI/HmiEndOfReadyCmd/FUFC": self.vProcessHmiEndOfReadyCmdFUFC,
            "ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC": self.vProcessHmiEndOfReadyCmdSPM_FUFC,
            "ADCS/HMI/HmiEndOfReadyCmd/Oversight": self.vProcessHmiEndOfReadyCmdOversight,
            "ADCS/HMI/HmiEndOfReadyCmd/Maintainer": self.vProcessHmiEndOfReadyCmdMaintainer,
            "ADCS/HMI/HmiShutdownCmd/APM": self.vProcessHmiShutdownCmdAPM,
            "ADCS/HMI/HmiShutdownCmd/FCO": self.vProcessHmiShutdownCmdFCO,
            "ADCS/HMI/HmiShutdownCmd/APM_FCO": self.vProcessHmiShutdownCmdAPM_FCO,
            "ADCS/HMI/HmiShutdownCmd/SPM": self.vProcessHmiShutdownCmdSPM,
            "ADCS/HMI/HmiShutdownCmd/FUFC": self.vProcessHmiShutdownCmdFUFC,
            "ADCS/HMI/HmiShutdownCmd/SPM_FUFC": self.vProcessHmiShutdownCmdSPM_FUFC,
            "ADCS/HMI/HmiShutdownCmd/Oversight": self.vProcessHmiShutdownCmdOversight,
            "ADCS/HMI/HmiShutdownCmd/Maintainer": self.vProcessHmiShutdownCmdMaintainer,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/APM": self.vProcessHmiAdcsShutdownCmdRspAPM,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO": self.vProcessHmiAdcsShutdownCmdRspFCO,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO": self.vProcessHmiAdcsShutdownCmdRspAPM_FCO,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM": self.vProcessHmiAdcsShutdownCmdRspSPM,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC": self.vProcessHmiAdcsShutdownCmdRspFUFC,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC": self.vProcessHmiAdcsShutdownCmdRspSPM_FUFC,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight": self.vProcessHmiAdcsShutdownCmdRspOversight,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer": self.vProcessHmiAdcsShutdownCmdRspMaintainer,
            "ADCS/OLHM/OlhmAdcsStatusUnsol": self.vProcessOlhmAdcsStatusUnsol,
            "ADCS/OLHM/OlhmAdcsHmiStatusUnsol": self.vProcessOlhmAdcsHmiStatusUnsol,
            "ADCS/OLHM/OlhmAdcsShutdownCmdRsp": self.vProcessOlhmAdcsShutdownCmdRsp,
            "ADCS/MMS/MmsShutdownCmdRsp": self.vProcessMmsShutdownCmdRsp,
        }

        # This is a dictionary which keeps track of how many tasks are currently being executed per topic - for typical use this number will be either 0 or 1
        self._dctNumExecutingTasks = {
            "ADCS/DR/DrStatusReportUnsol": 0,
            "ADCS/DR/DrEndOfSetupCmdRsp": 0,
            "ADCS/DR/DrEndOfReadyCmdRsp": 0,
            "ADCS/DR/DrShutdownCmdRsp": 0,
            "ADCS/PDBP/PdbpStatusReportUnsol": 0,
            "ADCS/PDBP/PdbpEndOfReadyCmdRsp": 0,
            "ADCS/PDBP/PdbpShutdownCmdRsp": 0,
            "ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp": 0,
            "ADCS/EIU/EiuStatusReportUnsol": 0,
            "ADCS/EIU/EiuEndOfSetupCmdRsp": 0,
            "ADCS/EIU/EiuEndOfReadyCmdRsp": 0,
            "ADCS/EIU/EiuShutdownCmdRsp": 0,
            "ADCS/TM/TmStatusReportUnsol": 0,
            "ADCS/TM/TmEndOfSetupCmdRsp": 0,
            "ADCS/TM/TmEndOfReadyCmdRsp": 0,
            "ADCS/TM/TmShutdownCmdRsp": 0,
            "ADCS/TEWA/TewaStatusReportUnsol": 0,
            "ADCS/TEWA/TewaEndOfSetupCmdRsp": 0,
            "ADCS/TEWA/TewaEndOfReadyCmdRsp": 0,
            "ADCS/TEWA/TewaShutdownCmdRsp": 0,
            "ADCS/SF1/Sf1StatusReportUnsol": 0,
            "ADCS/SF1/Sf1EndOfSetupCmdRsp": 0,
            "ADCS/SF1/Sf1EndOfReadyCmdRsp": 0,
            "ADCS/SF1/Sf1ShutdownCmdRsp": 0,
            "ADCS/SF1/Sf1ModeCmd": 0,
            "ADCS/SF2/Sf2StatusReportUnsol": 0,
            "ADCS/SF2/Sf2EndOfSetupCmdRsp": 0,
            "ADCS/SF2/Sf2EndOfReadyCmdRsp": 0,
            "ADCS/SF2/Sf2ShutdownCmdRsp": 0,
            "ADCS/SF3/Sf3StatusReportUnsol": 0,
            "ADCS/SF3/Sf3EndOfSetupCmdRsp": 0,
            "ADCS/SF3/Sf3EndOfReadyCmdRsp": 0,
            "ADCS/SF3/Sf3ShutdownCmdRsp": 0,
            "ADCS/HMI/HmiStatusReportUnsol/APM": 0,
            "ADCS/HMI/HmiStatusReportUnsol/FCO": 0,
            "ADCS/HMI/HmiStatusReportUnsol/APM_FCO": 0,
            "ADCS/HMI/HmiStatusReportUnsol/SPM": 0,
            "ADCS/HMI/HmiStatusReportUnsol/FUFC": 0,
            "ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC": 0,
            "ADCS/HMI/HmiStatusReportUnsol/Oversight": 0,
            "ADCS/HMI/HmiStatusReportUnsol/Maintainer": 0,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/APM": 0,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/FC": 0,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC": 0,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/SPM": 0,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC": 0,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC": 0,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight": 0,
            "ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer": 0,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/APM": 0,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/FCO": 0,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO": 0,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/SPM": 0,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC": 0,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC": 0,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight": 0,
            "ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer": 0,
            "ADCS/HMI/HmiShutdownCmdRsp/APM": 0,
            "ADCS/HMI/HmiShutdownCmdRsp/FCO": 0,
            "ADCS/HMI/HmiShutdownCmdRsp/APM_FCO": 0,
            "ADCS/HMI/HmiShutdownCmdRsp/SPM": 0,
            "ADCS/HMI/HmiShutdownCmdRsp/FUFC": 0,
            "ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC": 0,
            "ADCS/HMI/HmiShutdownCmdRsp/Oversight": 0,
            "ADCS/HMI/HmiShutdownCmdRsp/Maintainer": 0,
            "ADCS/HMI/HmiShutdownUnsol/APM": 0,
            "ADCS/HMI/HmiShutdownUnsol/FCO": 0,
            "ADCS/HMI/HmiShutdownUnsol/APM_FCO": 0,
            "ADCS/HMI/HmiShutdownUnsol/SPM": 0,
            "ADCS/HMI/HmiShutdownUnsol/FUFC": 0,
            "ADCS/HMI/HmiShutdownUnsol/SPM_FUFC": 0,
            "ADCS/HMI/HmiShutdownUnsol/Oversight": 0,
            "ADCS/HMI/HmiShutdownUnsol/Maintainer": 0,
            "ADCS/HMI/HmiAdcsShutdownCmd/APM": 0,
            "ADCS/HMI/HmiAdcsShutdownCmd/FCO": 0,
            "ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO": 0,
            "ADCS/HMI/HmiAdcsShutdownCmd/SPM": 0,
            "ADCS/HMI/HmiAdcsShutdownCmd/FUFC": 0,
            "ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC": 0,
            "ADCS/HMI/HmiAdcsShutdownCmd/Oversight": 0,
            "ADCS/HMI/HmiAdcsShutdownCmd/Maintainer": 0,
            "ADCS/OLHM/OlhmAdcsShutdownCmd": 0,
            "ADCS/MMS/MmsShutdownCmd": 0,
            "ADCS/DSF/AdcsConsolidatedAdcmUnsol": 0,
            "ADCS/DR/DrEndOfSetupCmd": 0,
            "ADCS/DR/DrEndOfReadyCmd": 0,
            "ADCS/DR/DrShutdownCmd": 0,
            "ADCS/PDBP/PdbpEndOfReadyCmd": 0,
            "ADCS/PDBP/PdbpShutdownCmd": 0,
            "ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd": 0,
            "ADCS/EIU/EiuEndOfSetupCmd": 0,
            "ADCS/EIU/EiuEndOfReadyCmd": 0,
            "ADCS/EIU/EiuShutdownCmd": 0,
            "ADCS/TM/TmEndOfSetupCmd": 0,
            "ADCS/TM/TmEndOfReadyCmd": 0,
            "ADCS/TM/TmShutdownCmd": 0,
            "ADCS/TEWA/TewaEndOfSetupCmd": 0,
            "ADCS/TEWA/TewaEndOfReadyCmd": 0,
            "ADCS/TEWA/TewaShutdownCmd": 0,
            "ADCS/SF1/Sf1EndOfSetupCmd": 0,
            "ADCS/SF1/Sf1EndOfReadyCmd": 0,
            "ADCS/SF1/Sf1ShutdownCmd": 0,
            "ADCS/SF1/Sf1ModeCmdRsp": 0,
            "ADCS/SF2/Sf2EndOfSetupCmd": 0,
            "ADCS/SF2/Sf2EndOfReadyCmd": 0,
            "ADCS/SF2/Sf2ShutdownCmd": 0,
            "ADCS/SF3/Sf3EndOfSetupCmd": 0,
            "ADCS/SF3/Sf3EndOfReadyCmd": 0,
            "ADCS/SF3/Sf3ShutdownCmd": 0,
            "ADCS/HMI/HmiEndOfSetupCmd/APM": 0,
            "ADCS/HMI/HmiEndOfSetupCmd/FCO": 0,
            "ADCS/HMI/HmiEndOfSetupCmd/APM_FCO": 0,
            "ADCS/HMI/HmiEndOfSetupCmd/SPM": 0,
            "ADCS/HMI/HmiEndOfSetupCmd/FUFC": 0,
            "ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC": 0,
            "ADCS/HMI/HmiEndOfSetupCmd/Oversight": 0,
            "ADCS/HMI/HmiEndOfSetupCmd/Maintainer": 0,
            "ADCS/HMI/HmiEndOfReadyCmd/APM": 0,
            "ADCS/HMI/HmiEndOfReadyCmd/FCO": 0,
            "ADCS/HMI/HmiEndOfReadyCmd/APM_FCO": 0,
            "ADCS/HMI/HmiEndOfReadyCmd/SPM": 0,
            "ADCS/HMI/HmiEndOfReadyCmd/FUFC": 0,
            "ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC": 0,
            "ADCS/HMI/HmiEndOfReadyCmd/Oversight": 0,
            "ADCS/HMI/HmiEndOfReadyCmd/Maintainer": 0,
            "ADCS/HMI/HmiShutdownCmd/APM": 0,
            "ADCS/HMI/HmiShutdownCmd/FCO": 0,
            "ADCS/HMI/HmiShutdownCmd/APM_FCO": 0,
            "ADCS/HMI/HmiShutdownCmd/SPM": 0,
            "ADCS/HMI/HmiShutdownCmd/FUFC": 0,
            "ADCS/HMI/HmiShutdownCmd/SPM_FUFC": 0,
            "ADCS/HMI/HmiShutdownCmd/Oversight": 0,
            "ADCS/HMI/HmiShutdownCmd/Maintainer": 0,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/APM": 0,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO": 0,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO": 0,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM": 0,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC": 0,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC": 0,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight": 0,
            "ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer": 0,
            "ADCS/OLHM/OlhmAdcsStatusUnsol": 0,
            "ADCS/OLHM/OlhmAdcsHmiStatusUnsol": 0,
            "ADCS/OLHM/OlhmAdcsShutdownCmdRsp": 0,
            "ADCS/MMS/MmsShutdownCmdRsp": 0,
        }

    # ==========================================================
    # PROCESS DICTIONARY START
    # ==========================================================
    async def vProcessDictObj(self, dctObjectPar) -> None:
        """ This is a public method which demuxes messages from the python queue.

        This is a public method which demuxes messages from the python queue. It uses a dictionary as a lookup in
        order to determine which method to call. Unknown topics will be logged as an error.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """

        # Make sure our input parameter is not None
        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        # Make sure our input parameter dictionary does have a topic key
        if ("Topic" not in dctObjectPar):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar does not contain the key Topic")
            return

        # Use the demux dictionary to determine which method should be called
        if (dctObjectPar["Topic"] in self._dctDemuxTopicToMethod):
            if ((self._dctNumExecutingTasks[dctObjectPar["Topic"]] <= 0) or (dctObjectPar["Topic"] in self._lstTasksAllowedForsimultaneousExecution)):
                self._dctNumExecutingTasks[dctObjectPar["Topic"]] += 1
                await self._dctDemuxTopicToMethod[dctObjectPar["Topic"]](dctObjectPar)
                self._dctNumExecutingTasks[dctObjectPar["Topic"]] -= 1
            else:
                logging.warning("Incoming topic %s cannot be processed right now because there is already a task executing for it - the task counter is %d", dctObjectPar["Topic"], self._dctNumExecutingTasks[dctObjectPar["Topic"]])
        else:
            logging.error("Received message with topic %s does not have a corresponding processing method to call - demux failed because topic unknown", dctObjectPar["Topic"])

        return

    # ==========================================================
    # PROCESS DICTIONARY START
    # ==========================================================
    async def vProcessDrStatusReportUnsol(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/DR/DrStatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrStatusReportUnsol is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/DR/DrStatusReportUnsol"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/DR/DrStatusReportUnsol"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/DR/DrStatusReportUnsol"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/DR/DrStatusReportUnsol"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/DR/DrStatusReportUnsol"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/DR/DrStatusReportUnsol"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadDrStatusReportUnsol(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadDrStatusReportUnsol(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/DR/DrStatusReportUnsol", "Class": sDR_STATUS_REPORT_UNSOL, "ClassName": "sDR_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/DR/DrStatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrStatusReportUnsol is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/DR/DrStatusReportUnsol"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/DR/DrStatusReportUnsol"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/DR/DrStatusReportUnsol"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("DrStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessDrEndOfSetupCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/DR/DrEndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrEndOfSetupCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadDrEndOfSetupCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadDrEndOfSetupCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/DR/DrEndOfSetupCmdRsp", "Class": sDR_END_OF_SETUP_CMD_RSP, "ClassName": "sDR_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/DR/DrEndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrEndOfSetupCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/DR/DrEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("DrEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessDrEndOfReadyCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/DR/DrEndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrEndOfReadyCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadDrEndOfReadyCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadDrEndOfReadyCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/DR/DrEndOfReadyCmdRsp", "Class": sDR_END_OF_READY_CMD_RSP, "ClassName": "sDR_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/DR/DrEndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrEndOfReadyCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/DR/DrEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("DrEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessDrShutdownCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/DR/DrShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrShutdownCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/DR/DrShutdownCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/DR/DrShutdownCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/DR/DrShutdownCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/DR/DrShutdownCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/DR/DrShutdownCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/DR/DrShutdownCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadDrShutdownCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadDrShutdownCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/DR/DrShutdownCmdRsp", "Class": sDR_SHUTDOWN_CMD_RSP, "ClassName": "sDR_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/DR/DrShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrShutdownCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/DR/DrShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/DR/DrShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/DR/DrShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("DrShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessPdbpStatusReportUnsol(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/PDBP/PdbpStatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/PDBP/PdbpStatusReportUnsol is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/PDBP/PdbpStatusReportUnsol"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/PDBP/PdbpStatusReportUnsol"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/PDBP/PdbpStatusReportUnsol"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/PDBP/PdbpStatusReportUnsol"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/PDBP/PdbpStatusReportUnsol"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/PDBP/PdbpStatusReportUnsol"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadPdbpStatusReportUnsol(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadPdbpStatusReportUnsol(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/PDBP/PdbpStatusReportUnsol", "Class": sPDBP_STATUS_REPORT_UNSOL, "ClassName": "sPDBP_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/PDBP/PdbpStatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/PDBP/PdbpStatusReportUnsol is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/PDBP/PdbpStatusReportUnsol"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/PDBP/PdbpStatusReportUnsol"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/PDBP/PdbpStatusReportUnsol"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("PdbpStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessPdbpEndOfReadyCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/PDBP/PdbpEndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/PDBP/PdbpEndOfReadyCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadPdbpEndOfReadyCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadPdbpEndOfReadyCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/PDBP/PdbpEndOfReadyCmdRsp", "Class": sPDBP_END_OF_READY_CMD_RSP, "ClassName": "sPDBP_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/PDBP/PdbpEndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/PDBP/PdbpEndOfReadyCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("PdbpEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessPdbpShutdownCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/PDBP/PdbpShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/PDBP/PdbpShutdownCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/PDBP/PdbpShutdownCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/PDBP/PdbpShutdownCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/PDBP/PdbpShutdownCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/PDBP/PdbpShutdownCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/PDBP/PdbpShutdownCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/PDBP/PdbpShutdownCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadPdbpShutdownCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadPdbpShutdownCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/PDBP/PdbpShutdownCmdRsp", "Class": sPDBP_SHUTDOWN_CMD_RSP, "ClassName": "sPDBP_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/PDBP/PdbpShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/PDBP/PdbpShutdownCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/PDBP/PdbpShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/PDBP/PdbpShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/PDBP/PdbpShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("PdbpShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessPdbpSendOutModuleDbMessagesCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadPdbpSendOutModuleDbMessagesCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadPdbpSendOutModuleDbMessagesCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp", "Class": sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP, "ClassName": "sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("PdbpSendOutModuleDbMessagesCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessEiuStatusReportUnsol(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/EIU/EiuStatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuStatusReportUnsol is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadEiuStatusReportUnsol(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadEiuStatusReportUnsol(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/EIU/EiuStatusReportUnsol", "Class": sEIU_STATUS_REPORT_UNSOL, "ClassName": "sEIU_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/EIU/EiuStatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuStatusReportUnsol is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("EiuStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessEiuEndOfSetupCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/EIU/EiuEndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuEndOfSetupCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadEiuEndOfSetupCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadEiuEndOfSetupCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/EIU/EiuEndOfSetupCmdRsp", "Class": sEIU_END_OF_SETUP_CMD_RSP, "ClassName": "sEIU_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/EIU/EiuEndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuEndOfSetupCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("EiuEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessEiuEndOfReadyCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/EIU/EiuEndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuEndOfReadyCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadEiuEndOfReadyCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadEiuEndOfReadyCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/EIU/EiuEndOfReadyCmdRsp", "Class": sEIU_END_OF_READY_CMD_RSP, "ClassName": "sEIU_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/EIU/EiuEndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuEndOfReadyCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("EiuEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessEiuShutdownCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/EIU/EiuShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuShutdownCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadEiuShutdownCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadEiuShutdownCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/EIU/EiuShutdownCmdRsp", "Class": sEIU_SHUTDOWN_CMD_RSP, "ClassName": "sEIU_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/EIU/EiuShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuShutdownCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("EiuShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessTmStatusReportUnsol(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TM/TmStatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmStatusReportUnsol is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TM/TmStatusReportUnsol"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TM/TmStatusReportUnsol"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TM/TmStatusReportUnsol"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TM/TmStatusReportUnsol"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TM/TmStatusReportUnsol"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TM/TmStatusReportUnsol"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTmStatusReportUnsol(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadTmStatusReportUnsol(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TM/TmStatusReportUnsol", "Class": sTM_STATUS_REPORT_UNSOL, "ClassName": "sTM_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TM/TmStatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmStatusReportUnsol is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TM/TmStatusReportUnsol"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TM/TmStatusReportUnsol"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TM/TmStatusReportUnsol"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TmStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessTmEndOfSetupCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TM/TmEndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmEndOfSetupCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTmEndOfSetupCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadTmEndOfSetupCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TM/TmEndOfSetupCmdRsp", "Class": sTM_END_OF_SETUP_CMD_RSP, "ClassName": "sTM_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TM/TmEndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmEndOfSetupCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TM/TmEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TmEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessTmEndOfReadyCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TM/TmEndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmEndOfReadyCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTmEndOfReadyCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadTmEndOfReadyCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TM/TmEndOfReadyCmdRsp", "Class": sTM_END_OF_READY_CMD_RSP, "ClassName": "sTM_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TM/TmEndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmEndOfReadyCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TM/TmEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TmEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessTmShutdownCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TM/TmShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmShutdownCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TM/TmShutdownCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TM/TmShutdownCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TM/TmShutdownCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TM/TmShutdownCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TM/TmShutdownCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TM/TmShutdownCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTmShutdownCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadTmShutdownCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TM/TmShutdownCmdRsp", "Class": sTM_SHUTDOWN_CMD_RSP, "ClassName": "sTM_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TM/TmShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmShutdownCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TM/TmShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TM/TmShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TM/TmShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TmShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessTewaStatusReportUnsol(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TEWA/TewaStatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TEWA/TewaStatusReportUnsol is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TEWA/TewaStatusReportUnsol"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TEWA/TewaStatusReportUnsol"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TEWA/TewaStatusReportUnsol"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TEWA/TewaStatusReportUnsol"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TEWA/TewaStatusReportUnsol"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TEWA/TewaStatusReportUnsol"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTewaStatusReportUnsol(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadTewaStatusReportUnsol(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TEWA/TewaStatusReportUnsol", "Class": sTEWA_STATUS_REPORT_UNSOL, "ClassName": "sTEWA_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TEWA/TewaStatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TEWA/TewaStatusReportUnsol is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TEWA/TewaStatusReportUnsol"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TEWA/TewaStatusReportUnsol"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TEWA/TewaStatusReportUnsol"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TewaStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessTewaEndOfSetupCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TEWA/TewaEndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TEWA/TewaEndOfSetupCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTewaEndOfSetupCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadTewaEndOfSetupCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TEWA/TewaEndOfSetupCmdRsp", "Class": sTEWA_END_OF_SETUP_CMD_RSP, "ClassName": "sTEWA_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TEWA/TewaEndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TEWA/TewaEndOfSetupCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TewaEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessTewaEndOfReadyCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TEWA/TewaEndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TEWA/TewaEndOfReadyCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTewaEndOfReadyCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadTewaEndOfReadyCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TEWA/TewaEndOfReadyCmdRsp", "Class": sTEWA_END_OF_READY_CMD_RSP, "ClassName": "sTEWA_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TEWA/TewaEndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TEWA/TewaEndOfReadyCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TewaEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessTewaShutdownCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TEWA/TewaShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TEWA/TewaShutdownCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TEWA/TewaShutdownCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TEWA/TewaShutdownCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TEWA/TewaShutdownCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TEWA/TewaShutdownCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TEWA/TewaShutdownCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TEWA/TewaShutdownCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTewaShutdownCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadTewaShutdownCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TEWA/TewaShutdownCmdRsp", "Class": sTEWA_SHUTDOWN_CMD_RSP, "ClassName": "sTEWA_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TEWA/TewaShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TEWA/TewaShutdownCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TEWA/TewaShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TEWA/TewaShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TEWA/TewaShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TewaShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessSf1StatusReportUnsol(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF1/Sf1StatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF1/Sf1StatusReportUnsol is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF1/Sf1StatusReportUnsol"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF1/Sf1StatusReportUnsol"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF1/Sf1StatusReportUnsol"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF1/Sf1StatusReportUnsol"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF1/Sf1StatusReportUnsol"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF1/Sf1StatusReportUnsol"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf1StatusReportUnsol(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadSf1StatusReportUnsol(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF1/Sf1StatusReportUnsol", "Class": sSF1_STATUS_REPORT_UNSOL, "ClassName": "sSF1_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF1/Sf1StatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF1/Sf1StatusReportUnsol is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF1/Sf1StatusReportUnsol"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF1/Sf1StatusReportUnsol"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF1/Sf1StatusReportUnsol"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf1StatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessSf1EndOfSetupCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF1/Sf1EndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF1/Sf1EndOfSetupCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf1EndOfSetupCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadSf1EndOfSetupCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF1/Sf1EndOfSetupCmdRsp", "Class": sSF1_END_OF_SETUP_CMD_RSP, "ClassName": "sSF1_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF1/Sf1EndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF1/Sf1EndOfSetupCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf1EndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessSf1EndOfReadyCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF1/Sf1EndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF1/Sf1EndOfReadyCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf1EndOfReadyCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadSf1EndOfReadyCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF1/Sf1EndOfReadyCmdRsp", "Class": sSF1_END_OF_READY_CMD_RSP, "ClassName": "sSF1_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF1/Sf1EndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF1/Sf1EndOfReadyCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf1EndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessSf1ShutdownCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF1/Sf1ShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF1/Sf1ShutdownCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF1/Sf1ShutdownCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF1/Sf1ShutdownCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF1/Sf1ShutdownCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF1/Sf1ShutdownCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF1/Sf1ShutdownCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF1/Sf1ShutdownCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf1ShutdownCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadSf1ShutdownCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF1/Sf1ShutdownCmdRsp", "Class": sSF1_SHUTDOWN_CMD_RSP, "ClassName": "sSF1_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF1/Sf1ShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF1/Sf1ShutdownCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF1/Sf1ShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF1/Sf1ShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF1/Sf1ShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf1ShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessSf1ModeCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF1/Sf1ModeCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF1/Sf1ModeCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF1/Sf1ModeCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF1/Sf1ModeCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF1/Sf1ModeCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF1/Sf1ModeCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF1/Sf1ModeCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF1/Sf1ModeCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf1ModeCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadSf1ModeCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF1/Sf1ModeCmd", "Class": sSF1_MODE_CMD, "ClassName": "sSF1_MODE_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF1/Sf1ModeCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF1/Sf1ModeCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF1/Sf1ModeCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF1/Sf1ModeCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF1/Sf1ModeCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf1ModeCmd's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessSf2StatusReportUnsol(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF2/Sf2StatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF2/Sf2StatusReportUnsol is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF2/Sf2StatusReportUnsol"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF2/Sf2StatusReportUnsol"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF2/Sf2StatusReportUnsol"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF2/Sf2StatusReportUnsol"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF2/Sf2StatusReportUnsol"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF2/Sf2StatusReportUnsol"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf2StatusReportUnsol(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadSf2StatusReportUnsol(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF2/Sf2StatusReportUnsol", "Class": sSF2_STATUS_REPORT_UNSOL, "ClassName": "sSF2_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF2/Sf2StatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF2/Sf2StatusReportUnsol is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF2/Sf2StatusReportUnsol"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF2/Sf2StatusReportUnsol"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF2/Sf2StatusReportUnsol"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf2StatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessSf2EndOfSetupCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF2/Sf2EndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF2/Sf2EndOfSetupCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf2EndOfSetupCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadSf2EndOfSetupCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF2/Sf2EndOfSetupCmdRsp", "Class": sSF2_END_OF_SETUP_CMD_RSP, "ClassName": "sSF2_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF2/Sf2EndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF2/Sf2EndOfSetupCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf2EndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessSf2EndOfReadyCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF2/Sf2EndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF2/Sf2EndOfReadyCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf2EndOfReadyCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadSf2EndOfReadyCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF2/Sf2EndOfReadyCmdRsp", "Class": sSF2_END_OF_READY_CMD_RSP, "ClassName": "sSF2_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF2/Sf2EndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF2/Sf2EndOfReadyCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf2EndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessSf2ShutdownCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF2/Sf2ShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF2/Sf2ShutdownCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF2/Sf2ShutdownCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF2/Sf2ShutdownCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF2/Sf2ShutdownCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF2/Sf2ShutdownCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF2/Sf2ShutdownCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF2/Sf2ShutdownCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf2ShutdownCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadSf2ShutdownCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF2/Sf2ShutdownCmdRsp", "Class": sSF2_SHUTDOWN_CMD_RSP, "ClassName": "sSF2_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF2/Sf2ShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF2/Sf2ShutdownCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF2/Sf2ShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF2/Sf2ShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF2/Sf2ShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf2ShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessSf3StatusReportUnsol(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF3/Sf3StatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF3/Sf3StatusReportUnsol is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF3/Sf3StatusReportUnsol"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF3/Sf3StatusReportUnsol"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF3/Sf3StatusReportUnsol"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF3/Sf3StatusReportUnsol"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF3/Sf3StatusReportUnsol"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF3/Sf3StatusReportUnsol"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf3StatusReportUnsol(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadSf3StatusReportUnsol(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF3/Sf3StatusReportUnsol", "Class": sSF3_STATUS_REPORT_UNSOL, "ClassName": "sSF3_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF3/Sf3StatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF3/Sf3StatusReportUnsol is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF3/Sf3StatusReportUnsol"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF3/Sf3StatusReportUnsol"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF3/Sf3StatusReportUnsol"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf3StatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessSf3EndOfSetupCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF3/Sf3EndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF3/Sf3EndOfSetupCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf3EndOfSetupCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadSf3EndOfSetupCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF3/Sf3EndOfSetupCmdRsp", "Class": sSF3_END_OF_SETUP_CMD_RSP, "ClassName": "sSF3_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF3/Sf3EndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF3/Sf3EndOfSetupCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf3EndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessSf3EndOfReadyCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF3/Sf3EndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF3/Sf3EndOfReadyCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf3EndOfReadyCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadSf3EndOfReadyCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF3/Sf3EndOfReadyCmdRsp", "Class": sSF3_END_OF_READY_CMD_RSP, "ClassName": "sSF3_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF3/Sf3EndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF3/Sf3EndOfReadyCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf3EndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessSf3ShutdownCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF3/Sf3ShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF3/Sf3ShutdownCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF3/Sf3ShutdownCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF3/Sf3ShutdownCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF3/Sf3ShutdownCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF3/Sf3ShutdownCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF3/Sf3ShutdownCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF3/Sf3ShutdownCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf3ShutdownCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadSf3ShutdownCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF3/Sf3ShutdownCmdRsp", "Class": sSF3_SHUTDOWN_CMD_RSP, "ClassName": "sSF3_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF3/Sf3ShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF3/Sf3ShutdownCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF3/Sf3ShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF3/Sf3ShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF3/Sf3ShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf3ShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiStatusReportUnsolAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiStatusReportUnsol/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiStatusReportUnsolAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiStatusReportUnsolAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiStatusReportUnsol/APM", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiStatusReportUnsol/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiStatusReportUnsolFCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiStatusReportUnsol/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiStatusReportUnsolFCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiStatusReportUnsolFCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiStatusReportUnsol/FCO", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiStatusReportUnsol/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiStatusReportUnsolAPM_FCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiStatusReportUnsol/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/APM_FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiStatusReportUnsolAPM_FCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiStatusReportUnsolAPM_FCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiStatusReportUnsol/APM_FCO", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiStatusReportUnsol/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/APM_FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/APM_FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiStatusReportUnsolSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiStatusReportUnsol/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiStatusReportUnsolSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiStatusReportUnsolSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiStatusReportUnsol/SPM", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiStatusReportUnsol/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiStatusReportUnsolFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiStatusReportUnsol/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiStatusReportUnsolFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiStatusReportUnsolFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiStatusReportUnsol/FUFC", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiStatusReportUnsol/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiStatusReportUnsolSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiStatusReportUnsolSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiStatusReportUnsolSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiStatusReportUnsolOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiStatusReportUnsol/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiStatusReportUnsolOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiStatusReportUnsolOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiStatusReportUnsol/Oversight", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiStatusReportUnsol/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiStatusReportUnsolMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiStatusReportUnsol/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiStatusReportUnsolMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiStatusReportUnsolMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiStatusReportUnsol/Maintainer", "Class": sHMI_STATUS_REPORT_UNSOL, "ClassName": "sHMI_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiStatusReportUnsol/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiStatusReportUnsol/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiStatusReportUnsol/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfSetupCmdRspAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdRspAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfSetupCmdRspAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/APM", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfSetupCmdRspFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/FC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/FC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdRspFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfSetupCmdRspFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/FC", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/FC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/FC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfSetupCmdRspAPM_FC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdRspAPM_FC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfSetupCmdRspAPM_FC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfSetupCmdRspSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdRspSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfSetupCmdRspSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/SPM", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfSetupCmdRspFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdRspFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfSetupCmdRspFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfSetupCmdRspSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdRspSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfSetupCmdRspSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfSetupCmdRspOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdRspOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfSetupCmdRspOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfSetupCmdRspMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdRspMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfSetupCmdRspMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer", "Class": sHMI_END_OF_SETUP_CMD_RSP, "ClassName": "sHMI_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfReadyCmdRspAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdRspAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfReadyCmdRspAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/APM", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfReadyCmdRspFCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdRspFCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfReadyCmdRspFCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/FCO", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfReadyCmdRspAPM_FCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdRspAPM_FCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfReadyCmdRspAPM_FCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfReadyCmdRspSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdRspSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfReadyCmdRspSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/SPM", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfReadyCmdRspFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdRspFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfReadyCmdRspFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfReadyCmdRspSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdRspSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfReadyCmdRspSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfReadyCmdRspOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdRspOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfReadyCmdRspOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiEndOfReadyCmdRspMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdRspMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiEndOfReadyCmdRspMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer", "Class": sHMI_END_OF_READY_CMD_RSP, "ClassName": "sHMI_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownCmdRspAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmdRsp/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdRspAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownCmdRspAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmdRsp/APM", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmdRsp/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownCmdRspFCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmdRsp/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdRspFCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownCmdRspFCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmdRsp/FCO", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmdRsp/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownCmdRspAPM_FCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmdRsp/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/APM_FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdRspAPM_FCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownCmdRspAPM_FCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmdRsp/APM_FCO", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmdRsp/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/APM_FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/APM_FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownCmdRspSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmdRsp/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdRspSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownCmdRspSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmdRsp/SPM", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmdRsp/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownCmdRspFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmdRsp/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdRspFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownCmdRspFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmdRsp/FUFC", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmdRsp/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownCmdRspSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdRspSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownCmdRspSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownCmdRspOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmdRsp/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdRspOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownCmdRspOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmdRsp/Oversight", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmdRsp/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownCmdRspMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmdRsp/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdRspMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownCmdRspMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmdRsp/Maintainer", "Class": sHMI_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmdRsp/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmdRsp/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownUnsolAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownUnsol/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownUnsolAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownUnsolAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownUnsol/APM", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownUnsol/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownUnsolFCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownUnsol/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownUnsolFCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownUnsolFCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownUnsol/FCO", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownUnsol/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownUnsolAPM_FCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownUnsol/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/APM_FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownUnsolAPM_FCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownUnsolAPM_FCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownUnsol/APM_FCO", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownUnsol/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/APM_FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownUnsol/APM_FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownUnsolSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownUnsol/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownUnsolSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownUnsolSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownUnsol/SPM", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownUnsol/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownUnsolFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownUnsol/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownUnsolFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownUnsolFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownUnsol/FUFC", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownUnsol/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownUnsol/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownUnsolSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownUnsol/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownUnsolSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownUnsolSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownUnsol/SPM_FUFC", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownUnsol/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownUnsol/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownUnsolOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownUnsol/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownUnsolOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownUnsolOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownUnsol/Oversight", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownUnsol/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiShutdownUnsolMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownUnsol/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownUnsolMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiShutdownUnsolMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownUnsol/Maintainer", "Class": sHMI_SHUTDOWN_UNSOL, "ClassName": "sHMI_SHUTDOWN_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownUnsol/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownUnsol/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownUnsol/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmd/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/APM", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmd/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmd's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdFCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmd/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdFCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdFCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/FCO", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmd/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmd's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdAPM_FCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdAPM_FCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdAPM_FCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmd's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmd/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/SPM", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmd/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmd's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmd/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/FUFC", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmd/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmd's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmd's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmd/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/Oversight", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmd/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmd's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmd/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmd/Maintainer", "Class": sHMI_ADCS_SHUTDOWN_CMD, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmd/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmd/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmd/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmd's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessOlhmAdcsShutdownCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/OLHM/OlhmAdcsShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/OLHM/OlhmAdcsShutdownCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadOlhmAdcsShutdownCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadOlhmAdcsShutdownCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/OLHM/OlhmAdcsShutdownCmd", "Class": sOLHM_ADCS_SHUTDOWN_CMD, "ClassName": "sOLHM_ADCS_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/OLHM/OlhmAdcsShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/OLHM/OlhmAdcsShutdownCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("OlhmAdcsShutdownCmd's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessMmsShutdownCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/MMS/MmsShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/MMS/MmsShutdownCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/MMS/MmsShutdownCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/MMS/MmsShutdownCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/MMS/MmsShutdownCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/MMS/MmsShutdownCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/MMS/MmsShutdownCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/MMS/MmsShutdownCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadMmsShutdownCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadMmsShutdownCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/MMS/MmsShutdownCmd", "Class": sMMS_SHUTDOWN_CMD, "ClassName": "sMMS_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/MMS/MmsShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/MMS/MmsShutdownCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/MMS/MmsShutdownCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/MMS/MmsShutdownCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/MMS/MmsShutdownCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("MmsShutdownCmd's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessAdcsConsolidatedAdcmUnsol(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/DSF/AdcsConsolidatedAdcmUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DSF/AdcsConsolidatedAdcmUnsol is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/DSF/AdcsConsolidatedAdcmUnsol"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/DSF/AdcsConsolidatedAdcmUnsol"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/DSF/AdcsConsolidatedAdcmUnsol"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/DSF/AdcsConsolidatedAdcmUnsol"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/DSF/AdcsConsolidatedAdcmUnsol"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/DSF/AdcsConsolidatedAdcmUnsol"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadAdcsConsolidatedAdcmUnsol(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadAdcsConsolidatedAdcmUnsol(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/DSF/AdcsConsolidatedAdcmUnsol", "Class": sADCS_CONSOLIDATED_ADCM_UNSOL, "ClassName": "sADCS_CONSOLIDATED_ADCM_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/DSF/AdcsConsolidatedAdcmUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DSF/AdcsConsolidatedAdcmUnsol is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/DSF/AdcsConsolidatedAdcmUnsol"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/DSF/AdcsConsolidatedAdcmUnsol"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/DSF/AdcsConsolidatedAdcmUnsol"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("AdcsConsolidatedAdcmUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessDrEndOfSetupCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/DR/DrEndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrEndOfSetupCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/DR/DrEndOfSetupCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/DR/DrEndOfSetupCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/DR/DrEndOfSetupCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/DR/DrEndOfSetupCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/DR/DrEndOfSetupCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/DR/DrEndOfSetupCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadDrEndOfSetupCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTDrEndOfSetupCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadDrEndOfSetupCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/DR/DrEndOfSetupCmd", "Class": sDR_END_OF_SETUP_CMD, "ClassName": "sDR_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/DR/DrEndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrEndOfSetupCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/DR/DrEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/DR/DrEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/DR/DrEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("DrEndOfSetupCmd's future -> %s", str(E))

        return(sDR_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTDrEndOfSetupCmdRsp(self, objDrEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objDrEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objDrEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objDrEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/DR/DrEndOfSetupCmdRsp", objDrEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessDrEndOfReadyCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/DR/DrEndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrEndOfReadyCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/DR/DrEndOfReadyCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/DR/DrEndOfReadyCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/DR/DrEndOfReadyCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/DR/DrEndOfReadyCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/DR/DrEndOfReadyCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/DR/DrEndOfReadyCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadDrEndOfReadyCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTDrEndOfReadyCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadDrEndOfReadyCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/DR/DrEndOfReadyCmd", "Class": sDR_END_OF_READY_CMD, "ClassName": "sDR_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/DR/DrEndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrEndOfReadyCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/DR/DrEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/DR/DrEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/DR/DrEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("DrEndOfReadyCmd's future -> %s", str(E))

        return(sDR_END_OF_READY_CMD_RSP())

    def vPublishToMQQTDrEndOfReadyCmdRsp(self, objDrEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objDrEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objDrEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objDrEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/DR/DrEndOfReadyCmdRsp", objDrEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessDrShutdownCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/DR/DrShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrShutdownCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/DR/DrShutdownCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/DR/DrShutdownCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/DR/DrShutdownCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/DR/DrShutdownCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/DR/DrShutdownCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/DR/DrShutdownCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadDrShutdownCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTDrShutdownCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadDrShutdownCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/DR/DrShutdownCmd", "Class": sDR_SHUTDOWN_CMD, "ClassName": "sDR_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/DR/DrShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/DR/DrShutdownCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/DR/DrShutdownCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/DR/DrShutdownCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/DR/DrShutdownCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("DrShutdownCmd's future -> %s", str(E))

        return(sDR_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTDrShutdownCmdRsp(self, objDrShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objDrShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objDrShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objDrShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/DR/DrShutdownCmdRsp", objDrShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessPdbpEndOfReadyCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/PDBP/PdbpEndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/PDBP/PdbpEndOfReadyCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadPdbpEndOfReadyCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTPdbpEndOfReadyCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadPdbpEndOfReadyCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/PDBP/PdbpEndOfReadyCmd", "Class": sPDBP_END_OF_READY_CMD, "ClassName": "sPDBP_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/PDBP/PdbpEndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/PDBP/PdbpEndOfReadyCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/PDBP/PdbpEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("PdbpEndOfReadyCmd's future -> %s", str(E))

        return(sPDBP_END_OF_READY_CMD_RSP())

    def vPublishToMQQTPdbpEndOfReadyCmdRsp(self, objPdbpEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objPdbpEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objPdbpEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objPdbpEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/PDBP/PdbpEndOfReadyCmdRsp", objPdbpEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessPdbpShutdownCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/PDBP/PdbpShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/PDBP/PdbpShutdownCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/PDBP/PdbpShutdownCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/PDBP/PdbpShutdownCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/PDBP/PdbpShutdownCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/PDBP/PdbpShutdownCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/PDBP/PdbpShutdownCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/PDBP/PdbpShutdownCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadPdbpShutdownCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTPdbpShutdownCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadPdbpShutdownCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/PDBP/PdbpShutdownCmd", "Class": sPDBP_SHUTDOWN_CMD, "ClassName": "sPDBP_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/PDBP/PdbpShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/PDBP/PdbpShutdownCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/PDBP/PdbpShutdownCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/PDBP/PdbpShutdownCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/PDBP/PdbpShutdownCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("PdbpShutdownCmd's future -> %s", str(E))

        return(sPDBP_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTPdbpShutdownCmdRsp(self, objPdbpShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objPdbpShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objPdbpShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objPdbpShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/PDBP/PdbpShutdownCmdRsp", objPdbpShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessPdbpSendOutModuleDbMessagesCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadPdbpSendOutModuleDbMessagesCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTPdbpSendOutModuleDbMessagesCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadPdbpSendOutModuleDbMessagesCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd", "Class": sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD, "ClassName": "sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("PdbpSendOutModuleDbMessagesCmd's future -> %s", str(E))

        return(sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP())

    def vPublishToMQQTPdbpSendOutModuleDbMessagesCmdRsp(self, objPdbpSendOutModuleDbMessagesCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objPdbpSendOutModuleDbMessagesCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objPdbpSendOutModuleDbMessagesCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objPdbpSendOutModuleDbMessagesCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp", objPdbpSendOutModuleDbMessagesCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessEiuEndOfSetupCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/EIU/EiuEndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuEndOfSetupCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadEiuEndOfSetupCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTEiuEndOfSetupCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadEiuEndOfSetupCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/EIU/EiuEndOfSetupCmd", "Class": sEIU_END_OF_SETUP_CMD, "ClassName": "sEIU_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/EIU/EiuEndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuEndOfSetupCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("EiuEndOfSetupCmd's future -> %s", str(E))

        return(sEIU_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTEiuEndOfSetupCmdRsp(self, objEiuEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objEiuEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objEiuEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objEiuEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/EIU/EiuEndOfSetupCmdRsp", objEiuEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessEiuEndOfReadyCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/EIU/EiuEndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuEndOfReadyCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadEiuEndOfReadyCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTEiuEndOfReadyCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadEiuEndOfReadyCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/EIU/EiuEndOfReadyCmd", "Class": sEIU_END_OF_READY_CMD, "ClassName": "sEIU_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/EIU/EiuEndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuEndOfReadyCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("EiuEndOfReadyCmd's future -> %s", str(E))

        return(sEIU_END_OF_READY_CMD_RSP())

    def vPublishToMQQTEiuEndOfReadyCmdRsp(self, objEiuEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objEiuEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objEiuEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objEiuEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/EIU/EiuEndOfReadyCmdRsp", objEiuEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessEiuShutdownCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/EIU/EiuShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuShutdownCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/EIU/EiuShutdownCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/EIU/EiuShutdownCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/EIU/EiuShutdownCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/EIU/EiuShutdownCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/EIU/EiuShutdownCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/EIU/EiuShutdownCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadEiuShutdownCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTEiuShutdownCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadEiuShutdownCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/EIU/EiuShutdownCmd", "Class": sEIU_SHUTDOWN_CMD, "ClassName": "sEIU_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/EIU/EiuShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuShutdownCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/EIU/EiuShutdownCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/EIU/EiuShutdownCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/EIU/EiuShutdownCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("EiuShutdownCmd's future -> %s", str(E))

        return(sEIU_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTEiuShutdownCmdRsp(self, objEiuShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objEiuShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objEiuShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objEiuShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/EIU/EiuShutdownCmdRsp", objEiuShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessTmEndOfSetupCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TM/TmEndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmEndOfSetupCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TM/TmEndOfSetupCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TM/TmEndOfSetupCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TM/TmEndOfSetupCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TM/TmEndOfSetupCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TM/TmEndOfSetupCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TM/TmEndOfSetupCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTmEndOfSetupCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTTmEndOfSetupCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadTmEndOfSetupCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TM/TmEndOfSetupCmd", "Class": sTM_END_OF_SETUP_CMD, "ClassName": "sTM_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TM/TmEndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmEndOfSetupCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TM/TmEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TM/TmEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TM/TmEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TmEndOfSetupCmd's future -> %s", str(E))

        return(sTM_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTTmEndOfSetupCmdRsp(self, objTmEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objTmEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objTmEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objTmEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/TM/TmEndOfSetupCmdRsp", objTmEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessTmEndOfReadyCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TM/TmEndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmEndOfReadyCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TM/TmEndOfReadyCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TM/TmEndOfReadyCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TM/TmEndOfReadyCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TM/TmEndOfReadyCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TM/TmEndOfReadyCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TM/TmEndOfReadyCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTmEndOfReadyCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTTmEndOfReadyCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadTmEndOfReadyCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TM/TmEndOfReadyCmd", "Class": sTM_END_OF_READY_CMD, "ClassName": "sTM_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TM/TmEndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmEndOfReadyCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TM/TmEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TM/TmEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TM/TmEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TmEndOfReadyCmd's future -> %s", str(E))

        return(sTM_END_OF_READY_CMD_RSP())

    def vPublishToMQQTTmEndOfReadyCmdRsp(self, objTmEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objTmEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objTmEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objTmEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/TM/TmEndOfReadyCmdRsp", objTmEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessTmShutdownCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TM/TmShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmShutdownCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TM/TmShutdownCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TM/TmShutdownCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TM/TmShutdownCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TM/TmShutdownCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TM/TmShutdownCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TM/TmShutdownCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTmShutdownCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTTmShutdownCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadTmShutdownCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TM/TmShutdownCmd", "Class": sTM_SHUTDOWN_CMD, "ClassName": "sTM_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TM/TmShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TM/TmShutdownCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TM/TmShutdownCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TM/TmShutdownCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TM/TmShutdownCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TmShutdownCmd's future -> %s", str(E))

        return(sTM_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTTmShutdownCmdRsp(self, objTmShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objTmShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objTmShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objTmShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/TM/TmShutdownCmdRsp", objTmShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessTewaEndOfSetupCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TEWA/TewaEndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TEWA/TewaEndOfSetupCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTewaEndOfSetupCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTTewaEndOfSetupCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadTewaEndOfSetupCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TEWA/TewaEndOfSetupCmd", "Class": sTEWA_END_OF_SETUP_CMD, "ClassName": "sTEWA_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TEWA/TewaEndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TEWA/TewaEndOfSetupCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TEWA/TewaEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TewaEndOfSetupCmd's future -> %s", str(E))

        return(sTEWA_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTTewaEndOfSetupCmdRsp(self, objTewaEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objTewaEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objTewaEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objTewaEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/TEWA/TewaEndOfSetupCmdRsp", objTewaEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessTewaEndOfReadyCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TEWA/TewaEndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TEWA/TewaEndOfReadyCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTewaEndOfReadyCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTTewaEndOfReadyCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadTewaEndOfReadyCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TEWA/TewaEndOfReadyCmd", "Class": sTEWA_END_OF_READY_CMD, "ClassName": "sTEWA_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TEWA/TewaEndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TEWA/TewaEndOfReadyCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TEWA/TewaEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TewaEndOfReadyCmd's future -> %s", str(E))

        return(sTEWA_END_OF_READY_CMD_RSP())

    def vPublishToMQQTTewaEndOfReadyCmdRsp(self, objTewaEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objTewaEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objTewaEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objTewaEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/TEWA/TewaEndOfReadyCmdRsp", objTewaEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessTewaShutdownCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/TEWA/TewaShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TEWA/TewaShutdownCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/TEWA/TewaShutdownCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/TEWA/TewaShutdownCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/TEWA/TewaShutdownCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/TEWA/TewaShutdownCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/TEWA/TewaShutdownCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/TEWA/TewaShutdownCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadTewaShutdownCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTTewaShutdownCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadTewaShutdownCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/TEWA/TewaShutdownCmd", "Class": sTEWA_SHUTDOWN_CMD, "ClassName": "sTEWA_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/TEWA/TewaShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/TEWA/TewaShutdownCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/TEWA/TewaShutdownCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/TEWA/TewaShutdownCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/TEWA/TewaShutdownCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("TewaShutdownCmd's future -> %s", str(E))

        return(sTEWA_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTTewaShutdownCmdRsp(self, objTewaShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objTewaShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objTewaShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objTewaShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/TEWA/TewaShutdownCmdRsp", objTewaShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessSf1EndOfSetupCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF1/Sf1EndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF1/Sf1EndOfSetupCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf1EndOfSetupCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTSf1EndOfSetupCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadSf1EndOfSetupCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF1/Sf1EndOfSetupCmd", "Class": sSF1_END_OF_SETUP_CMD, "ClassName": "sSF1_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF1/Sf1EndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF1/Sf1EndOfSetupCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF1/Sf1EndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf1EndOfSetupCmd's future -> %s", str(E))

        return(sSF1_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTSf1EndOfSetupCmdRsp(self, objSf1EndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objSf1EndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objSf1EndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objSf1EndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/SF1/Sf1EndOfSetupCmdRsp", objSf1EndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessSf1EndOfReadyCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF1/Sf1EndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF1/Sf1EndOfReadyCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf1EndOfReadyCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTSf1EndOfReadyCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadSf1EndOfReadyCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF1/Sf1EndOfReadyCmd", "Class": sSF1_END_OF_READY_CMD, "ClassName": "sSF1_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF1/Sf1EndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF1/Sf1EndOfReadyCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF1/Sf1EndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf1EndOfReadyCmd's future -> %s", str(E))

        return(sSF1_END_OF_READY_CMD_RSP())

    def vPublishToMQQTSf1EndOfReadyCmdRsp(self, objSf1EndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objSf1EndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objSf1EndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objSf1EndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/SF1/Sf1EndOfReadyCmdRsp", objSf1EndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessSf1ShutdownCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF1/Sf1ShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF1/Sf1ShutdownCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF1/Sf1ShutdownCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF1/Sf1ShutdownCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF1/Sf1ShutdownCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF1/Sf1ShutdownCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF1/Sf1ShutdownCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF1/Sf1ShutdownCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf1ShutdownCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTSf1ShutdownCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadSf1ShutdownCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF1/Sf1ShutdownCmd", "Class": sSF1_SHUTDOWN_CMD, "ClassName": "sSF1_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF1/Sf1ShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF1/Sf1ShutdownCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF1/Sf1ShutdownCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF1/Sf1ShutdownCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF1/Sf1ShutdownCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf1ShutdownCmd's future -> %s", str(E))

        return(sSF1_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTSf1ShutdownCmdRsp(self, objSf1ShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objSf1ShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objSf1ShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objSf1ShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/SF1/Sf1ShutdownCmdRsp", objSf1ShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessSf1ModeCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF1/Sf1ModeCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF1/Sf1ModeCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF1/Sf1ModeCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF1/Sf1ModeCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF1/Sf1ModeCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF1/Sf1ModeCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF1/Sf1ModeCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF1/Sf1ModeCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf1ModeCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadSf1ModeCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF1/Sf1ModeCmdRsp", "Class": sSF1_MODE_CMD_RSP, "ClassName": "sSF1_MODE_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF1/Sf1ModeCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF1/Sf1ModeCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF1/Sf1ModeCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF1/Sf1ModeCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF1/Sf1ModeCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf1ModeCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessSf2EndOfSetupCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF2/Sf2EndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF2/Sf2EndOfSetupCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf2EndOfSetupCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTSf2EndOfSetupCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadSf2EndOfSetupCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF2/Sf2EndOfSetupCmd", "Class": sSF2_END_OF_SETUP_CMD, "ClassName": "sSF2_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF2/Sf2EndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF2/Sf2EndOfSetupCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF2/Sf2EndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf2EndOfSetupCmd's future -> %s", str(E))

        return(sSF2_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTSf2EndOfSetupCmdRsp(self, objSf2EndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objSf2EndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objSf2EndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objSf2EndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/SF2/Sf2EndOfSetupCmdRsp", objSf2EndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessSf2EndOfReadyCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF2/Sf2EndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF2/Sf2EndOfReadyCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf2EndOfReadyCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTSf2EndOfReadyCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadSf2EndOfReadyCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF2/Sf2EndOfReadyCmd", "Class": sSF2_END_OF_READY_CMD, "ClassName": "sSF2_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF2/Sf2EndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF2/Sf2EndOfReadyCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF2/Sf2EndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf2EndOfReadyCmd's future -> %s", str(E))

        return(sSF2_END_OF_READY_CMD_RSP())

    def vPublishToMQQTSf2EndOfReadyCmdRsp(self, objSf2EndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objSf2EndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objSf2EndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objSf2EndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/SF2/Sf2EndOfReadyCmdRsp", objSf2EndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessSf2ShutdownCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF2/Sf2ShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF2/Sf2ShutdownCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF2/Sf2ShutdownCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF2/Sf2ShutdownCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF2/Sf2ShutdownCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF2/Sf2ShutdownCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF2/Sf2ShutdownCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF2/Sf2ShutdownCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf2ShutdownCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTSf2ShutdownCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadSf2ShutdownCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF2/Sf2ShutdownCmd", "Class": sSF2_SHUTDOWN_CMD, "ClassName": "sSF2_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF2/Sf2ShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF2/Sf2ShutdownCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF2/Sf2ShutdownCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF2/Sf2ShutdownCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF2/Sf2ShutdownCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf2ShutdownCmd's future -> %s", str(E))

        return(sSF2_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTSf2ShutdownCmdRsp(self, objSf2ShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objSf2ShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objSf2ShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objSf2ShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/SF2/Sf2ShutdownCmdRsp", objSf2ShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessSf3EndOfSetupCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF3/Sf3EndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF3/Sf3EndOfSetupCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf3EndOfSetupCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTSf3EndOfSetupCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadSf3EndOfSetupCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF3/Sf3EndOfSetupCmd", "Class": sSF3_END_OF_SETUP_CMD, "ClassName": "sSF3_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF3/Sf3EndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF3/Sf3EndOfSetupCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF3/Sf3EndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf3EndOfSetupCmd's future -> %s", str(E))

        return(sSF3_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTSf3EndOfSetupCmdRsp(self, objSf3EndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objSf3EndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objSf3EndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objSf3EndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/SF3/Sf3EndOfSetupCmdRsp", objSf3EndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessSf3EndOfReadyCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF3/Sf3EndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF3/Sf3EndOfReadyCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf3EndOfReadyCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTSf3EndOfReadyCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadSf3EndOfReadyCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF3/Sf3EndOfReadyCmd", "Class": sSF3_END_OF_READY_CMD, "ClassName": "sSF3_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF3/Sf3EndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF3/Sf3EndOfReadyCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF3/Sf3EndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf3EndOfReadyCmd's future -> %s", str(E))

        return(sSF3_END_OF_READY_CMD_RSP())

    def vPublishToMQQTSf3EndOfReadyCmdRsp(self, objSf3EndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objSf3EndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objSf3EndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objSf3EndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/SF3/Sf3EndOfReadyCmdRsp", objSf3EndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessSf3ShutdownCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/SF3/Sf3ShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF3/Sf3ShutdownCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/SF3/Sf3ShutdownCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/SF3/Sf3ShutdownCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/SF3/Sf3ShutdownCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/SF3/Sf3ShutdownCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/SF3/Sf3ShutdownCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/SF3/Sf3ShutdownCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadSf3ShutdownCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTSf3ShutdownCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadSf3ShutdownCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/SF3/Sf3ShutdownCmd", "Class": sSF3_SHUTDOWN_CMD, "ClassName": "sSF3_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/SF3/Sf3ShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/SF3/Sf3ShutdownCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/SF3/Sf3ShutdownCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/SF3/Sf3ShutdownCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/SF3/Sf3ShutdownCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("Sf3ShutdownCmd's future -> %s", str(E))

        return(sSF3_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTSf3ShutdownCmdRsp(self, objSf3ShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objSf3ShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objSf3ShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objSf3ShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/SF3/Sf3ShutdownCmdRsp", objSf3ShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfSetupCmdAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmd/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfSetupCmdRspAPM(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfSetupCmdAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmd/APM", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmd/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmd's future -> %s", str(E))

        return(sHMI_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTHmiEndOfSetupCmdRspAPM(self, objHmiEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/APM", objHmiEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfSetupCmdFCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmd/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdFCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfSetupCmdRspFCO(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfSetupCmdFCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmd/FCO", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmd/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmd's future -> %s", str(E))

        return(sHMI_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTHmiEndOfSetupCmdRspFCO(self, objHmiEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/FCO", objHmiEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfSetupCmdAPM_FCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmd/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/APM_FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdAPM_FCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfSetupCmdRspAPM_FCO(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfSetupCmdAPM_FCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmd/APM_FCO", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmd/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/APM_FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmd's future -> %s", str(E))

        return(sHMI_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTHmiEndOfSetupCmdRspAPM_FCO(self, objHmiEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/APM_FCO", objHmiEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfSetupCmdSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmd/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfSetupCmdRspSPM(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfSetupCmdSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmd/SPM", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmd/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmd's future -> %s", str(E))

        return(sHMI_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTHmiEndOfSetupCmdRspSPM(self, objHmiEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM", objHmiEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfSetupCmdFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmd/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfSetupCmdRspFUFC(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfSetupCmdFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmd/FUFC", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmd/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmd's future -> %s", str(E))

        return(sHMI_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTHmiEndOfSetupCmdRspFUFC(self, objHmiEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/FUFC", objHmiEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfSetupCmdSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfSetupCmdRspSPM_FUFC(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfSetupCmdSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmd's future -> %s", str(E))

        return(sHMI_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTHmiEndOfSetupCmdRspSPM_FUFC(self, objHmiEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/SPM_FUFC", objHmiEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfSetupCmdOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmd/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfSetupCmdRspOversight(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfSetupCmdOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmd/Oversight", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmd/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmd's future -> %s", str(E))

        return(sHMI_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTHmiEndOfSetupCmdRspOversight(self, objHmiEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/Oversight", objHmiEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfSetupCmdMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfSetupCmd/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfSetupCmdMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfSetupCmdRspMaintainer(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfSetupCmdMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfSetupCmd/Maintainer", "Class": sHMI_END_OF_SETUP_CMD, "ClassName": "sHMI_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfSetupCmd/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfSetupCmd/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfSetupCmd/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfSetupCmd's future -> %s", str(E))

        return(sHMI_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTHmiEndOfSetupCmdRspMaintainer(self, objHmiEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfSetupCmdRsp/Maintainer", objHmiEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfReadyCmdAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmd/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfReadyCmdRspAPM(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfReadyCmdAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmd/APM", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmd/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmd's future -> %s", str(E))

        return(sHMI_END_OF_READY_CMD_RSP())

    def vPublishToMQQTHmiEndOfReadyCmdRspAPM(self, objHmiEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/APM", objHmiEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfReadyCmdFCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmd/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdFCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfReadyCmdRspFCO(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfReadyCmdFCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmd/FCO", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmd/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmd's future -> %s", str(E))

        return(sHMI_END_OF_READY_CMD_RSP())

    def vPublishToMQQTHmiEndOfReadyCmdRspFCO(self, objHmiEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/FCO", objHmiEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfReadyCmdAPM_FCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmd/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/APM_FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdAPM_FCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfReadyCmdRspAPM_FCO(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfReadyCmdAPM_FCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmd/APM_FCO", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmd/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/APM_FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmd's future -> %s", str(E))

        return(sHMI_END_OF_READY_CMD_RSP())

    def vPublishToMQQTHmiEndOfReadyCmdRspAPM_FCO(self, objHmiEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/APM_FCO", objHmiEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfReadyCmdSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmd/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfReadyCmdRspSPM(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfReadyCmdSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmd/SPM", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmd/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmd's future -> %s", str(E))

        return(sHMI_END_OF_READY_CMD_RSP())

    def vPublishToMQQTHmiEndOfReadyCmdRspSPM(self, objHmiEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM", objHmiEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfReadyCmdFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmd/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfReadyCmdRspFUFC(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfReadyCmdFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmd/FUFC", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmd/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmd's future -> %s", str(E))

        return(sHMI_END_OF_READY_CMD_RSP())

    def vPublishToMQQTHmiEndOfReadyCmdRspFUFC(self, objHmiEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/FUFC", objHmiEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfReadyCmdSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfReadyCmdRspSPM_FUFC(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfReadyCmdSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmd's future -> %s", str(E))

        return(sHMI_END_OF_READY_CMD_RSP())

    def vPublishToMQQTHmiEndOfReadyCmdRspSPM_FUFC(self, objHmiEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/SPM_FUFC", objHmiEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfReadyCmdOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmd/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfReadyCmdRspOversight(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfReadyCmdOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmd/Oversight", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmd/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmd's future -> %s", str(E))

        return(sHMI_END_OF_READY_CMD_RSP())

    def vPublishToMQQTHmiEndOfReadyCmdRspOversight(self, objHmiEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/Oversight", objHmiEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiEndOfReadyCmdMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiEndOfReadyCmd/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiEndOfReadyCmdMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiEndOfReadyCmdRspMaintainer(objReplyMessage)

        return

    async def objProcessPayloadHmiEndOfReadyCmdMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiEndOfReadyCmd/Maintainer", "Class": sHMI_END_OF_READY_CMD, "ClassName": "sHMI_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiEndOfReadyCmd/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiEndOfReadyCmd/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiEndOfReadyCmd/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiEndOfReadyCmd's future -> %s", str(E))

        return(sHMI_END_OF_READY_CMD_RSP())

    def vPublishToMQQTHmiEndOfReadyCmdRspMaintainer(self, objHmiEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiEndOfReadyCmdRsp/Maintainer", objHmiEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiShutdownCmdAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmd/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiShutdownCmdRspAPM(objReplyMessage)

        return

    async def objProcessPayloadHmiShutdownCmdAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmd/APM", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmd/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmd's future -> %s", str(E))

        return(sHMI_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTHmiShutdownCmdRspAPM(self, objHmiShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiShutdownCmdRsp/APM", objHmiShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiShutdownCmdFCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmd/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdFCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiShutdownCmdRspFCO(objReplyMessage)

        return

    async def objProcessPayloadHmiShutdownCmdFCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmd/FCO", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmd/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmd/FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmd's future -> %s", str(E))

        return(sHMI_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTHmiShutdownCmdRspFCO(self, objHmiShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiShutdownCmdRsp/FCO", objHmiShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiShutdownCmdAPM_FCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmd/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/APM_FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdAPM_FCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiShutdownCmdRspAPM_FCO(objReplyMessage)

        return

    async def objProcessPayloadHmiShutdownCmdAPM_FCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmd/APM_FCO", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmd/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/APM_FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmd/APM_FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmd's future -> %s", str(E))

        return(sHMI_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTHmiShutdownCmdRspAPM_FCO(self, objHmiShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiShutdownCmdRsp/APM_FCO", objHmiShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiShutdownCmdSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmd/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiShutdownCmdRspSPM(objReplyMessage)

        return

    async def objProcessPayloadHmiShutdownCmdSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmd/SPM", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmd/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmd's future -> %s", str(E))

        return(sHMI_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTHmiShutdownCmdRspSPM(self, objHmiShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiShutdownCmdRsp/SPM", objHmiShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiShutdownCmdFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmd/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiShutdownCmdRspFUFC(objReplyMessage)

        return

    async def objProcessPayloadHmiShutdownCmdFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmd/FUFC", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmd/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmd/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmd's future -> %s", str(E))

        return(sHMI_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTHmiShutdownCmdRspFUFC(self, objHmiShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiShutdownCmdRsp/FUFC", objHmiShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiShutdownCmdSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmd/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiShutdownCmdRspSPM_FUFC(objReplyMessage)

        return

    async def objProcessPayloadHmiShutdownCmdSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmd/SPM_FUFC", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmd/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmd/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmd's future -> %s", str(E))

        return(sHMI_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTHmiShutdownCmdRspSPM_FUFC(self, objHmiShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiShutdownCmdRsp/SPM_FUFC", objHmiShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiShutdownCmdOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmd/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiShutdownCmdRspOversight(objReplyMessage)

        return

    async def objProcessPayloadHmiShutdownCmdOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmd/Oversight", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmd/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmd/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmd's future -> %s", str(E))

        return(sHMI_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTHmiShutdownCmdRspOversight(self, objHmiShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiShutdownCmdRsp/Oversight", objHmiShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiShutdownCmdMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiShutdownCmd/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiShutdownCmdMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTHmiShutdownCmdRspMaintainer(objReplyMessage)

        return

    async def objProcessPayloadHmiShutdownCmdMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiShutdownCmd/Maintainer", "Class": sHMI_SHUTDOWN_CMD, "ClassName": "sHMI_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiShutdownCmd/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiShutdownCmd/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiShutdownCmd/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiShutdownCmd's future -> %s", str(E))

        return(sHMI_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTHmiShutdownCmdRspMaintainer(self, objHmiShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objHmiShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objHmiShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objHmiShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/HMI/HmiShutdownCmdRsp/Maintainer", objHmiShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessHmiAdcsShutdownCmdRspAPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/APM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdRspAPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdRspAPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/APM", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/APM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/APM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdRspFCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdRspFCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdRspFCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdRspAPM_FCO(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdRspAPM_FCO(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdRspAPM_FCO(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "APM_FCO"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/APM_FCO"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdRspSPM(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdRspSPM(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdRspSPM(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdRspFUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdRspFUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdRspFUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdRspSPM_FUFC(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdRspSPM_FUFC(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdRspSPM_FUFC(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "SPM_FUFC"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/SPM_FUFC"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdRspOversight(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdRspOversight(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdRspOversight(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Oversight"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Oversight"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessHmiAdcsShutdownCmdRspMaintainer(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadHmiAdcsShutdownCmdRspMaintainer(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadHmiAdcsShutdownCmdRspMaintainer(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer", "Class": sHMI_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sHMI_ADCS_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": "Maintainer"}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/HMI/HmiAdcsShutdownCmdRsp/Maintainer"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("HmiAdcsShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessOlhmAdcsStatusUnsol(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/OLHM/OlhmAdcsStatusUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/OLHM/OlhmAdcsStatusUnsol is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/OLHM/OlhmAdcsStatusUnsol"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/OLHM/OlhmAdcsStatusUnsol"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/OLHM/OlhmAdcsStatusUnsol"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/OLHM/OlhmAdcsStatusUnsol"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/OLHM/OlhmAdcsStatusUnsol"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/OLHM/OlhmAdcsStatusUnsol"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadOlhmAdcsStatusUnsol(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadOlhmAdcsStatusUnsol(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/OLHM/OlhmAdcsStatusUnsol", "Class": sOLHM_ADCS_STATUS_UNSOL, "ClassName": "sOLHM_ADCS_STATUS_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/OLHM/OlhmAdcsStatusUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/OLHM/OlhmAdcsStatusUnsol is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/OLHM/OlhmAdcsStatusUnsol"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/OLHM/OlhmAdcsStatusUnsol"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/OLHM/OlhmAdcsStatusUnsol"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("OlhmAdcsStatusUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessOlhmAdcsHmiStatusUnsol(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/OLHM/OlhmAdcsHmiStatusUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/OLHM/OlhmAdcsHmiStatusUnsol is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/OLHM/OlhmAdcsHmiStatusUnsol"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/OLHM/OlhmAdcsHmiStatusUnsol"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/OLHM/OlhmAdcsHmiStatusUnsol"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/OLHM/OlhmAdcsHmiStatusUnsol"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/OLHM/OlhmAdcsHmiStatusUnsol"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/OLHM/OlhmAdcsHmiStatusUnsol"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadOlhmAdcsHmiStatusUnsol(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadOlhmAdcsHmiStatusUnsol(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/OLHM/OlhmAdcsHmiStatusUnsol", "Class": sOLHM_ADCS_HMI_STATUS_UNSOL, "ClassName": "sOLHM_ADCS_HMI_STATUS_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/OLHM/OlhmAdcsHmiStatusUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/OLHM/OlhmAdcsHmiStatusUnsol is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/OLHM/OlhmAdcsHmiStatusUnsol"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/OLHM/OlhmAdcsHmiStatusUnsol"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/OLHM/OlhmAdcsHmiStatusUnsol"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("OlhmAdcsHmiStatusUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessOlhmAdcsShutdownCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/OLHM/OlhmAdcsShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/OLHM/OlhmAdcsShutdownCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadOlhmAdcsShutdownCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadOlhmAdcsShutdownCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/OLHM/OlhmAdcsShutdownCmdRsp", "Class": sOLHM_ADCS_SHUTDOWN_CMD_RSP, "ClassName": "sOLHM_ADCS_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/OLHM/OlhmAdcsShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/OLHM/OlhmAdcsShutdownCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/OLHM/OlhmAdcsShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("OlhmAdcsShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessMmsShutdownCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/MMS/MmsShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/MMS/MmsShutdownCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/MMS/MmsShutdownCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/MMS/MmsShutdownCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/MMS/MmsShutdownCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/MMS/MmsShutdownCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/MMS/MmsShutdownCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/MMS/MmsShutdownCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadMmsShutdownCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadMmsShutdownCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/MMS/MmsShutdownCmdRsp", "Class": sMMS_SHUTDOWN_CMD_RSP, "ClassName": "sMMS_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/MMS/MmsShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/MMS/MmsShutdownCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/MMS/MmsShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/MMS/MmsShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/MMS/MmsShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("MmsShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    def vStorePublishConnectionState(self, tplPublishReturnStatePar):
        """ This is a public method which sets the connection state after a publish is done

        Args:
            tplPublishReturnStatePar (tuple): The first parameter. A tuple which came from the mqtt publish method. The items are (result, mid).

        Returns:

        Raises:
            Raises no exception.
        """
        # Store the current connection state
        self._tplPublishConnectionStateLast = tplPublishReturnStatePar
        if (self._tplPublishConnectionStateLast[0] != mqtt.MQTT_ERR_SUCCESS):
            self._tplPublishConnectionStateFirstFail = self._tplPublishConnectionStateLast

        return

    def vClearPublishConnectionState(self):
        """ This is a public method which sets the connection state to SUCCESS

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        # Set the current connection state
        self._tplPublishConnectionStateLast = (mqtt.MQTT_ERR_SUCCESS, 0)
        self._tplPublishConnectionStateFirstFail = (mqtt.MQTT_ERR_SUCCESS, 0)

        return

    def bMqttIsConnected(self):
        """ This is a public method which returns the mqtt broker connection state

        Args:

        Returns:
            (bool): Boolean value indicating if the mqtt broker connection is still active.

        Raises:
            Raises no exception.
        """
        # Store the current connection state
        return(self._tplPublishConnectionStateFirstFail[0] == mqtt.MQTT_ERR_SUCCESS)

# ==========================================================
# MQTT TEMPLATE CLASS STOP
# ==========================================================
# ==========================================================
# AUTOGEN STOP
# ==========================================================