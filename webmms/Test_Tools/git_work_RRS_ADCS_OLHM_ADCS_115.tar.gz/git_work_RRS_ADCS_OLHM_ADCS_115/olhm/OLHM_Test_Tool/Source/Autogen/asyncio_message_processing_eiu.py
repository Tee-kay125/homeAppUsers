#! /usr/bin/env python
# -*- coding: utf-8 -*-
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:32:42 SAST

    This module is the asyncio message processing class generated automatically from XML file(s). It is intended use is as a base class
    for a derived class which will be used in the asyncio event loop. The vProcessDictObj() method should only be called inside the
    asyncio event loop and using a create_task() call. Failure to do so might block the process currently running and should only be used
    as intended in a well designed asyncio implementation.

"""
# ==========================================================
# AUTOGEN START
# ==========================================================
import logging  # This is required to be able to log if there are problems
import asyncio  # This is required to concurrent operations in a single thread
import datetime  # This is needed to set a datetime result on a future
import time  # This is needed to get the time as time.CLOCK_MONOTONIC_RAW
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
from Autogen.mw_common_types import E2_MW_MESSAGE_STATUS
from Autogen.eiu_msg import *  # noqa: F401

# ==========================================================
# MQTT TEMPLATE CLASS START
# ==========================================================


class clsPythonAsyncioMessageProcessing():
    """ This is the message asyncio processing autogen class

    This is the message processing asyncio autogen class. Inherit this class in order to
    override the methods if required.

    Args:
        objMqttClientPar (mqtt.Client): The first parameter. The MQTT client instance for sending to the broker.
        dctMessagesPar (dict): The second parameter. A dictionary containing all messages and futures for messages which were automatically processed by the autogen
        lstTasksAllowedForsimultaneousExecutionPar (list): The third parameter. A list of topics for which simultaneous task execution is allowed. An empty list means no topics are allowed to execute simultaneously.
        objAsyncioLoopPar (object): The fourth parameter. The asyncio loop passed in so tasks can be created and for other asyncio functionality
        bLoggingEnabledPar (bool): The fifth parameter. A boolean flag indicating if logging should be done or not.

    """
    def __init__(self, objMqttClientPar: mqtt.Client, dctMessagesPar: dict, lstTasksAllowedForsimultaneousExecutionPar: list, objAsyncioLoopPar: object, bLoggingEnabledPar: bool = True):
        super().__init__()
        self._objMqttClient = objMqttClientPar
        self._dctMessages = dctMessagesPar
        self._lstTasksAllowedForsimultaneousExecution = lstTasksAllowedForsimultaneousExecutionPar
        self._objAsyncioLoop = objAsyncioLoopPar
        self._bLoggingEnabled = bLoggingEnabledPar
        # When we mqtt publish the connection state is returned - This property stores the last state
        self._tplPublishConnectionStateLast = (mqtt.MQTT_ERR_SUCCESS, 0)
        # When we mqtt publish the connection state is returned - This property stores the first time it failed 
        self._tplPublishConnectionStateFirstFail = (mqtt.MQTT_ERR_SUCCESS, 0)

        # In the message dictionary we store the Topic, ClassName, Class, MsgObject, Future, UTC timestamp, monotonic raw timestamp and role
        self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"] = {"ClassName": "sEIU_STATUS_REPORT_UNSOL", "Class": sEIU_STATUS_REPORT_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"] = {"ClassName": "sEIU_END_OF_SETUP_CMD_RSP", "Class": sEIU_END_OF_SETUP_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"] = {"ClassName": "sEIU_END_OF_READY_CMD_RSP", "Class": sEIU_END_OF_READY_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"] = {"ClassName": "sEIU_SHUTDOWN_CMD_RSP", "Class": sEIU_SHUTDOWN_CMD_RSP, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/EIU/EiuSensorPointTrackUnsol"] = {"ClassName": "sEIU_SENSOR_POINT_TRACK_UNSOL", "Class": sEIU_SENSOR_POINT_TRACK_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/EIU/EiuSensorBearingTrackUnsol"] = {"ClassName": "sEIU_SENSOR_BEARING_TRACK_UNSOL", "Class": sEIU_SENSOR_BEARING_TRACK_UNSOL, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"] = {"ClassName": "sEIU_END_OF_SETUP_CMD", "Class": sEIU_END_OF_SETUP_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"] = {"ClassName": "sEIU_END_OF_READY_CMD", "Class": sEIU_END_OF_READY_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}
        self._dctMessages["ADCS/EIU/EiuShutdownCmd"] = {"ClassName": "sEIU_SHUTDOWN_CMD", "Class": sEIU_SHUTDOWN_CMD, "MsgObject": None, "objAsyncioFutureProcessCompleted": asyncio.Future(), "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        # We have this dictionary to demux a topic into the processing method which should be called - it's more efficient than a long list of if statements
        self._dctDemuxTopicToMethod = {
            "ADCS/EIU/EiuStatusReportUnsol": self.vProcessEiuStatusReportUnsol,
            "ADCS/EIU/EiuEndOfSetupCmdRsp": self.vProcessEiuEndOfSetupCmdRsp,
            "ADCS/EIU/EiuEndOfReadyCmdRsp": self.vProcessEiuEndOfReadyCmdRsp,
            "ADCS/EIU/EiuShutdownCmdRsp": self.vProcessEiuShutdownCmdRsp,
            "ADCS/EIU/EiuSensorPointTrackUnsol": self.vProcessEiuSensorPointTrackUnsol,
            "ADCS/EIU/EiuSensorBearingTrackUnsol": self.vProcessEiuSensorBearingTrackUnsol,
            "ADCS/EIU/EiuEndOfSetupCmd": self.vProcessEiuEndOfSetupCmd,
            "ADCS/EIU/EiuEndOfReadyCmd": self.vProcessEiuEndOfReadyCmd,
            "ADCS/EIU/EiuShutdownCmd": self.vProcessEiuShutdownCmd,
        }

        # This is a dictionary which keeps track of how many tasks are currently being executed per topic - for typical use this number will be either 0 or 1
        self._dctNumExecutingTasks = {
            "ADCS/EIU/EiuStatusReportUnsol": 0,
            "ADCS/EIU/EiuEndOfSetupCmdRsp": 0,
            "ADCS/EIU/EiuEndOfReadyCmdRsp": 0,
            "ADCS/EIU/EiuShutdownCmdRsp": 0,
            "ADCS/EIU/EiuSensorPointTrackUnsol": 0,
            "ADCS/EIU/EiuSensorBearingTrackUnsol": 0,
            "ADCS/EIU/EiuEndOfSetupCmd": 0,
            "ADCS/EIU/EiuEndOfReadyCmd": 0,
            "ADCS/EIU/EiuShutdownCmd": 0,
        }

    # ==========================================================
    # PROCESS DICTIONARY START
    # ==========================================================
    async def vProcessDictObj(self, dctObjectPar) -> None:
        """ This is a public method which demuxes messages from the python queue.

        This is a public method which demuxes messages from the python queue. It uses a dictionary as a lookup in
        order to determine which method to call. Unknown topics will be logged as an error.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """

        # Make sure our input parameter is not None
        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        # Make sure our input parameter dictionary does have a topic key
        if ("Topic" not in dctObjectPar):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar does not contain the key Topic")
            return

        # Use the demux dictionary to determine which method should be called
        if (dctObjectPar["Topic"] in self._dctDemuxTopicToMethod):
            if ((self._dctNumExecutingTasks[dctObjectPar["Topic"]] <= 0) or (dctObjectPar["Topic"] in self._lstTasksAllowedForsimultaneousExecution)):
                self._dctNumExecutingTasks[dctObjectPar["Topic"]] += 1
                await self._dctDemuxTopicToMethod[dctObjectPar["Topic"]](dctObjectPar)
                self._dctNumExecutingTasks[dctObjectPar["Topic"]] -= 1
            else:
                logging.warning("Incoming topic %s cannot be processed right now because there is already a task executing for it - the task counter is %d", dctObjectPar["Topic"], self._dctNumExecutingTasks[dctObjectPar["Topic"]])
        else:
            logging.error("Received message with topic %s does not have a corresponding processing method to call - demux failed because topic unknown", dctObjectPar["Topic"])

        return

    # ==========================================================
    # PROCESS DICTIONARY START
    # ==========================================================
    async def vProcessEiuStatusReportUnsol(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/EIU/EiuStatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuStatusReportUnsol is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadEiuStatusReportUnsol(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadEiuStatusReportUnsol(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/EIU/EiuStatusReportUnsol", "Class": sEIU_STATUS_REPORT_UNSOL, "ClassName": "sEIU_STATUS_REPORT_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/EIU/EiuStatusReportUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuStatusReportUnsol is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/EIU/EiuStatusReportUnsol"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("EiuStatusReportUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessEiuEndOfSetupCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/EIU/EiuEndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuEndOfSetupCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadEiuEndOfSetupCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadEiuEndOfSetupCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/EIU/EiuEndOfSetupCmdRsp", "Class": sEIU_END_OF_SETUP_CMD_RSP, "ClassName": "sEIU_END_OF_SETUP_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/EIU/EiuEndOfSetupCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuEndOfSetupCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/EIU/EiuEndOfSetupCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("EiuEndOfSetupCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessEiuEndOfReadyCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/EIU/EiuEndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuEndOfReadyCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadEiuEndOfReadyCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadEiuEndOfReadyCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/EIU/EiuEndOfReadyCmdRsp", "Class": sEIU_END_OF_READY_CMD_RSP, "ClassName": "sEIU_END_OF_READY_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/EIU/EiuEndOfReadyCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuEndOfReadyCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/EIU/EiuEndOfReadyCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("EiuEndOfReadyCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessEiuShutdownCmdRsp(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/EIU/EiuShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuShutdownCmdRsp is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadEiuShutdownCmdRsp(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadEiuShutdownCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/EIU/EiuShutdownCmdRsp", "Class": sEIU_SHUTDOWN_CMD_RSP, "ClassName": "sEIU_SHUTDOWN_CMD_RSP", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/EIU/EiuShutdownCmdRsp" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuShutdownCmdRsp is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/EIU/EiuShutdownCmdRsp"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("EiuShutdownCmdRsp's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessEiuSensorPointTrackUnsol(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/EIU/EiuSensorPointTrackUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuSensorPointTrackUnsol is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/EIU/EiuSensorPointTrackUnsol"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/EIU/EiuSensorPointTrackUnsol"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/EIU/EiuSensorPointTrackUnsol"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/EIU/EiuSensorPointTrackUnsol"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/EIU/EiuSensorPointTrackUnsol"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/EIU/EiuSensorPointTrackUnsol"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadEiuSensorPointTrackUnsol(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadEiuSensorPointTrackUnsol(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/EIU/EiuSensorPointTrackUnsol", "Class": sEIU_SENSOR_POINT_TRACK_UNSOL, "ClassName": "sEIU_SENSOR_POINT_TRACK_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/EIU/EiuSensorPointTrackUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuSensorPointTrackUnsol is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/EIU/EiuSensorPointTrackUnsol"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/EIU/EiuSensorPointTrackUnsol"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/EIU/EiuSensorPointTrackUnsol"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("EiuSensorPointTrackUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessEiuSensorBearingTrackUnsol(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/EIU/EiuSensorBearingTrackUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuSensorBearingTrackUnsol is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/EIU/EiuSensorBearingTrackUnsol"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/EIU/EiuSensorBearingTrackUnsol"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/EIU/EiuSensorBearingTrackUnsol"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/EIU/EiuSensorBearingTrackUnsol"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/EIU/EiuSensorBearingTrackUnsol"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/EIU/EiuSensorBearingTrackUnsol"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadEiuSensorBearingTrackUnsol(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        # If no publish is being done here then this message does not have ReplyMsg defined in the XML
        # or it is a message from a secondary XML

        return

    async def objProcessPayloadEiuSensorBearingTrackUnsol(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/EIU/EiuSensorBearingTrackUnsol", "Class": sEIU_SENSOR_BEARING_TRACK_UNSOL, "ClassName": "sEIU_SENSOR_BEARING_TRACK_UNSOL", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/EIU/EiuSensorBearingTrackUnsol" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuSensorBearingTrackUnsol is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/EIU/EiuSensorBearingTrackUnsol"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/EIU/EiuSensorBearingTrackUnsol"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/EIU/EiuSensorBearingTrackUnsol"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("EiuSensorBearingTrackUnsol's future -> %s", str(E))

        # If a None is being returned here then this message has no ReplyMsg defined
        return(None)

    async def vProcessEiuEndOfSetupCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/EIU/EiuEndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuEndOfSetupCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadEiuEndOfSetupCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTEiuEndOfSetupCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadEiuEndOfSetupCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/EIU/EiuEndOfSetupCmd", "Class": sEIU_END_OF_SETUP_CMD, "ClassName": "sEIU_END_OF_SETUP_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/EIU/EiuEndOfSetupCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuEndOfSetupCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/EIU/EiuEndOfSetupCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("EiuEndOfSetupCmd's future -> %s", str(E))

        return(sEIU_END_OF_SETUP_CMD_RSP())

    def vPublishToMQQTEiuEndOfSetupCmdRsp(self, objEiuEndOfSetupCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objEiuEndOfSetupCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objEiuEndOfSetupCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objEiuEndOfSetupCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/EIU/EiuEndOfSetupCmdRsp", objEiuEndOfSetupCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessEiuEndOfReadyCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/EIU/EiuEndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuEndOfReadyCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadEiuEndOfReadyCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTEiuEndOfReadyCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadEiuEndOfReadyCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/EIU/EiuEndOfReadyCmd", "Class": sEIU_END_OF_READY_CMD, "ClassName": "sEIU_END_OF_READY_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/EIU/EiuEndOfReadyCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuEndOfReadyCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/EIU/EiuEndOfReadyCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("EiuEndOfReadyCmd's future -> %s", str(E))

        return(sEIU_END_OF_READY_CMD_RSP())

    def vPublishToMQQTEiuEndOfReadyCmdRsp(self, objEiuEndOfReadyCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objEiuEndOfReadyCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objEiuEndOfReadyCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objEiuEndOfReadyCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/EIU/EiuEndOfReadyCmdRsp", objEiuEndOfReadyCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    async def vProcessEiuShutdownCmd(self, dctObjectPar) -> None:
        """ This is a public method which processes a message once demuxed.

        This is a public method which processes a message once demuxed. It will place the received message into the message dictionary
        so that other methods also have access to it if required. The idea is that this method is not concerned with the specifics of
        the payload but the more the message in its entirety. For payload processing there should be another auto generated method which
        is designated to deal with it. For messages from a primary XML an automatic reply will done if the receiving message had a ReplyMsg
        attribute defined. Secondary messages will not be replied to even if a ReplyMsg is defined.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        objReplyMessage = None  # pylint: disable=W0612

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return

        if ("ADCS/EIU/EiuShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuShutdownCmd is not in self._dctMessages")
            return

        # Copy the items from the dictionary received from the queue and put them into the autogen message dictionary
        self._dctMessages["ADCS/EIU/EiuShutdownCmd"]["Class"] = dctObjectPar["Class"]
        self._dctMessages["ADCS/EIU/EiuShutdownCmd"]["ClassName"] = dctObjectPar["ClassName"]
        self._dctMessages["ADCS/EIU/EiuShutdownCmd"]["MsgObject"] = dctObjectPar["MsgObject"]
        self._dctMessages["ADCS/EIU/EiuShutdownCmd"]["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
        self._dctMessages["ADCS/EIU/EiuShutdownCmd"]["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
        self._dctMessages["ADCS/EIU/EiuShutdownCmd"]["acRole"] = dctObjectPar["acRole"]
        objReplyMessage = await self.objProcessPayloadEiuShutdownCmd(dctObjectPar)  # noqa: F841 - local variable is assigned but never used
        if (objReplyMessage is not None):
            self.vPublishToMQQTEiuShutdownCmdRsp(objReplyMessage)

        return

    async def objProcessPayloadEiuShutdownCmd(self, dctObjectPar) -> object:
        """ This is a public method which must be used to process a message payload.

        This is a public method which must be used to process a message payload. Pedending on if this message is from
        a primary XML and if the message has a ReplyMsg the method will return a reply message or None.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will contain the reply message if processing was successful. Will be None otherwise

        Raises:
            Raises no exception.
        """
        # This dictionary will be the Future's result value - fill in what we have for now
        dctFutureResult = {"Topic": "ADCS/EIU/EiuShutdownCmd", "Class": sEIU_SHUTDOWN_CMD, "ClassName": "sEIU_SHUTDOWN_CMD", "MsgObject": None, "objDateTimeUtc": None, "objDateTimeMonotonicRaw": None, "acRole": ""}

        if (dctObjectPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("dctObjectPar is None")
            return(None)

        if (self._objAsyncioLoop is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objAsyncioLoop is None")
            return(None)

        if (self._dctMessages is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._dctMessages is None")
            return(None)

        if ("ADCS/EIU/EiuShutdownCmd" not in self._dctMessages):
            if (self._bLoggingEnabled is True):
                logging.error("Dictionary key ADCS/EIU/EiuShutdownCmd is not in self._dctMessages")
            return(None)

        # First make sure we have an instance at least - no null values
        if (self._dctMessages["ADCS/EIU/EiuShutdownCmd"]["objAsyncioFutureProcessCompleted"] is not None):
            try:
                # Then check if the future is maybe already done
                if (self._dctMessages["ADCS/EIU/EiuShutdownCmd"]["objAsyncioFutureProcessCompleted"].done() is not True):
                    dctFutureResult["MsgObject"] = dctObjectPar["MsgObject"]
                    # We use UTC time to avoid daylight savings
                    dctFutureResult["objDateTimeUtc"] = datetime.datetime.now(datetime.timezone.utc)
                    # We use CLOCK_MONOTONIC_RAW to avoid NTP changes
                    dctFutureResult["objDateTimeMonotonicRaw"] = datetime.datetime.fromtimestamp(time.clock_gettime(time.CLOCK_MONOTONIC_RAW), tz=None)
                    self._dctMessages["ADCS/EIU/EiuShutdownCmd"]["objAsyncioFutureProcessCompleted"].set_result(dctFutureResult)  # Set the result dictionary as the result
            except Exception as E:
                if (self._bLoggingEnabled is True):
                    logging.error("EiuShutdownCmd's future -> %s", str(E))

        return(sEIU_SHUTDOWN_CMD_RSP())

    def vPublishToMQQTEiuShutdownCmdRsp(self, objEiuShutdownCmdRspPar) -> None:
        """ This is a public method which sends a reply message to MQTT.
        This method purposely does nothing so that it can overriden by a derived class.

        Args:
            objEiuShutdownCmdRspPar (object): The first parameter. A parameter containing the message which will be published using the mqtt client

        Returns:

        Raises:
            Raises no exception.
        """
        tplReturn = (mqtt.MQTT_ERR_NO_CONN, 0)

        if (self._objMqttClient is None):
            if (self._bLoggingEnabled is True):
                logging.error("self._objMqttClient is None")
            return

        if (objEiuShutdownCmdRspPar is None):
            if (self._bLoggingEnabled is True):
                logging.error("objEiuShutdownCmdRspPar is None")
            return

        # Get the publish result so we can know if we are still connected to the mqtt broker
        tplReturn = self._objMqttClient.publish("ADCS/EIU/EiuShutdownCmdRsp", objEiuShutdownCmdRspPar.btaSerialise(), qos=0)
        self.vStorePublishConnectionState(tplReturn)

        return

    def vStorePublishConnectionState(self, tplPublishReturnStatePar):
        """ This is a public method which sets the connection state after a publish is done

        Args:
            tplPublishReturnStatePar (tuple): The first parameter. A tuple which came from the mqtt publish method. The items are (result, mid).

        Returns:

        Raises:
            Raises no exception.
        """
        # Store the current connection state
        self._tplPublishConnectionStateLast = tplPublishReturnStatePar
        if (self._tplPublishConnectionStateLast[0] != mqtt.MQTT_ERR_SUCCESS):
            self._tplPublishConnectionStateFirstFail = self._tplPublishConnectionStateLast

        return

    def vClearPublishConnectionState(self):
        """ This is a public method which sets the connection state to SUCCESS

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        # Set the current connection state
        self._tplPublishConnectionStateLast = (mqtt.MQTT_ERR_SUCCESS, 0)
        self._tplPublishConnectionStateFirstFail = (mqtt.MQTT_ERR_SUCCESS, 0)

        return

    def bMqttIsConnected(self):
        """ This is a public method which returns the mqtt broker connection state

        Args:

        Returns:
            (bool): Boolean value indicating if the mqtt broker connection is still active.

        Raises:
            Raises no exception.
        """
        # Store the current connection state
        return(self._tplPublishConnectionStateFirstFail[0] == mqtt.MQTT_ERR_SUCCESS)

# ==========================================================
# MQTT TEMPLATE CLASS STOP
# ==========================================================
# ==========================================================
# AUTOGEN STOP
# ==========================================================