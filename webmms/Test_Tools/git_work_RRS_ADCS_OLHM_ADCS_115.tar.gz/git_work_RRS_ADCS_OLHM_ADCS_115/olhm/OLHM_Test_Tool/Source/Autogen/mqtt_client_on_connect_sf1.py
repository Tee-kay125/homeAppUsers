#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:32:41 SAST

    This module is the mqtt client on connect class, generated automatically from XML file(s). Its intended use is as a class
    with mqtt callbacks for on_connect() and on_message(). This class should be instantiated before the mqtt connect. The mqtt 
    on_connect() callback should be redirected as -> client.on_connect = objClsMqttAutogenHandler.vOnConnect
    It should be noted that all operations inside this class will execute inside the mqtt thread. The processing methods in this class
    will validate the incoming messages and reply only if validation failed. Messages which passed validation will be placed in a queue provided to
    the constructor of the class. 

"""
# ==========================================================
# AUTOGEN START
# ==========================================================
import logging  # This is required to be able to log if there are problems
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
import queue  # This is required to put the received message in a queue to pass on to another non-mqtt thread
from copy import deepcopy  # This is required to make a deepcopy of the message before insertion in the queue - it ensures proper garbage collection
from Autogen.mw_common_types import E2_MW_MESSAGE_STATUS
from Autogen.sf1_msg import *  # noqa: F401

# ==========================================================
# MQTT TEMPLATE CLASS START
# ==========================================================


class clsMqttAutogenHandler():
    """ This is the MQTT message handling autogen base class

    This is the MQTT message handling autogen base class. An instance of this class should be made before giving the mqtt client
    a on_connect() callback from this class.

    Args:
        objQueuePar (queue.Queue): The first parameter. The instance of the python queue into which we will push messages received
        bLoggingEnabledPar (bool): The second parameter. A boolean flag indicating if logging should be done or not. This parameter is by default True

    """
    def __init__(self, objQueuePar: queue.Queue, bLoggingEnabledPar: bool = True):
        super().__init__()
        self._bLoggingEnabled = bLoggingEnabledPar
        self._objQueue = objQueuePar
        # By default all subscriptions will auto reply if a ReplyMsg was specified
        self.bAutoReplyForSubscriptionSf1EndOfSetupCmd = True
        self.bAutoReplyForSubscriptionSf1EndOfReadyCmd = True
        self.bAutoReplyForSubscriptionSf1ShutdownCmd = True
        self.bAutoReplyForSubscriptionSf1ModeCmdRsp = True

    def vOnConnect(self, objMqttClientPar: mqtt.Client, userDataPar, dctFlags, iConnectionResult: int) -> None:  # pylint: disable=W0613
        """ This is the callback method for when client receives a CONNACK response from the server

        This is the callback method for when client receives a CONNACK response from the server. This method subscribes
        and registers callback methods for all incoming messages. Messages from secondary XML files will not automatically be
        subscribed to. The on message callbacks will however all automatically be registered even for secondary XML files.

        Args:
            objMqttClientPar (obj): The first parameter. A MQTT client object
            userDataPar: The second parameter. The private user data as set in Client() or userdata_set()
            flags: The third parameter. flags is a dict that contains response flags from the broker:
            rc: The fourth parameter. The connection result

        Returns:

        Raises:
            Raises no exceptions
        """

        # Subscribing and adding callback for Sf1EndOfSetupCmd 
        # Subscribing and adding callback for Sf1EndOfSetupCmd 
        # Subscribing and adding callback for Sf1EndOfSetupCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message Sf1EndOfSetupCmd  with topic ADCS/SF1/Sf1EndOfSetupCmd")

        try:
            objMqttClientPar.subscribe("ADCS/SF1/Sf1EndOfSetupCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf1EndOfSetupCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for Sf1EndOfSetupCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/SF1/Sf1EndOfSetupCmd", self.vOnMessageCallbackSf1EndOfSetupCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for Sf1EndOfSetupCmd  - Exception %s", str(E))
        # Subscribing and adding callback for Sf1EndOfReadyCmd 
        # Subscribing and adding callback for Sf1EndOfReadyCmd 
        # Subscribing and adding callback for Sf1EndOfReadyCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message Sf1EndOfReadyCmd  with topic ADCS/SF1/Sf1EndOfReadyCmd")

        try:
            objMqttClientPar.subscribe("ADCS/SF1/Sf1EndOfReadyCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf1EndOfReadyCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for Sf1EndOfReadyCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/SF1/Sf1EndOfReadyCmd", self.vOnMessageCallbackSf1EndOfReadyCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for Sf1EndOfReadyCmd  - Exception %s", str(E))
        # Subscribing and adding callback for Sf1ShutdownCmd 
        # Subscribing and adding callback for Sf1ShutdownCmd 
        # Subscribing and adding callback for Sf1ShutdownCmd 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message Sf1ShutdownCmd  with topic ADCS/SF1/Sf1ShutdownCmd")

        try:
            objMqttClientPar.subscribe("ADCS/SF1/Sf1ShutdownCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf1ShutdownCmd  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for Sf1ShutdownCmd ")

        try:
            objMqttClientPar.message_callback_add("ADCS/SF1/Sf1ShutdownCmd", self.vOnMessageCallbackSf1ShutdownCmd)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for Sf1ShutdownCmd  - Exception %s", str(E))
        # Subscribing and adding callback for Sf1ModeCmdRsp 
        # Subscribing and adding callback for Sf1ModeCmdRsp 
        # Subscribing and adding callback for Sf1ModeCmdRsp 

        if self._bLoggingEnabled:
            logging.info("Subscribed to message Sf1ModeCmdRsp  with topic ADCS/SF1/Sf1ModeCmdRsp")

        try:
            objMqttClientPar.subscribe("ADCS/SF1/Sf1ModeCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf1ModeCmdRsp  - Exception %s", str(E))

        if self._bLoggingEnabled:
            logging.debug("Adding message callback method for Sf1ModeCmdRsp ")

        try:
            objMqttClientPar.message_callback_add("ADCS/SF1/Sf1ModeCmdRsp", self.vOnMessageCallbackSf1ModeCmdRsp)  # Autogen: register callback
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not add message callback for Sf1ModeCmdRsp  - Exception %s", str(E))

        return

# =========================================================="
# MQTT CALLBACK METHODS START
# =========================================================="

    def vOnMessageCallbackSf1EndOfSetupCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message Sf1EndOfSetupCmd

        This is a public method callback for message Sf1EndOfSetupCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objSf1EndOfSetupCmd = sSF1_END_OF_SETUP_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objSf1EndOfSetupCmdRsp = sSF1_END_OF_SETUP_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1EndOfSetupCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1EndOfSetupCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1EndOfSetupCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objSf1EndOfSetupCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1EndOfSetupCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objSf1EndOfSetupCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for Sf1EndOfSetupCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objSf1EndOfSetupCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf1EndOfSetupCmd  validation failed")
            elif (objSf1EndOfSetupCmd.sMsgHeader.u2MsgLength.Value != (objSf1EndOfSetupCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf1EndOfSetupCmd  length field is invalid - it is %d and should be %d bytes", objSf1EndOfSetupCmd.sMsgHeader.u2MsgLength.Value, objSf1EndOfSetupCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/SF1/Sf1EndOfSetupCmd", "Class": sSF1_END_OF_SETUP_CMD, "ClassName": "sSF1_END_OF_SETUP_CMD", "acRole": "", "MsgObject": deepcopy(objSf1EndOfSetupCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/SF1/Sf1EndOfSetupCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionSf1EndOfSetupCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objSf1EndOfSetupCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/SF1/Sf1EndOfSetupCmdRsp", objSf1EndOfSetupCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("Sf1EndOfSetupCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackSf1EndOfReadyCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message Sf1EndOfReadyCmd

        This is a public method callback for message Sf1EndOfReadyCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objSf1EndOfReadyCmd = sSF1_END_OF_READY_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objSf1EndOfReadyCmdRsp = sSF1_END_OF_READY_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1EndOfReadyCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1EndOfReadyCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1EndOfReadyCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objSf1EndOfReadyCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1EndOfReadyCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objSf1EndOfReadyCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for Sf1EndOfReadyCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objSf1EndOfReadyCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf1EndOfReadyCmd  validation failed")
            elif (objSf1EndOfReadyCmd.sMsgHeader.u2MsgLength.Value != (objSf1EndOfReadyCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf1EndOfReadyCmd  length field is invalid - it is %d and should be %d bytes", objSf1EndOfReadyCmd.sMsgHeader.u2MsgLength.Value, objSf1EndOfReadyCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/SF1/Sf1EndOfReadyCmd", "Class": sSF1_END_OF_READY_CMD, "ClassName": "sSF1_END_OF_READY_CMD", "acRole": "", "MsgObject": deepcopy(objSf1EndOfReadyCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/SF1/Sf1EndOfReadyCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionSf1EndOfReadyCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objSf1EndOfReadyCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/SF1/Sf1EndOfReadyCmdRsp", objSf1EndOfReadyCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("Sf1EndOfReadyCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackSf1ShutdownCmd(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message Sf1ShutdownCmd

        This is a public method callback for message Sf1ShutdownCmd. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objSf1ShutdownCmd = sSF1_SHUTDOWN_CMD()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(True)   # This message has a ReplyMsg so we will reply if it is not valid
        objSf1ShutdownCmdRsp = sSF1_SHUTDOWN_CMD_RSP()
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1ShutdownCmd  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1ShutdownCmd  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1ShutdownCmd  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objSf1ShutdownCmd.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1ShutdownCmd  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objSf1ShutdownCmd.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for Sf1ShutdownCmd  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objSf1ShutdownCmd.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf1ShutdownCmd  validation failed")
            elif (objSf1ShutdownCmd.sMsgHeader.u2MsgLength.Value != (objSf1ShutdownCmd.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf1ShutdownCmd  length field is invalid - it is %d and should be %d bytes", objSf1ShutdownCmd.sMsgHeader.u2MsgLength.Value, objSf1ShutdownCmd.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/SF1/Sf1ShutdownCmd", "Class": sSF1_SHUTDOWN_CMD, "ClassName": "sSF1_SHUTDOWN_CMD", "acRole": "", "MsgObject": deepcopy(objSf1ShutdownCmd)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/SF1/Sf1ShutdownCmd")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        if ((bSendReply is True) and (self.bAutoReplyForSubscriptionSf1ShutdownCmd is True) and (eRspMsgStatus != E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)):
            try:
                # Set the status
                objSf1ShutdownCmdRsp.sMsgHeader.e2MsgStatus.Value = eRspMsgStatus

                # From paho mqtt reference: publish(topic, payload=None, qos=0, retain=False)
                objMqttClientPar.publish("ADCS/SF1/Sf1ShutdownCmdRsp", objSf1ShutdownCmdRsp.btaSerialise(), qos=0, retain=False)
            except Exception as E:
                if self._bLoggingEnabled:
                    logging.error("Sf1ShutdownCmd's publish threw exception - %s", str(E))

        return

    def vOnMessageCallbackSf1ModeCmdRsp(self, objMqttClientPar: mqtt.Client, userDataPar, objMsgPar) -> None:  # pylint: disable=W0613
        """ This is a public method callback for message Sf1ModeCmdRsp

        This is a public method callback for message Sf1ModeCmdRsp. This callback will, if executed, put the processed messages
        in a queue. Messages will automatically be replied to if the the message has a reply message and the message was not valid.

        Args:
            objMqttClientPar (obj): The first argument. The MQTT client.
            userDataPar: The second argument
            objMsgPar: The third argument. Contains the payload of the message received

        Returns:

        Raises:
            Raises no exceptions
        """

        objSf1ModeCmdRsp = sSF1_MODE_CMD_RSP()
        bProcessReceivedMessage = bool(True)  # We will only process a message if the length is correct and the validation passed
        bSendReply = bool(False)  # This message is not from a primary XML or does not have a ReplyMsg. We will therefore not reply.
        # If no reply message is being published here then this message does not have ReplyMsg or it is a message from a secondary XML
        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL  # Start the message status as normal for now

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            bSendReply = bool(False)  # noqa: F841
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1ModeCmdRsp  objMqttClientPar is None")

        # Make sure the method argument is not none
        if (objMsgPar is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1ModeCmdRsp  objMsgPar is None")

        # Make sure the method argument's payload is not none
        if (objMsgPar.payload is None):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1ModeCmdRsp  objMsgPar.payload is None")

        # Make sure the message payload is the correct length
        if (len(objMsgPar.payload) != objSf1ModeCmdRsp.iSizeBytes()):
            bProcessReceivedMessage = bool(False)
            eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_MSG_FIELD
            if self._bLoggingEnabled:
                logging.error("Callback method for Sf1ModeCmdRsp  length of objMsgPar.payload does not match the message")

        # Load the message into the object of the class if it looks valid so far
        if (eRspMsgStatus == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            try:
                objSf1ModeCmdRsp.vDeserialise(objMsgPar.payload)
            except Exception as E:
                bProcessReceivedMessage = bool(False)
                if self._bLoggingEnabled:
                    logging.error("Callback method for Sf1ModeCmdRsp  - vDeserialise threw exception - %s", str(E))

        if (bProcessReceivedMessage is True):
            if (objSf1ModeCmdRsp.bValidate() is not True):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf1ModeCmdRsp  validation failed")
            elif (objSf1ModeCmdRsp.sMsgHeader.u2MsgLength.Value != (objSf1ModeCmdRsp.iSizeBytes() - 2)):
                eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_INVALID_FIELD
                if self._bLoggingEnabled:
                    logging.error("Message Sf1ModeCmdRsp  length field is invalid - it is %d and should be %d bytes", objSf1ModeCmdRsp.sMsgHeader.u2MsgLength.Value, objSf1ModeCmdRsp.iSizeBytes() - 2)
            else:
                # Only put the message in the queue if the validation passed
                if (self._objQueue is not None):
                    if (self._objQueue.full() is False):
                        self._objQueue.put(({"Topic": "ADCS/SF1/Sf1ModeCmdRsp", "Class": sSF1_MODE_CMD_RSP, "ClassName": "sSF1_MODE_CMD_RSP", "acRole": "", "MsgObject": deepcopy(objSf1ModeCmdRsp)}))
                    else:
                        eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                        if self._bLoggingEnabled:
                            logging.error("Queue between MQTT client and asyncio is full! Dropping MQTT message %s", "ADCS/SF1/Sf1ModeCmdRsp")
                else:
                    eRspMsgStatus = E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_SOFTWARE_ERROR
                    if self._bLoggingEnabled:
                        logging.error("The class property self._objQueue is None - cannot place message in the queue")

        # If no reply message is being published here then this message does not have ReplyMsg

        return
# ==========================================================
# MQTT CALLBACK METHODS STOP
# ==========================================================
# ==========================================================
# MQTT SUBSCRIPTION METHODS START
# ==========================================================

    def vSubscribeMessageSf1EndOfSetupCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message Sf1EndOfSetupCmd.

        This is the auto generated method for subscribing message Sf1EndOfSetupCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for Sf1EndOfSetupCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/SF1/Sf1EndOfSetupCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf1EndOfSetupCmd  - Exception %s", str(E))

        return

    def vSubscribeMessageSf1EndOfReadyCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message Sf1EndOfReadyCmd.

        This is the auto generated method for subscribing message Sf1EndOfReadyCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for Sf1EndOfReadyCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/SF1/Sf1EndOfReadyCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf1EndOfReadyCmd  - Exception %s", str(E))

        return

    def vSubscribeMessageSf1ShutdownCmd(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message Sf1ShutdownCmd.

        This is the auto generated method for subscribing message Sf1ShutdownCmd.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for Sf1ShutdownCmd  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/SF1/Sf1ShutdownCmd", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf1ShutdownCmd  - Exception %s", str(E))

        return

    def vSubscribeMessageSf1ModeCmdRsp(self, objMqttClientPar: mqtt.Client) -> None:  # pylint: disable=W0613
        """ This is the auto generated method for subscribing message Sf1ModeCmdRsp.

        This is the auto generated method for subscribing message Sf1ModeCmdRsp.

        Args:
            objMqttClientPar (mqtt.Client): The first parameter. The MQTT client object being passed in.

        Returns:

        Raises:
            Raises no exceptions
        """

        # Make sure the mqtt client object is not None
        if (objMqttClientPar is None):
            if self._bLoggingEnabled:
                logging.error("Subscribe method for Sf1ModeCmdRsp  objMqttClientPar is None")
            return

        try:
            objMqttClientPar.subscribe("ADCS/SF1/Sf1ModeCmdRsp", qos=0)  # Autogen: subscribe to the message
        except Exception as E:
            if self._bLoggingEnabled:
                logging.error("Could not subscribe message Sf1ModeCmdRsp  - Exception %s", str(E))

        return

# ==========================================================
# MQTT SUBSCRIPTION METHODS START
# ==========================================================
# ==========================================================
# MQTT TEMPLATE CLASS STOP
# ==========================================================
# ==========================================================
# AUTOGEN STOP
# ==========================================================