#!/usr/bin/env python3.6
"""
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!
    Autogen - Do not edit by hand!

    Generated using Python 3.6.9
    Rendered with Jinja2 2.11.1
    Generated on 2020-05-25 14:32:29 SAST
"""


from Autogen.adcs_base_types import clsAdcsBaseType
from Autogen.adcs_base_types import clsAdcsEnumType
from Autogen.adcs_base_types import clsAdcsEnumArrayType
from Autogen.adcs_base_types import clsAdcsStructType
from Autogen.adcs_base_types import clsAdcsStructArrayType
from Autogen.adcs_base_types import clsAdcsMessageType
from Autogen.adcs_base_types import vAddEnum
from Autogen.adcs_base_types import vAddClass
from Autogen.adcs_base_types import vAddMessage
from Autogen.adcs_base_types import clsAdcsHeaderStructType
from Autogen.adcs_base_types import clsAdcsMessageStructType

# IMPORT CODE START
from Autogen.mw_common_types import *
from Autogen.adcs_common_types import *
# IMPORT CODE END

# TYPEDEFS START
class E1_OLHM_STATE(clsAdcsEnumType):
    """Public class definition of type E1_OLHM_STATE
    """
    def __init__(self, defaultValue=0):
        super().__init__("U1", defaultValue)
    OLHM_STATE_UNKNOWN = 0x00
    OLHM_STATE_OFFLINE = 0x01
    OLHM_STATE_INITIALISE = 0x02
    OLHM_STATE_READY = 0x03
    OLHM_STATE_OPERATIONAL = 0x04
    OLHM_STATE_SHUTDOWN = 0x05
    OLHM_STATE_FAILED = 0x06


vAddEnum("E1_OLHM_STATE", E1_OLHM_STATE)


class E1_OLHM_HEALTH_STATUS(clsAdcsEnumType):
    """Public class definition of type E1_OLHM_HEALTH_STATUS
    """
    def __init__(self, defaultValue=0):
        super().__init__("U1", defaultValue)
    OLHM_SYSTEM_HEALTH_UNKNOWN = 0
    OLHM_SYSTEM_HEALTH_NOT_FITTED = 1
    OLHM_SYSTEM_HEALTH_FAILED = 2
    OLHM_SYSTEM_HEALTH_DEGRADED = 3
    OLHM_SYSTEM_HEALTH_PASSED = 4


vAddEnum("E1_OLHM_HEALTH_STATUS", E1_OLHM_HEALTH_STATUS)


class E1_OLHM_ACTION_STATUS_REPORT(clsAdcsEnumType):
    """Public class definition of type E1_OLHM_ACTION_STATUS_REPORT
    """
    def __init__(self, defaultValue=0):
        super().__init__("U1", defaultValue)
    OLHM_ACTION_STATUS_REPORT_OUT_OF_ACTION = 0
    OLHM_ACTION_STATUS_REPORT_READY_FOR_ACTION = 1
    OLHM_ACTION_STATUS_REPORT_IN_ACTION = 2


vAddEnum("E1_OLHM_ACTION_STATUS_REPORT", E1_OLHM_ACTION_STATUS_REPORT)


class sOLHM_DETAILED_STATUS(clsAdcsStructType):
    """Public class definition of type sOLHM_DETAILED_STATUS
    """
    def __init__(self, defaultValue=0):
        super().__init__("sOLHM_DETAILED_STATUS")
        self.acName = clsAdcsBaseType("CH:32", "")
        self.vAddType("acName")
        self.acValue = clsAdcsBaseType("CH:64", "")
        self.vAddType("acValue")
        self.e1Status = E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN)
        self.vAddType("e1Status")
        self.e1State = E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE)
        self.vAddType("e1State")
        self.i2Level0Index = clsAdcsBaseType("I2", -1)
        self.vAddType("i2Level0Index")
        self.i2Level1Index = clsAdcsBaseType("I2", -1)
        self.vAddType("i2Level1Index")
        self.i2Level2Index = clsAdcsBaseType("I2", -1)
        self.vAddType("i2Level2Index")
        self.i2AbsoluteIndex = clsAdcsBaseType("I2", -1)
        self.vAddType("i2AbsoluteIndex")


vAddClass("sOLHM_DETAILED_STATUS",sOLHM_DETAILED_STATUS)


# TYPEDEFS END

# MESSAGE HEADERS START
class sOLHM_ADCS_STATUS_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sOLHM_ADCS_STATUS_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_OLHM)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0000)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sOLHM_ADCS_STATUS_UNSOL_MESSAGE_HEADER", sOLHM_ADCS_STATUS_UNSOL_MESSAGE_HEADER)


class sOLHM_END_OF_READY_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sOLHM_END_OF_READY_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_OLHM)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0002)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sOLHM_END_OF_READY_CMD_MESSAGE_HEADER", sOLHM_END_OF_READY_CMD_MESSAGE_HEADER)


class sOLHM_END_OF_READY_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sOLHM_END_OF_READY_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_OLHM)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0002)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sOLHM_END_OF_READY_CMD_RSP_MESSAGE_HEADER", sOLHM_END_OF_READY_CMD_RSP_MESSAGE_HEADER)


class sOLHM_ADCS_SHUTDOWN_CMD_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sOLHM_ADCS_SHUTDOWN_CMD
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_OLHM)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0010)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sOLHM_ADCS_SHUTDOWN_CMD_MESSAGE_HEADER", sOLHM_ADCS_SHUTDOWN_CMD_MESSAGE_HEADER)


class sOLHM_ADCS_SHUTDOWN_CMD_RSP_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sOLHM_ADCS_SHUTDOWN_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_CMD_RSP)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_OLHM)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0010)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sOLHM_ADCS_SHUTDOWN_CMD_RSP_MESSAGE_HEADER", sOLHM_ADCS_SHUTDOWN_CMD_RSP_MESSAGE_HEADER)


class sOLHM_ADCS_HMI_STATUS_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sOLHM_ADCS_HMI_STATUS_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_OLHM)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0011)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sOLHM_ADCS_HMI_STATUS_UNSOL_MESSAGE_HEADER", sOLHM_ADCS_HMI_STATUS_UNSOL_MESSAGE_HEADER)


class sOLHM_ACTION_STATUS_REPORT_UNSOL_MESSAGE_HEADER(clsAdcsHeaderStructType):
    """Public class definition of type sOLHM_ACTION_STATUS_REPORT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.u2MsgLength = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgLength")
        self.e2MsgType = E2_MW_MESSAGE_TYPE(E2_MW_MESSAGE_TYPE.MW_MESSAGE_TYPE_UNSOL)
        self.vAddType("e2MsgType")
        self.e2MsgStatus = E2_MW_MESSAGE_STATUS(E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL)
        self.vAddType("e2MsgStatus")
        self.e2ModuleAddress = E2_MW_MODULE_ADDRESS(E2_MW_MODULE_ADDRESS.MW_MODULE_ADDRESS_OLHM)
        self.vAddType("e2ModuleAddress")
        self.u2MsgId = clsAdcsBaseType("U2", 0x0012)
        self.vAddType("u2MsgId")
        self.u2MsgCount = clsAdcsBaseType("U2", 0)
        self.vAddType("u2MsgCount")
        self.u8TimeStampMs = clsAdcsBaseType("U8", 0)
        self.vAddType("u8TimeStampMs")
        self.u2ProcessStartCnt = clsAdcsBaseType("U2", 0xFFFF)
        self.vAddType("u2ProcessStartCnt")


vAddClass("sOLHM_ACTION_STATUS_REPORT_UNSOL_MESSAGE_HEADER", sOLHM_ACTION_STATUS_REPORT_UNSOL_MESSAGE_HEADER)


# MESSAGE HEADERS END

# PAYLOADS START
class sOLHM_ADCS_STATUS_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sOLHM_ADCS_STATUS_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sModuleInfo = sADCS_MODULE_INFO()
        self.vAddType("sModuleInfo")
        self.u2NumberOfValidBitItems = clsAdcsBaseType("U2", 0)
        self.u2NumberOfValidBitItems.vSetMin(0)
        self.u2NumberOfValidBitItems.vSetMax(100)
        self.vAddType("u2NumberOfValidBitItems")
        self.asBitItems = clsAdcsStructArrayType("sOLHM_DETAILED_STATUS:100")
        self.vAddType("asBitItems")


vAddClass("sOLHM_ADCS_STATUS_UNSOL_PL", sOLHM_ADCS_STATUS_UNSOL_PL)


class sOLHM_ADCS_HMI_STATUS_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sOLHM_ADCS_HMI_STATUS_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.sModuleInfo = sADCS_MODULE_INFO()
        self.vAddType("sModuleInfo")
        self.u2NumberOfValidBitItems = clsAdcsBaseType("U2", 0)
        self.u2NumberOfValidBitItems.vSetMin(0)
        self.u2NumberOfValidBitItems.vSetMax(100)
        self.vAddType("u2NumberOfValidBitItems")
        self.asBitItems = clsAdcsStructArrayType("sOLHM_DETAILED_STATUS:100")
        self.vAddType("asBitItems")


vAddClass("sOLHM_ADCS_HMI_STATUS_UNSOL_PL", sOLHM_ADCS_HMI_STATUS_UNSOL_PL)


class sOLHM_ACTION_STATUS_REPORT_UNSOL_PL(clsAdcsMessageStructType):
    """Public class definition of type sOLHM_ACTION_STATUS_REPORT_UNSOL_PL
    """
    def __init__(self, formatType=None):
        super().__init__(formatType)
        self.e1OlhmActionStatusReport = E1_OLHM_ACTION_STATUS_REPORT(E1_OLHM_ACTION_STATUS_REPORT.OLHM_ACTION_STATUS_REPORT_OUT_OF_ACTION)
        self.vAddType("e1OlhmActionStatusReport")


vAddClass("sOLHM_ACTION_STATUS_REPORT_UNSOL_PL", sOLHM_ACTION_STATUS_REPORT_UNSOL_PL)


# PAYLOADS END

# MESSAGES START
class sOLHM_ADCS_STATUS_UNSOL(clsAdcsMessageType):
    """Public class definition of type sOLHM_ADCS_STATUS_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sOLHM_ADCS_STATUS_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sOLHM_ADCS_STATUS_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sOLHM_ADCS_STATUS_UNSOL", sOLHM_ADCS_STATUS_UNSOL)


class sOLHM_END_OF_READY_CMD(clsAdcsMessageType):
    """Public class definition of type sOLHM_END_OF_READY_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sOLHM_END_OF_READY_CMD_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sOLHM_END_OF_READY_CMD", sOLHM_END_OF_READY_CMD)


class sOLHM_END_OF_READY_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sOLHM_END_OF_READY_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sOLHM_END_OF_READY_CMD_RSP_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sOLHM_END_OF_READY_CMD_RSP", sOLHM_END_OF_READY_CMD_RSP)


class sOLHM_ADCS_SHUTDOWN_CMD(clsAdcsMessageType):
    """Public class definition of type sOLHM_ADCS_SHUTDOWN_CMD
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sOLHM_ADCS_SHUTDOWN_CMD_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sOLHM_ADCS_SHUTDOWN_CMD", sOLHM_ADCS_SHUTDOWN_CMD)


class sOLHM_ADCS_SHUTDOWN_CMD_RSP(clsAdcsMessageType):
    """Public class definition of type sOLHM_ADCS_SHUTDOWN_CMD_RSP
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sOLHM_ADCS_SHUTDOWN_CMD_RSP_MESSAGE_HEADER()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sOLHM_ADCS_SHUTDOWN_CMD_RSP", sOLHM_ADCS_SHUTDOWN_CMD_RSP)


class sOLHM_ADCS_HMI_STATUS_UNSOL(clsAdcsMessageType):
    """Public class definition of type sOLHM_ADCS_HMI_STATUS_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sOLHM_ADCS_HMI_STATUS_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sOLHM_ADCS_HMI_STATUS_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sOLHM_ADCS_HMI_STATUS_UNSOL", sOLHM_ADCS_HMI_STATUS_UNSOL)


class sOLHM_ACTION_STATUS_REPORT_UNSOL(clsAdcsMessageType):
    """Public class definition of type sOLHM_ACTION_STATUS_REPORT_UNSOL
    """
    def __init__(self):
        super().__init__()
        self.sMsgHeader = sOLHM_ACTION_STATUS_REPORT_UNSOL_MESSAGE_HEADER()
        self.sMsgPayload = sOLHM_ACTION_STATUS_REPORT_UNSOL_PL()
        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2

        return


vAddMessage("sOLHM_ACTION_STATUS_REPORT_UNSOL", sOLHM_ACTION_STATUS_REPORT_UNSOL)


# MESSAGES END




