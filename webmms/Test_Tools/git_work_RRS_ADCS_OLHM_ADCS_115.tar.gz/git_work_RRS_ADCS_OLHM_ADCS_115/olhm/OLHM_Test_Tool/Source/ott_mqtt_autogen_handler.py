#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module contains a class to which used super class

Todo:

"""
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
import queue
import logging
from Autogen.mqtt_client_on_connect_ott import clsMqttAutogenHandler


class clsOttMqttAutogenHandler(clsMqttAutogenHandler):
    """ This is the MQTT message handling derived class for the OLHM

    Note!!! This class used clsMqttAutogenHandler as its base class

    Args:
        objQueuePar (queue.Queue): The first parameter. The instance of the python queue into which we will push messages received
        lstManualSubscribeTopicsPar (list): The second parameter. A list of topics to manually subscribe to
        bLoggingEnabledPar (bool): The third parameter. A boolean flag indicating if logging should be done or not. This parameter is by default True

    """
    def __init__(self, objQueuePar: queue.Queue, lstManualSubscribeTopicsPar: list, bLoggingEnabledPar: bool = True):
        super().__init__(objQueuePar, bLoggingEnabledPar)
        self._lstManualSubscribeTopics = lstManualSubscribeTopicsPar

        return

    def vOnConnect(self, objMqttClient: mqtt.Client, userdata, dctFlags, iConnectionResult: int) -> None:  # pylint: disable=W0613
        """ This is the callback method for when client receives a CONNACK response from the server

        This is the callback method for when client receives a CONNACK response from the server. This method subscribes
        and registers callback methods for all incoming messages. Messages from secondary XML files will not automatically be
        subscribed to. The on message callbacks will however all automatically be registered even for secondary XML files.

        Args:
            objMqttClient (obj): The first parameter. A MQTT client object
            userdata: The second parameter. The private user data as set in Client() or userdata_set()
            flags: The third parameter. flags is a dict that contains response flags from the broker:
            rc: The fourth parameter. The connection result

        Returns:

        Raises:
            Raises no exceptions
        """

        # NOTE!!! First call the vConnect() method in the super class
        # NOTE!!! First call the vConnect() method in the super class
        # NOTE!!! First call the vConnect() method in the super class
        super(clsOttMqttAutogenHandler, self).vOnConnect(objMqttClient, userdata, dctFlags, iConnectionResult)

        for acTopic in self._lstManualSubscribeTopics:
            objMqttClient.subscribe(acTopic)
            if (self._bLoggingEnabled):
                logging.debug("Subscibing message - manual subscribe %s", acTopic)

        return
