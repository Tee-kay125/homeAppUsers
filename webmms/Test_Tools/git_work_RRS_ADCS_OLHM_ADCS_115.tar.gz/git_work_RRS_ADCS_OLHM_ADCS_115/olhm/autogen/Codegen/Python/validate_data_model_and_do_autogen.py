#!/usr/bin/env python3.6

"""
    This python module validates the entire Data Model by looking at all the XML
    files in SICD directory and then generating logging errors if errors are
    detected.

    The module will then continue to produce autogen if it was configured to do so.

    A XML file called autogen_configuration.xml is used to configure this module.
    Its schema is contained in autogen_config_schema.dtd and it must adhere to it.


    Note!!! the autogen_configuration.xml file is not from the SICD repo. It is this same working directory
    Usage:
        python3.6 validate_data_model_and_do_autogen.py autogen_configuration.xml

    Python version: The required Python version is Python3.6

    PyPi packages required by this module:
    * lxml -> We need this for DTD validation



"""

import logging
import sys
import os  # We need this for file path related functionality
import glob  # We need this to find files in path with a certain extension
import subprocess  # We need this to execute xmllint
import shutil  # We need this to recursively delete directories
# Note:!!! etree from lxml is a separate thing from xml.etree.ElementTree. These are
# two different parsers. ElementTree is native to Python 3 but lxml is a
# PyPi package.
import xml.etree.ElementTree as ET  # ElementTree is native to Python
from lxml import etree  # lxml is a PyPi package and not native in Python

from Autogen_Toolbox.logging_manager import clsLoggingManager
from Autogen_Toolbox.autogen_toolbox_definition_validation_and_et_finding import clsAutogenToolboxDefinitionValidationAndETFinding
from Autogen_Toolbox.autogen_toolbox_definition_validation_and_et_finding import E_TYPEDEF_XML_FILE_TYPEDEF_TYPE
from Autogen_Toolbox.autogen_toolbox_definition_validation_and_et_finding import E_MESSAGE_FLOW_DIRECTION
from Autogen_Toolbox.autogen_toolbox_definition_validation_and_et_finding import E_COMMS_PROTOCOL
from Autogen_Toolbox.autogen_toolbox_find_included_xml_in_xml import clsAutogenToolboxFindIncludedXmlInXml
from Autogen_Toolbox.autogen_toolbox_jinja_writer import clsAutogenToolboxJinjaWriter
from Autogen_Toolbox.autogen_toolbox_jinja_writer import E_CPP_TYPE_OF_AUTOGEN_FILE
from Autogen_Toolbox.autogen_toolbox_jinja_writer import E_PYTHON_TYPE_OF_AUTOGEN_FILE
from Autogen_Toolbox.autogen_toolbox_jinja_writer import E_MATLAB_GENERATION_TYPE


G_dctAllTypedefFileEnums = {}
G_dctAllTypedefFileStructs = {}

# ==========================================================
# Group together all xmllint related function
# ==========================================================


def bXmllintIsInstalled():
    """ This public function which verifies if xmllint is installed

    Args:

    Returns:
        (bool): Flag which indicates if xmllint is installed

    Raises:
        Raises no exceptions

    """
    bReturn = bool(False)
    objCompletedProcess = None
    acStdErr = str("")

    # Try and the run xmllint to see if it is installed
    try:
        objCompletedProcess = subprocess.run(["xmllint", "--version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except Exception as E:
        logging.error("Could not run  xmllint --version")
        bReturn = bool(False)
        return(bReturn)

    acStdErr = objCompletedProcess.stderr.decode("ascii")

    # Check the stderr to confirm it is working
    if (acStdErr.startswith("xmllint: using") is False):
        logging.error("xmllint is probably not installed")
        bReturn = bool(False)
        return(bReturn)
    else:
        logging.info("xmllint seems to installed")
        bReturn = bool(True)

    return(bReturn)


# ==========================================================
# Group together all the functions which use the glob command to find file
# ==========================================================


def vFindAllMsgDefXmlFiles(dctGlobDictPar: dict):
    """ This public function which finds all the MsgDef (not included) XML files in the SICD folder.

    Note:!!! etree from lxml is a separate thing from xml.etree.ElementTree. These are
    two different parsers. ElementTree is native to Python 3 but lxml is a
    PyPi package.

    Parameters:
        dctGlobDictPar (dict): The global dictionary.

    Returns:

    Raises:
        Raises no exceptions

    """
    lstMsgDefXmlFiles = []
    objEtreeParser = None
    objEtreeTree = None
    acGlobCommand = str("")

    # This is the dictionary we will use keep info about a Typedef XML file
    dctMsgDefXmlFile = {}
    dctMsgDefXmlFile["acFilePath"] = str("")
    dctMsgDefXmlFile["acFileName"] = str("")
    dctMsgDefXmlFile["bFileExists"] = bool(False)
    dctMsgDefXmlFile["bEtreeParserPassed"] = bool(False)
    dctMsgDefXmlFile["objElementTreeTree"] = None
    dctMsgDefXmlFile["bElementTreeParserPassed"] = bool(False)
    dctMsgDefXmlFile["objElementTreeRoot"] = None
    dctMsgDefXmlFile["dctAllTypesElementsForThisFileIncludingIncludes"] = {}  # Will be populated in another method later
    dctMsgDefXmlFile["bValidationCheckClearedForAutogen"] = bool(False)
    dctMsgDefXmlFile["tplValidMessagePayloads"] = (bool(False), [])
    dctMsgDefXmlFile["tplValidMessageHeaders"] = (bool(False), [])

    if (not dctGlobDictPar):
        logging.error("dctGlobDictPar is invalid")
        return

    # Clear the list in the global dictionary
    dctGlobDictPar["lstMsgDefXmlFiles"] = []

    if (os.path.isdir(dctGlobDictPar["acSicdFolderPath"]) is False):
        logging.error("Path %s does not exist", dctGlobDictPar["acSicdFolderPath"])
        return

    acGlobCommand = dctGlobDictPar["acSicdFolderPath"]

    # If the path does not end with a forward slash then add one
    if (acGlobCommand[-1] != "/"):
        acGlobCommand += "/"

    acGlobCommand += "*_Msg.xml"

    lstMsgDefXmlFiles = glob.glob(acGlobCommand)

    for acMsgDefXmlFilePath in lstMsgDefXmlFiles:

        # Create a new dictionary for each file
        dctMsgDefXmlFile = {}
        dctMsgDefXmlFile["acFilePath"] = str("")  # The full file path
        dctMsgDefXmlFile["acFileName"] = str("")  # Just the name of the file - no path
        dctMsgDefXmlFile["bFileExists"] = bool(False)  # Bool to indicate if file exists
        dctMsgDefXmlFile["bEtreeParserPassed"] = bool(False)  # Bool to indicate if lxml.etree parse passed
        dctMsgDefXmlFile["objElementTreeTree"] = None  # Store the ElementTree object (not and ET.Element)
        dctMsgDefXmlFile["bElementTreeParserPassed"] = bool(False)  # Bool to indicate if ElementTree prase passed
        dctMsgDefXmlFile["objElementTreeRoot"] = None  # Root ElementTree Element of the file
        dctMsgDefXmlFile["tplCommonIncludeXmlFiles"] = []  # Will not be filled in in this method. Just a place holder for now
        dctMsgDefXmlFile["dctAllTypesElementsForThisFileIncludingIncludes"] = {}  # Will be populated in another method later
        dctMsgDefXmlFile["bValidationCheckClearedForAutogen"] = bool(False)  # Will be populated in another method later
        dctMsgDefXmlFile["tplValidMessagePayloads"] = (bool(False), [])
        dctMsgDefXmlFile["tplValidMessageHeaders"] = (bool(False), [])

        # Save the file path
        dctMsgDefXmlFile["acFilePath"] = acMsgDefXmlFilePath

        # Check if the file exists
        if (os.path.isfile(acMsgDefXmlFilePath) is True):
            dctMsgDefXmlFile["bFileExists"] = bool(True)
        else:
            dctMsgDefXmlFile["bFileExists"] = bool(False)

        # Don't even try to parse the file if it doesn't exists
        if (dctMsgDefXmlFile["bFileExists"] is True):

            _, dctMsgDefXmlFile["acFileName"] = os.path.split(acMsgDefXmlFilePath)

            if (dctMsgDefXmlFile["acFileName"] in dctGlobDictPar["lstMsgDefXmlFilesToExclude"]):
                logging.warning("Not processing %s because it was configured to be ignored", dctMsgDefXmlFile["acFileName"])
                continue

            # Use etree to parse the XML file and do the DTD validation
            # Note!!! for Typedef XML file we have to make dtd_validation False
            # Use the etree parser to check general syntax errors (like unclosed tags)
            objEtreeParser = etree.XMLParser(dtd_validation=True)
            try:
                objEtreeTree = etree.parse(acMsgDefXmlFilePath, objEtreeParser)
                dctMsgDefXmlFile["bEtreeParserPassed"] = bool(True)
            except Exception as E:
                dctMsgDefXmlFile["bEtreeParserPassed"] = bool(False)
                logging.error("Could not etree parse file %s - Exception %s", acMsgDefXmlFilePath, str(E))
                logging.error("Cannot continue to autogen due to the data model being invalid")
                sys.exit()

            # Only do the ElementTree parse and root if the etree pass
            if (dctMsgDefXmlFile["bEtreeParserPassed"] is True):
                try:
                    dctMsgDefXmlFile["objElementTreeTree"] = ET.parse(dctMsgDefXmlFile["acFilePath"])
                    dctMsgDefXmlFile["bElementTreeParserPassed"] = bool(True)
                except Exception as E:
                    dctMsgDefXmlFile["bElementTreeParserPassed"] = bool(False)
                    logging.error("Could not ElementTree parse %s", dctMsgDefXmlFile["acFilePath"])
                    logging.error("Cannot continue to autogen due to the data model being invalid")
                    sys.exit()

            if (dctMsgDefXmlFile["bElementTreeParserPassed"] is True):
                dctMsgDefXmlFile["objElementTreeRoot"] = dctMsgDefXmlFile["objElementTreeTree"].getroot()

            # Finally add the dictionary to the list if files
            dctGlobDictPar["lstMsgDefXmlFiles"].append(dctMsgDefXmlFile)

    return


def bFindAllTypedefXmlFiles(dctGlobDictPar: dict):
    """ This public function which finds all the typedef XML files in the SICD folder.

    Note:!!! etree from lxml is a separate thing from xml.etree.ElementTree. These are
    two different parsers. ElementTree is native to Python 3 but lxml is a
    PyPi package.

    Parameters:
        dctGlobDictPar (dict): The global dictionary. The keys we need are:
            * lstTypedefXmlFiles (list)
            * acSicdFolderPath (str)
            * lstTypedefXmlFilesToExclude (list)

    Returns:
        (bool): Flag to indicate validaty

    Raises:
        Raises no exceptions

    """
    bReturn = bool(False)
    lstTypedefXmlFiles = []
    objEtreeParser = None
    objEtreeTree = None
    acGlobCommand = str("")
    lstXmllintSubprocessRunArgs = []

    # This is the dictionary we will use keep info about a Typedef XML file
    dctTypedefXmlFile = {}
    dctTypedefXmlFile["acFilePath"] = str("")
    dctTypedefXmlFile["acFileName"] = str("")
    dctTypedefXmlFile["bFileExists"] = bool(False)
    dctTypedefXmlFile["bEtreeParserPassed"] = bool(False)
    dctTypedefXmlFile["objElementTreeTree"] = None
    dctTypedefXmlFile["bElementTreeParserPassed"] = bool(False)
    dctTypedefXmlFile["objElementTreeRoot"] = None

    if (not dctGlobDictPar):
        logging.error("dctGlobDictPar is invalid")
        return(bReturn)

    # Clear the list in the global dictionary
    dctGlobDictPar["lstTypedefXmlFiles"] = []

    if (os.path.isdir(dctGlobDictPar["acSicdFolderPath"]) is False):
        logging.error("Path %s does not exist", dctGlobDictPar["acSicdFolderPath"])
        return(bReturn)

    acGlobCommand = dctGlobDictPar["acSicdFolderPath"]

    if (acGlobCommand[-1] != "/"):
        acGlobCommand += "/"

    acGlobCommand += "*_Types.xml"

    lstTypedefXmlFiles = glob.glob(acGlobCommand)

    for acTypedefXmlFilePath in lstTypedefXmlFiles:

        # Create a new dictionary for each file
        dctTypedefXmlFile = {}
        dctTypedefXmlFile["acFilePath"] = str("")
        dctTypedefXmlFile["acFileName"] = str("")
        dctTypedefXmlFile["bFileExists"] = bool(False)
        dctTypedefXmlFile["bEtreeParserPassed"] = bool(False)
        dctTypedefXmlFile["objElementTreeTree"] = None
        dctTypedefXmlFile["bElementTreeParserPassed"] = bool(False)
        dctTypedefXmlFile["objElementTreeRoot"] = None

        # Save the file path
        dctTypedefXmlFile["acFilePath"] = acTypedefXmlFilePath

        # Check if the file exists
        if (os.path.isfile(acTypedefXmlFilePath) is True):
            dctTypedefXmlFile["bFileExists"] = bool(True)
        else:
            dctTypedefXmlFile["bFileExists"] = bool(False)

        try:
            _, dctTypedefXmlFile["acFileName"] = os.path.split(acTypedefXmlFilePath)
        except Exception as E:
            logging.error("Could not split path %s", acTypedefXmlFilePath)

        # Check if we should exclude this file
        if (dctTypedefXmlFile["acFileName"] in dctGlobDictPar["lstTypedefXmlFilesToExclude"]):
            logging.warning("Not processing %s because it was configured to be excluded", dctTypedefXmlFile["acFileName"])
            continue

        # Don't even try to parse the file if it doesn't exists
        if (dctTypedefXmlFile["bFileExists"] is True):

            # Call xmllint to test the DTD
            # xmllint --noout --noent --dtdvalid message_file.dtd ADCS_Common_Types.xml
            lstXmllintSubprocessRunArgs = ["xmllint", "--noout", "--noent", "--dtdvalid", dctGlobDictPar["acFullPathToDefintionDtdFile"], acTypedefXmlFilePath]
            try:
                objCompletedProcess = subprocess.run(lstXmllintSubprocessRunArgs, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            except Exception as E:
                logging.error("Could not run xmllint - Exception %s", str(E))
                return(bReturn)

            if (objCompletedProcess.stderr != b""):
                logging.error("File %s does not seems to valid against the DTD file", acTypedefXmlFilePath)
                logging.error("%s", objCompletedProcess.stderr.decode("ascii"))
                return(bReturn)

            # Use etree to parse the XML file and do the DTD validation
            # Note!!! for Typedef XML file we have to make dtd_validation False
            # Use the etree parser to check general syntax errors (like unclosed tags)
            objEtreeParser = etree.XMLParser(dtd_validation=False)
            try:
                objEtreeTree = etree.parse(acTypedefXmlFilePath, objEtreeParser)
                dctTypedefXmlFile["bEtreeParserPassed"] = bool(True)
            except Exception as E:
                dctTypedefXmlFile["bEtreeParserPassed"] = bool(False)
                logging.error("Could not etree parse file %s - Exception %s", acTypedefXmlFilePath, str(E))

        # Only do the ElementTree parse and root if the etree pass
        if (dctTypedefXmlFile["bEtreeParserPassed"] is True):
            try:
                dctTypedefXmlFile["objElementTreeTree"] = ET.parse(dctTypedefXmlFile["acFilePath"])
                dctTypedefXmlFile["bElementTreeParserPassed"] = bool(True)
            except Exception as E:
                dctTypedefXmlFile["bElementTreeParserPassed"] = bool(False)
                logging.error("Could not ElementTree parse %s", dctTypedefXmlFile["acFilePath"])

        if (dctTypedefXmlFile["bElementTreeParserPassed"] is True):
            dctTypedefXmlFile["objElementTreeRoot"] = dctTypedefXmlFile["objElementTreeTree"].getroot()

        # Finally add the dictionary to the list if files
        dctGlobDictPar["lstTypedefXmlFiles"].append(dctTypedefXmlFile)

    bReturn = True
    return(bReturn)


def vFindAllModuleInterfaceConfigurationXmlFiles(dctGlobDictPar: dict):
    """ This public function which finds all the module interface configuration XML files in the SICD folder.

    Note:!!! etree from lxml is a separate thing from xml.etree.ElementTree. These are
    two different parsers. ElementTree is native to Python 3 but lxml is a
    PyPi package.

    Parameters:
        dctGlobDictPar (dict): The global dictionary. These are the keys we will need:
            * lstModuleInterfaceConfiguationXmlFiles (list)
            * lstModuleInterfaceConfiguationXmlFilesToExclude (list)
            * acSicdFolderPath (str)

    Returns:

    Raises:
        Raises no exceptions

    """
    lstModuleInterfaceConfigurationXmlFiles = []
    objEtreeParser = None
    objEtreeTree = None
    acGlobCommand = str("")
    acFileNameAsCapUnderscores = str("")

    # This is the dictionary we will use keep info about a Typedef XML file
    dctModIntConfigFile = {}
    dctModIntConfigFile["acFilePath"] = str("")
    dctModIntConfigFile["acFileName"] = str("")
    dctModIntConfigFile["acFileNameAsCapUnderscores"] = str("")
    dctModIntConfigFile["bFileExists"] = bool(False)
    dctModIntConfigFile["bEtreeParserPassed"] = bool(False)
    dctModIntConfigFile["objElementTreeTree"] = None
    dctModIntConfigFile["bElementTreeParserPassed"] = bool(False)
    dctModIntConfigFile["objElementTreeRoot"] = None

    if (not dctGlobDictPar):
        logging.error("dctGlobDictPar is invalid")
        return

    # Clear the list in the global dictionary
    dctGlobDictPar["lstModuleInterfaceConfiguationXmlFiles"] = []

    if (os.path.isdir(dctGlobDictPar["acSicdFolderPath"]) is False):
        logging.error("Path %s does not exist", dctGlobDictPar["acSicdFolderPath"])
        return

    acGlobCommand = dctGlobDictPar["acSicdFolderPath"]

    if (acGlobCommand[-1] != "/"):
        acGlobCommand += "/"

    acGlobCommand += "Module_Interface_Config_*.xml"

    lstModuleInterfaceConfigurationXmlFiles = glob.glob(acGlobCommand)

    for acModIntConfigXmlFilePath in lstModuleInterfaceConfigurationXmlFiles:

        # Create a new dictionary for each file
        dctModIntConfigFile = {}
        dctModIntConfigFile["acFilePath"] = str("")
        dctModIntConfigFile["acFileName"] = str("")
        dctModIntConfigFile["acFileNameAsCapUnderscores"] = str("")
        dctModIntConfigFile["bFileExists"] = bool(False)
        dctModIntConfigFile["bEtreeParserPassed"] = bool(False)
        dctModIntConfigFile["objElementTreeTree"] = None
        dctModIntConfigFile["bElementTreeParserPassed"] = bool(False)
        dctModIntConfigFile["objElementTreeRoot"] = None

        # Save the file path
        dctModIntConfigFile["acFilePath"] = acModIntConfigXmlFilePath

        # Check if the file exists
        if (os.path.isfile(acModIntConfigXmlFilePath) is True):
            dctModIntConfigFile["bFileExists"] = bool(True)
        else:
            dctModIntConfigFile["bFileExists"] = bool(False)

        try:
            _, dctModIntConfigFile["acFileName"] = os.path.split(acModIntConfigXmlFilePath)
        except Exception as E:
            logging.error("Could not split path %s", acModIntConfigXmlFilePath)

        # Check if we should exclude this file
        if (dctModIntConfigFile["acFileName"] in dctGlobDictPar["lstModuleInterfaceConfiguationXmlFilesToExclude"]):
            logging.warning("Not processing %s because it was configured to be excluded", dctModIntConfigFile["acFileName"])
            continue

        acFileNameAsCapUnderscores = dctModIntConfigFile["acFileName"]
        acFileNameAsCapUnderscores = acFileNameAsCapUnderscores.replace(".xml", "").upper()

        dctModIntConfigFile["acFileNameAsCapUnderscores"] = acFileNameAsCapUnderscores

        # Don't even try to parse the file if it doesn't exists
        if (dctModIntConfigFile["bFileExists"] is True):

            # Use etree to parse the XML file and do the DTD validation
            # Note!!! for Typedef XML file we have to make dtd_validation False
            # Use the etree parser to check general syntax errors (like unclosed tags)
            objEtreeParser = etree.XMLParser(dtd_validation=False)
            try:
                objEtreeTree = etree.parse(acModIntConfigXmlFilePath, objEtreeParser)
                dctModIntConfigFile["bEtreeParserPassed"] = bool(True)
            except Exception as E:
                dctModIntConfigFile["bEtreeParserPassed"] = bool(False)
                logging.error("Could not etree parse file %s - Exception %s", acModIntConfigXmlFilePath, str(E))

        # Only do the ElementTree parse and root if the etree pass
        if (dctModIntConfigFile["bEtreeParserPassed"] is True):
            try:
                dctModIntConfigFile["objElementTreeTree"] = ET.parse(dctModIntConfigFile["acFilePath"])
                dctModIntConfigFile["bElementTreeParserPassed"] = bool(True)
            except Exception as E:
                dctModIntConfigFile["bElementTreeParserPassed"] = bool(False)
                logging.error("Could not ElementTree parse %s", dctModIntConfigFile["acFilePath"])

        if (dctModIntConfigFile["bElementTreeParserPassed"] is True):
            dctModIntConfigFile["objElementTreeRoot"] = dctModIntConfigFile["objElementTreeTree"].getroot()

        # Finally add the dictionary to the list if files
        dctGlobDictPar["lstModuleInterfaceConfiguationXmlFiles"].append(dctModIntConfigFile)

    return


# ==========================================================
# Group together all validation functions
# ==========================================================


def bValidateTypedefXmlFromRootElement(dctGlobDictPar):
    """ This public function which iterates through all the Typedef root ElementTree elements and validates the content.

    Parameters:
        dctGlobDictPar (dict): The global dictionary.

    Returns:
        (bool): Flag to indicate if validation failed.

    Raises:
        Raises no exceptions

    """
    bReturn = bool(False)
    bReturnForLoop = bool(False)
    dctTypedefXmlItem = None  # Will be fill in later

    if (not dctGlobDictPar):
        logging.error("dctGlobDictPar is invalid")
        return(bReturn)

    if ("lstTypedefXmlFiles" not in dctGlobDictPar):
        logging.error("dctGlobDictPar is invalid")
        return(bReturn)

    bReturn = bool(True)  # Assume perfect validation for now
    for dctTypedefXmlItem in dctGlobDictPar["lstTypedefXmlFiles"]:
        # Only pass the root Element of ElementTree of the Typedef file
        bReturnForLoop = clsAutogenToolboxDefinitionValidationAndETFinding.bValidateTypedefFileUsingElementTreeRootElement(dctTypedefXmlItem["objElementTreeRoot"])

        if (bReturnForLoop is False):
            # Once bReturn is False it remains False
            bReturn = bool(False)

    return(bReturn)


def bValidateMsgDefXmlFile(dctMsgDegXmlDicItemPar: dict, dctGlobDictPar: dict):
    """ This public function which validates a MsgDef (not Typedef) XML file

    Parameters:
        dctMsgDegXmlDicItemPar (dict): The keys we need are:
            * ["acFilePath"]
            * ["acFileName"]
            * ["objElementTreeRoot"]
            * ["tplCommonIncludeXmlFiles"]
              * [0] = bSuccess
              * [1] = lstIncludeXmlFiles
            * ["dctAllTypesElementsForThisFileIncludingIncludes"]
            * ["tplValidMessagePayloads"] (tuple) -> (bValid, [] list of Messages)
            * ["tplValidMessageHeaders"] (tuple) -> (bValid, [] list of Messages)
        dctGlobDictPar (dict)

    Returns:
        (bool): Flag to indicate if validation was successful

    Raises:
        Raises no exceptions

    """
    bReturn = bool(False)
    tplValidMessagePayloads = (False, [])
    tplValidMessageHeaders = (False, [])
    bValidTypedefFileTypes = bool(False)
    lstIncludedXmlFilesAsParsedInMsgDef = []
    lstTypedefXmlAsFoundInGlobalLookup = []
    bAllRequiredIncludedXmlPresent = bool(True)
    lstRecordElements = []
    lstDctTypedefStructs = []  # List of all the struct dict items just in this file
    lstDctTypedefEnums = []  # List of all the struct dict items just in this file
    dctAllStructsAndEnums = {}  # This list will contain all the Typedef of included XMLs and the ones in this MsgDef XML file
    bFieldAndRecordsValid = bool(False)
    lstAllTypedefElement = []

    dctAllStructsAndEnums.update(dctGlobDictPar["dctAllTypedefFileEnums"])
    dctAllStructsAndEnums.update(dctGlobDictPar["dctAllTypedefFileStructs"])

    # Do sanity check
    if (not dctMsgDegXmlDicItemPar):
        logging.error("dctMsgDegXmlDicItemPar is not valid")
        return(bReturn)

    # Keys in dictionaries must be there or return
    if ("tplCommonIncludeXmlFiles" not in dctMsgDegXmlDicItemPar):
        logging.error("tplCommonIncludeXmlFiles is not a key in dctMsgDegXmlDicItemPar")
        return(bReturn)

    # Keys in dictionaries must be there or return
    if ("acFileName" not in dctMsgDegXmlDicItemPar):
        logging.error("acFileName is not a key in dctMsgDegXmlDicItemPar")
        return(bReturn)

    # Keys in dictionaries must be there or return
    if ("objElementTreeRoot" not in dctMsgDegXmlDicItemPar):
        logging.error("objElementTreeRoot is not a key in dctMsgDegXmlDicItemPar")
        return(bReturn)

    if (dctMsgDegXmlDicItemPar["tplCommonIncludeXmlFiles"][0] is False):
        logging.error("MsgDef XML file %s did parse successfully for DOCTYPE", dctMsgDegXmlDicItemPar["acFileName"])
        return(bReturn)

    # Do sanity check
    if (not dctGlobDictPar):
        logging.error("dctGlobDictPar is not valid")
        return(bReturn)

    # Keys in dictionaries must be there or return
    if ("lstTypedefXmlFiles" not in dctGlobDictPar):
        logging.error("lstTypedefXmlFiles is not a key in dctGlobDictPar")
        return(bReturn)

    lstIncludedXmlFilesAsParsedInMsgDef = dctMsgDegXmlDicItemPar["tplCommonIncludeXmlFiles"][1]

    bAllRequiredIncludedXmlPresent = bool(True)  # Assume valid for now
    # Go through the included XML in the MsgDef file and see if they actually exists
    for acIncludedXmlFile in lstIncludedXmlFilesAsParsedInMsgDef:
        # In the global lookup search and see if the file that was included in file MsgDef actually exists
        lstTypedefXmlAsFoundInGlobalLookup = [dctItem for dctItem in dctGlobDictPar["lstTypedefXmlFiles"] if dctItem["acFileName"] == acIncludedXmlFile]

        if (not lstTypedefXmlAsFoundInGlobalLookup):
            logging.error("Included XML %s was not found in the SICD folder for file %s", acIncludedXmlFile, dctMsgDegXmlDicItemPar["acFileName"])
            bAllRequiredIncludedXmlPresent = bool(False)
            bReturn = bool(False)
            continue

        if (lstTypedefXmlAsFoundInGlobalLookup[0]["objElementTreeRoot"] is None):
            logging.error("Included XML %s does not have an ElementTree root maybe because it is invalid", acIncludedXmlFile)
            bAllRequiredIncludedXmlPresent = bool(False)
            bReturn = bool(False)
            continue

    if (bAllRequiredIncludedXmlPresent is False):
        logging.error("For MsgDef XML file %s included XMLs are missing or invalid", dctMsgDegXmlDicItemPar["acFileName"])
        bReturn = bool(False)
        return(bReturn)

    # Find all the structs just in this file
    lstDctTypedefStructs = clsAutogenToolboxDefinitionValidationAndETFinding.lstFindStructsAndEnumsFromElement(dctMsgDegXmlDicItemPar["objElementTreeRoot"],
                                                                                                               E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_STRUCT),
                                                                                                               dctMsgDegXmlDicItemPar["acFilePath"])

    # Find all the enums just in this file
    lstDctTypedefEnums = clsAutogenToolboxDefinitionValidationAndETFinding.lstFindStructsAndEnumsFromElement(dctMsgDegXmlDicItemPar["objElementTreeRoot"],
                                                                                                             E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_ENUM),
                                                                                                             dctMsgDegXmlDicItemPar["acFilePath"])

    # At this stage dctAllStructsAndEnums will already contains the Typedefs from the included XML files

    # Check if we have Typedef name already defined in the common includes
    for acTypedefName in dctAllStructsAndEnums:
        # Check if we have Typedef Emum name already defined in the common includes
        for dctMsgDefTypdefEnumItem in lstDctTypedefEnums:
            if (dctMsgDefTypdefEnumItem["acName"] == acTypedefName):
                logging.error("Typdef %s seems to be have been defined twice or more which is invalid", acTypedefName)
                sys.exit()

        # Check if we have Typedef Struct name already defined in the common includes
        for dctMsgDefTypdefStructItem in lstDctTypedefStructs:
            if (dctMsgDefTypdefStructItem["acName"] == acTypedefName):
                logging.error("Typdef %s seems to be have been defined twice or more which is invalid", acTypedefName)
                sys.exit()

    # Add all the Enum from this just file to a dictionary of all the Types for this file
    [dctAllStructsAndEnums.update({dctItem["acName"]: dctItem}) for dctItem in lstDctTypedefEnums]
    # Add all the Structs from this just file to a dictionary of all the Types for this file
    [dctAllStructsAndEnums.update({dctItem["acName"]: dctItem}) for dctItem in lstDctTypedefStructs]

    # Store the dictionary with all the Typedefs (this file + included) that's available
    dctMsgDegXmlDicItemPar["dctAllTypesElementsForThisFileIncludingIncludes"] = dctAllStructsAndEnums
    # Make a list of all the Typedef Elements
    lstAllTypedefElement = [dctTypedefDictItem["objElement"] for _,dctTypedefDictItem in dctAllStructsAndEnums.items()]

    # First go an validate the Enum Typedef in this MsgDef file
    # This is easy because there is not recursion
    for dctEnumTypedefItem in lstDctTypedefEnums:
        # Here we can call the Typdef type file (not MsgDef) Enum Typdef validate because
        # it can still be used - the rules are the same and there is no further recursion.
        bValidTypedefFileTypes = clsAutogenToolboxDefinitionValidationAndETFinding.bValidateTypedefOfTypeEnum(dctEnumTypedefItem["objElement"])
        if (bValidTypedefFileTypes is False):
            logging.error("Enum Typedef is invalid")
            bReturn = bool(False)
            return(bReturn)

    # Go and validate the Struct Enum Typdef in this MsgDef file
    # This is easy because there is not recursion
    for dctStructTypedef in lstDctTypedefStructs:
        # Here we can call the Typdef type file (not MsgDef) Struct Typdef validate because
        # it can still be used - the rules are the same and there is no further recursion.
        bValidTypedefFileTypes = clsAutogenToolboxDefinitionValidationAndETFinding.bValidateTypedefOfTypeStruct(dctStructTypedef["objElement"], bCheckApprovedListOfTypesPar=True, lstApprovedTypesElementStructAllowedToUsePar=lstAllTypedefElement, iRecursionLevel=int(0))
        if (bValidTypedefFileTypes is False):
            logging.error("Struct Typedef in %s names %s is invalid", dctStructTypedef["acXmlFileName"], dctStructTypedef["acName"])
            bReturn = bool(False)
            return(bReturn)

    # At this stage we have a consolidated list of all the enums and struct typdefs from the included files and the ones in
    # this MsgDef file. We can proceed and check all the Typedefs in this file and even follow them through recursively to
    # make sure all types listed does actually exist and are valid.

    bReturn = bool(True)  # Assume valid for now
    for dctStructTypedefItem in lstDctTypedefStructs:
        lstRecordElements = dctStructTypedefItem["objElement"].findall("./Record")
        for objRecordElement in lstRecordElements:
            # This is the start of the recursion so the recursion level int value is 0
            bFieldAndRecordsValid = clsAutogenToolboxDefinitionValidationAndETFinding.bValidateFieldOrRecordElementRecursively(objRecordElement, dctAllStructsAndEnums, iRecursionLevel=int(0))

            if (bFieldAndRecordsValid is False):
                logging.error("Record %s is invalid", objRecordElement.attrib["Name"])
                bReturn = bool(False)

    if (bReturn is False):
        logging.error("Validation for %s failed", dctMsgDegXmlDicItemPar["acFileName"])

    tplValidMessageHeaders = clsAutogenToolboxDefinitionValidationAndETFinding.tplValidateMsgDefHeadersFromRootElement(dctMsgDegXmlDicItemPar["objElementTreeRoot"], dctAllStructsAndEnums)

    dctMsgDegXmlDicItemPar["tplValidMessageHeaders"] = tplValidMessageHeaders

    if (tplValidMessageHeaders[0] is False):
        logging.error("Message headers of %s are invalid", dctMsgDegXmlDicItemPar["acFileName"])
        bReturn = bool(False)
        return(bReturn)
    else:
        for dctMsgDefMessageDictItem in dctMsgDegXmlDicItemPar["tplValidMessageHeaders"][1]:
            dctMsgDefMessageDictItem["acMsgDefXmlFilename"] = dctMsgDegXmlDicItemPar["acFileName"]

    # Extract all the Message tags from this MsgDef file - inside we will also set extra Element attributes needed for easier autogen
    tplValidMessagePayloads = clsAutogenToolboxDefinitionValidationAndETFinding.tplValidateMsgDefPayloadFromRootElement(dctMsgDegXmlDicItemPar["objElementTreeRoot"], dctAllStructsAndEnums)

    dctMsgDegXmlDicItemPar["tplValidMessagePayloads"] = tplValidMessagePayloads

    if (tplValidMessagePayloads[0] is False):
        logging.error("Message payloads of %s are invalid", dctMsgDegXmlDicItemPar["acFileName"])
        bReturn = bool(False)
        return(bReturn)

    bReturn = bool(True)
    return(bReturn)


def bValidateModuleInterfaceConfigurationXmlFiles(dctGlobDictPar: dict):
    """ This public function which validates and parses the Module Interface Configuration files

    Parameters:
        dctGlobDictPar (dict): The keys we need are:
            * lstModuleInterfaceConfiguationXmlFiles (list)
            * lstMsgDefXmlFiles (list)

    Returns:
        (bool): Flag to indicate if validation was successful

    Raises:
        Raises no exceptions

    """
    bReturn = bool(False)
    lstGlobalListOfAllMessagesAvailable = []  # This will store all the MsgDef messages that are available in the data model
    acRoles = str("")  # Stores the roles taken from MsgDef XML for HMI messages
    lstRoles = []  # Stores the roles taken from MsgDef XML for HMI messages but as a list of strings

    dctFullTopicPartsDictItem = {}
    dctFullTopicPartsDictItem["acSystem"] = str("")
    dctFullTopicPartsDictItem["acModule"] = str("")
    dctFullTopicPartsDictItem["acMessageName"] = str("")
    dctFullTopicPartsDictItem["lstRoles"] = []
    dctFullTopicPartsDictItem["eMessageFlowDirection"] = E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH)  # Just set to Publish for now
    dctFullTopicPartsDictItem["eCommsProtocol"] = E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT)  # Just set to MQTT for now
    dctFullTopicPartsDictItem["acMsgDefFileName"] = str("")
    dctFullTopicPartsDictItem["acReplyMsg"] = str("")
    dctFullTopicPartsDictItem["acReplyMsgFullTopic"] = str("")

    lstTopicElements = []  # To store all the Topic elements
    lstMsgElements = []  # To store all the Msg elements
    objMsgElement = None  # To keep a Msg Element

    lstModInterConfAndMsgDefMatchingMessage = []

    # These two strings match the tags in the module interface configuration DTD
    lstMessageDirectionFlowsAsStrings = ["Publish", "Subscribe"]

    dctDirectionFlowStringToEnumLookup = {}
    dctDirectionFlowStringToEnumLookup["Publish"] = E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH)
    dctDirectionFlowStringToEnumLookup["Subscribe"] = E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE)

    dctStringToCommsProtocolLookup = {}
    dctStringToCommsProtocolLookup["MQTT"] = E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT)
    dctStringToCommsProtocolLookup["ZMQ"] = E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_ZMQ)

    lstMsgDefFilenamesWhichContainsSpecificMessage = []  # To store the MsgDef filename which contains a message

    lstRequiredMsgDefFilenames = []  # A list of all the MsgDef XML files needed by this interface. Note! this list will not have unique entries
    sttRequiredMsgDefFilenames = {}  # A set of all the MsgDef XML files needed by this interface. The set will have unique entries

    lstFullTopicPartsForThisModConfInterface = []  # A list to store dictionaries with the topic in parts

    dctTopicsPublishedOnDataModel = {}
    lstTopicsBeingPublishedByMoreThanOneModule = []
    acFullTopic = str("")

    # Do some checks before we start

    if (dctGlobDictPar is None):
        logging.error("dctGlobDictPar cannot be None")
        return(bReturn)

    # Iterate through all the MsgDef files
    for dctMsgDefXmlDictItem in dctGlobDictPar["lstMsgDefXmlFiles"]:
        # For each MsgDef file iterate through its messages
        if (dctMsgDefXmlDictItem["tplValidMessageHeaders"][0] is True):
            # Make a list dict items with the message name and the associated filename
            [lstGlobalListOfAllMessagesAvailable.append({"acMessageName": dctItem["acName"], "acFileName": dctItem["acMsgDefXmlFilename"]}) for dctItem in dctMsgDefXmlDictItem["tplValidMessageHeaders"][1]]

    # Iterate through all the module interface configuration files
    for dctModIntConfigDictItem in dctGlobDictPar["lstModuleInterfaceConfiguationXmlFiles"]:

        # Clear the list of this module interface
        lstFullTopicPartsForThisModConfInterface = []  # A list to store dictionaries with the topic in parts
        lstRequiredMsgDefFilenames = []  # A list of all the MsgDef XML files needed by this interface. Note! this list will not have unique entries
        sttRequiredMsgDefFilenames = {}  # A set of all the MsgDef XML files needed by this interface. The set will have unique entries

        if ("objElementTreeRoot" not in dctModIntConfigDictItem):
            logging.error("objElementTreeRoot for %s not in dctModIntConfigDictItem", dctModIntConfigDictItem["acFileName"])
            return(bReturn)

        if (dctModIntConfigDictItem["objElementTreeRoot"] is None):
            logging.error("objElementTreeRoot None for %s in dctModIntConfigDictItem", dctModIntConfigDictItem["acFileName"])
            return(bReturn)

        for acMessageDirectionFlow in lstMessageDirectionFlowsAsStrings:

            lstTopicElements = dctModIntConfigDictItem["objElementTreeRoot"].findall("./%s/Topic" % (acMessageDirectionFlow))

            for objTopicElement in lstTopicElements:
                lstMsgElements = objTopicElement.findall("./Msg")

                for objMsgElement in lstMsgElements:

                    dctFullTopicPartsDictItem = {}
                    dctFullTopicPartsDictItem["acSystem"] = objTopicElement.attrib["System"]
                    dctFullTopicPartsDictItem["acModule"] = objTopicElement.attrib["Name"]
                    dctFullTopicPartsDictItem["acMessageName"] = objMsgElement.attrib["Name"]
                    dctFullTopicPartsDictItem["lstRoles"] = []
                    dctFullTopicPartsDictItem["eMessageFlowDirection"] = dctDirectionFlowStringToEnumLookup[acMessageDirectionFlow]
                    dctFullTopicPartsDictItem["eCommsProtocol"] = dctStringToCommsProtocolLookup[objMsgElement.attrib["Protocol"]]
                    dctFullTopicPartsDictItem["acMsgDefFileName"] = str("")
                    dctFullTopicPartsDictItem["acReplyMsg"] = str("")
                    dctFullTopicPartsDictItem["acReplyMsgFullTopic"] = str("")

                    lstMsgDefFilenamesWhichContainsSpecificMessage = []
                    [lstMsgDefFilenamesWhichContainsSpecificMessage.append(dctMsgFilePair) for dctMsgFilePair in lstGlobalListOfAllMessagesAvailable if dctMsgFilePair["acMessageName"] == dctFullTopicPartsDictItem["acMessageName"]]

                    if (not lstMsgDefFilenamesWhichContainsSpecificMessage):
                        logging.error("In file %s message %s cannot be found in the data model", dctModIntConfigDictItem["acFileName"], dctFullTopicPartsDictItem["acMessageName"])
                        return(bReturn)

                    if (len(lstMsgDefFilenamesWhichContainsSpecificMessage) != 1):
                        logging.error("In file %s message %s was found but in multiple MsgDef XML files which is invalid", dctModIntConfigDictItem["acFileName"], dctFullTopicPartsDictItem["acMessageName"])
                        return(bReturn)

                    dctFullTopicPartsDictItem["acMsgDefFileName"] = lstMsgDefFilenamesWhichContainsSpecificMessage[0]["acFileName"]

                    # Go through the MsgDef XML file message headers to get the ReplyMsg value
                    for dctMsgDefXmlFile in dctGlobDictPar["lstMsgDefXmlFiles"]:
                        if ("tplValidMessageHeaders" in dctMsgDefXmlFile):
                            # Make sure the headers are valid
                            if (dctMsgDefXmlFile["tplValidMessageHeaders"][0] is True):

                                # Make a list of messages from the MsgDef message list which matches the message from the Mod. Interface. Conf. file
                                lstModInterConfAndMsgDefMatchingMessage = [dctMessage for dctMessage in dctMsgDefXmlFile["tplValidMessageHeaders"][1] if dctMessage["acName"] == dctFullTopicPartsDictItem["acMessageName"] and dctMessage["acMsgDefXmlFilename"] == dctFullTopicPartsDictItem["acMsgDefFileName"]]

                                if (lstModInterConfAndMsgDefMatchingMessage):
                                    # Set the ReplyMsg once we found it
                                    dctFullTopicPartsDictItem["acReplyMsg"] = lstModInterConfAndMsgDefMatchingMessage[0]["acReplyMsg"]

                                    # Get the HMI roles from the MsgDef XML
                                    if ("Roles" in lstModInterConfAndMsgDefMatchingMessage[0]["objMessageElement"].attrib):
                                        acRoles = lstModInterConfAndMsgDefMatchingMessage[0]["objMessageElement"].attrib["Roles"]
                                        lstRoles = acRoles.split(",")
                                        dctFullTopicPartsDictItem["lstRoles"] = lstRoles

                                    break

                    lstFullTopicPartsForThisModConfInterface.append(dctFullTopicPartsDictItem)

            [lstRequiredMsgDefFilenames.append(dctFullTopicPartsDictItem["acMsgDefFileName"]) for dctFullTopicPartsDictItem in lstFullTopicPartsForThisModConfInterface]
            sttRequiredMsgDefFilenames = set(lstRequiredMsgDefFilenames)
            dctModIntConfigDictItem["sttRequiredMsgDefFilenames"] = sttRequiredMsgDefFilenames
            dctModIntConfigDictItem["lstFullTopicPartsForThisModConfInterface"] = lstFullTopicPartsForThisModConfInterface

        # Now go through the all the topics (publish and subscribe) of this mod inter conf file and build up the topics of the reply messages
        for dctTopicParts in dctModIntConfigDictItem["lstFullTopicPartsForThisModConfInterface"]:
            # To have a valid ReplyMsg we must 1) have the ReplyMsg from the XML 2) be MQTT 3) this message must subscribed to
            if (dctTopicParts["acReplyMsg"] and dctTopicParts["eCommsProtocol"] == E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT) and dctTopicParts["eMessageFlowDirection"] == E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE)):
                # To be a match the message must 1) have a ReplyMsg 2) use MQTT 3) the ReplyMsg must be a publish message
                lstMatchingPublishAndReplyMsg = [dctFullTopic for dctFullTopic in lstFullTopicPartsForThisModConfInterface if dctTopicParts["acReplyMsg"] == dctFullTopic["acMessageName"] and dctFullTopic["eCommsProtocol"] == E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT) and dctFullTopic["eMessageFlowDirection"] == E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH)]

                # If the message names are a match then build up the full topic of the ReplyMsg
                if (lstMatchingPublishAndReplyMsg):
                    dctTopicParts["acReplyMsgFullTopic"] = lstMatchingPublishAndReplyMsg[0]["acSystem"] + "/" + lstMatchingPublishAndReplyMsg[0]["acModule"] + "/" + lstMatchingPublishAndReplyMsg[0]["acMessageName"]

            # We need to verify how many modules are publishing unique messages - add message name to lookup if being published
            if ((dctGlobDictPar["bIgnoreCheckForMultiplePublishersOfSameTopic"] == bool(False)) and (dctTopicParts["eMessageFlowDirection"] == E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH))):

                # See if this message has roles
                if (dctTopicParts["lstRoles"]):
                    # Iterate through the roles and build up a topic for each
                    for acRole in dctTopicParts["lstRoles"]:
                        # The role is part of the topic
                        acFullTopic = dctTopicParts["acSystem"] + "/" + dctTopicParts["acModule"] + "/" + dctTopicParts["acMessageName"] + "/" + acRole

                        # If the message is not in the lookup yet, then create an new entry
                        if (acFullTopic not in dctTopicsPublishedOnDataModel):
                            dctTopicsPublishedOnDataModel[acFullTopic] = {}  # Create a new dict
                            dctTopicsPublishedOnDataModel[acFullTopic]["lstModulesWhichPublish"] = []  # Make a list of all module publishing this message
                            dctTopicsPublishedOnDataModel[acFullTopic]["iNumberOfModulesPublishing"] = int(0)  # Make a counter of how many times this message is being published

                        dctTopicsPublishedOnDataModel[acFullTopic]["lstModulesWhichPublish"].append(dctModIntConfigDictItem["acFileName"])
                        dctTopicsPublishedOnDataModel[acFullTopic]["iNumberOfModulesPublishing"] = dctTopicsPublishedOnDataModel[acFullTopic]["iNumberOfModulesPublishing"] + 1

                        # For performance reasons check here if there are topics being sent by more than 1 module
                        if (dctTopicsPublishedOnDataModel[acFullTopic]["iNumberOfModulesPublishing"] > 1):
                            lstTopicsBeingPublishedByMoreThanOneModule.append(acFullTopic)

                            logging.error("For topic %s two or more MICs are publishing which is not allowed - Details  %s", acFullTopic, str(dctTopicsPublishedOnDataModel[acFullTopic]))

                else:
                    # Messges without roles are just the system, module and message name
                    acFullTopic = dctTopicParts["acSystem"] + "/" + dctTopicParts["acModule"] + "/" + dctTopicParts["acMessageName"]

                    # If the message is not in the lookup yet, then create an new entry
                    if (acFullTopic not in dctTopicsPublishedOnDataModel):
                        dctTopicsPublishedOnDataModel[acFullTopic] = {}  # Create a new dict
                        dctTopicsPublishedOnDataModel[acFullTopic]["lstModulesWhichPublish"] = []  # Make a list of all module publishing this message
                        dctTopicsPublishedOnDataModel[acFullTopic]["iNumberOfModulesPublishing"] = int(0)  # Make a counter of how many times this message is being published

                    dctTopicsPublishedOnDataModel[acFullTopic]["lstModulesWhichPublish"].append(dctModIntConfigDictItem["acFileName"])
                    dctTopicsPublishedOnDataModel[acFullTopic]["iNumberOfModulesPublishing"] = dctTopicsPublishedOnDataModel[acFullTopic]["iNumberOfModulesPublishing"] + 1

                    # For performance reasons check here if there are topics being sent by more than 1 module
                    if (dctTopicsPublishedOnDataModel[acFullTopic]["iNumberOfModulesPublishing"] > 1):
                        lstTopicsBeingPublishedByMoreThanOneModule.append(acFullTopic)

                        logging.error("For topic %s two or more MICs are publishing which is not allowed - Details  %s", acFullTopic, str(dctTopicsPublishedOnDataModel[acFullTopic]))

    if (lstTopicsBeingPublishedByMoreThanOneModule):
        logging.error("These topic(s) are published by two or more modules which is not allowed %s", str(lstTopicsBeingPublishedByMoreThanOneModule))
        bReturn = bool(False)
    else:
        bReturn = bool(True)
    return(bReturn)


# ==========================================================
# Group together functions related to the autogen configuration XML file (not the files in the SICD directory)
# ==========================================================


def bValidateAndParseConfigurationXmlFile(dctGlobDictPar: dict):
    """ This public function which validates the autogen XML configuration
    file. Note!!! this is not an XML from the SICD repo. This the
    dedicated XML file used to configure the autogen.

    Parameters:
        dctGlobDictPar (dict). The keys we are:
            * acPathToAutogenConfigXmlFile (str) -> The path to the autogen configuration XML file
            * acCurrentWorkingDirectory (str) -> The current working directory
            * bValidateOnlyProduceNoAutogen (bool) -> Flag to indicate if we are only going to do validation and no autogen
            * bIgnoreCheckForMultiplePublishersOfSameTopic (bool) -> Flag to indicate if we should ignore the check for multiple publishers of the same topic
            * acSicdFolderPath (str) -> path to the SICD directory
            * dctCodeGenerationInformation (dict)
                * Cpp
                * Python
            * lstTypedefXmlFilesToExclude (list)
            * lstMsgDefXmlFilesToExclude
            * lstModuleInterfaceConfiguationXmlFilesToExclude

    Returns:
        (bool): Flag to indicate if validation passed

    Raises:
        Raises no exceptions

    """
    bReturn = bool(False)
    objConfigXmlEtreeTree = None  # These will be used later to parse the XML file with all the autogen configuration in it
    objConfigXmlEtreeParser = None  # These will be used later to parse the XML file with all the autogen configuration in it
    objConfigXmlElementTreeTree = None  # These will be used later to parse the XML file with all the autogen configuration in it
    objConfigXmlElementTreeRoot = None  # These will be used later to parse the XML file with all the autogen configuration in it
    acPathToConfigXmlFile = str("")
    acCurrentWorkingDirectory = str("")
    acPathJinjaTemplateCppDefinition = str("")
    acPathJinjaTemplateCppDefinitionMessageEventHandlerHFile = str("")
    acPathJinjaTemplateCppModInterConfHFile = str("")
    acPathJinjaTemplateCppModInterConfCppFile = str("")
    acPathJinjaTemplateCppModInterConfTopicsHFile = str("")
    acPathJinjaTemplateCppModInterConfEventHandlerHFile = str("")
    acPathJinjaTemplatePythonDefinition = str("")
    acPathJinjaTemplatePythonModInterConf = str("")
    acPathJinjaTemplatePythonMqttClientOnConnect = str("")
    acPathJinjaTemplatePythonAsyncioMessageProcessing = str("")
    acPathJinjaTemplateCSharpDefinitionEnum = str("")
    acPathJinjaTemplateCSharpDefinitionStruct = str("")
    acPathJinjaTemplateCSharpDefinitionControl = str("")
    acPathJinjaTemplateCSharpDefinitionData = str("")
    acPathJinjaTemplateMatlabDefinition = str("")

    objETElementCppTag = None  # Will store the ET.Element of the Cpp tag in the autogen config XML file
    objETElementCppTypesHeaderFilePathTag = None
    objETElementCppDefinitionTemplatePathTag = None  # Will store the ET.Element of the DefinitionTemplatePath tag in the autogen config XML file
    objETElementCppDefinitionMessageEventHandlerTemplatePathHFileTag = None
    objETElementCppModInterConfTemplatePathHFileTag = None  # Will store the ET.Element of the DefinitionTemplatePath tag in the autogen config XML file
    objETElementCppModInterConfTemplatePathCppFileTag = None  # Will store the ET.Element of the DefinitionTemplatePath tag in the autogen config XML file
    objETElementCppModInterConfTopicTemplatePathHFileTag = None  # Will store the ET.Element of the ModInterConfTopicTemplatePathHFile tag in the autogen config XML file
    objETElementCppModInterConfEventHandlerTemplatePathHFileTag = None

    objETElementPythonTag = None  # Will store the ET.Element of the Python tag in the autogen config XML file
    objETElementPythonDefinitionTemplatePathTag = None
    objETElementPythonTypesHeaderFilePathTag = None
    objETElementPythonModInterConfTemplatePathTag = None
    objETElementPythonMqttClientOnConnectTemplatePathTag = None
    objETElementPythonAsyncioMessageProcessingTemplatePathTag = None

    objETElementCSharpTag = None  # Will store the ET.Element of the CSharp tag in the autogen config XML file
    objETElementCSharpDefinitionEnumTemplatePathTag = None
    objETElementCSharpDefinitionStructTemplatePathTag = None
    objETElementCSharpDefinitionControlTemplatePathTag = None
    objETElementCSharpDefinitionDataTemplatePathTag = None

    objETElementMatlabTag = None  # Will store the ET.Element of the Matlab tag in the autogen config XML file
    objETElementMatlabDefinitionTemplatePathTag = None

    acOutputPathPython = str("")
    acOutputPathCpp = str("")
    acOutputPathMatlabTypeSizeMatched = str("")
    acOutputPathMatlabTypesAsDoubles = str("")
    acOutputPathMatlabRoot = str("")
    acOutputPathCSharpRoot = str("")
    acCppBaseTypesHeaderFilePath = str("")
    acPythonBaseTypesHeaderFilePath = str("")

    if (dctGlobDictPar is None):
        logging.error("dctGlobDictPar cannot be None")
        sys.exit()
        return(bReturn)

    acPathToConfigXmlFile = dctGlobDictPar["acPathToAutogenConfigXmlFile"]  # Get the path to the autogen config XML file from the global dictionary
    acCurrentWorkingDirectory = dctGlobDictPar["acCurrentWorkingDirectory"]  # Get the current working directory from the global dictionary

    # Parse the XML against the DTD to see if it is valid that way
    try:
        objConfigXmlEtreeTree = etree.XMLParser(dtd_validation=True)
    except Exception as E:
        logging.error("Cannot create etree.XMLParser")
        sys.exit()
        return(bReturn)

    try:
        objConfigXmlEtreeParser = etree.parse(acPathToConfigXmlFile, objConfigXmlEtreeTree)
    except Exception as E:
        logging.error("Cannot etree parse %s - Exception %s", acPathToConfigXmlFile, str(E))
        sys.exit()
        return(bReturn)

    try:
        objConfigXmlElementTreeTree = ET.parse(acPathToConfigXmlFile)
    except Exception as E:
        logging.error("Cannot ElementTree parse %s - Exception %s", acPathToConfigXmlFile, str(E))
        sys.exit()
        return(bReturn)

    try:
        objConfigXmlElementTreeRoot = objConfigXmlElementTreeTree.getroot()
    except Exception as E:
        logging.error("Could not get root of objConfigXmlElementTreeRoot - Exception %s", str(E))
        return(bReturn)

    # Check if we were configured to only do Data Model validation
    dctGlobDictPar["bValidateOnlyProduceNoAutogen"] = objConfigXmlElementTreeRoot.attrib["OnlyValidateDoNotGenerateCode"] == "True"

    dctGlobDictPar["bIgnoreCheckForMultiplePublishersOfSameTopic"] = objConfigXmlElementTreeRoot.attrib["IgnoreCheckForMultiplePublishersOfSameTopic"] == "True"

    # Get the path of the SICD directory
    acPathToSicdFolder = os.path.join(acCurrentWorkingDirectory, objConfigXmlElementTreeRoot.attrib["SicdPath"])

    # Make sure the SICD directory exists
    if (os.path.isdir(acPathToSicdFolder) is False):
        logging.error("The SICD path %s is not valid", acPathToSicdFolder)
        sys.exit()
        return(bReturn)

    dctGlobDictPar["acSicdFolderPath"] = acPathToSicdFolder

    dctGlobDictPar["acFullPathToDefintionDtdFile"] = os.path.join(dctGlobDictPar["acSicdFolderPath"], dctGlobDictPar["acPathToDefintionDtdFile"])

    if (os.path.isfile(dctGlobDictPar["acFullPathToDefintionDtdFile"]) is False):
        logging.error("Definition DTD file %s does not exist", dctGlobDictPar["acFullPathToDefintionDtdFile"])
        return(bReturn)

    # Create the paths to the output directories
    # Create the paths to the output directories
    # Create the paths to the output directories

    acOutputPathCpp = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], "Output/Cpp")
    acOutputPathPython = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], "Output/Python")
    acOutputPathCSharpRoot = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], "Output/CSharp")
    acOutputPathMatlabTypeSizeMatched = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], "Output/Matlab/Structs")
    acOutputPathMatlabTypesAsDoubles = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], "Output/Matlab/Structs_Double")
    acOutputPathMatlabRoot = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], "Output/Matlab")

    # Create the CPP output directory
    try:
        os.makedirs(acOutputPathCpp, exist_ok=True)
        logging.info("Created directory %s", acOutputPathCpp)
        dctGlobDictPar["dctCodeGenerationInformation"]["Cpp"]["acOutputPathCpp"] = acOutputPathCpp
    except Exception as E:
        logging.error("Creation of the directory %s failed - Exception %s", acOutputPathCpp, str(E))
        sys.exit()
        return(bReturn)

    lstFilesToDelete = glob.glob(os.path.join(acOutputPathCpp, "*.cpp"))

    # Exclude file TestAutogen.cpp from being deleted
    lstFilesToDelete = [acFilePath for acFilePath in lstFilesToDelete if (acFilePath.endswith("TestAutogen.cpp") is False)]

    # Iterate over the list of filepaths and remove each file.
    for acFilePath in lstFilesToDelete:
        try:
            os.remove(acFilePath)
        except Exception as E:
            logging.error("Could not delete file %s - Exception %s", acFilePath, str(E))

    lstFilesToDelete = glob.glob(os.path.join(acOutputPathCpp, "*.h"))

    # Iterate over the list of filepaths and remove each file.
    for acFilePath in lstFilesToDelete:
        try:
            os.remove(acFilePath)
        except Exception as E:
            logging.error("Could not delete file %s - Exception %s", acFilePath, str(E))

    # Create the Python output directory
    try:
        os.makedirs(acOutputPathPython, exist_ok=True)
        logging.info("Created directory %s", acOutputPathPython)
        dctGlobDictPar["dctCodeGenerationInformation"]["Python"]["acOutputPathPython"] = acOutputPathPython
    except Exception as E:
        logging.error("Creation of the directory %s failed - Exception %s", acOutputPathPython, str(E))
        sys.exit()
        return(bReturn)

    lstFilesToDelete = glob.glob(os.path.join(acOutputPathPython, "*.py"))

    # Iterate over the list of filepaths and remove each file.
    for acFilePath in lstFilesToDelete:
        try:
            os.remove(acFilePath)
        except Exception as E:
            logging.error("Could not delete file %s - Exception %s", acFilePath, str(E))

    # Create the CSharp output directory - root directory
    try:
        os.makedirs(acOutputPathCSharpRoot, exist_ok=True)
        logging.info("Created directory %s", acOutputPathCSharpRoot)
        dctGlobDictPar["dctCodeGenerationInformation"]["CSharp"]["acOutputPathCSharpRoot"] = acOutputPathCSharpRoot
    except Exception as E:
        logging.error("Creation of the directory %s failed - Exception %s", acOutputPathCSharpRoot, str(E))
        sys.exit()
        return(bReturn)

    dctGlobDictPar["dctCodeGenerationInformation"]["Matlab"]["acOutputPathMatlabRoot"] = acOutputPathMatlabRoot

    # Create the Matlab output directory - The "Structs" directory
    try:
        os.makedirs(acOutputPathMatlabTypeSizeMatched, exist_ok=True)
        logging.info("Created directory %s", acOutputPathMatlabTypeSizeMatched)
        dctGlobDictPar["dctCodeGenerationInformation"]["Matlab"]["acOutputPathMatlabTypeSizeMatched"] = acOutputPathMatlabTypeSizeMatched
    except Exception as E:
        logging.error("Creation of the directory %s failed - Exception %s", acOutputPathMatlabTypeSizeMatched, str(E))
        sys.exit()
        return(bReturn)

    lstFilesToDelete = glob.glob(os.path.join(acOutputPathMatlabTypeSizeMatched, "*.m"))

    # Iterate over the list of filepaths and remove each file.
    for acFilePath in lstFilesToDelete:
        try:
            os.remove(acFilePath)
        except Exception as E:
            logging.error("Could not delete file %s - Exception %s", acFilePath, str(E))

    # Create the Matlab output directory - The "Structs_Double" directory
    try:
        os.makedirs(acOutputPathMatlabTypesAsDoubles, exist_ok=True)
        logging.info("Created directory %s", acOutputPathMatlabTypesAsDoubles)
        dctGlobDictPar["dctCodeGenerationInformation"]["Matlab"]["acOutputPathMatlabTypesAsDoubles"] = acOutputPathMatlabTypesAsDoubles
    except Exception as E:
        logging.error("Creation of the directory %s failed - Exception %s", acOutputPathMatlabTypesAsDoubles, str(E))
        sys.exit()
        return(bReturn)

    lstFilesToDelete = glob.glob(os.path.join(acOutputPathMatlabTypesAsDoubles, "*.m"))

    # Iterate over the list of filepaths and remove each file.
    for acFilePath in lstFilesToDelete:
        try:
            os.remove(acFilePath)
        except Exception as E:
            logging.error("Could not delete file %s - Exception %s", acFilePath, str(E))

    # Now validate C++ autogen related things
    # Now validate C++ autogen related things
    # Now validate C++ autogen related things

    objETElementCppTag = objConfigXmlElementTreeRoot.find(".//Cpp")

    if (objETElementCppTag is None):
        logging.error("Could not find the Cpp tag into the autogen config XML file %s", acPathToConfigXmlFile)
        sys.exit()
        return(bReturn)

    objETElementCppDefinitionTemplatePathTag = objETElementCppTag.find("./DefinitionTemplatePath")

    if (objETElementCppDefinitionTemplatePathTag is None):
        logging.error("Could not find the Cpp DefinitionTemplatePath tag into the autogen config XML file %s", acPathToConfigXmlFile)
        sys.exit()
        return(bReturn)

    acPathJinjaTemplateCppDefinition = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], objETElementCppDefinitionTemplatePathTag.attrib["Path"])

    # Check that the C++ definition generation template exists
    if (os.path.isfile(acPathJinjaTemplateCppDefinition) is False):
        logging.error("Cpp definition jinja template path %s does not exist", acPathJinjaTemplateCppDefinition)
        sys.exit()
        return(bReturn)

    # Set the value in the global dictionary
    dctGlobDictPar["dctCodeGenerationInformation"]["Cpp"]["acPathJinjaTemplateCppDefinition"] = acPathJinjaTemplateCppDefinition

    objETElementCppDefinitionMessageEventHandlerTemplatePathHFileTag = objETElementCppTag.find("./DefinitionMessageEventHandlerTemplatePath")

    if (objETElementCppDefinitionMessageEventHandlerTemplatePathHFileTag is None):
        logging.error("Could not find the Cpp DefinitionMessageEventHandlerTemplatePath tag into the autogen config XML file %s", acPathToConfigXmlFile)
        sys.exit()
        return(bReturn)

    acPathJinjaTemplateCppDefinitionMessageEventHandlerHFile = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], objETElementCppDefinitionMessageEventHandlerTemplatePathHFileTag.attrib["Path"])

    if (os.path.isfile(acPathJinjaTemplateCppDefinitionMessageEventHandlerHFile) is False):
        logging.error("Cpp definition jinja template path %s does not exist", acPathJinjaTemplateCppDefinitionMessageEventHandlerHFile)
        sys.exit()
        return(bReturn)

    # Set the value in the global dictionary
    dctGlobDictPar["dctCodeGenerationInformation"]["Cpp"]["acPathJinjaTemplateCppDefinitionMessageEventHandler"] = acPathJinjaTemplateCppDefinitionMessageEventHandlerHFile

    objETElementCppModInterConfTemplatePathHFileTag = objETElementCppTag.find("./ModInterConfTemplatePathHFile")

    if (objETElementCppModInterConfTemplatePathHFileTag is None):
        logging.error("Could not find the Cpp ModInterConfTemplatePathHFile tag into the autogen config XML file %s", acPathToConfigXmlFile)
        sys.exit()
        return(bReturn)

    acPathJinjaTemplateCppModInterConfHFile = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], objETElementCppModInterConfTemplatePathHFileTag.attrib["Path"])

    # Check that the C++ definition generation template exists
    if (os.path.isfile(acPathJinjaTemplateCppModInterConfHFile) is False):
        logging.error("Cpp module interface configuration jinja template path %s does not exist", acPathJinjaTemplateCppModInterConfHFile)
        sys.exit()
        return(bReturn)

    # Set the value in the global dictionary
    dctGlobDictPar["dctCodeGenerationInformation"]["Cpp"]["acPathJinjaTemplateCppModInterConfHFile"] = acPathJinjaTemplateCppModInterConfHFile

    objETElementCppModInterConfTemplatePathCppFileTag = objETElementCppTag.find("./ModInterConfTemplatePathCppFile")

    acPathJinjaTemplateCppModInterConfCppFile = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], objETElementCppModInterConfTemplatePathCppFileTag.attrib["Path"])

    # Check that the C++ definition generation template exists
    if (os.path.isfile(acPathJinjaTemplateCppModInterConfCppFile) is False):
        logging.error("Cpp module interface configuration jinja template path %s does not exist", acPathJinjaTemplateCppModInterConfCppFile)
        sys.exit()
        return(bReturn)

    # Set the value in the global dictionary
    dctGlobDictPar["dctCodeGenerationInformation"]["Cpp"]["acPathJinjaTemplateCppModInterConfCppFile"] = acPathJinjaTemplateCppModInterConfCppFile

    objETElementCppTypesHeaderFilePathTag = objETElementCppTag.find("./TypesHeaderFilePath")

    # Get the path of the C++ base types header file
    acCppBaseTypesHeaderFilePath = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], objETElementCppTypesHeaderFilePathTag.attrib["Path"])

    # Check that the C++ base types header file exists
    if (os.path.isfile(acCppBaseTypesHeaderFilePath) is False):
        logging.error("Cpp base types header file path %s does not exist", acCppBaseTypesHeaderFilePath)
        sys.exit()
        return(bReturn)

    dctGlobDictPar["dctCodeGenerationInformation"]["Cpp"]["acBaseTypesHeaderFilePath"] = acCppBaseTypesHeaderFilePath

    objETElementCppModInterConfTopicTemplatePathHFileTag = objETElementCppTag.find("./ModInterConfTopicTemplatePathHFile")

    if (objETElementCppModInterConfTopicTemplatePathHFileTag is None):
        logging.error("Could not find the objETElementCppModInterConfTopicTemplatePathHFileTag tag into the autogen config XML file %s", acPathToConfigXmlFile)
        sys.exit()
        return(bReturn)

    acPathJinjaTemplateCppModInterConfTopicsHFile = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], objETElementCppModInterConfTopicTemplatePathHFileTag.attrib["Path"])

    if (os.path.isfile(acPathJinjaTemplateCppModInterConfTopicsHFile) is False):
        logging.error("Cpp module interface configuration topic jinja template path %s does not exist", acPathJinjaTemplateCppModInterConfTopicsHFile)
        sys.exit()
        return(bReturn)

    dctGlobDictPar["dctCodeGenerationInformation"]["Cpp"]["acPathJinjaTemplateCppModInterConfTopicHFile"] = acPathJinjaTemplateCppModInterConfTopicsHFile

    objETElementCppModInterConfEventHandlerTemplatePathHFileTag = objETElementCppTag.find("./ModInterConfEventHandlerTemplatePathHFile")

    if (objETElementCppModInterConfEventHandlerTemplatePathHFileTag is None):
        logging.error("Could not find the objETElementCppModInterConfEventHandlerTemplatePathHFileTag tag into the autogen config XML file %s", acPathToConfigXmlFile)
        sys.exit()
        return(bReturn)

    acPathJinjaTemplateCppModInterConfEventHandlerHFile = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], objETElementCppModInterConfEventHandlerTemplatePathHFileTag.attrib["Path"])

    if (os.path.isfile(acPathJinjaTemplateCppModInterConfEventHandlerHFile) is False):
        logging.error("Cpp module interface configuration topic jinja template path %s does not exist", acPathJinjaTemplateCppModInterConfEventHandlerHFile)
        sys.exit()
        return(bReturn)

    dctGlobDictPar["dctCodeGenerationInformation"]["Cpp"]["acPathJinjaTemplateCppModInterConfEventHandlerHFile"] = acPathJinjaTemplateCppModInterConfEventHandlerHFile

    # Now validate Python autogen related things
    # Now validate Python autogen related things
    # Now validate Python autogen related things

    objETElementPythonTag = objConfigXmlElementTreeRoot.find(".//Python")

    if (objETElementPythonTag is None):
        logging.error("Could not find the Cpp tag into the autogen config XML file %s", acPathToConfigXmlFile)
        sys.exit()
        return(bReturn)

    objETElementPythonDefinitionTemplatePathTag = objETElementPythonTag.find("./DefinitionTemplatePath")

    acPathJinjaTemplatePythonDefinition = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], objETElementPythonDefinitionTemplatePathTag.attrib["Path"])

    # Check that the Python definition generation template exists
    if (os.path.isfile(acPathJinjaTemplatePythonDefinition) is False):
        logging.error("Python definition jinja template path %s does not exist", acPathJinjaTemplatePythonDefinition)
        sys.exit()
        return(bReturn)

    # Set the value in the global dictionary
    dctGlobDictPar["dctCodeGenerationInformation"]["Python"]["acPathJinjaTemplatePythonDefinition"] = acPathJinjaTemplatePythonDefinition

    objETElementPythonModInterConfTemplatePathTag = objETElementPythonTag.find("./ModInterConfTemplatePath")

    acPathJinjaTemplatePythonModInterConf = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], objETElementPythonModInterConfTemplatePathTag.attrib["Path"])

    # Check that the Python definition generation template exists
    if (os.path.isfile(acPathJinjaTemplatePythonModInterConf) is False):
        logging.error("Python module interface configuration jinja template path %s does not exist", acPathJinjaTemplatePythonModInterConf)
        sys.exit()
        return(bReturn)

    # Set the value in the global dictionary
    dctGlobDictPar["dctCodeGenerationInformation"]["Python"]["acPathJinjaTemplatePythonModInterConf"] = acPathJinjaTemplatePythonModInterConf

    objETElementPythonMqttClientOnConnectTemplatePathTag = objETElementPythonTag.find("./MqttClientOnConnectTemplatePath")

    acPathJinjaTemplatePythonMqttClientOnConnect = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], objETElementPythonMqttClientOnConnectTemplatePathTag.attrib["Path"])

    # Check that the Python MQTT client on connect template exists
    if (os.path.isfile(acPathJinjaTemplatePythonMqttClientOnConnect) is False):
        logging.error("Python MQTT client on connect template file path %s does not exist", acPathJinjaTemplatePythonMqttClientOnConnect)
        sys.exit()
        return(bReturn)

    dctGlobDictPar["dctCodeGenerationInformation"]["Python"]["acPathJinjaTemplatePythonMqttClientOnConnect"] = acPathJinjaTemplatePythonMqttClientOnConnect

    # Python asyncio message processing template
    # Python asyncio message processing template
    # Python asyncio message processing template

    objETElementPythonAsyncioMessageProcessingTemplatePathTag = objETElementPythonTag.find("./AsyncioMessageProcessingTemplatePath")

    acPathJinjaTemplatePythonAsyncioMessageProcessing = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], objETElementPythonAsyncioMessageProcessingTemplatePathTag.attrib["Path"])

    # Check that the Python asyncio message processing template exists
    if (os.path.isfile(acPathJinjaTemplatePythonAsyncioMessageProcessing) is False):
        logging.error("Python message processing template file path %s does not exist", acPathJinjaTemplatePythonAsyncioMessageProcessing)
        sys.exit()
        return(bReturn)

    dctGlobDictPar["dctCodeGenerationInformation"]["Python"]["acPathJinjaTemplatePythonAsyncioMessageProcessing"] = acPathJinjaTemplatePythonAsyncioMessageProcessing

    # Python base types file
    # Python base types file
    # Python base types file

    objETElementPythonTypesHeaderFilePathTag = objETElementPythonTag.find("./TypesHeaderFilePath")

    # Get the path of the Python base types header file
    acPythonBaseTypesHeaderFilePath = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], objETElementPythonTypesHeaderFilePathTag.attrib["Path"])

    # Check that the Python base types file exists
    if (os.path.isfile(acPythonBaseTypesHeaderFilePath) is False):
        logging.error("Python base types file path %s does not exist", acPythonBaseTypesHeaderFilePath)
        sys.exit()
        return(bReturn)

    dctGlobDictPar["dctCodeGenerationInformation"]["Python"]["acBaseTypesHeaderFilePath"] = acPythonBaseTypesHeaderFilePath

    # Now validate CSharp autogen related things
    # Now validate CSharp autogen related things
    # Now validate CSharp autogen related things

    objETElementCSharpTag = objConfigXmlElementTreeRoot.find(".//CSharp")

    # C# Defintion template for Enum

    objETElementCSharpDefinitionEnumTemplatePathTag = objETElementCSharpTag.find("./DefinitionEnumTemplatePath")

    acPathJinjaTemplateCSharpDefinitionEnum = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], objETElementCSharpDefinitionEnumTemplatePathTag.attrib["Path"])

    # Check that the CSharp definition enum file exists
    if (os.path.isfile(acPathJinjaTemplateCSharpDefinitionEnum) is False):
        logging.error("CSharp enum definition jinja template file path %s does not exist", acPathJinjaTemplateCSharpDefinitionEnum)
        sys.exit()
        return(bReturn)

    dctGlobDictPar["dctCodeGenerationInformation"]["CSharp"]["acPathJinjaTemplateCSharpDefinitionEnum"] = acPathJinjaTemplateCSharpDefinitionEnum

    # C# Defintion template for Struct

    objETElementCSharpDefinitionStructTemplatePathTag = objETElementCSharpTag.find("./DefinitionStructTemplatePath")

    acPathJinjaTemplateCSharpDefinitionStruct = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], objETElementCSharpDefinitionStructTemplatePathTag.attrib["Path"])

    # Check that the CSharp definition struct file exists
    if (os.path.isfile(acPathJinjaTemplateCSharpDefinitionStruct) is False):
        logging.error("CSharp struct definition jinja template file path %s does not exist", acPathJinjaTemplateCSharpDefinitionStruct)
        sys.exit()
        return(bReturn)

    dctGlobDictPar["dctCodeGenerationInformation"]["CSharp"]["acPathJinjaTemplateCSharpDefinitionStruct"] = acPathJinjaTemplateCSharpDefinitionStruct

    # C# Defintion template for Control

    objETElementCSharpDefinitionControlTemplatePathTag = objETElementCSharpTag.find("./DefinitionControlTemplatePath")

    acPathJinjaTemplateCSharpDefinitionControl = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], objETElementCSharpDefinitionControlTemplatePathTag.attrib["Path"])

    # Check that the CSharp definition control file exists
    if (os.path.isfile(acPathJinjaTemplateCSharpDefinitionControl) is False):
        logging.error("CSharp control definition jinja template file path %s does not exist", acPathJinjaTemplateCSharpDefinitionControl)
        sys.exit()
        return(bReturn)

    dctGlobDictPar["dctCodeGenerationInformation"]["CSharp"]["acPathJinjaTemplateCSharpDefinitionControl"] = acPathJinjaTemplateCSharpDefinitionControl

    # C# Defintion template for Data

    objETElementCSharpDefinitionDataTemplatePathTag = objETElementCSharpTag.find("./DefinitionDataTemplatePath")

    acPathJinjaTemplateCSharpDefinitionData = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], objETElementCSharpDefinitionDataTemplatePathTag.attrib["Path"])

    # Check that the CSharp definition data file exists
    if (os.path.isfile(acPathJinjaTemplateCSharpDefinitionData) is False):
        logging.error("CSharp control definition jinja template file path %s does not exist", acPathJinjaTemplateCSharpDefinitionData)
        sys.exit()
        return(bReturn)

    dctGlobDictPar["dctCodeGenerationInformation"]["CSharp"]["acPathJinjaTemplateCSharpDefinitionData"] = acPathJinjaTemplateCSharpDefinitionData

    # C# related things end
    # C# related things end
    # C# related things end

    # Matlab related things start
    # Matlab related things start
    # Matlab related things start

    objETElementMatlabTag = objConfigXmlElementTreeRoot.find(".//Matlab")

    # Matlab Defintion template

    objETElementMatlabDefinitionTemplatePathTag = objETElementMatlabTag.find("./DefinitionTemplatePath")

    acPathJinjaTemplateMatlabDefinition = os.path.join(dctGlobDictPar["acCurrentWorkingDirectory"], objETElementMatlabDefinitionTemplatePathTag.attrib["Path"])

    # Check that the CSharp definition data file exists
    if (os.path.isfile(acPathJinjaTemplateMatlabDefinition) is False):
        logging.error("Matlab definition jinja template file path %s does not exist", acPathJinjaTemplateMatlabDefinition)
        sys.exit()
        return(bReturn)

    dctGlobDictPar["dctCodeGenerationInformation"]["Matlab"]["acPathJinjaTemplateCppDefinition"] = acPathJinjaTemplateMatlabDefinition

    # From the config XML file get the names of the Typdef XML files we want to exclude from processing
    dctGlobDictPar["lstTypedefXmlFilesToExclude"] = [objElementExcludedFile.attrib["Name"] for objElementExcludedFile in objConfigXmlElementTreeRoot.findall("./ExcludedTypedefFiles/File")]

    # From the config XML file get the names of the Message XML files we want to exclude from processing
    dctGlobDictPar["lstMsgDefXmlFilesToExclude"] = [objElementExcludedFile.attrib["Name"] for objElementExcludedFile in objConfigXmlElementTreeRoot.findall("./ExcludedMessageFiles/File")]

    # From the config XML file get the names of the Message XML files we want to exclude from processing
    dctGlobDictPar["lstModuleInterfaceConfiguationXmlFilesToExclude"] = [objElementExcludedFile.attrib["Name"] for objElementExcludedFile in objConfigXmlElementTreeRoot.findall("./ExcludedModuleInterfaceConfigFiles/File")]

    bReturn = bool(True)
    return(bReturn)


def bGetGitHashFromSicdSubmodule(dctGlobDictPar: dict):
    """ This public function which gets the GIT hash of the SICD submodule

    Parameters:
        dctGlobDictPar (dict). The keys we are:
            * acSicdFolderPath (str)
            * acCurrentWorkingDirectory (str)

    Returns:
        (bool): Flag to indicate if function was successful

    Raises:
        Raises no exceptions

    """
    bResult = bool(False)
    bChdirWasSuccessful = bool(False)
    bSubprocessRunWasSuccessful = bool(False)
    acGitHash = str("")

    # Do some sanity checks

    if (dctGlobDictPar is None):
        logging.error("dctGlobDictPar cannot be None")
        sys.exit()
        return(bResult)

    if ("acSicdFolderPath" not in dctGlobDictPar):
        logging.error("Key acSicdFolderPath is missing from dctGlobDictPar")
        return(bResult)

    if ("acCurrentWorkingDirectory" not in dctGlobDictPar):
        logging.error("Key acCurrentWorkingDirectory is missing from dctGlobDictPar")
        return(bResult)

    if (not dctGlobDictPar["acSicdFolderPath"]):
        logging.error("Value for key acSicdFolderPath cannot be empty")
        return(bResult)

    if (not dctGlobDictPar["acCurrentWorkingDirectory"]):
        logging.error("Value for key acCurrentWorkingDirectory cannot be empty")
        return(bResult)

    # Check that the SICD and working directory exists
    if (os.path.isdir(dctGlobDictPar["acSicdFolderPath"]) is False):
        logging.error("Path %s does not exist", dctGlobDictPar["acSicdFolderPath"])
        return(bResult)

    # Check that the SICD and working directory exists
    if (os.path.isdir(dctGlobDictPar["acCurrentWorkingDirectory"]) is False):
        logging.error("Path %s does not exist", dctGlobDictPar["acCurrentWorkingDirectory"])
        return(bResult)

    # Even though we are in the working directory, see if we can change into it
    bChdirWasSuccessful = bool(False)
    try:
        os.chdir(dctGlobDictPar["acCurrentWorkingDirectory"])
        bChdirWasSuccessful = bool(True)
    except Exception as E:
        logging.error("Could not change directory to %s - Exception %s", dctGlobDictPar["acCurrentWorkingDirectory"], str(E))
        bChdirWasSuccessful = bool(False)

    if (bChdirWasSuccessful is False):
        logging.error("Could not change directory")
        return(bResult)

    # Now chdir into the SICD
    bChdirWasSuccessful = bool(False)
    try:
        os.chdir(dctGlobDictPar["acSicdFolderPath"])
        bChdirWasSuccessful = bool(True)
    except Exception as E:
        logging.error("Could not change directory to %s - Exception %s", dctGlobDictPar["acSicdFolderPath"], str(E))
        return(bResult)

    if (bChdirWasSuccessful is False):
        logging.error("Could not change directory")
        return(bResult)

    # Get the SICD module has
    bSubprocessRunWasSuccessful = bool(False)
    try:
        objCompletedProcess = subprocess.run(["git", "rev-parse", "HEAD"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        bSubprocessRunWasSuccessful = bool(True)
    except Exception as E:
        logging.error("Could not execute subprocess.run - Exception %s", str(E))

    # Do some checks to make sure we got the result we excepted
    if ((bSubprocessRunWasSuccessful is True) and (objCompletedProcess is not None) and (objCompletedProcess.returncode == 0) and (not objCompletedProcess.stderr) and (objCompletedProcess.stdout) and (len(objCompletedProcess.stdout) == 41)):
        acGitHash = objCompletedProcess.stdout.decode("ascii").rstrip()

    # Finally we must get back to the working directory
    try:
        os.chdir(dctGlobDictPar["acCurrentWorkingDirectory"])
    except Exception as E:
        logging.error("Could not change directory to %s - Exception %s", dctGlobDictPar["acCurrentWorkingDirectory"], str(E))

    if (len(acGitHash) == 40):
        bResult = bool(True)
        dctGlobDictPar["acSicdGitHash"] = acGitHash
        logging.info("SICD hash is %s", acGitHash)
    else:
        bResult = bool(False)

    return(bResult)


def bWriteSicdGitHashToFile(dctGlobDictPar: dict):
    """ This public function which writes the SICD GIT hash to a file for Python, Cpp, Matlab and CSharp

    Parameters:
        dctGlobDictPar (dict). The keys we are:
            * dctCodeGenerationInformation (dict)

    Returns:
        (bool): Flag to indicate if function was successful

    Raises:
        Raises no exceptions

    """
    bResult = bool(False)
    acFilePath = str("")
    objFileHandle = None

    # Do some sanity checks

    if (dctGlobDictPar is None):
        logging.error("dctGlobDictPar cannot be None")
        sys.exit()
        return(bResult)

    if ("dctCodeGenerationInformation" not in dctGlobDictPar):
        logging.error("Key dctCodeGenerationInformation not in dctGlobDictPar")
        return(bResult)

    if ("Python" not in dctGlobDictPar["dctCodeGenerationInformation"]):
        logging.error("Key Python not in dctCodeGenerationInformation")
        return(bResult)

    if ("Cpp" not in dctGlobDictPar["dctCodeGenerationInformation"]):
        logging.error("Key Cpp not in dctCodeGenerationInformation")
        return(bResult)

    if ("Matlab" not in dctGlobDictPar["dctCodeGenerationInformation"]):
        logging.error("Key Matlab not in dctCodeGenerationInformation")
        return(bResult)

    if ("CSharp" not in dctGlobDictPar["dctCodeGenerationInformation"]):
        logging.error("Key CSharp not in dctCodeGenerationInformation")
        return(bResult)

    # Write Python file
    if (("acOutputPathPython" in dctGlobDictPar["dctCodeGenerationInformation"]["Python"]) and (dctGlobDictPar["dctCodeGenerationInformation"]["Python"]["acOutputPathPython"])):
        try:
            acFilePath = os.path.join(dctGlobDictPar["dctCodeGenerationInformation"]["Python"]["acOutputPathPython"], "sicd_hash.sha1")
        except Exception as E:
            logging.error("Cannot join path - Exception %s", str(E))

        try:
            if (acFilePath):
                os.remove(acFilePath)
        except:
            pass

        try:
            if (dctGlobDictPar["acSicdGitHash"]):
                objFileHandle = open(acFilePath, "w")
                objFileHandle.write(dctGlobDictPar["acSicdGitHash"])
                objFileHandle.close()
        except Exception as E:
            logging.error("Could not write to file - Exception %s", str(E))

    # Write Cpp file
    if (("acOutputPathCpp" in dctGlobDictPar["dctCodeGenerationInformation"]["Cpp"]) and (dctGlobDictPar["dctCodeGenerationInformation"]["Cpp"]["acOutputPathCpp"])):
        try:
            acFilePath = os.path.join(dctGlobDictPar["dctCodeGenerationInformation"]["Cpp"]["acOutputPathCpp"], "sicd_hash.sha1")
        except Exception as E:
            logging.error("Cannot join path - Exception %s", str(E))

        try:
            if (acFilePath):
                os.remove(acFilePath)
        except:
            pass

        try:
            if (dctGlobDictPar["acSicdGitHash"]):
                objFileHandle = open(acFilePath, "w")
                objFileHandle.write(dctGlobDictPar["acSicdGitHash"])
                objFileHandle.close()
        except Exception as E:
            logging.error("Could not write to file - Exception %s", str(E))

    # Write CSharp file
    if (("acOutputPathCSharpRoot" in dctGlobDictPar["dctCodeGenerationInformation"]["CSharp"]) and (dctGlobDictPar["dctCodeGenerationInformation"]["CSharp"]["acOutputPathCSharpRoot"])):
        try:
            acFilePath = os.path.join(dctGlobDictPar["dctCodeGenerationInformation"]["CSharp"]["acOutputPathCSharpRoot"], "sicd_hash.sha1")
        except Exception as E:
            logging.error("Cannot join path - Exception %s", str(E))

        try:
            if (acFilePath):
                os.remove(acFilePath)
        except:
            pass

        try:
            if (dctGlobDictPar["acSicdGitHash"]):
                objFileHandle = open(acFilePath, "w")
                objFileHandle.write(dctGlobDictPar["acSicdGitHash"])
                objFileHandle.close()
        except Exception as E:
            logging.error("Could not write to file - Exception %s", str(E))

    # Write Matlab file
    if (("acOutputPathMatlabRoot" in dctGlobDictPar["dctCodeGenerationInformation"]["Matlab"]) and (dctGlobDictPar["dctCodeGenerationInformation"]["Matlab"]["acOutputPathMatlabRoot"])):
        try:
            acFilePath = os.path.join(dctGlobDictPar["dctCodeGenerationInformation"]["Matlab"]["acOutputPathMatlabRoot"], "sicd_hash.sha1")
        except Exception as E:
            logging.error("Cannot join path - Exception %s", str(E))

        try:
            if (acFilePath):
                os.remove(acFilePath)
        except:
            pass

        try:
            if (dctGlobDictPar["acSicdGitHash"]):
                objFileHandle = open(acFilePath, "w")
                objFileHandle.write(dctGlobDictPar["acSicdGitHash"])
                objFileHandle.close()
        except Exception as E:
            logging.error("Could not write to file - Exception %s", str(E))

    bResult = bool(True)
    return(bResult)


# ==========================================================
# The main method
# ==========================================================


def main():

    acPathToConfigXmlFile = str("")
    acCurrentWorkingDirectory = str("")
    acSysArgv0 = str("")  # The full path as the Python file was run
    acSysArgv1 = str("")  # The SICD relative path
    bAutogenConfigXMLFileIsValid = bool(False)
    tplMsgDegXmlIncludedFiles = ()
    acFileNameAsCapUnderscores = str("")

    acDirectoryPath = str("")
    acInterfaceModuleName = str("")
    lstRequiredMessages = []
    lstModConfMessage = []
    dctModConfMessage = {}
    iMsgDefMessageHeaderCnt = int(-1)
    dctMessageHeader = {}
    dctMessagePayload = {}

    # These are the context dictionaries which are given to the jinja writers
    dctCppDefWriterContext = {}
    dctCppModInterConfContext = {}
    dctPythonModInterConfContext = {}
    dctPythonAsyncioMessageProcessingContext = {}
    dctPythonMqttClientOnConnectContext = {}
    dctCSharpDefWriterContext = {}
    dctMatlabDefWriterContext = {}

    iMessageHeaderCount = int(0)

    # For the Matlab Typedef generation we want to optimise the autogen so that 
    # a typedef is only generated once. Sometimes typedefs are included in
    # multiple module files and then the typedef is generated multiple times
    # with exactly the same code which just wastes time. We therefore keep a 
    # dictionary with the names of the typedefs we already generated. If it
    # was already generated then don't do it again
    dctTypesGenerated = {}

    # This is the global dictionary used throughout this file. It will be passed into public methods to
    # prevent we having to pass many arguments into functions
    dctGlobalDict = {}
    dctGlobalDict["bValidateOnlyProduceNoAutogen"] = bool(False)
    dctGlobalDict["bIgnoreCheckForMultiplePublishersOfSameTopic"] = bool(False)
    dctGlobalDict["acPathToAutogenConfigXmlFile"] = str("")  # Note this is not an XML file from the SICD repo! It's an XML file to configure the autogen
    dctGlobalDict["acPathToDefintionDtdFile"] = str("message_file.dtd")  # We need this for xmllint
    dctGlobalDict["acFullPathToDefintionDtdFile"] = str("")  # We need this for xmllint
    dctGlobalDict["dctAllTypedefFileEnums"] = G_dctAllTypedefFileEnums
    dctGlobalDict["dctAllTypedefFileStructs"] = G_dctAllTypedefFileStructs
    dctGlobalDict["lstTypedefXmlFiles"] = []  # These will store all the Typedef files found in the SICD folder
    dctGlobalDict["lstTypedefXmlFilesToExclude"] = []  # These are the Typedef XML files we want to exclude from processing
    dctGlobalDict["lstMsgDefXmlFiles"] = []  # These will store all the Message files found in the SICD folder
    dctGlobalDict["lstMsgDefXmlFilesToExclude"] = []  # These are the Message XML files we want to exclude from processing
    dctGlobalDict["lstModuleInterfaceConfiguationXmlFiles"] = []  # These are the module interface configuration files
    dctGlobalDict["lstModuleInterfaceConfiguationXmlFilesToExclude"] = []  # These are the module interface configuration files we want to exclude from processing
    dctGlobalDict["acSicdFolderPath"] = str("")  # This stores the path to the SICD folder
    dctGlobalDict["acSicdGitHash"] = str("")
    dctGlobalDict["acCurrentWorkingDirectory"] = str("")  # This stores path to the current working directory
    dctGlobalDict["dctCodeGenerationInformation"] = {}
    dctGlobalDict["dctCodeGenerationInformation"]["acPythonVersion"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["acJinja2Version"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["Cpp"] = {}
    dctGlobalDict["dctCodeGenerationInformation"]["Cpp"]["acOutputPathCpp"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["Cpp"]["acPathJinjaTemplateCppDefinition"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["Cpp"]["acPathJinjaTemplateCppDefinitionMessageEventHandler"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["Cpp"]["acPathJinjaTemplateCppModInterConfHFile"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["Cpp"]["acPathJinjaTemplateCppModInterConfTopicHFile"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["Cpp"]["acPathJinjaTemplateCppModInterConfEventHandlerHFile"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["Cpp"]["acBaseTypesHeaderFilePath"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["Python"] = {}
    dctGlobalDict["dctCodeGenerationInformation"]["Python"]["acOutputPathPython"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["Python"]["acPathJinjaTemplatePythonDefinition"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["Python"]["acBaseTypesHeaderFilePath"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["Python"]["acPathJinjaTemplatePythonModInterConf"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["Python"]["acPathJinjaTemplatePythonMqttClientOnConnect"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["Python"]["acPathJinjaTemplatePythonAsyncioMessageProcessing"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["CSharp"] = {}
    dctGlobalDict["dctCodeGenerationInformation"]["CSharp"]["acOutputPathCSharpRoot"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["CSharp"]["acPathJinjaTemplateCSharpDefinitionEnum"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["CSharp"]["acPathJinjaTemplateCSharpDefinitionStruct"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["CSharp"]["acPathJinjaTemplateCSharpDefinitionControl"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["CSharp"]["acPathJinjaTemplateCSharpDefinitionData"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["Matlab"] = {}
    dctGlobalDict["dctCodeGenerationInformation"]["Matlab"]["acOutputPathMatlabTypeSizeMatched"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["Matlab"]["acOutputPathMatlabTypesAsDoubles"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["Matlab"]["acOutputPathMatlabRoot"] = str("")
    dctGlobalDict["dctCodeGenerationInformation"]["Matlab"]["acPathJinjaTemplateCppDefinition"] = str("")

    if (len(sys.argv) != 2):
        logging.error("Insufficient number of command line arguments provided")
        logging.error("Usage: python3.6 validate_data_model_definitions_xml.py XML_FILE")
        logging.error("The XML file provided here are a command line parameter is not from the SICD repo!")
        logging.error("This XML is a special and dedicated XML file to configure the Autogen code.")
        print("Example: python3.6 validate_data_model_and_do_autogen.py autogen_configuration.xml")
        sys.exit()

    objClsLoggerManager = clsLoggingManager()
    objClsLoggerManager.vConfigureLogger()
    objRootLogger = objClsLoggerManager.objGetLoggerInstance()
    objRootLogger.setLevel(logging.INFO)

    logging.info("Module validate_data_model_definitions_xml.py")
    logging.info("sys argv are %s and %s", sys.argv[0], sys.argv[1])

    acSysArgv0 = sys.argv[0]  # The full path as the Python file was run
    acSysArgv1 = sys.argv[1]  # The configuration XML file

    try:
        acCurrentWorkingDirectory = os.getcwd()
        dctGlobalDict["acCurrentWorkingDirectory"] = acCurrentWorkingDirectory
    except Exception as E:
        logging.error("Cannot get current working directory")
        sys.exit()

    acPathToConfigXmlFile = os.path.join(acCurrentWorkingDirectory, acSysArgv1)

    if (os.path.isfile(acPathToConfigXmlFile) is False):
        logging.error("XML file %s does not exist", acPathToConfigXmlFile)
        sys.exit()

    # Store the path of the autogen config XML file to the global dictionary
    dctGlobalDict["acPathToAutogenConfigXmlFile"] = acPathToConfigXmlFile
    # Now that we have the path of autogen config XML file call a dedicated function to validate and parse it
    bAutogenConfigXMLFileIsValid = bValidateAndParseConfigurationXmlFile(dctGlobalDict)  # Parse and validate the autogen config XML file

    # See if the xmllint program is installed - otherwise exit
    if (bXmllintIsInstalled() is False):
        logging.error("xmllint does not seem to be installed")
        logging.error("Type -> sudo apt-get install libxml2-utils")
        sys.exit()

    # See if the autogen config file is valid otherwise exit
    if (bAutogenConfigXMLFileIsValid is False):
        logging.error("Autogen config XML file %s is invalid", acPathToConfigXmlFile)
        sys.exit()

    bGetGitHashFromSicdSubmodule(dctGlobalDict)

    bWriteSicdGitHashToFile(dctGlobalDict)

    # Find all the Typedef XML files
    if (bFindAllTypedefXmlFiles(dctGlobalDict) is False):
        logging.error("Could not find and parse all the Typdef XML files")
        sys.exit()

    if (bValidateTypedefXmlFromRootElement(dctGlobalDict) is False):
        logging.error("Typedef XML is invalid - will not continue autogen")
        sys.exit()

    # Make a global dictionary for all typdef enums and global dictionary for all typedef structs
    for dctTypedefXmlFile in dctGlobalDict["lstTypedefXmlFiles"]:
        if (dctTypedefXmlFile["objElementTreeRoot"]):
            lstStructDictItems = clsAutogenToolboxDefinitionValidationAndETFinding.lstFindStructsAndEnumsFromElement(dctTypedefXmlFile["objElementTreeRoot"], E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_STRUCT), dctTypedefXmlFile["acFilePath"])
            for dctStructDictItem in lstStructDictItems:
                G_dctAllTypedefFileStructs[dctStructDictItem["acName"]] = dctStructDictItem

            lstEnumDictItems = clsAutogenToolboxDefinitionValidationAndETFinding.lstFindStructsAndEnumsFromElement(dctTypedefXmlFile["objElementTreeRoot"], E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_ENUM), dctTypedefXmlFile["acFilePath"])
            for dctEnumDictItem in lstEnumDictItems:
                G_dctAllTypedefFileEnums[dctEnumDictItem["acName"]] = dctEnumDictItem

    # Find all the Message Definition (MsdDef not Typedef) XML files
    vFindAllMsgDefXmlFiles(dctGlobalDict)

    for dctMsgDefXmlDictItem in dctGlobalDict["lstMsgDefXmlFiles"]:
        dctMsgDefXmlDictItem["tplCommonIncludeXmlFiles"] = clsAutogenToolboxFindIncludedXmlInXml.tplFindIncludedXmlFilesInsideXmlFile(dctMsgDefXmlDictItem["acFilePath"])
        # Keep a general flag if this MsgDef is valid and ready for autogen
        dctMsgDefXmlDictItem["bValidationCheckClearedForAutogen"] = bValidateMsgDefXmlFile(dctMsgDefXmlDictItem, dctGlobalDict)

    # Iterate through all the MsgDef files and see if any one of them failed validation
    if (all([dctMsgDefXmlDictItem["bValidationCheckClearedForAutogen"] for dctMsgDefXmlDictItem in dctGlobalDict["lstMsgDefXmlFiles"]]) is False):
        logging.error("A MsgDef XML failed validation - autogen will not continue")
        sys.exit()

    # Find all the module interface configuration XML files
    vFindAllModuleInterfaceConfigurationXmlFiles(dctGlobalDict)
    if (bValidateModuleInterfaceConfigurationXmlFiles(dctGlobalDict) is False):
        logging.error("One of the module interface configuration files is not valid - autogen will not continue")
        sys.exit()

    # Validation is now over, now we do autogen
    # Validation is now over, now we do autogen
    # Validation is now over, now we do autogen

    if (dctGlobalDict["bValidateOnlyProduceNoAutogen"] is True):
        logging.info("autogen_configuration.xml configured to only validate and do no autogen - End of process")
        sys.exit()

    # Iterate through all the message definition XML files
    # Iterate through all the message definition XML files
    # Iterate through all the message definition XML files

    # Before we start iterating the MsgDef files, initialise a dict of Matlab Typedefs.
    # Every time we generate a typedef keep a record of it so that we don't have to 
    # generate it again
    dctTypesGenerated = {}

    for dctMsgDefXmlFile in dctGlobalDict["lstMsgDefXmlFiles"]:

        # If this MsgDef file is not valid then continue the for loop
        if (dctMsgDefXmlFile["bValidationCheckClearedForAutogen"] is False):
            logging.error("Autogen cannot be generated for %s because it is invalid", dctMsgDefXmlFile["acFileName"])
            continue

        # C++ definition
        # C++ definition
        # C++ definition

        # Make a new dictionary and fill it with things needed for the Jinja writer for C++
        dctCppDefWriterContext = {}
        # Get the module name from the MsgDef filename
        dctCppDefWriterContext["acModuleName"] = dctMsgDefXmlFile["acFileName"].replace("_Msg.xml", "")
        dctCppDefWriterContext["acJinja2Version"] = str("")
        dctCppDefWriterContext["acPythonVersion"] = str("")
        dctCppDefWriterContext["acDate"] = str("")
        dctCppDefWriterContext["acCppDefJinjaTemplatePath"] = dctGlobalDict["dctCodeGenerationInformation"]["Cpp"]["acPathJinjaTemplateCppDefinition"]
        dctCppDefWriterContext["acCppDefMessageEventHanderTemplatePath"] = dctGlobalDict["dctCodeGenerationInformation"]["Cpp"]["acPathJinjaTemplateCppDefinitionMessageEventHandler"]
        dctCppDefWriterContext["acCppAutogenOutputDirectory"] = dctGlobalDict["dctCodeGenerationInformation"]["Cpp"]["acOutputPathCpp"]
        dctCppDefWriterContext["dctMsgDefXmlFile"] = dctMsgDefXmlFile
        dctCppDefWriterContext["dctProgLangSpecific"] = {}
        dctCppDefWriterContext["acCppBaseTypesHeaderFilePath"] = dctGlobalDict["dctCodeGenerationInformation"]["Cpp"]["acBaseTypesHeaderFilePath"]

        clsAutogenToolboxJinjaWriter.bPopulateGeneralAutogenRequiredInformationForDefinition(dctCppDefWriterContext)
        # Generate for the main MsgDef (not include) file
        clsAutogenToolboxJinjaWriter.bPrepareRenderContextForCppDefinition(dctCppDefWriterContext, E_CPP_TYPE_OF_AUTOGEN_FILE(E_CPP_TYPE_OF_AUTOGEN_FILE.CPP_AUTOGEN_TYPE_MAIN_MSG_DEF_FILE), "NA")
        clsAutogenToolboxJinjaWriter.bWriteCppDefinition(dctCppDefWriterContext)

        # Matlab definition
        # Matlab definition
        # Matlab definition

        dctMatlabDefWriterContext = {}
        dctMatlabDefWriterContext["acModuleName"] = dctCppDefWriterContext["acModuleName"]
        dctMatlabDefWriterContext["acJinja2Version"] = dctCppDefWriterContext["acJinja2Version"]
        dctMatlabDefWriterContext["acPythonVersion"] = dctCppDefWriterContext["acPythonVersion"]
        dctMatlabDefWriterContext["acDate"] = dctCppDefWriterContext["acDate"]
        dctMatlabDefWriterContext["acMatlabDefJinjaTemplatePath"] = dctGlobalDict["dctCodeGenerationInformation"]["Matlab"]["acPathJinjaTemplateCppDefinition"]
        dctMatlabDefWriterContext["acMatlabAutogenOutputDirectoryTypeSizeMatched"] = dctGlobalDict["dctCodeGenerationInformation"]["Matlab"]["acOutputPathMatlabTypeSizeMatched"]
        dctMatlabDefWriterContext["acMatlabAutogenOutputDirectoryTypesAsDoubles"] = dctGlobalDict["dctCodeGenerationInformation"]["Matlab"]["acOutputPathMatlabTypesAsDoubles"]
        dctMatlabDefWriterContext["dctMsgDefXmlFile"] = dctMsgDefXmlFile
        dctMatlabDefWriterContext["dctProgLangSpecific"] = {}
        dctMatlabDefWriterContext["acOutputFilename"] = str("")

        # See if the message headers and payloads for this definition file is valid
        if ((dctMsgDefXmlFile["tplValidMessageHeaders"][0] is True) and (dctMsgDefXmlFile["tplValidMessagePayloads"][0] is True) and (len(dctMsgDefXmlFile["tplValidMessageHeaders"][1]) == len(dctMsgDefXmlFile["tplValidMessagePayloads"][1]))):

            iMessageHeaderCount = int(-1)
            # Iterate through the messages
            for dctValidMessageHeader in dctMsgDefXmlFile["tplValidMessageHeaders"][1]:
                iMessageHeaderCount += 1

                # In the context populate info on the specific message we are at now so we can generate message event handler info
                dctCppDefWriterContext["dctValidMessageHeader"] = dctValidMessageHeader
                # Prepare the context to generate a message event handler
                clsAutogenToolboxJinjaWriter.bPrepareRenderContextForCppDefinitionMessageEventHandler(dctCppDefWriterContext)
                # Generate the C++ Message Event Handler H file
                clsAutogenToolboxJinjaWriter.bWriteCppDefinitionMessageEventHandler(dctCppDefWriterContext)

                # Matlab
                dctMatlabDefWriterContext["dctValidMessageHeader"] = dctValidMessageHeader
                # While we are getting the header, also get the payload
                dctMatlabDefWriterContext["dctValidMessagePayload"] = dctMsgDefXmlFile["tplValidMessagePayloads"][1][iMessageHeaderCount]

                # Prepare the context by getting Message and Struct Typedef
                clsAutogenToolboxJinjaWriter.bPrepareRenderContextForMatlabDefinition(dctMatlabDefWriterContext)
                # Write out here Messages only

                # Write into the "Structs" directory
                dctMatlabDefWriterContext["dctProgLangSpecific"]["Matlab"]["Definition"]["bGenerateUsingDoubleTypes"] = bool(False)
                clsAutogenToolboxJinjaWriter.bWriteMatlabDefinition(dctMatlabDefWriterContext, E_MATLAB_GENERATION_TYPE.MATLAB_GENERATION_STRUCTS)
                # Write into the "Structs_Double" directory
                dctMatlabDefWriterContext["dctProgLangSpecific"]["Matlab"]["Definition"]["bGenerateUsingDoubleTypes"] = bool(True)
                clsAutogenToolboxJinjaWriter.bWriteMatlabDefinition(dctMatlabDefWriterContext, E_MATLAB_GENERATION_TYPE.MATLAB_GENERATION_STRUCTS_DOUBLE)

                # Now iterate through Typedefs referenced by this MsgDef file - this include Typedefs in the MsgDef file and typedefs referenced in this file
                for dctStructTypdef in dctMatlabDefWriterContext["dctProgLangSpecific"]["Matlab"]["Definition"]["lstTypes"]:

                    # Every time we generate a typedef keep a record of it so that we don't have to 
                    # generate it again
                    if (dctStructTypdef["acName"] in dctTypesGenerated):
                        continue

                    dctMatlabDefWriterContext["dctProgLangSpecific"]["Matlab"]["Definition"]["acOutputFilename"] = dctStructTypdef["acName"] + ".m"
                    dctMatlabDefWriterContext["dctProgLangSpecific"]["Matlab"]["Definition"]["acStructureName"] = dctStructTypdef["acName"]
                    dctMatlabDefWriterContext["dctProgLangSpecific"]["Matlab"]["Definition"]["lstFields"] = dctStructTypdef["lstRecords"]
                    # Write into the "Structs" directory
                    dctMatlabDefWriterContext["dctProgLangSpecific"]["Matlab"]["Definition"]["bGenerateUsingDoubleTypes"] = bool(False)
                    clsAutogenToolboxJinjaWriter.bWriteMatlabDefinition(dctMatlabDefWriterContext, E_MATLAB_GENERATION_TYPE.MATLAB_GENERATION_STRUCTS)
                    # Write into the "Structs_Double" directory
                    dctMatlabDefWriterContext["dctProgLangSpecific"]["Matlab"]["Definition"]["bGenerateUsingDoubleTypes"] = bool(True)
                    clsAutogenToolboxJinjaWriter.bWriteMatlabDefinition(dctMatlabDefWriterContext, E_MATLAB_GENERATION_TYPE.MATLAB_GENERATION_STRUCTS_DOUBLE)

                    # Because we generated a typedef add its name to a lookup of typedefs already generated
                    dctTypesGenerated[dctStructTypdef["acName"]] = bool(True)

        else:
            logging.error("MsgDef file set of hgeaders or paylods are not valid")

        # Make a new dictionary and fill it with things needed for the Jinja writer for Python
        dctPythonDefWriterContext = {}
        dctPythonDefWriterContext["acJinja2Version"] = str("")
        dctPythonDefWriterContext["acPythonVersion"] = str("")
        dctPythonDefWriterContext["acDate"] = str("")
        dctPythonDefWriterContext["acPythonDefJinjaTemplatePath"] = dctGlobalDict["dctCodeGenerationInformation"]["Python"]["acPathJinjaTemplatePythonDefinition"]
        dctPythonDefWriterContext["acPythonAutogenOutputDirectory"] = dctGlobalDict["dctCodeGenerationInformation"]["Python"]["acOutputPathPython"]
        dctPythonDefWriterContext["dctMsgDefXmlFile"] = dctMsgDefXmlFile
        dctPythonDefWriterContext["dctProgLangSpecific"] = {}
        dctPythonDefWriterContext["acPythonBaseTypesHeaderFilePath"] = dctGlobalDict["dctCodeGenerationInformation"]["Python"]["acBaseTypesHeaderFilePath"]

        clsAutogenToolboxJinjaWriter.bPopulateGeneralAutogenRequiredInformationForDefinition(dctPythonDefWriterContext)
        # Generate for the main MsgDef (not include) file
        clsAutogenToolboxJinjaWriter.bPrepareRenderContextForPythonDefinition(dctPythonDefWriterContext, E_PYTHON_TYPE_OF_AUTOGEN_FILE(E_PYTHON_TYPE_OF_AUTOGEN_FILE.PYTHON_AUTOGEN_TYPE_MAIN_MSG_DEF_FILE), "NA")
        clsAutogenToolboxJinjaWriter.bWritePythonDefinition(dctPythonDefWriterContext)

        tplMsgDegXmlIncludedFiles = dctMsgDefXmlFile["tplCommonIncludeXmlFiles"]

        if (tplMsgDegXmlIncludedFiles[0] is True):
            for acTypedefXmlFile in tplMsgDegXmlIncludedFiles[1]:
                # For C++
                clsAutogenToolboxJinjaWriter.bPrepareRenderContextForCppDefinition(dctCppDefWriterContext, E_CPP_TYPE_OF_AUTOGEN_FILE(E_CPP_TYPE_OF_AUTOGEN_FILE.CPP_AUTOGEN_TYPE_INCLUDED_TYPE_FILE), acTypedefXmlFile)
                clsAutogenToolboxJinjaWriter.bWriteCppDefinition(dctCppDefWriterContext)

                # For Python
                clsAutogenToolboxJinjaWriter.bPrepareRenderContextForPythonDefinition(dctPythonDefWriterContext, E_PYTHON_TYPE_OF_AUTOGEN_FILE(E_PYTHON_TYPE_OF_AUTOGEN_FILE.PYTHON_AUTOGEN_TYPE_INCLUDED_TYPE_FILE), acTypedefXmlFile)
                clsAutogenToolboxJinjaWriter.bWritePythonDefinition(dctPythonDefWriterContext)
        else:
            logging.error("The included XML file for %s is invalid", dctMsgDefXmlFile["acFileName"])

        # Certain modules in the ADCS require Typedef XML files not in the data model to be generated
        # Therefore iterate through all the Typdef XML files even if they are used in a MsgDef XML file
        for dctTypedefXmlFileItem in dctGlobalDict["lstTypedefXmlFiles"]:
            # We must however check if this file was excluded in the config file
            if (dctTypedefXmlFileItem["acFileName"] in dctGlobalDict["lstTypedefXmlFilesToExclude"]):
                continue

            # Check the validity of this Typedef file
            if ((dctTypedefXmlFileItem["bFileExists"] is False) or (dctTypedefXmlFileItem["bElementTreeParserPassed"] is False) or(dctTypedefXmlFileItem["bEtreeParserPassed"] is False)):
                logging.error("Typefile file %s can not be autogended because it is not valid", dctTypedefXmlFileItem["acFileName"])
                continue

            acTypedefXmlFile = dctTypedefXmlFileItem["acFileName"]

            # For C++
            clsAutogenToolboxJinjaWriter.bPrepareRenderContextForCppDefinition(dctCppDefWriterContext, E_CPP_TYPE_OF_AUTOGEN_FILE(E_CPP_TYPE_OF_AUTOGEN_FILE.CPP_AUTOGEN_TYPE_INCLUDED_TYPE_FILE), acTypedefXmlFile)
            clsAutogenToolboxJinjaWriter.bWriteCppDefinition(dctCppDefWriterContext)

    # Iterate through all the module interface configuration files
    # Iterate through all the module interface configuration files
    # Iterate through all the module interface configuration files

    for dctModInterConfFileDictItem in dctGlobalDict["lstModuleInterfaceConfiguationXmlFiles"]:

        # C++ related
        # C++ related
        # C++ related

        # C++ module interface configuration
        # C++ module interface configuration
        # C++ module interface configuration

        dctCppModInterConfContext = {}
        dctCppModInterConfContext["acModuleName"] = dctModInterConfFileDictItem["acFileName"].replace(".xml", "").replace("Module_Interface_Config_", "")
        dctCppModInterConfContext["acJinja2Version"] = str("")
        dctCppModInterConfContext["acPythonVersion"] = str("")
        dctCppModInterConfContext["acDate"] = str("")
        dctCppModInterConfContext["acCppModInterConfJinjaTemplatePathHFile"] = dctGlobalDict["dctCodeGenerationInformation"]["Cpp"]["acPathJinjaTemplateCppModInterConfHFile"]
        dctCppModInterConfContext["acCppModInterConfJinjaTemplatePathCppFile"] = dctGlobalDict["dctCodeGenerationInformation"]["Cpp"]["acPathJinjaTemplateCppModInterConfCppFile"]
        dctCppModInterConfContext["acCppModInterConfTopicJinjaTemplatePathHFile"] = dctGlobalDict["dctCodeGenerationInformation"]["Cpp"]["acPathJinjaTemplateCppModInterConfTopicHFile"]
        dctCppModInterConfContext["acCppModInterConfEventHandlerJinjaTemplatePathHFile"] = dctGlobalDict["dctCodeGenerationInformation"]["Cpp"]["acPathJinjaTemplateCppModInterConfEventHandlerHFile"]
        dctCppModInterConfContext["acCppAutogenOutputDirectory"] = dctGlobalDict["dctCodeGenerationInformation"]["Cpp"]["acOutputPathCpp"]
        dctCppModInterConfContext["dctProgLangSpecific"] = {}
        dctCppModInterConfContext["acModInterConfXmlFilename"] = dctModInterConfFileDictItem["acFileName"]

        acFileNameAsCapUnderscores = dctModInterConfFileDictItem["acFileName"]
        acFileNameAsCapUnderscores = acFileNameAsCapUnderscores.replace(".xml", "").upper()

        dctCppModInterConfContext["acModInterConfXmlFilenameAsCapUnder"] = acFileNameAsCapUnderscores

        if (clsAutogenToolboxJinjaWriter.bPopulateGeneralAutogenRequiredInformationForModInterConf(dctCppModInterConfContext) is False):
            logging.error("bPopulateGeneralAutogenRequiredInformationForModInterConf failed")
            sys.exit()

        if (clsAutogenToolboxJinjaWriter.bPrepareRenderContextForCppModInterConf(dctCppModInterConfContext, dctModInterConfFileDictItem) is False):
            logging.error("bPrepareRenderContextForCppModInterConf failed")
            sys.exit()

        # Write out the standard MIC files
        clsAutogenToolboxJinjaWriter.bWriteCppModInterConf(dctCppModInterConfContext)
        # Write out the TOPIC MIC H file
        clsAutogenToolboxJinjaWriter.bWriteCppModInterConfTopicH(dctCppModInterConfContext)
        # Write out the Event Handler MIC H file
        clsAutogenToolboxJinjaWriter.bWriteCppModInterConfEventHandlerH(dctCppModInterConfContext)

        # Python related
        # Python related
        # Python related

        # Python Module Interface Configuration
        # Python Module Interface Configuration
        # Python Module Interface Configuration

        dctPythonModInterConfContext = {}
        dctPythonModInterConfContext["acJinja2Version"] = str("")
        dctPythonModInterConfContext["acPythonVersion"] = str("")
        dctPythonModInterConfContext["acDate"] = str("")
        dctPythonModInterConfContext["acPythonModInterConfJinjaTemplatePath"] = dctGlobalDict["dctCodeGenerationInformation"]["Python"]["acPathJinjaTemplatePythonModInterConf"]
        dctPythonModInterConfContext["acPythonAutogenOutputDirectory"] = dctGlobalDict["dctCodeGenerationInformation"]["Python"]["acOutputPathPython"]
        dctPythonModInterConfContext["dctProgLangSpecific"] = {}
        dctPythonModInterConfContext["acModInterConfXmlFilename"] = dctModInterConfFileDictItem["acFileName"]

        acFileNameAsCapUnderscores = dctModInterConfFileDictItem["acFileName"]
        acFileNameAsCapUnderscores = acFileNameAsCapUnderscores.replace(".xml", "").upper()

        dctPythonModInterConfContext["acModInterConfXmlFilenameAsCapUnder"] = acFileNameAsCapUnderscores

        if (clsAutogenToolboxJinjaWriter.bPopulateGeneralAutogenRequiredInformationForModInterConf(dctPythonModInterConfContext) is False):
            logging.error("bPrepareRenderContextForCppModInterConf failed")
            sys.exit()

        if (clsAutogenToolboxJinjaWriter.bPrepareRenderContextForPythonModInterConf(dctPythonModInterConfContext, dctModInterConfFileDictItem) is False):
            logging.error("bPrepareRenderContextForPythonModInterConf failed")
            sys.exit()

        clsAutogenToolboxJinjaWriter.bWritePythonModInterConf(dctPythonModInterConfContext)

        # Python MQTT client on connect
        # Python MQTT client on connect
        # Python MQTT client on connect

        dctPythonMqttClientOnConnectContext = {}
        dctPythonMqttClientOnConnectContext["acJinja2Version"] = str("")
        dctPythonMqttClientOnConnectContext["acPythonVersion"] = str("")
        dctPythonMqttClientOnConnectContext["acDate"] = str("")
        dctPythonMqttClientOnConnectContext["acPathJinjaTemplatePythonMqttClientOnConnect"] = dctGlobalDict["dctCodeGenerationInformation"]["Python"]["acPathJinjaTemplatePythonMqttClientOnConnect"]
        dctPythonMqttClientOnConnectContext["acPythonAutogenOutputDirectory"] = dctGlobalDict["dctCodeGenerationInformation"]["Python"]["acOutputPathPython"]
        dctPythonMqttClientOnConnectContext["dctProgLangSpecific"] = {}
        dctPythonMqttClientOnConnectContext["acModuleName"] = str("")
        dctPythonMqttClientOnConnectContext["acModInterConfXmlFilename"] = dctModInterConfFileDictItem["acFileName"]
        dctPythonMqttClientOnConnectContext["acModInterConfXmlFilenameAsCapUnder"] = acFileNameAsCapUnderscores

        dctPythonMqttClientOnConnectContext["acModuleName"] = dctModInterConfFileDictItem["objElementTreeRoot"].attrib["Name"]

        if (clsAutogenToolboxJinjaWriter.bPopulateGeneralAutogenRequiredInformationForPythonMqttClientOnConnect(dctPythonMqttClientOnConnectContext) is False):
            logging.error("bPopulateGeneralAutogenRequiredInformationForPythonMqttClientOnConnect failed")
            sys.exit()

        if (clsAutogenToolboxJinjaWriter.bPrepareRenderContextForPythonMqttClientOnConnect(dctPythonMqttClientOnConnectContext, dctModInterConfFileDictItem) is False):
            logging.error("bPrepareRenderContextForPythonMqttClientOnConnect failed")
            sys.exit()

        # Write out the Python MQTT client on connect class
        clsAutogenToolboxJinjaWriter.bWritePythonMqttClientOnConnect(dctPythonMqttClientOnConnectContext)

        # Python asyncio message processing
        # Python asyncio message processing
        # Python asyncio message processing

        dctPythonAsyncioMessageProcessingContext = {}
        dctPythonAsyncioMessageProcessingContext["acJinja2Version"] = str("")
        dctPythonAsyncioMessageProcessingContext["acPythonVersion"] = str("")
        dctPythonAsyncioMessageProcessingContext["acDate"] = str("")
        dctPythonAsyncioMessageProcessingContext["acPathJinjaTemplatePythonAsyncioMessageProcessing"] = dctGlobalDict["dctCodeGenerationInformation"]["Python"]["acPathJinjaTemplatePythonAsyncioMessageProcessing"]
        dctPythonAsyncioMessageProcessingContext["acPythonAutogenOutputDirectory"] = dctGlobalDict["dctCodeGenerationInformation"]["Python"]["acOutputPathPython"]
        dctPythonAsyncioMessageProcessingContext["dctProgLangSpecific"] = {}
        dctPythonAsyncioMessageProcessingContext["acModuleName"] = str("")
        dctPythonAsyncioMessageProcessingContext["acModInterConfXmlFilename"] = dctModInterConfFileDictItem["acFileName"]
        dctPythonAsyncioMessageProcessingContext["acModInterConfXmlFilenameAsCapUnder"] = acFileNameAsCapUnderscores

        dctPythonAsyncioMessageProcessingContext["acModuleName"] = dctModInterConfFileDictItem["objElementTreeRoot"].attrib["Name"]

        if (clsAutogenToolboxJinjaWriter.bPopulateGeneralAutogenRequiredInformationForPythonAsyncioMessageProcessing(dctPythonAsyncioMessageProcessingContext) is False):
            logging.error("bPopulateGeneralAutogenRequiredInformationForPythonAsyncioMessageProcessing failed")
            sys.exit()

        if (clsAutogenToolboxJinjaWriter.bPrepareRenderContextForPythonAsyncioMessageProcessing(dctPythonAsyncioMessageProcessingContext, dctModInterConfFileDictItem) is False):
            logging.error("bPrepareRenderContextForPythonAsyncioMessageProcessing failed")
            sys.exit()

        clsAutogenToolboxJinjaWriter.bWritePythonAsyncioMessageProcessing(dctPythonAsyncioMessageProcessingContext)

    # Iterate through the module interface configuration files again for the C# code generation
    # Iterate through the module interface configuration files again for the C# code generation
    # Iterate through the module interface configuration files again for the C# code generation

    for dctModInterConfFileDictItem in dctGlobalDict["lstModuleInterfaceConfiguationXmlFiles"]:

        # From the module interface config filename, filter out just the name of module to which it belongs
        acInterfaceModuleName = dctModInterConfFileDictItem["acFileName"].replace("Module_Interface_Config_", "").replace(".xml", "")

        # If we are here then we are generating for the acInterfaceModuleName interface
        acDirectoryPath = os.path.join(dctGlobalDict["dctCodeGenerationInformation"]["CSharp"]["acOutputPathCSharpRoot"], acInterfaceModuleName)

        # We first need to try and delete the old autogen files - we need to start clean
        if (os.path.isdir(acDirectoryPath) is True):
            try:
                shutil.rmtree(acDirectoryPath)
                logging.info("Removed directory %s", acDirectoryPath)
            except Exception as E:
                logging.error("Could remove directory %s - Exception %s", acDirectoryPath, str(E))
                continue

        # Create the directory into which the files will be generated
        try:
            os.makedirs(acDirectoryPath, exist_ok=True)
            logging.info("Created directory %s", acDirectoryPath)
        except Exception as E:
            logging.error("Creation of the directory %s failed - Exception %s", acDirectoryPath, str(E))
            continue

        # C# Enums directory
        # C# Enums directory
        # C# Enums directory

        acDirectoryPath = os.path.join(acDirectoryPath, "Enums")

        # Create the directory into which the files will be generated
        try:
            os.makedirs(acDirectoryPath, exist_ok=True)
            logging.info("Created directory %s", acDirectoryPath)
        except Exception as E:
            logging.error("Creation of the directory %s failed - Exception %s", acDirectoryPath, str(E))
            continue

        # C# Structs directory
        # C# Structs directory
        # C# Structs directory

        acDirectoryPath = os.path.join(dctGlobalDict["dctCodeGenerationInformation"]["CSharp"]["acOutputPathCSharpRoot"], acInterfaceModuleName)
        acDirectoryPath = os.path.join(acDirectoryPath, "Structs")

        # Create the directory into which the files will be generated
        try:
            os.makedirs(acDirectoryPath, exist_ok=True)
            logging.info("Created directory %s", acDirectoryPath)
        except Exception as E:
            logging.error("Creation of the directory %s failed - Exception %s", acDirectoryPath, str(E))
            continue

        # C# Control directory
        # C# Control directory
        # C# Control directory

        acDirectoryPath = os.path.join(dctGlobalDict["dctCodeGenerationInformation"]["CSharp"]["acOutputPathCSharpRoot"], acInterfaceModuleName)
        acDirectoryPath = os.path.join(acDirectoryPath, "Control")

        # Create the directory into which the files will be generated
        try:
            os.makedirs(acDirectoryPath, exist_ok=True)
            logging.info("Created directory %s", acDirectoryPath)
        except Exception as E:
            logging.error("Creation of the directory %s failed - Exception %s", acDirectoryPath, str(E))
            continue

        # C# Data directory
        # C# Data directory
        # C# Data directory

        acDirectoryPath = os.path.join(dctGlobalDict["dctCodeGenerationInformation"]["CSharp"]["acOutputPathCSharpRoot"], acInterfaceModuleName)
        acDirectoryPath = os.path.join(acDirectoryPath, "Data")

        # Create the directory into which the files will be generated
        try:
            os.makedirs(acDirectoryPath, exist_ok=True)
            logging.info("Created directory %s", acDirectoryPath)
        except Exception as E:
            logging.error("Creation of the directory %s failed - Exception %s", acDirectoryPath, str(E))
            continue

        # C# directories create end
        # C# directories create end
        # C# directories create end

        # Get a list of all the required messages
        lstRequiredMessages = [dctModConfIntMessage["acMessageName"] for dctModConfIntMessage in dctModInterConfFileDictItem["lstFullTopicPartsForThisModConfInterface"]]

        # Iterate through all the MsgDef files
        for dctMsgDefXmlFile in dctGlobalDict["lstMsgDefXmlFiles"]:
            # Iterate through all the required MsgDef files
            for acRequiredXmlFile in dctModInterConfFileDictItem["sttRequiredMsgDefFilenames"]:
                # Only consider required files
                if dctMsgDefXmlFile["acFileName"] == acRequiredXmlFile:

                    # Create a new enum context dictionary
                    dctCSharpDefWriterContext = {}
                    dctCSharpDefWriterContext["acModuleInterfaceName"] = acInterfaceModuleName
                    dctCSharpDefWriterContext["acJinja2Version"] = str("")
                    dctCSharpDefWriterContext["acPythonVersion"] = str("")
                    dctCSharpDefWriterContext["acDate"] = str("")
                    dctCSharpDefWriterContext["acCSharpDefEnumJinjaTemplatePath"] = dctGlobalDict["dctCodeGenerationInformation"]["CSharp"]["acPathJinjaTemplateCSharpDefinitionEnum"]
                    dctCSharpDefWriterContext["acCSharpDefStructJinjaTemplatePath"] = dctGlobalDict["dctCodeGenerationInformation"]["CSharp"]["acPathJinjaTemplateCSharpDefinitionStruct"]
                    dctCSharpDefWriterContext["acCSharpAutogenOutputDirectory"] = dctGlobalDict["dctCodeGenerationInformation"]["CSharp"]["acOutputPathCSharpRoot"]
                    dctCSharpDefWriterContext["dctMsgDefXmlFile"] = dctMsgDefXmlFile
                    dctCSharpDefWriterContext["dctProgLangSpecific"] = {}

                    clsAutogenToolboxJinjaWriter.bPopulateGeneralAutogenRequiredInformationForDefinition(dctCSharpDefWriterContext)

                    # Iterate through all the Typedefs for this required MsgDef file
                    for acTypedefName, dctTypedefItem in dctMsgDefXmlFile["dctAllTypesElementsForThisFileIncludingIncludes"].items():
                        if (dctTypedefItem["eTypedefType"] == E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_ENUM)):

                            clsAutogenToolboxJinjaWriter.bPrepareRenderContextForCSharpDefinitionEnum(dctCSharpDefWriterContext, acTypedefName)
                            clsAutogenToolboxJinjaWriter.bWriteCSharpEnum(dctCSharpDefWriterContext)

                        elif (dctTypedefItem["eTypedefType"] == E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_STRUCT)):

                            clsAutogenToolboxJinjaWriter.bPrepareRenderContextForCSharpDefinitionStruct(dctCSharpDefWriterContext, acTypedefName)
                            clsAutogenToolboxJinjaWriter.bWriteCSharpStruct(dctCSharpDefWriterContext)

                    iMsgDefMessageHeaderCnt = -1
                    # Iterate through all the messages in this required MsgDef XML file
                    for dctMessageHeader in dctMsgDefXmlFile["tplValidMessageHeaders"][1]:
                        # Increment the counter
                        iMsgDefMessageHeaderCnt += 1

                        # Also get the payload now that we have the header
                        dctMessagePayload = dctMsgDefXmlFile["tplValidMessagePayloads"][1][iMsgDefMessageHeaderCnt]

                        # If the current message is not required in the ModConfInter then go to the next
                        if (dctMessageHeader["acName"] not in lstRequiredMessages):
                            continue

                        # Double check that this message header matches the message payload
                        if (dctMessageHeader["acName"] != dctMessagePayload["acName"]):
                            logging.error("For C Sharp message autogen something went wrong - The header name does not match the payload name")
                            continue

                        # Use list comprehension to see if this MsgDef message is in ModConfInter messages and if it is get the dict with the other info
                        lstModConfMessage = [dctModConfMessage for dctModConfMessage in dctModInterConfFileDictItem["lstFullTopicPartsForThisModConfInterface"] if dctModConfMessage["acMessageName"] == dctMessageHeader["acName"]]

                        # The resultant list cannot be empty
                        if (not lstModConfMessage):
                            continue

                        # The list should only have one entry so use the first one
                        # This dictionary will contain info like Roles etc. things from the Module Interface Configuration file
                        dctModConfMessage = lstModConfMessage[0]

                        # Create a new enum context dictionary
                        dctCSharpDefWriterContext = {}
                        dctCSharpDefWriterContext["acModuleInterfaceName"] = acInterfaceModuleName
                        dctCSharpDefWriterContext["acJinja2Version"] = str("")
                        dctCSharpDefWriterContext["acPythonVersion"] = str("")
                        dctCSharpDefWriterContext["acDate"] = str("")
                        dctCSharpDefWriterContext["acCSharpDefControlJinjaTemplatePath"] = dctGlobalDict["dctCodeGenerationInformation"]["CSharp"]["acPathJinjaTemplateCSharpDefinitionControl"]
                        dctCSharpDefWriterContext["acCSharpAutogenOutputDirectory"] = dctGlobalDict["dctCodeGenerationInformation"]["CSharp"]["acOutputPathCSharpRoot"]
                        dctCSharpDefWriterContext["dctMsgDefXmlFile"] = dctMsgDefXmlFile
                        dctCSharpDefWriterContext["dctProgLangSpecific"] = {}

                        clsAutogenToolboxJinjaWriter.bPopulateGeneralAutogenRequiredInformationForDefinition(dctCSharpDefWriterContext)

                        # Filter out only the MQTT messages
                        if (dctModConfMessage["eCommsProtocol"] == E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT)):

                            dctCSharpDefWriterContext["acCSharpDefControlJinjaTemplatePath"] = dctGlobalDict["dctCodeGenerationInformation"]["CSharp"]["acPathJinjaTemplateCSharpDefinitionControl"]

                            clsAutogenToolboxJinjaWriter.bPrepareRenderContextForCSharpDefinitionControl(dctCSharpDefWriterContext, dctModConfMessage, dctMessageHeader, dctMessagePayload)
                            clsAutogenToolboxJinjaWriter.bWriteCSharpControl(dctCSharpDefWriterContext)
                        elif (dctModConfMessage["eCommsProtocol"] == E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_ZMQ)):

                            dctCSharpDefWriterContext["acCSharpDefDataJinjaTemplatePath"] = dctGlobalDict["dctCodeGenerationInformation"]["CSharp"]["acPathJinjaTemplateCSharpDefinitionData"]

                            clsAutogenToolboxJinjaWriter.bPrepareRenderContextForCSharpDefinitionData(dctCSharpDefWriterContext, dctModConfMessage, dctMessageHeader, dctMessagePayload)
                            clsAutogenToolboxJinjaWriter.bWriteCSharpData(dctCSharpDefWriterContext)

    return


if __name__ == "__main__":
    main()
