# Agenda

* The workshop will focus mainly on how to convert an XML definition file into a C++ definition header
* Getting started (software setup)
* Discuss XML schema for message definition
* Discuss how to do validation using xmllint
* XML file parsed using ElementTree
* The definition Jinja template
* C++ defition output example
* A little C++ example program showing usage after autogen
* How definitions can be done in programming languages which does not support packed structures and direct memory access.

---

# Introduction

* Using XML to define message definition a tried and tested method at Reutech
* Allows for very flexible design which will be able to autogen into many languages
* At Reutech autogen into C++, C, Matlab, Python, Delphi and C# for instance
* XML remains platform independent and can be used to define SICD as a formal document if needed

---

# Getting started

* Code was tested on Ubuntu 18.04 and Windows 7. However, small C++ test app will not compile
* Python 3.6 is required to run the code. Normal python 3.6 is good enough. Anaconda can also be used
* sudo pip3 install lxml. On windows pip install lxml
* sudo pip3 install Jinja2. On Windows pip install Jinja2
* xmllint can be used on both Linux and Windows
* We recommend VS Code for development and debugging
* The combination of Python and VS Code provides a very good debugging environment

---

# Python recap

* Using Python 3 because it is more future proof
* Dereference a list
* Dereference a dictionary
* Using get() method will have the option to provide default value and will not generated an KeyError exception
* For a dictionary the update() method will update a key's value or set it for the first time if it does not exist

---

# Useful commands related to XML files

* Use xmllint to validate XML file(s). Some useful commands are:
  * **xmllint --noout --dtdvalid message_file.dtd RMS_SCS_Msg.xml**
    * Parameter **--dtdvalid [URL]** means use DTD from specified URL   
  * **xmllint --noout --noent --dtdvalid message_file.dtd RMS_SCS_Msg.xml**
  * **xmllint --noout --noent --valid RMS_SCS_Msg.xml**
  * The **--noent** switch tells xmllint to substitute entity values for entity refences.
  * The **--noout** switch tells xmllint to supress output.

---

# The definition XML schema (DTD)

Below is a typical definition XML file layout

```
MessageFile
╚═╗
  ╠═ Section
  ║    ╚═ TypeFile                            ┐
  ║        ╠═ Typedef                         │
  ║        ║   ╚═ Record                      │
  ║        ║        ╠═ Enumeration            │
  ║        ║        ╠═ Enumeration            │
  ║        ║        ╚═ Enumeration            ├─────  From seperate included XML file
  ║        ║                                  │
  ║        ╚═ Typedef                         │
  ║            ╠═ Record                      │
  ║            ╠═ Record                      │
  ║            ╠═ Record                      │
  ║            ╚═ Record                      ┘
  ║
  ╠═ Section
  ║    ╠═ Typedef
  ║    ║   ╚═ Record
  ║    ║        ╠═ Enumeration
  ║    ║        ╠═ Enumeration
  ║    ║        ╚═ Enumeration
  ║    ║
  ║    ╚═ Typedef
  ║        ╠═ Record
  ║        ╠═ Record
  ║        ╠═ Record
  ║        ╚═ Record
  ║
  ║
  ╠═ Section
  ║    ╚═ Message
  ║        ╠═ Header
  ║        ║   ╠═ Field
  ║        ║   ╠═ Field
  ║        ║   ╠═ Field
  ║        ║   ╠═ Field
  ║        ║   ╚═ Field
  ║        ║
  ║        ╚═ Payload
  ║            ╠═ Field
  ║            ╠═ Field
  ║            ╚═ Field
  ║
══╝

```

---

# We hope to support for definition

* Enumeration definition
* Structure definition (known as Record in XML)
* Fields with base types U1, U2, U4, U8, I1, I2, I4, I8, F4, F8 and CH
* UUIDs is supported using a Field with type CH and count of 16
* Minimum and maximum limits on numerical base types
* Infinitely nested structures
* Array (list) of structures
* Array (list) of enumeration
* Allow for common XML include

---

# Definition XML file requirements I

* All messages must use the same header definition. The autogen will take the first header as a template for all other messages.
* All messages must have a payload section even if it is empty.
* A comment block must be used to indicate if a message has no payload.
* When a field's type is a struct then the UseStruct=True must be used.
* The name of a struct must start with a 's'.

---

# Definition XML file requirements II

* The name of an enumeration must start with a 'E'
* Header fields cannot have enumerations as default values.
* Structures (Typedef with Records) must have at least 2 fields.
* Enums (Typedef with a record and enumerations inside) must have at least 2 enumerations.
* Enumeration field names must be unique. This is due to certain languages like C++ requiring them to be.
* Entity injection cannot be used.

---

# Definition XML file recommendations

* Add enough comments
* Avoid XML comments and instead use Comment schema tags
* Go in order of enumerations, structures and then messages
* Use a reasonbly nice editor when working on XML files for highlighting

---

# Proposed pre-validation

* The names of structures must have a prefix of 's'
* The names of enumerations must have a prefix of 'E' followed by the size of the enumeration
* All types required must be defined
* A ReplyMsg must have been defined if it is implied.
* Non-symmetrical command and command response message pair should not be allowed

---

# Purpose of RrsBaseTypes.h?

* The RrsBaseTypes.h file defines the base types which are to be used by the autogen definition. This file is not autogenerated.
* It allows for the fundamental base types to be changed quickly

---

# Purpose of CCS_Types.h?

* The CCS_Types.h header defines enumerations for the header message type and the message status. This file is not autogenerated.

---

# How do we include a common types XML into another XML without entity injection

* For security reasons most XML parsers no long support entity injection. In the schema code seems to be fine but not in the XML.
* Therefore injection is already assumed when there is a DOCTYPE include.


---

# Main parts of the autogen Python code

* Parse config ini file and make sure files exist.
* Parse each XML with ElementTree into a root with nested Element(s)
* Build up a context dictionary which will given to the Jinja writer
* Write the definition out using the Jinja writer

---

# What to expect after ElementTree parsed an XML file?

* An ElementTree once parsed is a tree data structure made out of nested Element objects.
* Each ElementTree Element will have properties **attrib**, **tag**, **tail**, **text** and children as a list of Element objects.
* Use the **findall** method on the root to find "./Section/Message". This will make a list of all the messages defined in the XML file.
* The message header struct name is hard coded to "sMESSAGE_HEADER".

---

![90%](./Workshop/xml_definition_file_example.png "XML file in terms of ElementTree Element(s)")

---

# Jinja C++ definition template sections

* Pre-compiler "ifndef/define"
* CCS and RRS type includes (these files are not auto generated)
* Common types XML include (auto generated)
* Type definitions (enumerations and structs)
* Header of all messages
* Message payload structs
* Full message structs
* Pre-compiler "endif"

---

# Jinja quick recap

* To make comments use **{# ... -#}**
* To make for loops and conditionals use **{% ... -%}**
* To write out a python property valuse **{{ ... }}**
* Use the "-" character to stop Jinja from writing out a newline

---

# Context dictionary for Jinja definition template I

* **date** The datetime at which the XML was parsed. We need this to timestamp when the autogen was done
* **acPrecompilerFileName** the string used for the ifndef/define precompiler code. We want to ensure code is only defined once
* **RrsBaseTypes** a string with the name of the base types include file. For this code it is **RrsBaseTypes.h**
* **CCSTypes** a string with the name of the CCS types include file. For this code it is **CCS_Types.h**

---

# Context dictionary for Jinja definition template I

* **PyVersion** a string with the Python version
* **JinjaVersion** a string with the Jinja version

---

# Context dictionary for Jinja definition template I

![](./Workshop/JinjaTemplateIncludes.png)

---

# Context dictionary for Jinja definition template II

* **EnumTypes** a dictionary mapping enumeration type name to a base type ex. {"E1_SCS_BOOL": "U1", ...}. We need this to check if a field is an enumeration or something else
* **XmlIncludes** a list of str. The XML files included as a common type XML ex. ["COMMON_TYPES.xml"]. We need this to write the #include "..." lines

---

# Context dictionary for Jinja definition template III - Message header

* **Header** is an Element and will have a list of Element children which are the fields of the header. We will iterate through this list and determine if the field is an enumeration or a base type and then write out


  ![70%](./Workshop/JinjaTemplateMessageHeader.png)

---

# Context dictionary for Jinja definition template III - Message header

* The **Header** element is sourced from the Header tag Element from the first message in **objClsETreeXmlParser.messages**

---

# Context dictionary for Jinja definition template IV - Type definitions

* **TypeDefElements** contains all the type definitions (enumerations and structs) as a list of Element(s)
* For each type definition we are trying to write out need to know  what type it is (enum or struct), what the fields are and finally what the name if this type should be.

---

# Context dictionary for Jinja definition template IV

```

TypeDefElements [{},{},{},...]
╠═ FunctionType (str) "enum" or "struct"
╠═ FunctionVariables [Element, Element, Element, ...]
╚═ TypedefTest (Element with Typedef tag)

```


---

![20%](./Workshop/typedef_jinja_conditional_flowchart.png "Typedef flowchart")

---

# Context dictionary for Jinja definition template V - Message payloads

* The message payloads can be found in **MessageStructs** context dictionary
* Building up **MessageStructs** we iterate through all messages' payload.
* If a payload starts with **Comment** then we know the payload is empty and then we update the **PayloadBool** attribute
* If the payload is not empty then we iterate through the Payload's fields and update **CountBool**

---

# Context dictionary for Jinja definition template V - Message payloads

```

MessageStructs [Element, Element, ...] (Payload tags)
╚═[0].tag
     .attrib
     [0] (Element with Comment or Field tag)


```

---

# Context dictionary for Jinja definition template V - Message payloads

* We iterate over **MessageStructs** to get the **Payload** Element
* If a message **PayloadBool** is True then there is no payload
* If there is a payload then we need to check if the count is greater than one or not
* Then we need to check if the type is an enum, struct or base type
* If the type is in **EnumTypes** then it is an enum
* Else if the **UseStruct** is in the **attrib** dictionary then it is a struct type
* Otherwise it must be a base type
* If **CountBool** is True then it means it is an array type

---

# Context dictionary for Jinja definition template V - Message payloads

![](./Workshop/JinjaTemplateMessagePayloads.png)

---

# Context dictionary for Jinja definition template VI - Full messages

* **MessageStructs** contains all the defined messages. It is a list of **Payload** Element(s)

---

# Context dictionary for Jinja definition template VI - Full messages

```

MessageStructs [Element, Element, ...] (Payload tags)
╚═[0].tag
     .attrib
     [0] (Element with Comment or Field tag)


```

---

# Context dictionary for Jinja definition template VI - Full messages

![](./Workshop/JinjaTemplateMessageFull.png)

---

# Autogen definition strategy for languages without packed structs I

* A language like Python does not have packed structures or direct memory access
* Have a base classes to implement the different types one might need such as base types, enumeration, struct, array of struct, array of enumeration
* Each base class must be able to serialize and de-serialize its data type
* Base classes are not auto generated
* Autogened classes will inherit the required base class
 

---

# Autogen definition strategy for languages without packed structs II

* Message will thus be constructed from nested autogen classes which call their base class methods to do things like initialize, serialize, de-serialize and validate amongst other things
* This is also possible for languages without reflection but more meta data will have to auto generated to make it work

---

# Conclusion

* All the building blocks are present to implement a very flexible XML defined based auto generation system
* Validation can be done at every step to ensure integrity
* It can be used to produce auto-generated code for most of the notable programming languages

---

# Thank you


