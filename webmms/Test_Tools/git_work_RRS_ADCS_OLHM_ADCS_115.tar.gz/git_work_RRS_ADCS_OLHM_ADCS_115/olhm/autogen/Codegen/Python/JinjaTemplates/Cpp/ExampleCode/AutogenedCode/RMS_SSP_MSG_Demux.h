/*  Autogen Message Demux h File  */
/*  Generated using Python 2.7.11 |Anaconda 4.1.0 (64-bit)| (default, Jun 15 2016, 15:21:30) , with Jinja2 2.10 */
/*  Generated on Thursday, 13 June 2019 SAST 09:22           */

#ifndef RMS_SSP_MSG_DEMUX_H
#define RMS_SSP_MSG_DEMUX_H

#include <stdio.h>

#include "../../../SSP_Toolbox/Types/C/RrsBaseTypes.h"
#include "../../../SSP_Toolbox/Enums/C/CCS_Types.h"

#define MODULE_ADDRESS  0x0002


//************************************************************************
//Typedef and Message Structures
//************************************************************************
typedef enum
{
  
  SSP_FALSE = 0x00,
  SSP_TRUE = 0x01,
  
} E1_SSP_BOOL;

typedef enum
{
  
  SSP_TEMP_OK = 0x00,
  SSP_TEMP_HIGH = 0x01,
  
} E1_SSP_TEMP_STATUS;

typedef enum
{
  
  SSP_PASS = 0x00,
  SSP_FAILED = 0x01,
  SSP_DEGRADED = 0x02,
  SSP_UNKNOWN = 0x03,
  SSP_NOT_FITTED = 0x04,
  
} E1_SSP_STATUS;

typedef enum
{
  
  SSP_OFFLINE = 0x0000,
  SSP_SETUP = 0x2200,
  SSP_OPERATIONAL = 0x2500,
  
} E2_SSP_STATE;

typedef enum
{
  
  NORTH = 78,
  SOUTH = 83,
  
} E1_SSP_LAT_DIR;

typedef enum
{
  
  WEST = 87,
  EAST = 69,
  
} E1_SSP_LONG_DIR;

typedef enum
{
  
  SSP_NOTIFICATION_SEVERITY_NORMAL = 0,
  SSP_NOTIFICATION_SEVERITY_WARNING = 1,
  SSP_NOTIFICATION_SEVERITY_ERROR = 2,
  SSP_NOTIFICATION_SEVERITY_ALARM = 3,
  
} E1_SSP_NOTIFICATION_SEVERITY;

/* TYPDEFS STOP */


/* MESSAGE STRUCTS START */

/* HEADER OF ALL MESSAGES */

typedef struct
{

  U2 u2MsgLength;
  U2 u2MsgType;
  U2 u2MsgStatus;
  U2 u2ModuleAddress;
  U2 u2MsgId;
  
} __attribute__ ((packed)) sMESSAGE_HEADER;

typedef struct
{
  
  /* NO PAYLOAD */
  
} __attribute__ ((packed)) sSSPSTATUSREQ_PL;

typedef struct
{
  
  U1 e1SspStatus;
  U1 e1SspDataStatus;
  U1 e1SspProcessorStatus;
  U1 e1SspOverloadStatus;
  I4 i4SspCpuTempDegreesC;
  I4 i4SspGpuTempDegreesC;
  U1 e1SspTempStatus;
  U4 u4SspProfileId;
  I1 i1SspDetectionSensitivity;
  CH achSspGeoMapFilename[128];
  U2 e2SspState;
  U2 u2VersionNumberMajor;
  U2 u2VersionNumberMinor;
  CH achPartNumber[32];
  U1 e1VpDataReceiverStatus;
  U1 e1VpProcessorStatus;
  U1 e1VpOverloadStatus;
  I4 i4VpCpuTempDegreesC;
  I4 i4VpGpuTempDegreesC;
  U1 e1VpTempStatus;
  U1 e1DpDataReceiverStatus;
  U1 e1DpProcessorStatus;
  U1 e1DpOverloadStatus;
  U1 e1PexProcessorStatus;
  U1 e1PexOverloadStatus;
  I4 i4DpCpuTempDegreesC;
  I4 i4DpGpuTempDegreesC;
  U1 e1DpTempStatus;
  
} __attribute__ ((packed)) sSSPSTATUSREQRSP_PL;

typedef struct
{
  
  /* NO PAYLOAD */
  
} __attribute__ ((packed)) sSSPSETUPCMD_PL;

typedef struct
{
  
  /* NO PAYLOAD */
  
} __attribute__ ((packed)) sSSPSETUPCMDRSP_PL;

typedef struct
{
  
  /* NO PAYLOAD */
  
} __attribute__ ((packed)) sSSPENDOFSETUPCMD_PL;

typedef struct
{
  
  /* NO PAYLOAD */
  
} __attribute__ ((packed)) sSSPENDOFSETUPCMDRSP_PL;

typedef struct
{
  
  /* NO PAYLOAD */
  
} __attribute__ ((packed)) sSSPRESETCMD_PL;

typedef struct
{
  
  /* NO PAYLOAD */
  
} __attribute__ ((packed)) sSSPRESETCMDRSP_PL;

typedef struct
{
  
  /* NO PAYLOAD */
  
} __attribute__ ((packed)) sSSPSHUTDOWNCMD_PL;

typedef struct
{
  
  /* NO PAYLOAD */
  
} __attribute__ ((packed)) sSSPSHUTDOWNCMDRSP_PL;

typedef struct
{
  
  U4 u4ProfileId;
  
} __attribute__ ((packed)) sSSPSETACTIVEPROFILECMD_PL;

typedef struct
{
  
  U4 u4ProfileId;
  
} __attribute__ ((packed)) sSSPSETACTIVEPROFILECMDRSP_PL;

typedef struct
{
  
  /* NO PAYLOAD */
  
} __attribute__ ((packed)) sSSPINITCLUTTERMAPSCMD_PL;

typedef struct
{
  
  /* NO PAYLOAD */
  
} __attribute__ ((packed)) sSSPINITCLUTTERMAPSCMDRSP_PL;

typedef struct
{
  
  I1 i1DetectionSensitivity;
  
} __attribute__ ((packed)) sSSPSETSENSITIVITYCONTROLCMD_PL;

typedef struct
{
  
  I1 i1DetectionSensitivity;
  
} __attribute__ ((packed)) sSSPSETSENSITIVITYCONTROLCMDRSP_PL;

typedef struct
{
  
  U1 e1LatitudeDirection;
  F8 f8LatitudeDecDeg;
  U1 e1LongitudeDirection;
  F8 f8LongitudeDecDeg;
  U2 u2HeightMeters;
  
} __attribute__ ((packed)) sSSPSETDEPLOYMENTPOSITIONCMD_PL;

typedef struct
{
  
  U1 e1LatitudeDirection;
  F8 f8LatitudeDecDeg;
  U1 e1LongitudeDirection;
  F8 f8LongitudeDecDeg;
  U2 u2HeightMeters;
  
} __attribute__ ((packed)) sSSPSETDEPLOYMENTPOSITIONCMDRSP_PL;

typedef struct
{
  
  CH achGeoMapFilename[128];
  U1 e1Severity;
  CH achStatusMessage[128];
  
} __attribute__ ((packed)) sSSPLOADGEOMAPCMD_PL;

typedef struct
{
  
  CH achGeoMapFilename[128];
  U1 e1Severity;
  CH achStatusMessage[128];
  
} __attribute__ ((packed)) sSSPLOADGEOMAPCMDRSP_PL;



/* START FULL MESSAGE STRUCTS */


typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  /**************/
  /* NO PAYLOAD */
  /**************/
  
} __attribute__ ((packed)) sSSPSTATUSREQ;

typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  U1 e1SspStatus;
  U1 e1SspDataStatus;
  U1 e1SspProcessorStatus;
  U1 e1SspOverloadStatus;
  I4 i4SspCpuTempDegreesC;
  I4 i4SspGpuTempDegreesC;
  U1 e1SspTempStatus;
  U4 u4SspProfileId;
  I1 i1SspDetectionSensitivity;
  CH achSspGeoMapFilename[128];
  U2 e2SspState;
  U2 u2VersionNumberMajor;
  U2 u2VersionNumberMinor;
  CH achPartNumber[32];
  U1 e1VpDataReceiverStatus;
  U1 e1VpProcessorStatus;
  U1 e1VpOverloadStatus;
  I4 i4VpCpuTempDegreesC;
  I4 i4VpGpuTempDegreesC;
  U1 e1VpTempStatus;
  U1 e1DpDataReceiverStatus;
  U1 e1DpProcessorStatus;
  U1 e1DpOverloadStatus;
  U1 e1PexProcessorStatus;
  U1 e1PexOverloadStatus;
  I4 i4DpCpuTempDegreesC;
  I4 i4DpGpuTempDegreesC;
  U1 e1DpTempStatus;
  
} __attribute__ ((packed)) sSSPSTATUSREQRSP;

typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  /**************/
  /* NO PAYLOAD */
  /**************/
  
} __attribute__ ((packed)) sSSPSETUPCMD;

typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  /**************/
  /* NO PAYLOAD */
  /**************/
  
} __attribute__ ((packed)) sSSPSETUPCMDRSP;

typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  /**************/
  /* NO PAYLOAD */
  /**************/
  
} __attribute__ ((packed)) sSSPENDOFSETUPCMD;

typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  /**************/
  /* NO PAYLOAD */
  /**************/
  
} __attribute__ ((packed)) sSSPENDOFSETUPCMDRSP;

typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  /**************/
  /* NO PAYLOAD */
  /**************/
  
} __attribute__ ((packed)) sSSPRESETCMD;

typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  /**************/
  /* NO PAYLOAD */
  /**************/
  
} __attribute__ ((packed)) sSSPRESETCMDRSP;

typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  /**************/
  /* NO PAYLOAD */
  /**************/
  
} __attribute__ ((packed)) sSSPSHUTDOWNCMD;

typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  /**************/
  /* NO PAYLOAD */
  /**************/
  
} __attribute__ ((packed)) sSSPSHUTDOWNCMDRSP;

typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  U4 u4ProfileId;
  
} __attribute__ ((packed)) sSSPSETACTIVEPROFILECMD;

typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  U4 u4ProfileId;
  
} __attribute__ ((packed)) sSSPSETACTIVEPROFILECMDRSP;

typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  /**************/
  /* NO PAYLOAD */
  /**************/
  
} __attribute__ ((packed)) sSSPINITCLUTTERMAPSCMD;

typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  /**************/
  /* NO PAYLOAD */
  /**************/
  
} __attribute__ ((packed)) sSSPINITCLUTTERMAPSCMDRSP;

typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  I1 i1DetectionSensitivity;
  
} __attribute__ ((packed)) sSSPSETSENSITIVITYCONTROLCMD;

typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  I1 i1DetectionSensitivity;
  
} __attribute__ ((packed)) sSSPSETSENSITIVITYCONTROLCMDRSP;

typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  U1 e1LatitudeDirection;
  F8 f8LatitudeDecDeg;
  U1 e1LongitudeDirection;
  F8 f8LongitudeDecDeg;
  U2 u2HeightMeters;
  
} __attribute__ ((packed)) sSSPSETDEPLOYMENTPOSITIONCMD;

typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  U1 e1LatitudeDirection;
  F8 f8LatitudeDecDeg;
  U1 e1LongitudeDirection;
  F8 f8LongitudeDecDeg;
  U2 u2HeightMeters;
  
} __attribute__ ((packed)) sSSPSETDEPLOYMENTPOSITIONCMDRSP;

typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  CH achGeoMapFilename[128];
  U1 e1Severity;
  CH achStatusMessage[128];
  
} __attribute__ ((packed)) sSSPLOADGEOMAPCMD;

typedef struct
{
  
  sMESSAGE_HEADER sMsgHeader;

  /* PAYLOAD START */
  CH achGeoMapFilename[128];
  U1 e1Severity;
  CH achStatusMessage[128];
  
} __attribute__ ((packed)) sSSPLOADGEOMAPCMDRSP;




//************************************************************************
//Demux function prototype
//************************************************************************
I4 i4Demux_RMS_SSP_MSG(U4* pu4MsgLen, U1* pu1Msg);


//************************************************************************
//Validation function prototypes
//************************************************************************
I4 i4Validation_SspStatusReq(U4* pu4MsgLen, sSSPSTATUSREQ_PL* psMsg);
I4 i4Validation_SspSetupCmd(U4* pu4MsgLen, sSSPSETUPCMD_PL* psMsg);
I4 i4Validation_SspEndOfSetupCmd(U4* pu4MsgLen, sSSPENDOFSETUPCMD_PL* psMsg);
I4 i4Validation_SspResetCmd(U4* pu4MsgLen, sSSPRESETCMD_PL* psMsg);
I4 i4Validation_SspShutdownCmd(U4* pu4MsgLen, sSSPSHUTDOWNCMD_PL* psMsg);
I4 i4Validation_SspSetActiveProfileCmd(U4* pu4MsgLen, sSSPSETACTIVEPROFILECMD_PL* psMsg);
I4 i4Validation_SspInitClutterMapsCmd(U4* pu4MsgLen, sSSPINITCLUTTERMAPSCMD_PL* psMsg);
I4 i4Validation_SspSetSensitivityControlCmd(U4* pu4MsgLen, sSSPSETSENSITIVITYCONTROLCMD_PL* psMsg);
I4 i4Validation_SspSetDeploymentPositionCmd(U4* pu4MsgLen, sSSPSETDEPLOYMENTPOSITIONCMD_PL* psMsg);
I4 i4Validation_SspLoadGeoMapCmd(U4* pu4MsgLen, sSSPLOADGEOMAPCMD_PL* psMsg);


//************************************************************************
//Processing function prototypes
//************************************************************************
I4 i4Process_SspStatusReq(U4* pu4MsgLen, sSSPSTATUSREQ_PL* psMsg);
I4 i4Process_SspSetupCmd(U4* pu4MsgLen, sSSPSETUPCMD_PL* psMsg);
I4 i4Process_SspEndOfSetupCmd(U4* pu4MsgLen, sSSPENDOFSETUPCMD_PL* psMsg);
I4 i4Process_SspResetCmd(U4* pu4MsgLen, sSSPRESETCMD_PL* psMsg);
I4 i4Process_SspShutdownCmd(U4* pu4MsgLen, sSSPSHUTDOWNCMD_PL* psMsg);
I4 i4Process_SspSetActiveProfileCmd(U4* pu4MsgLen, sSSPSETACTIVEPROFILECMD_PL* psMsg);
I4 i4Process_SspInitClutterMapsCmd(U4* pu4MsgLen, sSSPINITCLUTTERMAPSCMD_PL* psMsg);
I4 i4Process_SspSetSensitivityControlCmd(U4* pu4MsgLen, sSSPSETSENSITIVITYCONTROLCMD_PL* psMsg);
I4 i4Process_SspSetDeploymentPositionCmd(U4* pu4MsgLen, sSSPSETDEPLOYMENTPOSITIONCMD_PL* psMsg);
I4 i4Process_SspLoadGeoMapCmd(U4* pu4MsgLen, sSSPLOADGEOMAPCMD_PL* psMsg);

#endif

/* END OF FILE */