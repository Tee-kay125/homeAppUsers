""" This module provides a class which provides Matlab code generation

"""
import logging
from Autogen_Toolbox.autogen_toolbox_definition_validation_and_et_finding import E_FIELD_OR_RECORD_TYPE
from Autogen_Toolbox.autogen_toolbox_definition_validation_and_et_finding import E_TYPEDEF_XML_FILE_TYPEDEF_TYPE

# This dictionary's key is a tuple
# The tuple's fields are:
#  * The base type (str)
#  * Does the the field have count greater than 1 (bool)
G_dctTypeToMatlabFieldPrefix = {}
G_dctTypeToMatlabFieldPrefix[("U1", False)] = str("u1")
G_dctTypeToMatlabFieldPrefix[("U2", False)] = str("u2")
G_dctTypeToMatlabFieldPrefix[("U4", False)] = str("u4")
G_dctTypeToMatlabFieldPrefix[("U8", False)] = str("u8")
G_dctTypeToMatlabFieldPrefix[("I1", False)] = str("i1")
G_dctTypeToMatlabFieldPrefix[("I2", False)] = str("i2")
G_dctTypeToMatlabFieldPrefix[("I4", False)] = str("i4")
G_dctTypeToMatlabFieldPrefix[("I8", False)] = str("i8")
G_dctTypeToMatlabFieldPrefix[("F4", False)] = str("f4")
G_dctTypeToMatlabFieldPrefix[("F8", False)] = str("f8")
G_dctTypeToMatlabFieldPrefix[("CH", False)] = str("ach")
G_dctTypeToMatlabFieldPrefix[("U1", True)] = str("au1")
G_dctTypeToMatlabFieldPrefix[("U2", True)] = str("au2")
G_dctTypeToMatlabFieldPrefix[("U4", True)] = str("au4")
G_dctTypeToMatlabFieldPrefix[("U8", True)] = str("au8")
G_dctTypeToMatlabFieldPrefix[("I1", True)] = str("ai1")
G_dctTypeToMatlabFieldPrefix[("I2", True)] = str("ai2")
G_dctTypeToMatlabFieldPrefix[("I4", True)] = str("ai4")
G_dctTypeToMatlabFieldPrefix[("I8", True)] = str("ai8")
G_dctTypeToMatlabFieldPrefix[("F4", True)] = str("af4")
G_dctTypeToMatlabFieldPrefix[("F8", True)] = str("af8")
G_dctTypeToMatlabFieldPrefix[("CH", True)] = str("ch")
G_dctTypeToMatlabFieldPrefix[("STRUCT", True)] = str("")
G_dctTypeToMatlabFieldPrefix[("STRUCT", False)] = str("")
G_dctTypeToMatlabFieldPrefix[("E1", True)] = str("ae")
G_dctTypeToMatlabFieldPrefix[("E2", True)] = str("ae")
G_dctTypeToMatlabFieldPrefix[("E4", True)] = str("ae")
G_dctTypeToMatlabFieldPrefix[("E8", True)] = str("e")
G_dctTypeToMatlabFieldPrefix[("E1", False)] = str("e")
G_dctTypeToMatlabFieldPrefix[("E2", False)] = str("e")
G_dctTypeToMatlabFieldPrefix[("E4", False)] = str("e")
G_dctTypeToMatlabFieldPrefix[("E8", False)] = str("e")

G_dctTypeToMatlabPrimitiveType = {}
G_dctTypeToMatlabPrimitiveType["CH"] = "uint8"
G_dctTypeToMatlabPrimitiveType["U1"] = "uint8"
G_dctTypeToMatlabPrimitiveType["U2"] = "uint16"
G_dctTypeToMatlabPrimitiveType["U4"] = "uint32"
G_dctTypeToMatlabPrimitiveType["U8"] = "uint64"
G_dctTypeToMatlabPrimitiveType["I1"] = "int8"
G_dctTypeToMatlabPrimitiveType["I2"] = "int16"
G_dctTypeToMatlabPrimitiveType["I4"] = "int32"
G_dctTypeToMatlabPrimitiveType["I8"] = "int64"
G_dctTypeToMatlabPrimitiveType["F4"] = "float"
G_dctTypeToMatlabPrimitiveType["F8"] = "double"

G_dctEnumTypeToBaseType = {}
G_dctEnumTypeToBaseType["E1"] = "U1"
G_dctEnumTypeToBaseType["E2"] = "U2"
G_dctEnumTypeToBaseType["E4"] = "U4"
G_dctEnumTypeToBaseType["E8"] = "U8"

G_dctBaseTypesToSizeInBytes = {}
G_dctBaseTypesToSizeInBytes["CH"] = int(1)
G_dctBaseTypesToSizeInBytes["U1"] = int(1)
G_dctBaseTypesToSizeInBytes["U2"] = int(2)
G_dctBaseTypesToSizeInBytes["U4"] = int(4)
G_dctBaseTypesToSizeInBytes["U8"] = int(8)
G_dctBaseTypesToSizeInBytes["I1"] = int(1)
G_dctBaseTypesToSizeInBytes["I2"] = int(2)
G_dctBaseTypesToSizeInBytes["I4"] = int(4)
G_dctBaseTypesToSizeInBytes["I8"] = int(8)
G_dctBaseTypesToSizeInBytes["F4"] = int(4)
G_dctBaseTypesToSizeInBytes["F8"] = int(4)


class clsAutogenToolboxCodeGenerationMatlab():
    """ This class provides a class which provides Matlab code generation


    """

    @staticmethod
    def lstGenerateMessageFields(dctMessageHeaderPar: dict, dctMessagePayloadPar: dict):
        """ This is a public static method which generates Matlab message fields

        Args:
            dctMessageHeaderPar (dict): A dictionary containing header info
            dctMessagePayloadPar (dict): A dictionary containg payload info

        Returns:
            (list): A list of fields as dictionary items. The keys are:
                * "acName" (str)
                * "acPrefix" (str)
                * "acTypeNotAsDoubles" (str)
                * "acTypeAsDoubles" (str)

        Raises:
            Raises no exception.
        """
        lstReturn = []
        bCountGreaterThanOne = bool(False)
        acFieldPrefix = str("")
        acFieldType = str("")
        acFieldCount = str("")
        acMatlabTypeCodeNotAsDoubles = str("")
        acMatlabTypeCodeAsDoubles = str("")
        acEnumType = str("")
        acEnumBaseType = str("")
        acEnumMatlabPrimitiveType = str("")

        # Dictionarie with these keys will be appended into lstReturn
        dctFieldItem = {}
        dctFieldItem["acName"] = str("")
        dctFieldItem["acPrefix"] = str("")
        dctFieldItem["acTypeNotAsDoubles"] = str("")
        dctFieldItem["acTypeAsDoubles"] = str("")

        if (dctMessageHeaderPar is None):
            logging.error("dctMessageHeaderPar cannot be None")
            return(lstReturn)

        if (dctMessagePayloadPar is None):
            logging.error("dctMessagePayloadPar cannot be None")
            return(lstReturn)

        for dctField in dctMessagePayloadPar["lstFieldElements"]:

            # Initialise a dict item
            dctFieldItem = {}
            dctFieldItem["acName"] = str("")
            dctFieldItem["acPrefix"] = str("")
            dctFieldItem["acTypeNotAsDoubles"] = str("")
            dctFieldItem["acTypeAsDoubles"] = str("")

            # Initialise all the required variables
            acFieldPrefix = str("")
            tplTypeLookupTupleKey = (None, None)
            acFieldType = str("")
            acMatlabTypeCodeNotAsDoubles = str("")
            acMatlabTypeCodeAsDoubles = str("")
            acFieldCount = str("")
            acEnumType = str("")
            acEnumBaseType = str("")
            acEnumMatlabPrimitiveType = str("")

            # Determine if the count is greater than 1
            bCountGreaterThanOne = dctField.attrib["Count"] != "1"
            acFieldCount = dctField.attrib["Count"]

            if (dctField.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_BASE)):
                acFieldType = dctField.attrib["Type"]

                tplTypeLookupTupleKey = (acFieldType, bCountGreaterThanOne)
                acMatlabTypeCodeNotAsDoubles = "zeros(%s, 1, '%s')" % (acFieldCount, G_dctTypeToMatlabPrimitiveType[acFieldType])
                acMatlabTypeCodeAsDoubles = "zeros(%s, 1, 'double')" % (acFieldCount)

            elif (dctField.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_ENUM)):
                if (len(dctField.attrib["Type"]) >= 2):
                    acEnumType = dctField.attrib["Type"][:2]
                    acEnumBaseType = G_dctEnumTypeToBaseType[acEnumType]
                    acEnumMatlabPrimitiveType = G_dctTypeToMatlabPrimitiveType[acEnumBaseType]

                    tplTypeLookupTupleKey = (acEnumType, bCountGreaterThanOne)
                    acMatlabTypeCodeNotAsDoubles = "zeros(%s, 1, '%s')" % (acFieldCount, acEnumMatlabPrimitiveType)
                    acMatlabTypeCodeAsDoubles = "zeros(%s, 1, 'double')" % (acFieldCount)

                else:
                    logging.error("The Type attribute of field %s is not valid", dctField.attrib["Name"])

            elif (dctField.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_STRUCT)):
                tplTypeLookupTupleKey = ("STRUCT", bCountGreaterThanOne)

                if (bCountGreaterThanOne is False):
                    acMatlabTypeCodeNotAsDoubles = dctField.attrib["Type"]
                    acMatlabTypeCodeAsDoubles = dctField.attrib["Type"]
                else:
                    acMatlabTypeCodeNotAsDoubles = "zeros(%s, 1, '%s')" % (acFieldCount, dctField.attrib["Type"])
                    acMatlabTypeCodeAsDoubles = "zeros(%s, 1, '%s')" % (acFieldCount, dctField.attrib["Type"])

            if (tplTypeLookupTupleKey in G_dctTypeToMatlabFieldPrefix):
                acFieldPrefix = G_dctTypeToMatlabFieldPrefix[tplTypeLookupTupleKey]
            else:
                logging.error("Could not lookup prefix %s", (str(tplTypeLookupTupleKey)))
                acFieldPrefix = "error_prefix_unknown"

            dctFieldItem["acName"] = dctField.attrib["Name"]
            dctFieldItem["acPrefix"] = acFieldPrefix
            dctFieldItem["acTypeNotAsDoubles"] = acMatlabTypeCodeNotAsDoubles
            dctFieldItem["acTypeAsDoubles"] = acMatlabTypeCodeAsDoubles

            lstReturn.append(dctFieldItem)

        return(lstReturn)

    @staticmethod
    def lstGenerateTypedefs(dctMsgDefXmlFilePar: dict):
        """ This is a public static method which generates Matlab code for Typedefs

        Args:
            dctMsgDefXmlFilePar (dict): A dictionary containing MsgDef file info. Important keys are:
                * dctAllTypesElementsForThisFileIncludingIncludes (dict)

        Returns:
            (list): A list of Typedefs

        Raises:
            Raises no exception.
        """
        lstReturn = []
        dctMsgDefXmlFile = None  # Keep a local copy of a dict key value
        lstAllStructTypedefs = []
        objTypedefElement = None
        lstRecordElements = []

        acMatlabTypeCodeNotAsDoubles = str("")
        acMatlabTypeCodeAsDoubles = str("")
        acFieldPrefix = str("")
        bCountGreaterThanOne = bool(False)
        acFieldCount = str("")

        dctTypedefItem = {}
        dctTypedefItem["acName"] = str("")
        dctTypedefItem["lstRecords"] = []

        # Do some sanity checks

        if (dctMsgDefXmlFilePar is None):
            logging.error("dctMsgDefXmlFilePar cannot be None")
            return(lstReturn)

        if ("dctAllTypesElementsForThisFileIncludingIncludes" not in dctMsgDefXmlFilePar):
            logging.error("Dict key dctAllTypesElementsForThisFileIncludingIncludes does not exist")
            return(lstReturn)

        dctMsgDefXmlFile = dctMsgDefXmlFilePar["dctAllTypesElementsForThisFileIncludingIncludes"]

        # Filter out only the Typedef Structs - leave out the Enum Typedefs
        lstAllStructTypedefs = [dctTypedefItem for dctTypedefItem in dctMsgDefXmlFile.items() if dctTypedefItem[1]["eTypedefType"] == E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_STRUCT)]

        # Iterate through all the Struct Typedefs
        for tplTypedefItem in lstAllStructTypedefs:

            # Initialise the Typedef item
            dctTypedefItem = {}
            dctTypedefItem["acName"] = tplTypedefItem[0]
            dctTypedefItem["lstRecords"] = []

            objTypedefElement = tplTypedefItem[1]["objElement"]

            # Get all the Record Elements
            lstRecordElements = objTypedefElement.findall("./Record")

            # Iterate through all the Records
            for objRecordElement in lstRecordElements:

                # Initialise the Record item
                dctRecordItem = {}
                dctRecordItem["acName"] = str("")
                dctRecordItem["acPrefix"] = str("")
                dctRecordItem["acTypeNotAsDoubles"] = str("")
                dctRecordItem["acTypeAsDoubles"] = str("")

                acEnumType = str("")
                acMatlabTypeCodeNotAsDoubles = str("")
                acMatlabTypeCodeAsDoubles = str("")
                acFieldType = str("")
                tplTypeLookupTupleKey = (None, None)

                # Determine if the count is greater than 1
                bCountGreaterThanOne = objRecordElement.attrib["Count"] != "1"
                acFieldCount = objRecordElement.attrib["Count"]

                if (objRecordElement.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_BASE)):
                    acFieldType = objRecordElement.attrib["Type"]

                    tplTypeLookupTupleKey = (acFieldType, bCountGreaterThanOne)
                    acMatlabTypeCodeNotAsDoubles = "zeros(%s, 1, '%s')" % (acFieldCount, G_dctTypeToMatlabPrimitiveType[acFieldType])
                    acMatlabTypeCodeAsDoubles = "zeros(%s, 1, 'double')" % (acFieldCount)

                elif (objRecordElement.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_ENUM)):
                    if (len(objRecordElement.attrib["Type"]) >= 2):
                        acEnumType = objRecordElement.attrib["Type"][:2]
                        acEnumBaseType = G_dctEnumTypeToBaseType[acEnumType]
                        acEnumMatlabPrimitiveType = G_dctTypeToMatlabPrimitiveType[acEnumBaseType]

                        tplTypeLookupTupleKey = (acEnumType, bCountGreaterThanOne)
                        acMatlabTypeCodeNotAsDoubles = "zeros(%s, 1, '%s')" % (acFieldCount, acEnumMatlabPrimitiveType)
                        acMatlabTypeCodeAsDoubles = "zeros(%s, 1, 'double')" % (acFieldCount)

                    else:
                        logging.error("The Type attribute of field %s is not valid", objRecordElement.attrib["Name"])

                elif (objRecordElement.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_STRUCT)):
                    tplTypeLookupTupleKey = ("STRUCT", bCountGreaterThanOne)

                    if (bCountGreaterThanOne is False):
                        acMatlabTypeCodeNotAsDoubles = objRecordElement.attrib["Type"]
                        acMatlabTypeCodeAsDoubles = objRecordElement.attrib["Type"]
                    else:
                        acMatlabTypeCodeNotAsDoubles = "zeros(%s, 1, '%s')" % (acFieldCount, objRecordElement.attrib["Type"])
                        acMatlabTypeCodeAsDoubles = "zeros(%s, 1, '%s')" % (acFieldCount, objRecordElement.attrib["Type"])

                if (tplTypeLookupTupleKey in G_dctTypeToMatlabFieldPrefix):
                    acFieldPrefix = G_dctTypeToMatlabFieldPrefix[tplTypeLookupTupleKey]
                else:
                    logging.error("Could not lookup prefix %s", (str(tplTypeLookupTupleKey)))
                    acFieldPrefix = "error_prefix_unknown"

                dctRecordItem["acName"] = objRecordElement.attrib["Name"]
                dctRecordItem["acPrefix"] = acFieldPrefix
                dctRecordItem["acTypeNotAsDoubles"] = acMatlabTypeCodeNotAsDoubles
                dctRecordItem["acTypeAsDoubles"] = acMatlabTypeCodeAsDoubles

                # Append to the list of Record
                dctTypedefItem["lstRecords"].append(dctRecordItem)

            # Append to the list of Typedef
            lstReturn.append(dctTypedefItem)

        return(lstReturn)
