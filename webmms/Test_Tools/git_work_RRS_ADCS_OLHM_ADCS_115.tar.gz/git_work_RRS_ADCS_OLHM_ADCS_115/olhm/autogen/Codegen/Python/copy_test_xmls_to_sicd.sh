#!/bin/bash

cp -f Output/Cpp/TEST_Common_Types.xml ../../sicd
cp -f Output/Cpp/TEST_Msg.xml ../../sicd