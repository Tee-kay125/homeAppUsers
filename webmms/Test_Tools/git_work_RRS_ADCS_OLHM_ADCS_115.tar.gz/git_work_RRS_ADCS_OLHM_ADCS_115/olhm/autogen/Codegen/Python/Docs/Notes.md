
# Things required inside a C++ .h files

* Comment block
* precompiler conditional
* includes (base includes RRS types + CCS types)
* hash define num of topics
* hash define topics
* common includes
