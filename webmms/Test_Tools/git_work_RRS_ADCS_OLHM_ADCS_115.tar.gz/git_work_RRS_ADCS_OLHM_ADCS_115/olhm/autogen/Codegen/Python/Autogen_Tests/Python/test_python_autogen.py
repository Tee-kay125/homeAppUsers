#!/usr/bin/env python3.6
# -*- coding: utf-8 -*-
""" This module tests the Python autogen

"""
from test_msg import *
from module_interface_config_olhm import clsMODULE_INTERFACE_CONFIG_OLHM
from mqtt_client_on_connect_olhm import *

def vMain():
    """ This is a public function which is the main function for the module

    Args:
    
    Returns:
    
    Raises:
        Raises no exception.
    """
    objA = sTEST_STRUCTURE_01()
    iSizeBytes = objA.iSizeBytes()

    objsTEST_ADCS_STATUS_UNSOL_PL = sTEST_ADCS_STATUS_UNSOL_PL()
    bValid = objsTEST_ADCS_STATUS_UNSOL_PL.bValidate()

    objsTEST_ADCS_STATUS_UNSOL = sTEST_ADCS_STATUS_UNSOL()
    bValid = objsTEST_ADCS_STATUS_UNSOL.bValidate()

    lstA = clsMODULE_INTERFACE_CONFIG_OLHM.lstModInterConfTopicInfo

    for dctTopicItem in lstA:
        print(dctTopicItem)

    return

if __name__ == "__main__":
    vMain()