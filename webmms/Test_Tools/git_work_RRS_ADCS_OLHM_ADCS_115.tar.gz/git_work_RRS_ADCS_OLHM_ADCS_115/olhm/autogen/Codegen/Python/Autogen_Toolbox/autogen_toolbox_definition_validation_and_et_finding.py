#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
""" This module provides a class which provides definition validation related functionality

See document 5850-BS-0000V01.00-001 DR (ADCS DATA MODEL XML DEFINITION DESIGN DESCRIPTION) for
exact details on rules

"""
import logging  # We need this to log to a logger file
import os  # We need this do path and file related things
import re  # We need this to split strings into token
import xml.etree.ElementTree as ET  # We need this to parse XML files
from enum import Enum  # We need this to make enums in Python

# from autogen_toolbox_elementtree_parsing import clsAutogenToolboxElementTreeParsing

# These are the approved base types used by the ADCS schema
G_lstAdcsBaseTypes = ["F4", "F8", "U1", "U2", "U4", "U8", "I1", "I2", "I4", "I8", "CH"]
G_dctBaseTypesDefaultValues = {}
G_dctBaseTypesDefaultValues["F4"] = str("0.0")
G_dctBaseTypesDefaultValues["F8"] = str("0.0")
G_dctBaseTypesDefaultValues["U1"] = str("0")
G_dctBaseTypesDefaultValues["U2"] = str("0")
G_dctBaseTypesDefaultValues["U4"] = str("0")
G_dctBaseTypesDefaultValues["U8"] = str("0")
G_dctBaseTypesDefaultValues["I1"] = str("0")
G_dctBaseTypesDefaultValues["I2"] = str("0")
G_dctBaseTypesDefaultValues["I4"] = str("0")
G_dctBaseTypesDefaultValues["I8"] = str("0")
G_dctBaseTypesDefaultValues["CH"] = str("")


class E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(Enum):
    """ This is enum which denotes all the types of Typedefs a Typedef XML can have.

    """
    TYPEDEF_XML_FILE_TYPEDEF_TYPE_ENUM = 1
    TYPEDEF_XML_FILE_TYPEDEF_TYPE_STRUCT = 2


class E_NUMERIC_VALUE_TYPE(Enum):
    """ This is enum which denotes all the types of numeric values of a string

    """
    NUMERIC_VALUE_TYPE_INVALID = 1  # Indicates value is invalid - not a value
    NUMERIC_VALUE_TYPE_INTEGER = 2  # Indicates value is an integer (not hex)
    NUMERIC_VALUE_TYPE_FLOAT = 3  # Indicates value is a float
    NUMERIC_VALUE_TYPE_HEX_INTEGER = 4  # Indicates value in hex


class E_FIELD_OR_RECORD_TYPE(Enum):
    """ This is enum which denotes all the types a Record or Field could have

    """
    FIELD_OR_RECORD_IS_BASE = 1  # Indicates a base type
    FIELD_OR_RECORD_IS_ENUM = 2  # Indicates an enum
    FIELD_OR_RECORD_IS_STRUCT = 3  # Indicates a struct


class E_MESSAGE_FLOW_DIRECTION(Enum):
    """ This is enum which denotes the message flow direction

    """
    MESSAGE_FLOW_DIRECTION_PUBLISH = 1
    MESSAGE_FLOW_DIRECTION_SUBSCRIBE = 2


class E_COMMS_PROTOCOL(Enum):
    """ This is enum which denotes the supported comms protocols

    """
    COMMS_PROTOCOL_MQTT = 1
    COMMS_PROTOCOL_ZMQ = 2


class clsAutogenToolboxDefinitionValidationAndETFinding():
    """ This class provides a class which provides definition validation related functionality


    """

    # ===============================================================================
    # Methods for Typdef XML (not MsgDef) files
    # ===============================================================================

    @staticmethod
    def bValidateTypedefFileUsingElementTreeRootElement(objTypedefFileRootElementPar: ET.Element):
        """ This is a public static method which validate a Typedef file from a ElementTree root Element

        Args:
            objTypedefFileRootElementPar (ET.Element): The root ElementTree Element

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        bReturnForLoop = bool(False)
        lstTypedefElements = []
        tplTypedefType = (bool(False), E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_ENUM))
        sttTypedefNames = {}  # We use this to make sure Typedefs are uniquely defined
        lstTypedefNames = []  # We use this to make sure Typedefs are uniquely defined
        dctTypedefNames = {}  # We use this to make sure Typedefs are uniquely defined
        objTypedefElement = None

        if (not objTypedefFileRootElementPar):
            logging.error("objTypedefFileRootElementPar is invalid")
            return(bReturn)

        if (isinstance(objTypedefFileRootElementPar, ET.Element) is False):
            logging.error("objTypedefFileRootElementPar is not and ET.Element")
            return(bReturn)

        # Get a list of all the Typdefs in this file only! This is a Typdef XML file
        lstTypedefElements = objTypedefFileRootElementPar.findall(".//Typedef")

        [lstTypedefNames.append(objTypedefElement.attrib["Name"]) for objTypedefElement in lstTypedefElements]  # pylint: disable=expression-not-assigned

        sttTypedefNames = set(lstTypedefNames)

        if (len(lstTypedefNames) != len(sttTypedefNames)):

            for acTypedefName in lstTypedefNames:
                if (acTypedefName in dctTypedefNames):
                    logging.error("Seems like Typedef name %s was defined twice or more in", acTypedefName)
                    return(bReturn)
                else:
                    dctTypedefNames[acTypedefName] = acTypedefName

            logging.error("Seems like a Typedef name was defined twice or more")
            return(bReturn)

        # If list is empty then there is nothing left to do
        if (not lstTypedefElements):
            # This just means this file does not have any Typedef tags
            bReturn = bool(True)
            return(bReturn)

        bReturn = bool(True)  # Assume perfect validation for now
        for objTypedefElement in lstTypedefElements:
            tplTypedefType = clsAutogenToolboxDefinitionValidationAndETFinding.tplClassifyTypedefFileTypedefElementAsEnumOrStruct(objTypedefElement)

            if (tplTypedefType[0] is False):
                bReturnForLoop = bool(False)
                logging.error("Typedef %s is invalid", str(objTypedefElement.attrib["Name"]))
            elif (tplTypedefType[1] == E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_ENUM)):
                bReturnForLoop = clsAutogenToolboxDefinitionValidationAndETFinding.bValidateTypedefOfTypeEnum(objTypedefElement)
            elif (tplTypedefType[1] == E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_STRUCT)):

                # Set the recursion level to 0 because we just started
                bReturnForLoop = clsAutogenToolboxDefinitionValidationAndETFinding.bValidateTypedefOfTypeStruct(objTypedefElement, bCheckApprovedListOfTypesPar=True, lstApprovedTypesElementStructAllowedToUsePar=lstTypedefElements, iRecursionLevel=int(0))

            if (bReturnForLoop is False):
                logging.error("Typedef %s file is invalid", objTypedefElement.attrib["Name"])
                bReturn = bool(False)

        return(bReturn)

    @staticmethod
    def tplClassifyTypedefFileTypedefElementAsEnumOrStruct(objTypedefElementPar):
        """ This is a public static method determines if a Typdef file typdef element is an enum or struct

        Args:
            objTypedefElementPar (ET.Element): A Typedef Element

        Returns:
            (E_TYPEDEF_XML_FILE_TYPEDEF_TYPE): Enum indicating if Typedef is an Enum or a Struct

        Raises:
            Raises no exception.
        """
        bSuccess = bool(False)
        eReturnValue = E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_ENUM)
        tplReturn = (bSuccess, eReturnValue)
        acTypeDefName = str("")

        lstEnumerationElements = []
        lstRecordElements = []

        if (objTypedefElementPar is None):
            logging.error("objTypedefElementPar is None")
            return(tplReturn)

        if (isinstance(objTypedefElementPar, ET.Element) is False):
            logging.error("objTypedefElementPar is not an ET.Element")
            return(tplReturn)

        if ("Name" not in objTypedefElementPar.attrib):
            logging.error("Could not get Name from Element attrib")
            return(tplReturn)

        acTypeDefName = objTypedefElementPar.attrib["Name"]

        if (objTypedefElementPar.tag != "Typedef"):
            logging.error("This Element with name %s is not a Typedef Element", acTypeDefName)

        lstRecordElements = objTypedefElementPar.findall("./Record")

        if (not lstRecordElements):
            logging.error("Typedef %s Element contains no Record tags which is invalid", str(objTypedefElementPar.attrib["Name"]))
            return(tplReturn)

        lstEnumerationElements = objTypedefElementPar.findall("./Record/Enumeration")

        # An enum will have only 1 Record and then Enumeration
        # A struct will have at least 1 Record and no Enumeration
        if ((len(lstRecordElements) == 1) and (lstEnumerationElements)):
            bSuccess = bool(True)
            eReturnValue = E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_ENUM)
        elif ((len(lstRecordElements) >= 1) and (not lstEnumerationElements)):
            bSuccess = bool(True)
            eReturnValue = E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_STRUCT)
        else:
            bSuccess = bool(False)
            logging.error("Typedef Element %s is invalid", str(objTypedefElementPar.attrib["Name"]))

        tplReturn = (bSuccess, eReturnValue)
        return(tplReturn)

    # ===============================================================================
    # Recursive methods (used most only on MsgDef XML files and not Typedef XML files!)
    # ===============================================================================

    @staticmethod
    def bValidateFieldOrRecordElementRecursively(objElementPar: ET.Element, dctDatabaseOfAllTypedefs: dict, iRecursionLevel: int):
        """ This is a public static which validates a Field or Record Element

        Note! The first time we enter this method the dctDatabaseOfAllTypedefs dict
        must have all the Enums and Structs that are in the XML files in question. That
        means the Typdef XML files and the MsgDef XML file in question

        Note! This method will if the type of this Field or Recors is a struct or enum
        proceed and also validate those types. This will happen recursively.

        Args:
            objElementPar (ET.Element): The Field or Record Element
            dctDatabaseOfAllTypedefs (dict): The keys are:
                * {str (Name of typedef): dctTypeDef}
                    * dctTypeDef keys are:
                        * ["acName"] (str) -> The name of the typedef
                        * ["acXmlFileName"] (str) -> The filename - no path, just the filename
                        * ["acXmlFilePath"] (str) -> The full path to XML where this typedef is defined
                        * ["eTypedefType"] (str) -> The type of typedef
                        * ["objElement"] (str) -> The Element object
            iRecursionLevel (int): An int indicating how far down we are in the recursion of the validating.

        Returns:
            (bool): Flag indicating if validation passed

        Raises:
            Raises no exception.

        """
        bReturn = bool(False)
        acType = str("")
        acName = str("")
        dctTypedefDictItem = {}
        iCount = int(0)
        lstEnumerationElements = []
        objTypedefElement = None

        if (iRecursionLevel > 30):
            logging.error("The number of recursion calls are greater than what is deemed safe - recursion stopped")
            return(bReturn)

        # Check if None
        if (objElementPar is None):
            logging.error("objElementPar is None")
            return(bReturn)

        if (isinstance(objElementPar, ET.Element) is False):
            logging.error("objElementPar is not and ET.Element")
            return(bReturn)

        if (objElementPar.tag not in ["Field", "Record"]):
            logging.error("objElementPar is not a Field or a Record Element")
            return(bReturn)

        if ("Name" not in objElementPar.attrib):
            logging.error("Attribute Name is missing from Field")
            return(bReturn)

        acName = objElementPar.attrib["Name"]

        if ("Type" not in objElementPar.attrib):
            logging.error("Attribute Type is missing from Field %s", acName)
            return(bReturn)

        acType = objElementPar.attrib["Type"]

        # We add extra attributes later for autogen
        if ("Count" not in objElementPar.attrib):
            objElementPar.attrib["Count"] = str("1")

        # Check if Count is an int
        try:
            iCount = int(objElementPar.attrib["Count"])
        except:
            logging.error("The Count attribute %s does not seem to be an int", objElementPar.attrib["Count"])
            return(bReturn)

        if (iCount <= 0):
            logging.error("The Count attribute %s must be 1 or greater", objElementPar.attrib["Count"])
            return(bReturn)

        # All paths are covered by the conditionals below. The bReturn will have value when finished
        if (acType in G_lstAdcsBaseTypes):
            # Then it must be base type "F4", "U4" etc.
            bReturn = clsAutogenToolboxDefinitionValidationAndETFinding.bValidateBaseTypeFieldOrdRecord(objElementPar)
            # We add attribute to elements later for autogen
            objElementPar.attrib["eRecordType"] = E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_BASE)

        elif (acType in dctDatabaseOfAllTypedefs):
            # If we are in here then the type was found in the global list of Typedefs
            dctTypedefDictItem = dctDatabaseOfAllTypedefs[acType]

            # Now we need to see if this Field's type is an Enum or Struct
            if (dctTypedefDictItem["eTypedefType"] == E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_STRUCT)):
                # Do a non-recursive check of the Struct Field or Record
                bReturn = clsAutogenToolboxDefinitionValidationAndETFinding.bValidateStructTypeFieldOrdRecord(objElementPar)

                # If the basic check passed then do a recursive check
                if (bReturn is True):
                    # Increase the recursion level
                    bReturn = clsAutogenToolboxDefinitionValidationAndETFinding.bValidateTypdefStructRecursive(dctTypedefDictItem["objElement"], dctDatabaseOfAllTypedefs, iRecursionLevel + 1)
                else:
                    logging.error("Struct Field or Record %s is invalid", objElementPar.attrib["Name"])

                # We add attribute to elements later for autogen
                objElementPar.attrib["eRecordType"] = E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_STRUCT)
            elif (dctTypedefDictItem["eTypedefType"] == E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_ENUM)):
                # We don't pass in a recursion value because Enums do not need futher recursive checking
                # Also! We just call the Typdef type file Enum validate because it will also work for a MsgDef Enum Typedef
                # Do a basic Enum Typdef check
                bReturn = clsAutogenToolboxDefinitionValidationAndETFinding.bValidateTypedefOfTypeEnum(dctTypedefDictItem["objElement"])

                if (bReturn is True):
                    # Check if the Type in our list of available Types
                    if (acType not in dctDatabaseOfAllTypedefs):
                        logging.error("Enum Field or Record %s Type %s is unknown", objElementPar.attrib["Name"], acType)
                        bReturn = bool(False)
                    else:
                        # Now check if the Default attribute exists for that Enumeration
                        lstEnumerationElements = [objEnumerationElement for objEnumerationElement in dctDatabaseOfAllTypedefs[acType]["objElement"].findall("./Record/Enumeration") if objEnumerationElement.attrib["Name"] == objElementPar.attrib["Default"]]

                        if (not lstEnumerationElements):
                            logging.error("Enum Field or Record %s of Type %s seems to have a Default value %s which does not exist", objElementPar.attrib["Name"], acType, objElementPar.attrib["Default"])
                            bReturn = bool(False)
                        else:
                            bReturn = bool(True)

                            # Add extra atttributes to an Enum Record
                            objElementPar.attrib["lstAllEnumValuesAsInt"] = []
                            objElementPar.attrib["lstAllEnumValuesAsStr"] = []
                            objTypedefElement = dctDatabaseOfAllTypedefs[acType]["objElement"]

                            # Keep a list of all the values as int
                            [objElementPar.attrib["lstAllEnumValuesAsInt"].append(objEnumerationElement.attrib["Value"]) for objEnumerationElement in objTypedefElement.findall("./Record/Enumeration")]  # pylint: disable=expression-not-assigned
                            # Keep a list of all the values as str
                            [objElementPar.attrib["lstAllEnumValuesAsStr"].append(objEnumerationElement.attrib["Name"]) for objEnumerationElement in objTypedefElement.findall("./Record/Enumeration")]  # pylint: disable=expression-not-assigned

                # We add attribute to elements later for autogen
                objElementPar.attrib["eRecordType"] = E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_ENUM)

        else:
            logging.error("The type %s required by Field or Record %s does not exist", acType, acName)
            bReturn = bool(False)
            return(bReturn)

        return(bReturn)

    @staticmethod
    def bValidateTypdefStructRecursive(objElementPar: ET.Element, dctDatabaseOfAllTypedefs: dict, iRecursionLevel: int):
        """ This is a public static which takes a Struct typedef and validates. It does this
        recursively. If this struct contains Records which are of type struct then they will
        also be checked and validated.

        Note! The dctDatabaseOfAllTypedefs dict must have all the Enums and Structs
        that are in the XML files in question. That means the Typdef XML files and the
        MsgDef XML file in question.

        Args:
            objElementPar (ET.Element): The Field or Record Element
            dctDatabaseOfAllTypedefs (dict): The keys are:
                * {str (Name of typedef): dctTypeDef}
                    * dctTypeDef keys are:
                        * ["acName"] (str) -> The name of the typedef
                        * ["acXmlFileName"] (str) -> The filename - no path, just the filename
                        * ["acXmlFilePath"] (str) -> The full path to XML where this typedef is defined
                        * ["eTypedefType"] (str) -> The type of typedef
                        * ["objElement"] (str) -> The Element object
            iRecursionLevel (int): Recursion is only passed through!

        Returns:
            (bool): Flag to indicate if validation passed

        Raises:
            Raises no exception.

        """
        bReturn = bool(False)
        bReturnForLoop = bool(False)
        lstFieldOrRecordElements = []

        # Check if None
        if (objElementPar is None):
            logging.error("objElementPar is None")
            return(bReturn)

        if (isinstance(objElementPar, ET.Element) is False):
            logging.error("objElementPar is not and ET.Element")
            return(bReturn)

        if (objElementPar.tag != "Typedef"):
            logging.error("objElementPar is not a Typedef Element")
            return(bReturn)

        lstFieldOrRecordElements = objElementPar.findall("./Record")

        bReturn = bool(True)  # Assume perfectly validated for now
        for objRecordElement in lstFieldOrRecordElements:
            # When we call bValidateFieldOrRecordElementRecursively we increase the recursion level
            bReturnForLoop = clsAutogenToolboxDefinitionValidationAndETFinding.bValidateFieldOrRecordElementRecursively(objRecordElement, dctDatabaseOfAllTypedefs, iRecursionLevel + 1)

            # Once a validation fails in the loop the entire loop is considered invalid
            if (bReturnForLoop is False):
                logging.error("Record %s in invalid", objRecordElement.attrib["Name"])
                bReturn = bool(False)

        return(bReturn)

    @staticmethod
    def bValidateTypedefOfTypeStruct(objStructTypedefElementPar: ET.Element, bCheckApprovedListOfTypesPar: bool, lstApprovedTypesElementStructAllowedToUsePar: list, iRecursionLevel: int):
        """ This is a public static method which validates a struct Typedef Element.
        Note! The method assumes it is an struct Typedef
        Note! The method assumes the XML file passed the DTD schema

        Note! This is not a recursive method. It will not if it finds Record which are
        of Struct Typedef go an validate them as well. It will validate it in isolation only

        Args:
            objStructTypedefElementPar (ET.Element): The Typdef Element which is a struct.
            bCheckApprovedListOfTypesPar (bool): Flag indicatting if a Record is of a approved type
            lstApprovedTypesElementStructAllowedToUsePar (list): A list of Element which is approved. Will not be used if bCheckApprovedListOfTypesPar is False
            iRecursionLevel (int): This method can be called recursively so this keeps count of how many levels deep we are

        Returns:
            (bool): Flag to indicate if validation failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        bReturnForLoop = bool(False)
        acTypedefName = str("")  # The name of the struct Typedef
        lstRecordElement = []  # The list of Record Elements this struct will have
        lstEnumerationElement = []  # The list of Enumeration Elements this struct might have - if it does then we return
        tplRecordTypedefType = (False, E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_ENUM))  # Just Enum for now
        acRecordType = str("")  # The type of the Record(s) in this struct
        lstTypedefFoundInApprovedList = []
        lstTypdefEnumElements = []
        objEnumerationElement = None

        if (iRecursionLevel > 30):
            logging.error("iRecursionLevel is more than 30 which is more than is allowed")
            return(bReturn)

        if (objStructTypedefElementPar is None):
            logging.error("objStructTypedefElementPar is None")
            return(bReturn)

        if (isinstance(objStructTypedefElementPar, ET.Element) is False):
            logging.error("objStructTypedefElementPar is not an ET.Element")
            return(bReturn)

        # Check that the Name is there
        if ("Name" not in objStructTypedefElementPar.attrib):
            logging.error("Name not in enum Typedef")
            return(bReturn)

        if (not objStructTypedefElementPar.attrib["Name"]):
            logging.error("The Name of a Typedef is not allowed to be an empty string")
            return(bReturn)

        if (objStructTypedefElementPar.attrib["Name"][0] != "s"):
            logging.error("The Typedef name %s must start with a lower case s", objStructTypedefElementPar.attrib["Name"])
            return(bReturn)

        if (clsAutogenToolboxDefinitionValidationAndETFinding.bIsCasingStandardValidCapitalisedUnderscores(objStructTypedefElementPar.attrib["Name"][1:], bIgnoreUnderscores=True) is False):
            logging.error("The Typedef name %s must start with a lower case s and then be capitalised underscores", objStructTypedefElementPar.attrib["Name"])
            return(bReturn)

        acTypedefName = objStructTypedefElementPar.attrib["Name"]
        # Get the Record child tags of the Typedef
        lstRecordElement = objStructTypedefElementPar.findall("./Record")

        if (not lstRecordElement):
            logging.error("Struct %s does not have a Record child", acTypedefName)
            return(bReturn)

        lstEnumerationElement = objStructTypedefElementPar.findall("./Record/Enumeration")

        if (lstEnumerationElement):
            logging.error("Struct %s is not allowed to have any Enumeration tags under the Record tag", acTypedefName)
            return(bReturn)

        bReturn = bool(True)  # Assume perfect validation for now
        for objRecordElement in lstRecordElement:
            acRecordType = objRecordElement.attrib["Type"]

            if (acRecordType in G_lstAdcsBaseTypes):
                # Then this Record is a base type so validate it
                bReturnForLoop = clsAutogenToolboxDefinitionValidationAndETFinding.bValidateBaseTypeFieldOrdRecord(objRecordElement)

                if (bReturnForLoop is False):
                    logging.error("Struct %s is not valid", objStructTypedefElementPar.attrib["Name"])

                # We add extra attributes later for autogen
                objRecordElement.attrib["eRecordType"] = E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_BASE)

                # We add extra attributes later for autogen
                if ("Count" not in objRecordElement.attrib):
                    objRecordElement.attrib["Count"] = str("1")

            else:
                # If we are here then the Type of this Record is a Enum or Struct Typedef

                # Check if we need to verify that this Record type actually exists in this file - remember this
                # is Typedef file which means types must be defined inside this XML file to be valid
                if (bCheckApprovedListOfTypesPar is True):
                    # Use list comprehension to find the Type of this Record in a list of approved (exists in this file)
                    lstTypedefFoundInApprovedList = [objTypedefElement for objTypedefElement in lstApprovedTypesElementStructAllowedToUsePar if objTypedefElement.attrib["Name"] == acRecordType]

                    # After the list comprehension see if the list is empty or not - if it is empty then the Record type does not exist
                    if (not lstTypedefFoundInApprovedList):
                        logging.error("In struct Typedef %s there is no defined type %s", acTypedefName, acRecordType)
                        bReturnForLoop = bool(False)
                    else:
                        # If we are here then the Type used for this Record does exist and is defined in this file

                        tplRecordTypedefType = clsAutogenToolboxDefinitionValidationAndETFinding.tplClassifyTypedefFileTypedefElementAsEnumOrStruct(lstTypedefFoundInApprovedList[0])

                        # Check that when we tried to classify the Typedef that we could get a valid result
                        if (tplRecordTypedefType[0] is True):

                            # We add extra attributes later for autogen
                            if ("Count" not in objRecordElement.attrib):
                                objRecordElement.attrib["Count"] = str("1")

                            if (tplRecordTypedefType[1] == E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_STRUCT)):
                                # Do a basic non-recursive check of the Struct Field or Record
                                bReturnForLoop = clsAutogenToolboxDefinitionValidationAndETFinding.bValidateStructTypeFieldOrdRecord(objRecordElement)

                                if (bReturnForLoop is True):
                                    # Increase the recursion level because we are calling this same method again
                                    bReturnForLoop = clsAutogenToolboxDefinitionValidationAndETFinding.bValidateTypedefOfTypeStruct(lstTypedefFoundInApprovedList[0], bCheckApprovedListOfTypesPar, lstApprovedTypesElementStructAllowedToUsePar, iRecursionLevel + 1)
                                else:
                                    logging.error("Struct Field or Record %s is invalid", objRecordElement.attrib["Name"])

                                # We add extra attributes later for autogen
                                objRecordElement.attrib["eRecordType"] = E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_STRUCT)
                            elif (tplRecordTypedefType[1] == E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_ENUM)):
                                bReturnForLoop = clsAutogenToolboxDefinitionValidationAndETFinding.bValidateEnumTypeFieldOrdRecord(objRecordElement)

                                # Add extra atttributes to an Enum Record
                                objRecordElement.attrib["lstAllEnumValuesAsInt"] = []
                                objRecordElement.attrib["lstAllEnumValuesAsStr"] = []
                                lstEnumType = [objEnumTypeDefElement for objEnumTypeDefElement in lstApprovedTypesElementStructAllowedToUsePar if objEnumTypeDefElement.attrib["Name"] == objRecordElement.attrib["Type"]]

                                if (not lstEnumType):
                                    logging.error("lstEnumType cannot be empty for %s", objRecordElement.attrib["Name"])
                                else:
                                    # Keep a list of all the values as int
                                    [objRecordElement.attrib["lstAllEnumValuesAsInt"].append(objEnumerationElement.attrib["Value"]) for objEnumerationElement in lstEnumType[0].findall("./Record/Enumeration")]  # pylint: disable=expression-not-assigned
                                    # Keep a list of all the values as str
                                    [objRecordElement.attrib["lstAllEnumValuesAsStr"].append(objEnumerationElement.attrib["Name"]) for objEnumerationElement in lstEnumType[0].findall("./Record/Enumeration")]  # pylint: disable=expression-not-assigned

                                # Now we have to check if the Default value of this Enum Record is valid
                                if (bReturnForLoop is True):
                                    # At this point know that the Record will have a Default attribute
                                    # Find the Type from this list of known Typedef Elements
                                    lstTypdefEnumElements = [objTypdefEnumElement for objTypdefEnumElement in lstApprovedTypesElementStructAllowedToUsePar if objTypdefEnumElement.attrib["Name"] == acRecordType]

                                    if (not lstTypdefEnumElements):
                                        # If the typdef was not found then it's a problem
                                        bReturnForLoop = bool(False)
                                        logging.error("Record defined type %s does not exist", acRecordType)
                                    else:
                                        # Try to find the Default in this specific Type the Record claims it is
                                        objEnumerationElement = lstTypdefEnumElements[0].find("./Record/Enumeration[@Name=\'%s\']" % (objRecordElement.attrib["Default"]))

                                        if (objEnumerationElement is None):
                                            # If the matching Enumeration was not found then it is invalid
                                            bReturnForLoop = bool(False)
                                            logging.error("Invalid Default value %s for Enum Record %s", objRecordElement.attrib["Default"], objRecordElement.attrib["Name"])
                                        else:
                                            bReturnForLoop = bool(True)

                                # We add extra attributes later for autogen
                                objRecordElement.attrib["eRecordType"] = E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_ENUM)
                        else:
                            bReturnForLoop = bool(False)
                            logging.error("Could not classify Record type %s as a struct or enum Typdef", acRecordType)

            if (bReturnForLoop is False):
                logging.error("Record %s is invalid", objRecordElement.attrib["Name"])
                bReturn = bool(False)

        return(bReturn)

    # ===============================================================================
    # MsgDef XML file Header related methods
    # ===============================================================================

    @staticmethod
    def tplValidateMsgDefHeadersFromRootElement(objRootElementPar: ET.Element, dctDatabaseOfAllTypedefsPar: dict):
        """ This is a public static method which finds all the Header Elements and
        then validates them.

        Note! The dctDatabaseOfAllTypedefsPar dict must have all the Enums and Structs
        that are in the XML files in question. That means the Typdef XML files and the
        MsgDef XML file in question.

        Args:
            objRootElementPar (ET.Element): The root MsgDef Element
            dctDatabaseOfAllTypedefsPar (dict): The keys are:
                * {str (Name of typedef): dctTypeDef}
                    * dctTypeDef keys are:
                        * ["acName"] (str) -> The name of the typedef
                        * ["acXmlFileName"] (str) -> The filename - no path, just the filename
                        * ["acXmlFilePath"] (str) -> The full path to XML where this typedef is defined
                        * ["eTypedefType"] (str) -> The type of typedef
                        * ["objElement"] (str) -> The Element object

        Returns:
            (tuple): With the following value
                * (bool) -> Did the validation pass
                * (list) -> A list of Message tag dict item

        Raises:
            Raises no exception.

        """
        bReturn = bool(False)
        tplReturn = (bReturn, [])
        lstMessageHeaderTagDictItems = []

        bFieldsAndRecordsValid = bool(False)
        lstMessageHeaderPairedElements = []  # This will store a list of all the Message Header paired Elements
        lstHeaderFieldNames = []  # This will store all the Fields of a Header
        tplHeaderFieldNames = ()  # This is the same as the above list but as a tuple

        lstHeaderFieldTypes = []  # This will store all the Types of a Header
        tplHeaderFieldTypes = ()  # This is the same as the above list but as a tuple
        # The ADCS approved header fields are these ones and in this order
        tplRequiredHeaderFields = ("MsgLength", "MsgType", "MsgStatus", "ModuleAddress", "MsgId", "MsgCount", "TimeStampMs", "ProcessStartCnt")
        tplRequiredHeaderTypes = ("U2", "E2_MW_MESSAGE_TYPE", "E2_MW_MESSAGE_STATUS", "E2_MW_MODULE_ADDRESS", "U2", "U2", "U8", "U2")

        # We define a dictionary item to store Message Header related info
        dctMessageHeaderTagDictItem = {}
        dctMessageHeaderTagDictItem["acName"] = str("")
        dctMessageHeaderTagDictItem["acMsgDefXmlFilename"] = str("")  # Will be filled in outside this method
        dctMessageHeaderTagDictItem["objMessageElement"] = str("")
        dctMessageHeaderTagDictItem["objHeaderElement"] = str("")
        dctMessageHeaderTagDictItem["lstFieldElements"] = []
        dctMessageHeaderTagDictItem["acReplyMsg"] = str("")

        if (objRootElementPar is None):
            logging.error("objRootElementPar cannot be None")
            return(tplReturn)

        if (isinstance(objRootElementPar, ET.Element) is False):
            logging.error("objRootElementPar must be an ET.Element")
            return(tplReturn)

        if (isinstance(dctDatabaseOfAllTypedefsPar, dict) is False):
            logging.error("dctDatabaseOfAllTypedefsPar must be a dict")
            return(tplReturn)

        # Find all the Header Elements
        lstMessageHeaderPairedElements = clsAutogenToolboxDefinitionValidationAndETFinding.lstFindMessageHeaderPairElementsFromMsgDefRootElement(objRootElementPar)

        # There might not be any messages in the MsgDeg XML file
        if (not lstMessageHeaderPairedElements):
            bReturn = bool(True)
            tplReturn = (bReturn, [])
            return(tplReturn)

        bReturn = bool(True)  # Assume all perfect validation for now
        if (lstMessageHeaderPairedElements):
            for dctMessageHeaderPair in lstMessageHeaderPairedElements:

                dctMessageHeaderTagDictItem = {}
                dctMessageHeaderTagDictItem["acName"] = dctMessageHeaderPair["acMessageName"]
                dctMessageHeaderTagDictItem["acMsgDefXmlFilename"] = str("")  # Will be filled in outside this method
                dctMessageHeaderTagDictItem["objMessageElement"] = dctMessageHeaderPair["objMessageElement"]
                dctMessageHeaderTagDictItem["objHeaderElement"] = dctMessageHeaderPair["objHeaderElement"]
                dctMessageHeaderTagDictItem["lstFieldElements"] = []
                dctMessageHeaderTagDictItem["acReplyMsg"] = str("")

                lstMessageHeaderTagDictItems.append(dctMessageHeaderTagDictItem)

                if ("ReplyMsg" in dctMessageHeaderTagDictItem["objMessageElement"].attrib):
                    dctMessageHeaderTagDictItem["acReplyMsg"] = dctMessageHeaderTagDictItem["objMessageElement"].attrib["ReplyMsg"]

                # Find all the Field Elements
                lstHeaderFieldElements = clsAutogenToolboxDefinitionValidationAndETFinding.lstFindFieldElementsFromHeaderElement(dctMessageHeaderPair["objHeaderElement"])

                dctMessageHeaderTagDictItem["lstFieldElements"] = lstHeaderFieldElements

                lstHeaderFieldNames = [objElement.attrib["Name"] for objElement in lstHeaderFieldElements]
                tplHeaderFieldNames = tuple(lstHeaderFieldNames)

                if (tplHeaderFieldNames != tplRequiredHeaderFields):
                    logging.error("Message %s Header does not have the approved ADCS header fields %s vs %s", dctMessageHeaderPair["acMessageName"], str(tplHeaderFieldNames), str(tplRequiredHeaderFields))
                    bReturn = bool(False)
                    break

                lstHeaderFieldTypes = [objElement.attrib["Type"] for objElement in lstHeaderFieldElements]
                tplHeaderFieldTypes = tuple(lstHeaderFieldTypes)

                if (tplHeaderFieldTypes != tplRequiredHeaderTypes):
                    logging.error("Message %s Header does not have the approved ADCS header field types", dctMessageHeaderPair["acMessageName"])
                    bReturn = bool(False)
                    break

                for objHeaderFieldElement in lstHeaderFieldElements:
                    # This is the Fields in the Header so the recursion starts as 0
                    bFieldsAndRecordsValid = clsAutogenToolboxDefinitionValidationAndETFinding.bValidateFieldOrRecordElementRecursively(objHeaderFieldElement, dctDatabaseOfAllTypedefsPar, iRecursionLevel=int(0))

                    if (bFieldsAndRecordsValid is False):
                        logging.error("Field %s in Message %s is invalid", objHeaderFieldElement.attrib["Name"], dctMessageHeaderPair["acMessageName"])
                        bReturn = bool(False)
                        break

                if (bReturn is False):
                    break

        return((bReturn, lstMessageHeaderTagDictItems))

    @staticmethod
    def lstFindMessageHeaderPairElementsFromMsgDefRootElement(objRootElementPar: ET.Element):
        """ This is a public static method which find the paired Message and Header Elements from
        a root MsgDef XML Element. When we say pair we say we find the Header in a Message and group
        them together so we have more information when processing the Header Element.

        Args:
            objRootElementPar (ET.Element): The root Element of a MsgDef XML file

        Returns:
            (list): A list of dict items. The keys of the dict are
                ["acMessageName"] -> The message name
                ["objMessageElement"] -> This is Message Element. The Header is the "parent". The Header below is its child
                ["objHeaderElement"] -> This is the Header Element (the child) of the Message stored above

        Raises:
            Raises no exception.
        """
        lstReturn = []
        lstMessageElements = []
        lstHeaderElements = []
        acCurrentMessageName = str("")

        # A Message will always have a Header (because of the schema)
        # We want to group them together when we go looking for Header Elements
        dctMessageHeaderPair = {}
        dctMessageHeaderPair["acMessageName"] = str("")
        dctMessageHeaderPair["objMessageElement"] = None  # This will store the Message Element. The Header is the "parent". The Header below is its child
        dctMessageHeaderPair["objHeaderElement"] = None  # This will store the Header Element (the child) of the Message stored above

        # Check that it's not None
        if (not objRootElementPar):
            logging.error("objRootElementPar is invalid")
            return(lstReturn)

        # Check that it's an Element object
        if (isinstance(objRootElementPar, ET.Element) is False):
            logging.error("objRootElementPar is not and ET.Element")
            return(lstReturn)

        # Check that it's an Element object
        if (objRootElementPar.tag != "MessageFile"):
            logging.error("objRootElementPar is not a MessageFile tag")
            return(lstReturn)

        lstMessageElements = objRootElementPar.findall(".//Message")

        # If there are no Message Eleements, then there won't be any headers
        if (not lstMessageElements):
            return(lstReturn)

        for objMessage in lstMessageElements:

            # For convenience and logging store the name of the message
            acCurrentMessageName = objMessage.attrib["Name"]

            # We are going to add extra attributes to the Elements to make autogen easier
            objMessage.attrib["acNameAsCapitalisedUnderscores"] = clsAutogenToolboxDefinitionValidationAndETFinding.acPascalCaseToCapitalisedUnderscores(acCurrentMessageName)

            # Make a new dict for a Message Header pair
            dctMessageHeaderPair = {}
            dctMessageHeaderPair["acMessageName"] = acCurrentMessageName  # Store the Message name
            dctMessageHeaderPair["objMessageElement"] = objMessage  # This will store the Message Element. The Header is the "parent". The Header below is its child
            dctMessageHeaderPair["objHeaderElement"] = None  # This will store the Header Element (the child) of the Message stored above

            lstHeaderElements = objMessage.findall("./Header")

            if (not lstHeaderElements):
                logging.error("Message %s does not have a Header", acCurrentMessageName)
                continue

            if (len(lstHeaderElements) != 1):
                logging.error("Message %s is only allowed to have one Header", acCurrentMessageName)
                continue

            dctMessageHeaderPair["objHeaderElement"] = lstHeaderElements[0]  # Store the Header Element

            # We are going to add extra attributes to the Elements to make autogen easier
            dctMessageHeaderPair["objHeaderElement"].attrib["Name"] = acCurrentMessageName
            dctMessageHeaderPair["objHeaderElement"].attrib["acNameAsCapitalisedUnderscores"] = objMessage.attrib["acNameAsCapitalisedUnderscores"]

            lstReturn.append(dctMessageHeaderPair)

        return(lstReturn)

    @staticmethod
    def lstFindMessagePayloadPairElementsFromMsgDefRootElement(objRootElementPar: ET.Element):
        """ This is a public static method which find the paired Message and Payload Elements from
        a root MsgDef XML Element. When we say pair we say we find the Header in a Message and group
        them together so we have more information when processing the Header Element.

        Args:
            objRootElementPar (ET.Element): The root Element of a MsgDef XML file

        Returns:
            (list): A list of dict items. The keys of the dict are
                ["acMessageName"] -> The message name
                ["objMessageElement"] -> This is Message Element. The Header is the "parent". The Header below is its child
                ["objPayloadElement"] -> This is the Payload Element (the child) of the Message stored above

        Raises:
            Raises no exception.
        """
        lstReturn = []
        lstMessageElements = []
        lstPayloadElements = []
        acCurrentMessageName = str("")

        # A Message will always have a Header (because of the schema)
        # We want to group them together when we go looking for Header Elements
        dctMessagePayloadPair = {}
        dctMessagePayloadPair["acMessageName"] = str("")
        dctMessagePayloadPair["objMessageElement"] = None  # This will store the Message Element. The Header is the "parent". The Header below is its child
        dctMessagePayloadPair["objPayloadElement"] = None  # This will store the Header Element (the child) of the Message stored above

        # Check that it's not None
        if (not objRootElementPar):
            logging.error("objRootElementPar is invalid")
            return(lstReturn)

        # Check that it's an Element object
        if (isinstance(objRootElementPar, ET.Element) is False):
            logging.error("objRootElementPar is not and ET.Element")
            return(lstReturn)

        # Check that it's an Element object
        if (objRootElementPar.tag != "MessageFile"):
            logging.error("objRootElementPar is not a MessageFile tag")
            return(lstReturn)

        lstMessageElements = objRootElementPar.findall(".//Message")

        # If there are no Message Elements, then there won't be any Payload
        if (not lstMessageElements):
            return(lstReturn)

        for objMessage in lstMessageElements:

            # For convenience and logging store the name of the message
            acCurrentMessageName = objMessage.attrib["Name"]

            # We are going to add extra attributes to the Elements to make autogen easier
            objMessage.attrib["acNameAsCapitalisedUnderscores"] = clsAutogenToolboxDefinitionValidationAndETFinding.acPascalCaseToCapitalisedUnderscores(acCurrentMessageName)

            # Make a new dict for a Message Header pair
            dctMessagePayloadPair = {}
            dctMessagePayloadPair["acMessageName"] = acCurrentMessageName  # Store the Message name
            dctMessagePayloadPair["objMessageElement"] = objMessage  # This will store the Message Element. The Header is the "parent". The Header below is its child
            dctMessagePayloadPair["objPayloadElement"] = None  # This will store the Header Element (the child) of the Message stored above

            lstPayloadElements = objMessage.findall("./Payload")

            if (not lstPayloadElements):
                logging.error("Message %s does not have a Payload", acCurrentMessageName)
                continue

            if (len(lstPayloadElements) != 1):
                logging.error("Message %s is only allowed to have one Payload", acCurrentMessageName)
                continue

            dctMessagePayloadPair["objPayloadElement"] = lstPayloadElements[0]  # Store the Payload Element

            # We are going to add extra attributes to the Elements to make autogen easier
            dctMessagePayloadPair["objPayloadElement"].attrib["Name"] = acCurrentMessageName
            dctMessagePayloadPair["objPayloadElement"].attrib["acNameAsCapitalisedUnderscores"] = objMessage.attrib["acNameAsCapitalisedUnderscores"]

            lstReturn.append(dctMessagePayloadPair)

        return(lstReturn)

    @staticmethod
    def lstFindFieldElementsFromHeaderElement(objHeaderElement: ET.Element):
        """ This is a public static method which finds all the Field Elements
        in a Header Element

        Args:
            objHeaderElement (ET.Element): A Header Element

        Returns:
            (list): A list of Field Elements

        Raises:
            Raises no exception.
        """
        lstReturn = []

        # Check that it's not None
        if (not objHeaderElement):
            logging.error("objHeaderElement is invalid")
            return(lstReturn)

        # Check that it's an Element object
        if (isinstance(objHeaderElement, ET.Element) is False):
            logging.error("objHeaderElement is not and ET.Element")
            return(lstReturn)

        # Check that it's an Element object
        if (objHeaderElement.tag != "Header"):
            logging.error("objHeaderElement is not a Header tag")
            return(lstReturn)

        lstReturn = objHeaderElement.findall("./Field")

        return(lstReturn)

    # ===============================================================================
    # MsgDef XML file Payload related methods
    # ===============================================================================

    @staticmethod
    def tplValidateMsgDefPayloadFromRootElement(objRootElementPar: ET.Element, dctDatabaseOfAllTypedefsPar: dict):
        """ This is a public static method which finds all the Payload Elements and
        then validates them.

        Note! The dctDatabaseOfAllTypedefsPar dict must have all the Enums and Structs
        that are in the XML files in question. That means the Typdef XML files and the
        MsgDef XML file in question.

        Args:
            objRootElementPar (ET.Element): The root MsgDef Element
            dctDatabaseOfAllTypedefsPar (dict): The keys are:
                * {str (Name of typedef): dctTypeDef}
                    * dctTypeDef keys are:
                        * ["acName"] (str) -> The name of the typedef
                        * ["acXmlFileName"] (str) -> The filename - no path, just the filename
                        * ["acXmlFilePath"] (str) -> The full path to XML where this typedef is defined
                        * ["eTypedefType"] (str) -> The type of typedef
                        * ["objElement"] (str) -> The Element object

        Returns:
            (tuple): With the following value
                * (bool) -> Did the validation pass
                * (list) -> A list of Message tag dict item

        Raises:
            Raises no exception.

        """
        bReturn = bool(False)
        tplReturn = (bReturn, [])
        lstMessageTagDictItems = []

        bReturnForLoop = bool(False)
        lstMessagePayloadPairedElements = []  # This will store a list of all the Message Header paired Elements
        lstFieldElements = []
        acFieldType = str("")
        lstEnumerationElements = []

        # We define a dictionary item to store Message related info
        dctMessageTagDictItem = {}
        dctMessageTagDictItem["acName"] = str("")
        dctMessageTagDictItem["objMessageElement"] = str("")
        dctMessageTagDictItem["objPayloadElement"] = str("")
        dctMessageTagDictItem["lstFieldElements"] = []

        # Find all the Header Elements
        lstMessagePayloadPairedElements = clsAutogenToolboxDefinitionValidationAndETFinding.lstFindMessagePayloadPairElementsFromMsgDefRootElement(objRootElementPar)

        if (not lstMessagePayloadPairedElements):
            # This means this file does not have any Messages
            bReturn = bool(True)
            tplReturn = (bReturn, [])
            return(tplReturn)

        bReturn = bool(True)
        if (lstMessagePayloadPairedElements):
            for dctMessagePayloadPair in lstMessagePayloadPairedElements:

                # We define a dictionary item to store Message related info
                dctMessageTagDictItem = {}
                dctMessageTagDictItem["acName"] = dctMessagePayloadPair["acMessageName"]
                dctMessageTagDictItem["objMessageElement"] = dctMessagePayloadPair["objMessageElement"]
                dctMessageTagDictItem["objPayloadElement"] = dctMessagePayloadPair["objPayloadElement"]
                dctMessageTagDictItem["lstFieldElements"] = []

                # Add this dict item to a list
                lstMessageTagDictItems.append(dctMessageTagDictItem)

                # Find all the Field Elements
                lstFieldElements = dctMessagePayloadPair["objPayloadElement"].findall("./Field")

                if (not lstFieldElements):
                    # This means the Payload does not have any Field
                    dctMessagePayloadPair["objPayloadElement"].attrib["bPayloadWithNoFields"] = bool(True)
                    continue
                else:
                    dctMessagePayloadPair["objPayloadElement"].attrib["bPayloadWithNoFields"] = bool(False)

                dctMessageTagDictItem["lstFieldElements"] = lstFieldElements

                for objFieldElement in lstFieldElements:

                    acFieldType = objFieldElement.attrib["Type"]

                    # We add extra attributes later for autogen
                    if ("Count" not in objFieldElement.attrib):
                        objFieldElement.attrib["Count"] = str("1")

                    if (acFieldType in G_lstAdcsBaseTypes):
                        # Then this Record is a base type so validate it
                        bReturnForLoop = clsAutogenToolboxDefinitionValidationAndETFinding.bValidateBaseTypeFieldOrdRecord(objFieldElement)

                        if (bReturnForLoop is False):
                            logging.error("Message %s Payload is not valid", dctMessagePayloadPair["objMessageElement"].attrib["Name"])

                        # We add extra attributes later for autogen
                        objFieldElement.attrib["eRecordType"] = E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_BASE)

                    else:
                        # If we are here then the Type of this Record is a Enum or Struct Typedef

                        # Use list comprehension to find the Type of this Record in a list of approved (exists in this file)
                        lstTypedefFoundInApprovedList = [dctTypedefItem for acKey, dctTypedefItem in dctDatabaseOfAllTypedefsPar.items() if dctTypedefItem["acName"] == acFieldType]

                        # After the list comprehension see if the list is empty or not - if it is empty then the Record type does not exist
                        if (not lstTypedefFoundInApprovedList):
                            logging.error("In Message %s Payload the Field type %s is missing", dctMessagePayloadPair["objMessageElement"].attrib["Name"], acFieldType)
                            bReturnForLoop = bool(False)
                        else:
                            # If we are here then the Type does exist

                            dctTypedefItem = dctDatabaseOfAllTypedefsPar[acFieldType]

                            # We add extra attributes later for autogen
                            if ("Count" not in objFieldElement.attrib):
                                objFieldElement.attrib["Count"] = str("1")

                            if (dctTypedefItem["eTypedefType"] == E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_STRUCT)):
                                # Do a basic non-recursive check of the Struct Field or Record
                                bReturnForLoop = clsAutogenToolboxDefinitionValidationAndETFinding.bValidateStructTypeFieldOrdRecord(objFieldElement)

                                # We add extra attributes later for autogen
                                objFieldElement.attrib["eRecordType"] = E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_STRUCT)
                            elif (dctTypedefItem["eTypedefType"] == E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_ENUM)):
                                bReturnForLoop = clsAutogenToolboxDefinitionValidationAndETFinding.bValidateEnumTypeFieldOrdRecord(objFieldElement)

                                # Add extra atttributes to an Enum Field
                                objFieldElement.attrib["lstAllEnumValuesAsInt"] = []
                                objFieldElement.attrib["lstAllEnumValuesAsStr"] = []

                                # This is where we need to get all the values of the Enum
                                [objFieldElement.attrib["lstAllEnumValuesAsInt"].append(objEnumerationElement.attrib["Value"]) for objEnumerationElement in dctTypedefItem["objElement"].findall("./Record/Enumeration")]  # pylint: disable=expression-not-assigned
                                # Keep a list of all the values as str
                                [objFieldElement.attrib["lstAllEnumValuesAsStr"].append(objEnumerationElement.attrib["Name"]) for objEnumerationElement in dctTypedefItem["objElement"].findall("./Record/Enumeration")]  # pylint: disable=expression-not-assigned

                                # At this stage we know the Field does have a Default attribute
                                if (bReturnForLoop is True):

                                    lstEnumerationElements = dctTypedefItem["objElement"].findall("./Record/Enumeration[@Name=\'%s\']" % objFieldElement.attrib["Default"])

                                    if (not lstEnumerationElements):
                                        logging.error("Enumeration value %s is not in %s", objFieldElement.attrib["Default"], dctTypedefItem["acName"])
                                        bReturnForLoop = bool(False)

                                # We add extra attributes later for autogen
                                objFieldElement.attrib["eRecordType"] = E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_ENUM)

                    if (bReturnForLoop is False):
                        logging.error("Field %s in Message %s is invalid", objFieldElement.attrib["Name"], dctMessagePayloadPair["objMessageElement"].attrib["Name"])
                        bReturn = bool(False)

        return((bReturn, lstMessageTagDictItems))

    # ===============================================================================
    # Methods related to finding Typedef which are Enums and Structs
    # ===============================================================================

    @staticmethod
    def lstFindStructsAndEnumsFromElement(objElementPar: ET.Element, eTypedefType: E_TYPEDEF_XML_FILE_TYPEDEF_TYPE, acXmlFilePathPar: str):
        """ This is a public static method which find struct Typedef Elements

        Note!: This method assumes the actual XML file from which objElementPar came exists

        Args:
            objElementPar (ET.Element): An Element
            eTypedefType (E_TYPEDEF_XML_FILE_TYPEDEF_TYPE): The type of typedef
            acXmlFilePathPar (str): The full path to the XML file

        Returns:
            (dict): Keys are:
                ["acName"] (str) -> Name of the Typedef
                ["objElement"]  (ET.Element) -> The Element of the Typedef
                ["acXmlFilePath"] (str) -> The full path to the XML file
                ["acXmlFileName"] (str) -> The XML filename - no path
                ["eTypedefType"] (E_TYPEDEF_XML_FILE_TYPEDEF_TYPE) -> The type of typdef struct or enum

        Raises:
            Raises no exception.
        """
        lstReturn = []
        lstTypedefElements = []
        tplTypdefType = (False, None)

        dctTypedefItem = {}
        dctTypedefItem["acName"] = str("")
        dctTypedefItem["objElement"] = None
        dctTypedefItem["acXmlFilePath"] = str("")
        dctTypedefItem["acXmlFileName"] = str("")
        dctTypedefItem["eTypedefType"] = E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_STRUCT)

        # Check that it's not None
        if (not objElementPar):
            logging.error("objElementPar is invalid")
            return

        # Check that the path is not None or empty str
        if (not acXmlFilePathPar):
            logging.error("acXmlFilePathPar is invalid")
            return

        # Check that it's an Element object
        if (isinstance(objElementPar, ET.Element) is False):
            logging.error("objElementPar is not and ET.Element - File path %s", acXmlFilePathPar)
            return

        # Check that the file exists
        if (os.path.isfile(acXmlFilePathPar) is False):
            logging.error("Required file %s does not exist", acXmlFilePathPar)
            return

        lstTypedefElements = objElementPar.findall(".//Typedef")

        for objTypdefElement in lstTypedefElements:

            tplTypdefType = clsAutogenToolboxDefinitionValidationAndETFinding.tplClassifyTypedefFileTypedefElementAsEnumOrStruct(objTypdefElement)

            if ((tplTypdefType[0] is True) and (tplTypdefType[1] == eTypedefType)):

                dctTypedefItem = {}
                dctTypedefItem["acName"] = objTypdefElement.attrib["Name"]
                dctTypedefItem["objElement"] = objTypdefElement
                dctTypedefItem["acXmlFilePath"] = acXmlFilePathPar
                _, dctTypedefItem["acXmlFileName"] = os.path.split(acXmlFilePathPar)
                dctTypedefItem["eTypedefType"] = eTypedefType

                lstReturn.append(dctTypedefItem)

        return(lstReturn)

    # ===============================================================================
    # Conversion methods
    # ===============================================================================

    @staticmethod
    def acPascalCaseToCapitalisedUnderscores(acStringPar: str):
        """ This is a public static method which converts Pascal case into capitalised underscores

        Args:
            acStringPar (str): The Pascal case string

        Returns:
            (str): The resultant capitalised underscores string

        Raises:
            Raises no exception.
        """
        acReturn = str("")
        lstTokens = []

        if (acStringPar is None):
            logging.error("acStringPar cannot be None")
            return(acReturn)

        if (isinstance(acStringPar, str) is False):
            logging.error("acStringPar is not a string")
            return(acReturn)

        if (not acStringPar):
            logging.error("acStringPar is empty")
            return(acReturn)

        try:
            lstTokens = re.sub('([A-Z][a-z]+)', r' \1', re.sub('([A-Z]+)', r' \1', acStringPar)).split()
        except Exception as E:
            logging.error("Could not split string %s - Exception %s", acStringPar, str(E))
            return(acReturn)

        acReturn = str("")
        for acToken in lstTokens:
            acReturn += acToken.upper() + "_"

        acReturn = acReturn[:-1]

        return(acReturn)

    # ===============================================================================
    # Letter casing validation
    # ===============================================================================

    @staticmethod
    def bIsCasingStandardValidPascalCase(acStringPar: str, bAllowUppercaseAcronymsPar: bool = False):
        """ This is a public static method which checks if a string is valid for Pascal case

        Pascal case string examples:
        * TewaStatusReqRsp
        * OlhmStatusReqRsp

        Rules:
        * The First letter must be upper case.

        Args:
            acStringPar (str): The string.
            bAllowUppercaseAcronymsPar (bool): Flag to indicate if we are very strict and not allow all uppercase Acronyms

        Returns:
            (bool): Flag to indicate valid or invalid

        Raises:
            Raises no exception.
        """
        bIsValid = bool(False)
        lstLowerCaseLetters = []

        if (acStringPar is None):
            logging.error("acStringPar is None")
            return(bIsValid)

        if (isinstance(acStringPar, str) is False):
            logging.error("acStringPar is not a str")
            return(bIsValid)

        if (not acStringPar):
            logging.error("acStringPar is an empty string")
            return(bIsValid)

        if (acStringPar[0].isupper() is False):
            logging.error("For string %s the first letter must be upper case to comply with Pascal case", acStringPar)
            return(bIsValid)

        # Check for "_" - must not have any
        if (acStringPar.find("_") != -1):
            logging.error("String %s is not valid Pascal case", acStringPar)
            return(bIsValid)

        # Check for " " - must not have any
        if (acStringPar.find(" ") != -1):
            logging.error("String %s is not valid Pascal case", acStringPar)
            return(bIsValid)

        # Check for lower case letters
        lstLowerCaseLetters = [acChar for acChar in acStringPar if acChar.islower()]

        if (bAllowUppercaseAcronymsPar is False):
            if (not lstLowerCaseLetters):
                logging.error("String %s should have some lower case letters to be Pascal case", acStringPar)
                return(bIsValid)

        return(True)

    @staticmethod
    def bIsCasingStandardValidCapitalisedUnderscores(acStringPar: str, bIgnoreUnderscores: bool = False):
        """ This is a public static method which checks if a string is valid for capitalised underscores

        Capitalised underscores string examples:
        * E2_POWER_LEVEL
        * E1_MW_BOOLEAN


        Args:
            acStringPar (str): The string.
            bIgnoreUnderscores (bool): Bool indicating if we should ignore the check for underscores
                * For certain cases like the name of Enumeration there might not be any underscores because only one word is used

        Returns:
            (bool): Flag to indicate valid or invalid

        Raises:
            Raises no exception.
        """
        bIsValid = bool(False)
        lstLowerCaseLetters = []

        if (not acStringPar):
            logging.error("String is not valid")
            return(bIsValid)

        if (isinstance(acStringPar, str) is False):
            logging.error("acStringPar is not a str")
            return(bIsValid)

        # For certain cases like the name of Enumeration there might not be any underscores because only one word is used
        if (bIgnoreUnderscores is False):
            # Check for "_" - must have some
            if (acStringPar.find("_") == -1):
                logging.error("String %s is not valid capitalised underscores", acStringPar)
                return(bIsValid)

        # Check for " " - must not have
        if (acStringPar.find(" ") != -1):
            logging.error("String %s is not valid capitalised underscores", acStringPar)
            return(bIsValid)

        # Check for lower case letters
        lstLowerCaseLetters = [acChar for acChar in acStringPar if acChar.islower()]

        if (lstLowerCaseLetters):
            logging.error("String %s should not have any lower case letters to be capitalised underscores", acStringPar)
            return(bIsValid)

        return(True)

    @staticmethod
    def bIsCasingStandardValidCamelCaseWithUnderscores(acStringPar: str):
        """ This is a public static method which checks if a string is valid for camel case with underscores

        Camel case with underscores string examples:
        * MW_Common_Types
        * TEWA_Msg


        Args:
            acStringPar (str): The string.

        Returns:
            (bool): Flag to indicate valid or invalid

        Raises:
            Raises no exception.
        """
        bIsValid = bool(False)

        if (not acStringPar):
            logging.error("String is not valid")
            return(bIsValid)

        if (isinstance(acStringPar, str) is False):
            logging.error("acStringPar is not a str")
            return(bIsValid)

        # Check for " " - must not have any
        if (acStringPar.find(" ") != -1):
            logging.error("String %s is not valid camel case with underscores", acStringPar)
            return(bIsValid)

        return(True)

    # ===============================================================================
    # General validate methods - no recursive methods here!
    # ===============================================================================

    @staticmethod
    def bValidateTypedefOfTypeEnum(objEnumTypedefElementPar: ET.Element):
        """ This is a public static method which validates a enum Typedef Element.
        Note! The method assumes it is an Enum Typedef
        Note! The method assumes the XML file passed the DTD schema

        This method will check the following:
        * Its Enumeration names are the correct casing standard
        * Its Enumeration values are integers

        Args:
            objEnumTypedefElementPar (ET.Element): A Typedef Element which is an Enum

        Returns:
            (bool): Flag to indicate if validation passed

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        lstEnumerationElements = []
        lstRecordElement = None
        acTypedefName = str("")
        acTypedefType = str("")
        acEnumerationName = str("")
        acEnumerationValue = str("")
        eValueType = E_NUMERIC_VALUE_TYPE(E_NUMERIC_VALUE_TYPE.NUMERIC_VALUE_TYPE_INVALID)

        if (not objEnumTypedefElementPar):
            logging.error("objEnumTypedefElementPar is invalid")
            return(bReturn)

        if (isinstance(objEnumTypedefElementPar, ET.Element) is False):
            logging.error("objEnumTypedefElementPar is not an ET.Element")
            return(bReturn)

        # Check that the Name is there
        if ("Name" not in objEnumTypedefElementPar.attrib):
            logging.error("Name not in enum Typedef")
            return(bReturn)

        acTypedefName = objEnumTypedefElementPar.attrib["Name"]
        # Get the Record child tag of the Typedef
        lstRecordElement = objEnumTypedefElementPar.findall("./Record")

        if (not lstRecordElement):
            logging.error("Enum %s does not have a Record child", acTypedefName)
            return(bReturn)

        # An enum Typedef may only have 1 Record child
        if (len(lstRecordElement) != 1):
            logging.error("Typedef Element %s is invalid", acTypedefName)
            return(bReturn)

        # There must be a Type
        if ("Type" not in lstRecordElement[0].attrib):
            logging.error("Typedef %s does not specify a base type", acTypedefName)
            return(bReturn)

        acTypedefType = lstRecordElement[0].attrib["Type"]

        if (acTypedefType not in G_lstAdcsBaseTypes):
            logging.error("The base type %s given for enum %s is invalid", acTypedefType, acTypedefName)
            return(bReturn)

        if (clsAutogenToolboxDefinitionValidationAndETFinding.bIsEnumerationNameValid(acTypedefName, acTypedefType) is False):
            logging.error("Enum %s name is not valid", acTypedefName)
            return(bReturn)

        lstEnumerationElements = objEnumTypedefElementPar.findall("./Record/Enumeration")

        if (not lstEnumerationElements):
            logging.error("Enum %s does not even have one Enumeration Element", acTypedefName)
            return(bReturn)

        bReturn = bool(True)  # Assume innocent until proved guilty
        for objEnumerationElement in lstEnumerationElements:

            # We are adding additional attributes to Elements to make autogen easier
            objEnumerationElement.attrib["acBaseType"] = acTypedefType

            if ("Name" in objEnumerationElement.attrib):
                acEnumerationName = objEnumerationElement.attrib["Name"]

                if (clsAutogenToolboxDefinitionValidationAndETFinding.bIsCasingStandardValidCapitalisedUnderscores(acEnumerationName, bIgnoreUnderscores=True) is False):
                    logging.error("Typdef %s Enumeration name %s does comply with the letter case standard", acTypedefName, acEnumerationName)
                    bReturn = bool(False)
                    break
            else:
                logging.error("Enumeration field of %s does not have a Name", acTypedefName)
                bReturn = bool(False)
                break

            if ("Value" in objEnumerationElement.attrib):
                acEnumerationValue = objEnumerationElement.attrib["Value"]

                eValueType = clsAutogenToolboxDefinitionValidationAndETFinding.eClassifyStringAsNumericType(acEnumerationValue)

                if (eValueType not in [E_NUMERIC_VALUE_TYPE(E_NUMERIC_VALUE_TYPE.NUMERIC_VALUE_TYPE_HEX_INTEGER), E_NUMERIC_VALUE_TYPE(E_NUMERIC_VALUE_TYPE.NUMERIC_VALUE_TYPE_INTEGER)]):
                    logging.error("Typdef %s Enumeration value %s is not an integer or even hex integer", acTypedefName, acEnumerationValue)
                    bReturn = bool(False)
                    break
            else:
                logging.error("Enumeration field of %s does not have a Name", acTypedefName)
                bReturn = bool(False)
                break

        return(bReturn)

    @staticmethod
    def bIsEnumerationNameValid(acEnumNamePar: str, acBaseTypePar: str = ""):
        """ This is a public static method which checks if an enum name valid against the standard

        Valid name examples
        * E2_POWER_LEVEL
        * E1_MW_BOOLEAN

        Args:
            acEnumNamePar (str): The enum name.

        Returns:
            (bool): Flag to indicate valid or invalid

        Raises:
            Raises no exception.
        """
        bIsValid = bool(False)
        acByteSizeCharacter = str("")

        # Check if it is None or empty string
        if (not acEnumNamePar):
            logging.error("String is not valid")
            return(bIsValid)

        # Make sure it is a str
        if (isinstance(acEnumNamePar, str) is False):
            logging.error("acEnumNamePar is not a str")
            return(bIsValid)

        if (len(acEnumNamePar) < 4):
            logging.error("Enum name %s is too short to be valid", acEnumNamePar)
            return(bIsValid)

        # Check that it is capitalised underscores
        if (clsAutogenToolboxDefinitionValidationAndETFinding.bIsCasingStandardValidCapitalisedUnderscores(acEnumNamePar, bIgnoreUnderscores=False) is False):
            logging.error("Enum name %s is not capitalised underscores", acEnumNamePar)
            return(bIsValid)

        if (acEnumNamePar[0] != "E"):
            logging.error("Enum name %s first character must be an E", acEnumNamePar)
            return(bIsValid)

        # Get the size character
        acByteSizeCharacter = acEnumNamePar[1]

        if (acByteSizeCharacter.isdigit() is False):
            logging.error("Enum name %s does not specify a size", acEnumNamePar)
            return(bIsValid)

        if ((acBaseTypePar) and (len(acBaseTypePar) == 2)):
            if (acByteSizeCharacter != acBaseTypePar[1]):
                logging.error("Enum name %s size is different to the specified type %s", acEnumNamePar, acBaseTypePar)
                return(bIsValid)
            else:
                return(True)
        else:
            return(True)

        return(True)

    @staticmethod
    def bIsStructNameValid(acStructNamePar: str):
        """ This is a public static method which checks if a struct name is valid against the standard

        Valid struct name examples
        * sADCS_TIMESTAMP
        * sOLHM_DETAILED_STATUS

        Args:
            acStructNamePar (str): The struct name.

        Returns:
            (bool): Flag to indicate valid or invalid

        Raises:
            Raises no exception.
        """
        bIsValid = bool(False)
        acStructNameWithFirstS = str("")

        # Check if it is None or empty string
        if (not acStructNamePar):
            logging.error("Struct name is not valid")
            return(bIsValid)

        # Make sure it is a str
        if (isinstance(acStructNamePar, str) is False):
            logging.error("acStructNamePar is not a str")
            return(bIsValid)

        if (len(acStructNamePar) < 3):
            logging.error("Struct name %s is too short to be valid", acStructNamePar)
            return(bIsValid)

        if (acStructNamePar[0] != "s"):
            logging.error("Struct name %s must start with an s", acStructNamePar)
            return(bIsValid)

        acStructNameWithFirstS = acStructNamePar[1:]

        # Ignore underscores when checking casing because it could possibly be only one word
        if (clsAutogenToolboxDefinitionValidationAndETFinding.bIsCasingStandardValidCapitalisedUnderscores(acStructNameWithFirstS, bIgnoreUnderscores=True) is False):
            logging.error("Struct name %s is not valid against the standard - the casing standard is wrong", acStructNamePar)
            return(bIsValid)

        return(True)

    @staticmethod
    def eClassifyStringAsNumericType(acStringPar: str):
        """ This is a public static method which determines if a string represents a numeric value

        Args:
            acStringPar (str): The string value

        Returns:
            (E_NUMERIC_VALUE_TYPE): Enum which indicates the type

        Raises:
            Raises no exception.
        """
        eReturn = E_NUMERIC_VALUE_TYPE(E_NUMERIC_VALUE_TYPE.NUMERIC_VALUE_TYPE_INVALID)
        bIsValidInt = bool(False)
        bIsValidFloat = bool(False)
        bIsValidHexInt = bool(False)

        # Check if the string in None
        if (acStringPar is None):
            logging.error("acStringPar cannot be None")
            return(eReturn)

        # Check if the string is empty
        if (not acStringPar):
            return(eReturn)

        if (isinstance(acStringPar, str) is False):
            logging.error("acStringPar is invalid")
            return(eReturn)

        # Check if this is a float
        try:
            float(acStringPar)
            bIsValidFloat = bool(True)
        except:
            bIsValidFloat = bool(False)

        # Check if this is a base 10 int
        try:
            int(acStringPar, 10)
            bIsValidInt = bool(True)
        except:
            bIsValidInt = bool(False)

        # Check if this is a base 16 int
        try:
            int(acStringPar, 16)
            bIsValidHexInt = bool(True)
        except:
            bIsValidHexInt = bool(False)

        if ((bIsValidInt is True) and (bIsValidFloat is True)):
            eReturn = E_NUMERIC_VALUE_TYPE(E_NUMERIC_VALUE_TYPE.NUMERIC_VALUE_TYPE_INTEGER)
            return(eReturn)
        elif ((bIsValidInt is False) and (bIsValidFloat is True)):
            eReturn = E_NUMERIC_VALUE_TYPE(E_NUMERIC_VALUE_TYPE.NUMERIC_VALUE_TYPE_FLOAT)
            return(eReturn)
        elif ((bIsValidInt is False) and (bIsValidFloat is False) and (bIsValidHexInt is True)):
            eReturn = E_NUMERIC_VALUE_TYPE(E_NUMERIC_VALUE_TYPE.NUMERIC_VALUE_TYPE_HEX_INTEGER)
            return(eReturn)

        return(eReturn)

    @staticmethod
    def bValidateBaseTypeFieldOrdRecord(objElementPar: ET.Element):
        """ This is a public static which validates a base type Field or Record Element

        Args:
            objElementPar (ET.Element): The Field or Record Element

        Returns:
            (bool): Flag which indicates if the validation passed

        Raises:
            Raises no exception.

        """
        bReturn = bool(False)
        acName = str("")
        acType = str("")
        lstBaseTypesInteger = ["I1", "I2", "I4", "I8", "U1", "U2", "U4", "U8"]
        lstBaseTypesFloat = ["F4", "F8"]
        lstBaseTypesString = ["CH"]
        acStringValue = str("")
        eStringValueType = E_NUMERIC_VALUE_TYPE(E_NUMERIC_VALUE_TYPE.NUMERIC_VALUE_TYPE_INVALID)  # Make invalid for now
        lstAttributesToCheck = ["Default", "Max", "Min", "Count"]
        iCount = int(0)

        # Check if None
        if (objElementPar is None):
            logging.error("objElementPar is None")
            return(bReturn)

        if (isinstance(objElementPar, ET.Element) is False):
            logging.error("objElementPar is not and ET.Element")
            return(bReturn)

        if (objElementPar.tag not in ["Field", "Record"]):
            logging.error("objElementPar is not a Field or a Record Element")
            return(bReturn)

        if ("Name" not in objElementPar.attrib):
            logging.error("Attribute Name is missing from Field")
            return(bReturn)

        acName = objElementPar.attrib["Name"]

        if (clsAutogenToolboxDefinitionValidationAndETFinding.bIsCasingStandardValidPascalCase(acName, bAllowUppercaseAcronymsPar=True) is False):
            logging.error("Attribute Name is not in Pascal case letter casing")
            return(bReturn)

        if ("Type" not in objElementPar.attrib):
            logging.error("Attribute Type is missing from Field %s", acName)
            return(bReturn)

        acType = objElementPar.attrib["Type"]

        if (acType == "ST"):
            logging.error("The ST Type is not a valid Type - check Field or Record %s", acName)
            return(bReturn)

        if (acType not in G_lstAdcsBaseTypes):
            logging.error("Element %s is not of a base type", acName)
            return(bReturn)

        # Fields or Records of Type CH must have a Count attribute
        if ((acType == "CH") and ("Count" not in objElementPar.attrib)):
            logging.error("Field or Record %s which is of Type CH must have a Count attribute defined", acName)
            return(bReturn)

        # We add extra attributes later for autogen
        if ("Count" not in objElementPar.attrib):
            objElementPar.attrib["Count"] = str("1")

        if ("Default" not in objElementPar.attrib):
            objElementPar.attrib["Default"] = G_dctBaseTypesDefaultValues[acType]

        # Check if Count is an int
        try:
            iCount = int(objElementPar.attrib["Count"])
        except:
            logging.error("The Count attribute %s does not seem to be an int", objElementPar.attrib["Count"])
            return(bReturn)

        if (iCount <= 0):
            logging.error("The Count attribute %s must be 1 or greater", objElementPar.attrib["Count"])
            return(bReturn)

        bReturn = bool(True)
        for acAttribute in lstAttributesToCheck:

            if (acAttribute in objElementPar.attrib):

                acStringValue = objElementPar.attrib[acAttribute]
                eStringValueType = clsAutogenToolboxDefinitionValidationAndETFinding.eClassifyStringAsNumericType(acStringValue)

                if (acType in lstBaseTypesInteger):
                    if (eStringValueType not in [E_NUMERIC_VALUE_TYPE(E_NUMERIC_VALUE_TYPE.NUMERIC_VALUE_TYPE_HEX_INTEGER), E_NUMERIC_VALUE_TYPE(E_NUMERIC_VALUE_TYPE.NUMERIC_VALUE_TYPE_INTEGER)]):
                        bReturn = bool(False)
                        logging.error("Field or Record %s attribute %s is invalid", acName, acAttribute)
                        break

                elif (acType in lstBaseTypesFloat):
                    if (eStringValueType not in [E_NUMERIC_VALUE_TYPE(E_NUMERIC_VALUE_TYPE.NUMERIC_VALUE_TYPE_FLOAT), E_NUMERIC_VALUE_TYPE(E_NUMERIC_VALUE_TYPE.NUMERIC_VALUE_TYPE_INTEGER)]):
                        bReturn = bool(False)
                        logging.error("Field or Record %s attribute %s is invalid", acName, acAttribute)
                        break

                elif (acType in lstBaseTypesString):
                    if ("Max" in objElementPar.attrib):
                        bReturn = bool(False)
                        logging.error("Field or Record %s cannot have a Max attribute", acName)
                        break

                    if ("Min" in objElementPar.attrib):
                        bReturn = bool(False)
                        logging.error("Field or Record %s cannot have a Max attribute", acName)
                        break

        return(bReturn)

    @staticmethod
    def bValidateEnumTypeFieldOrdRecord(objEnumFieldRecordElementPar: ET.Element):
        """ This is a public static method which validates an enum type Field or Record Element

        Args:
            objEnumFieldRecordElementPar (ET.Element): The Enum Field or Record Element

        Returns:
            (bool): Flag which indicates if the validation passed

        Raises:
            Raises no exception.

        """
        bReturn = bool(False)
        acName = str("")

        if (objEnumFieldRecordElementPar is None):
            logging.error("objEnumFieldRecordElementPar cannot be None")
            return(bReturn)

        if (isinstance(objEnumFieldRecordElementPar, ET.Element) is False):
            logging.error("objEnumFieldRecordElementPar is not a ET.Element")
            return(bReturn)

        if (objEnumFieldRecordElementPar.tag not in ["Field", "Record"]):
            logging.error("objEnumFieldRecordElementPar is not a Field or Record")
            return(bReturn)

        if ("Name" not in objEnumFieldRecordElementPar.attrib):
            logging.error("objEnumFieldRecordElementPar does not have a Name attribute")
            return(bReturn)

        acName = objEnumFieldRecordElementPar.attrib["Name"]

        if ("Default" not in objEnumFieldRecordElementPar.attrib):
            logging.error("Enum Record or Field %s does not have a Default attribute", acName)
            return(bReturn)

        bReturn = bool(True)
        return(bReturn)

    @staticmethod
    def bValidateStructTypeFieldOrdRecord(objStructFieldRecordElementPar: ET.Element):
        """ This is a public static method which validates an enum type Field or Record Element

        Args:
            objStructFieldRecordElementPar (ET.Element): The Enum Field or Record Element

        Returns:
            (bool): Flag which indicates if the validation passed

        Raises:
            Raises no exception.

        """
        bReturn = bool(False)
        acName = str("")

        if (objStructFieldRecordElementPar is None):
            logging.error("objStructFieldRecordElementPar cannot be None")
            return(bReturn)

        if (isinstance(objStructFieldRecordElementPar, ET.Element) is False):
            logging.error("objStructFieldRecordElementPar is not a ET.Element")
            return(bReturn)

        if (objStructFieldRecordElementPar.tag not in ["Field", "Record"]):
            logging.error("objStructFieldRecordElementPar is not a Field or Record")
            return(bReturn)

        if ("Name" not in objStructFieldRecordElementPar.attrib):
            logging.error("objStructFieldRecordElementPar does not have a Name attribute")
            return(bReturn)

        acName = objStructFieldRecordElementPar.attrib["Name"]

        if (clsAutogenToolboxDefinitionValidationAndETFinding.bIsCasingStandardValidPascalCase(acName) is False):
            logging.error("Struct Field or Record %s name is not Pascal case", acName)
            return(bReturn)

        if ("UseStruct" not in objStructFieldRecordElementPar.attrib):
            logging.error("Struct Field or Record %s name does not have UseStruct attribute and it probably should have", acName)
            return(bReturn)

        if (objStructFieldRecordElementPar.attrib["UseStruct"] == "False"):
            logging.error("Struct Field or Record %s UseStruct is False and it should probably be True", acName)
            return(bReturn)

        bReturn = bool(True)
        return(bReturn)
