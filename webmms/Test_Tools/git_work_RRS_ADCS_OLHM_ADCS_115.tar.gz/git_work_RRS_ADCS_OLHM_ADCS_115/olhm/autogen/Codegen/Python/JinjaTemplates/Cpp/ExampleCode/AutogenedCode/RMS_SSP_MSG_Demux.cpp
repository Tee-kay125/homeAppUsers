/*  Autogen Message Demux c File  */
/*  Generated using Python 2.7.11 |Anaconda 4.1.0 (64-bit)| (default, Jun 15 2016, 15:21:30) , with Jinja2 2.10 */
/*  Generated on Thursday, 13 June 2019 SAST 09:22           */

#include "RMS_SSP_MSG_Demux.h"

//************************************************************************
//Demux function
//************************************************************************
I4 i4Demux_RMS_SSP_MSG (U4* pu4MsgLen, U1* pu1Msg)
{
  sMESSAGE_HEADER* psMsgHeader = (sMESSAGE_HEADER*) pu1Msg;
  U1 *pu1MsgPayload = pu1Msg + sizeof(sMESSAGE_HEADER);
  I4 i4Return = 0;
  U4 u4Key = 0;

  U2 u2MessageStatus = psMsgHeader->u2MsgStatus;
  U2 u2ModuleAddress = psMsgHeader->u2ModuleAddress;
  U2 u2MessageType   = psMsgHeader->u2MsgType;
  *pu4MsgLen = psMsgHeader->u2MsgLength + 2;
  psMsgHeader->u2MsgType = psMsgHeader->u2MsgType + 1;

  if (u2MessageStatus != MsNormal)
  {
    printf("Message Status Error. Got %u, expected %u \n", u2MessageStatus, MsNormal);
    psMsgHeader->u2MsgLength = 8;
    psMsgHeader->u2MsgStatus = MsInvalidField;
    return(-MsInvalidField);
  }

  if (u2ModuleAddress != MODULE_ADDRESS)
  {
    printf("Module Address incorrect. Got %u, expected %u \n", u2ModuleAddress, MODULE_ADDRESS);
    psMsgHeader->u2MsgLength = 8;
    psMsgHeader->u2MsgStatus = MsInvalidField;
    psMsgHeader->u2ModuleAddress = u2ModuleAddress;
    return(-MsInvalidField);
  }

  u4Key = (((U4) psMsgHeader->u2MsgId << 8) | u2MessageType);

  //DEBUG2(("Checking message type and ID. \n"););
  switch (u4Key)
  {
    
    case 0x000002:
      //DEBUG2(("Starting Processing SspStatusReq. \n"););
      i4Return = i4Validation_SspStatusReq(pu4MsgLen, (sSSPSTATUSREQ_PL*) pu1MsgPayload);
      break;
    
    case 0x000100:
      //DEBUG2(("Starting Processing SspSetupCmd. \n"););
      i4Return = i4Validation_SspSetupCmd(pu4MsgLen, (sSSPSETUPCMD_PL*) pu1MsgPayload);
      break;
    
    case 0x000200:
      //DEBUG2(("Starting Processing SspEndOfSetupCmd. \n"););
      i4Return = i4Validation_SspEndOfSetupCmd(pu4MsgLen, (sSSPENDOFSETUPCMD_PL*) pu1MsgPayload);
      break;
    
    case 0x000E00:
      //DEBUG2(("Starting Processing SspResetCmd. \n"););
      i4Return = i4Validation_SspResetCmd(pu4MsgLen, (sSSPRESETCMD_PL*) pu1MsgPayload);
      break;
    
    case 0x000F00:
      //DEBUG2(("Starting Processing SspShutdownCmd. \n"););
      i4Return = i4Validation_SspShutdownCmd(pu4MsgLen, (sSSPSHUTDOWNCMD_PL*) pu1MsgPayload);
      break;
    
    case 0x001000:
      //DEBUG2(("Starting Processing SspSetActiveProfileCmd. \n"););
      i4Return = i4Validation_SspSetActiveProfileCmd(pu4MsgLen, (sSSPSETACTIVEPROFILECMD_PL*) pu1MsgPayload);
      break;
    
    case 0x001100:
      //DEBUG2(("Starting Processing SspInitClutterMapsCmd. \n"););
      i4Return = i4Validation_SspInitClutterMapsCmd(pu4MsgLen, (sSSPINITCLUTTERMAPSCMD_PL*) pu1MsgPayload);
      break;
    
    case 0x001200:
      //DEBUG2(("Starting Processing SspSetSensitivityControlCmd. \n"););
      i4Return = i4Validation_SspSetSensitivityControlCmd(pu4MsgLen, (sSSPSETSENSITIVITYCONTROLCMD_PL*) pu1MsgPayload);
      break;
    
    case 0x001300:
      //DEBUG2(("Starting Processing SspSetDeploymentPositionCmd. \n"););
      i4Return = i4Validation_SspSetDeploymentPositionCmd(pu4MsgLen, (sSSPSETDEPLOYMENTPOSITIONCMD_PL*) pu1MsgPayload);
      break;
    
    case 0x001500:
      //DEBUG2(("Starting Processing SspLoadGeoMapCmd. \n"););
      i4Return = i4Validation_SspLoadGeoMapCmd(pu4MsgLen, (sSSPLOADGEOMAPCMD_PL*) pu1MsgPayload);
      break;
    
    default:
      printf("Error");
      return(-MsInvalidMsgType);
  }

  if (i4Return != MsNormal)
  {
    psMsgHeader->u2MsgStatus = MsInvalidField;
  }

  return(i4Return);
}


//************************************************************************
//Validation functions
//************************************************************************

I4 i4Validation_SspStatusReq(U4* pu4MsgLen, sSSPSTATUSREQ_PL* psMsg)
{
  if (*pu4MsgLen != (sizeof(sSSPSTATUSREQ)))
  {
    return(-MsInvalidMsgLength);
  }

  

  //Process Data and update response message
  return(i4Process_SspStatusReq(pu4MsgLen, psMsg));
}
/*************************************************************************************************************************************/

I4 i4Validation_SspSetupCmd(U4* pu4MsgLen, sSSPSETUPCMD_PL* psMsg)
{
  if (*pu4MsgLen != (sizeof(sSSPSETUPCMD)))
  {
    return(-MsInvalidMsgLength);
  }

  

  //Process Data and update response message
  return(i4Process_SspSetupCmd(pu4MsgLen, psMsg));
}
/*************************************************************************************************************************************/

I4 i4Validation_SspEndOfSetupCmd(U4* pu4MsgLen, sSSPENDOFSETUPCMD_PL* psMsg)
{
  if (*pu4MsgLen != (sizeof(sSSPENDOFSETUPCMD)))
  {
    return(-MsInvalidMsgLength);
  }

  

  //Process Data and update response message
  return(i4Process_SspEndOfSetupCmd(pu4MsgLen, psMsg));
}
/*************************************************************************************************************************************/

I4 i4Validation_SspResetCmd(U4* pu4MsgLen, sSSPRESETCMD_PL* psMsg)
{
  if (*pu4MsgLen != (sizeof(sSSPRESETCMD)))
  {
    return(-MsInvalidMsgLength);
  }

  

  //Process Data and update response message
  return(i4Process_SspResetCmd(pu4MsgLen, psMsg));
}
/*************************************************************************************************************************************/

I4 i4Validation_SspShutdownCmd(U4* pu4MsgLen, sSSPSHUTDOWNCMD_PL* psMsg)
{
  if (*pu4MsgLen != (sizeof(sSSPSHUTDOWNCMD)))
  {
    return(-MsInvalidMsgLength);
  }

  

  //Process Data and update response message
  return(i4Process_SspShutdownCmd(pu4MsgLen, psMsg));
}
/*************************************************************************************************************************************/

I4 i4Validation_SspSetActiveProfileCmd(U4* pu4MsgLen, sSSPSETACTIVEPROFILECMD_PL* psMsg)
{
  if (*pu4MsgLen != (sizeof(sSSPSETACTIVEPROFILECMD)))
  {
    return(-MsInvalidMsgLength);
  }

  if ((psMsg->u4ProfileId < 1) || (psMsg->u4ProfileId > 4))
  {
    return(-MsInvalidField);
  }
  

  //Process Data and update response message
  return(i4Process_SspSetActiveProfileCmd(pu4MsgLen, psMsg));
}
/*************************************************************************************************************************************/

I4 i4Validation_SspInitClutterMapsCmd(U4* pu4MsgLen, sSSPINITCLUTTERMAPSCMD_PL* psMsg)
{
  if (*pu4MsgLen != (sizeof(sSSPINITCLUTTERMAPSCMD)))
  {
    return(-MsInvalidMsgLength);
  }

  

  //Process Data and update response message
  return(i4Process_SspInitClutterMapsCmd(pu4MsgLen, psMsg));
}
/*************************************************************************************************************************************/

I4 i4Validation_SspSetSensitivityControlCmd(U4* pu4MsgLen, sSSPSETSENSITIVITYCONTROLCMD_PL* psMsg)
{
  if (*pu4MsgLen != (sizeof(sSSPSETSENSITIVITYCONTROLCMD)))
  {
    return(-MsInvalidMsgLength);
  }

  if ((psMsg->i1DetectionSensitivity < -5) || (psMsg->i1DetectionSensitivity > 5))
  {
    return(-MsInvalidField);
  }
  

  //Process Data and update response message
  return(i4Process_SspSetSensitivityControlCmd(pu4MsgLen, psMsg));
}
/*************************************************************************************************************************************/

I4 i4Validation_SspSetDeploymentPositionCmd(U4* pu4MsgLen, sSSPSETDEPLOYMENTPOSITIONCMD_PL* psMsg)
{
  if (*pu4MsgLen != (sizeof(sSSPSETDEPLOYMENTPOSITIONCMD)))
  {
    return(-MsInvalidMsgLength);
  }

  switch (psMsg->e1LatitudeDirection)
  {
    
    case NORTH: 
    case SOUTH: 
      break;
    default:
      return(-MsInvalidField);
  }
  if ((psMsg->f8LatitudeDecDeg < 0.0) || (psMsg->f8LatitudeDecDeg > 90.0))
  {
    return(-MsInvalidField);
  }
  switch (psMsg->e1LongitudeDirection)
  {
    
    case WEST: 
    case EAST: 
      break;
    default:
      return(-MsInvalidField);
  }
  if ((psMsg->f8LongitudeDecDeg < 0.0) || (psMsg->f8LongitudeDecDeg > 180.0))
  {
    return(-MsInvalidField);
  }
  if ((psMsg->u2HeightMeters < 0) || (psMsg->u2HeightMeters > 10000))
  {
    return(-MsInvalidField);
  }
  

  //Process Data and update response message
  return(i4Process_SspSetDeploymentPositionCmd(pu4MsgLen, psMsg));
}
/*************************************************************************************************************************************/

I4 i4Validation_SspLoadGeoMapCmd(U4* pu4MsgLen, sSSPLOADGEOMAPCMD_PL* psMsg)
{
  if (*pu4MsgLen != (sizeof(sSSPLOADGEOMAPCMD)))
  {
    return(-MsInvalidMsgLength);
  }

  switch (psMsg->e1Severity)
  {
    
    case SSP_NOTIFICATION_SEVERITY_NORMAL: 
    case SSP_NOTIFICATION_SEVERITY_WARNING: 
    case SSP_NOTIFICATION_SEVERITY_ERROR: 
    case SSP_NOTIFICATION_SEVERITY_ALARM: 
      break;
    default:
      return(-MsInvalidField);
  }
  

  //Process Data and update response message
  return(i4Process_SspLoadGeoMapCmd(pu4MsgLen, psMsg));
}
/*************************************************************************************************************************************/


/* END OF FILE */