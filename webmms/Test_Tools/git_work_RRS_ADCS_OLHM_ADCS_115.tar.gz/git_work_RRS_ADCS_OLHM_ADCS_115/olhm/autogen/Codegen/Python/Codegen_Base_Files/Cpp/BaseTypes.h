#ifndef BASE_TYPES_H
#define BASE_TYPES_H

#include <stdint.h>

#ifndef tight_struct
  #define tight_struct struct __attribute__ ((packed))
#endif

/* Example use : LOG_MACRO(("This is my info\n");)       */
#define LOG_MACRO(achPrintfParameters) { printf("%s:",__FILE__);       printf("%d:",__LINE__);       printf("%s: ",__func__);        printf achPrintfParameters } 

// Language-independent types of standardised size

typedef float    F4;
typedef double   F8;

typedef uint8_t  U1;
typedef uint16_t U2;
typedef uint32_t U4;
typedef uint64_t U8;

typedef int8_t   I1;
typedef int16_t  I2;
typedef int32_t  I4;
typedef int64_t  I8;

typedef char     CH;
#define ST The_ST_type_is_obsolete__Use_CH_instead
//------------------------------------------------------------------------------

#endif
//------------------------------------------------------------------------------

