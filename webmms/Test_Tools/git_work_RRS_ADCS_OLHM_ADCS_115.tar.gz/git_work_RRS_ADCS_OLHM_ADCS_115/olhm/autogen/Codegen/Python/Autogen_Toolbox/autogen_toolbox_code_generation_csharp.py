#!/usr/bin/env python3.6
# -*- coding: utf-8 -*-
""" This module provides a class which provides C# code generation

"""
import logging
from Autogen_Toolbox.autogen_toolbox_definition_validation_and_et_finding import E_FIELD_OR_RECORD_TYPE


G_dctEnumTypeToCSharpEnumType = {}
G_dctEnumTypeToCSharpEnumType["U1"] = str("byte")
G_dctEnumTypeToCSharpEnumType["U2"] = str("ushort")
G_dctEnumTypeToCSharpEnumType["U4"] = str("uint")
G_dctEnumTypeToCSharpEnumType["U8"] = str("ulong")

# This is used for hex conversion
G_dctIntTypeToHexStringTotalLength = {}
G_dctIntTypeToHexStringTotalLength["U1"] = int(4)
G_dctIntTypeToHexStringTotalLength["U2"] = int(6)
G_dctIntTypeToHexStringTotalLength["U4"] = int(10)
G_dctIntTypeToHexStringTotalLength["U8"] = int(18)
G_dctIntTypeToHexStringTotalLength["I1"] = int(4)
G_dctIntTypeToHexStringTotalLength["I2"] = int(6)
G_dctIntTypeToHexStringTotalLength["I4"] = int(10)
G_dctIntTypeToHexStringTotalLength["I8"] = int(18)

# This is used for XML type to C# type conversion
G_dctStructRecordTypeToCSharpType = {}
G_dctStructRecordTypeToCSharpType["U1"] = "byte"
G_dctStructRecordTypeToCSharpType["U2"] = "ushort"
G_dctStructRecordTypeToCSharpType["U4"] = "uint"
G_dctStructRecordTypeToCSharpType["U8"] = "ulong"
G_dctStructRecordTypeToCSharpType["I1"] = "sbyte"
G_dctStructRecordTypeToCSharpType["I2"] = "short"
G_dctStructRecordTypeToCSharpType["I4"] = "int"
G_dctStructRecordTypeToCSharpType["I8"] = "long"
G_dctStructRecordTypeToCSharpType["F4"] = "float"
G_dctStructRecordTypeToCSharpType["F8"] = "double"
G_dctStructRecordTypeToCSharpType["CH"] = "string"


class clsAutogenToolboxCodeGenerationCSharp():
    """ This class provides a class which provides C# code generation


    """

    @staticmethod
    def acConvertXmlCommentToCSharpComment(acXmlCommentPar: str):
        """ This is a public static method which takes an XML comment converts it into a C# comment,
            for use with Visual Studio's IDE Tooltips. These do not allow for formatting, as such
            the preference falls towards simple text.

        Args:
            acXmlCommentPar (str): Original comment string with formatting as applied in the SICD.

        Returns:
            (str): A C# comment

        Raises:
            Raises no exception.
        """
        acResultComment = str("")

        if (acXmlCommentPar is None):
            logging.error("acXmlCommentPar cannot be None")
            return(acResultComment)

        if (isinstance(acXmlCommentPar, str) is False):
            logging.error("acXmlCommentPar must be a str")
            return(acResultComment)

        acResultComment = ' '.join(acXmlCommentPar.split()).replace('==', '').replace('  ', ' ').strip()

        return(acResultComment)

    @staticmethod
    def acConvertNumberToCSharpFormattedValue(acValue: str, acType: str):
        """ Consistently formats int/float/hex values into string representations of the C# 7.0+ digit formats
            (e.g. hexadecimal literals with digit separation)

        Args:
            acValue (str): Value to convert.
            acIntegerType (str): Integer type of associated value.

        Returns:
            (str): A C# 7.3+ formatted digit as a string.

        Raises:
            Raises no exception.
        """
        acFormattedNumericalValue = str("")
        acCompactValue = int(0)

        if acType.startswith("U"):
            # Convert the Enumeration value to an int - with a 0 second parameter Python will know if it is a decimal or hex string
            acIntegerValue = int(acValue, 0)
            acTypeLength = G_dctIntTypeToHexStringTotalLength[acType]
            acCompactValue = ("{0:#0{1}x}".format(acIntegerValue, acTypeLength))
            acFormattedNumericalValue = acCompactValue[:2] + ('_'.join([acCompactValue[i:i + 4] for i in range(2, len(acCompactValue), 4)])).upper()
        elif acType.startswith("F"):
            acNumDecimalPlaces = acValue[::-1].find('.')
            acFormattedNumericalValue = '{:.{}f}'.format(float(acValue), acNumDecimalPlaces if acNumDecimalPlaces > 1 else 1)

        return(acFormattedNumericalValue)

    @staticmethod
    def dctGenerateTypeEnumComplete(dctTypedefEnumPar: dict):
        """ This is a public static method which generates a C# enum code.

        Args:
            dctTypedefEnumPar (dict): A dictionary containing the information needed to write C# Definition files. The keys are:
                * ["acName"] (str)
                * ["acXmlFileName"] (str)
                * ["acXmlFilePath"] (str)
                * ["eTypedefType"] (E_TYPEDEF_XML_FILE_TYPEDEF_TYPE)
                * ["objElement"] (ET.Element)

        Returns:
            (dict): A dictionary with various keys
                * ["acTypedefComment"] (str)
                * ["lstEnumerations"] (list)
                    * (dict)
                        * ["acComment"] (str)
                        * ["acName"] (str)
                        * ["acValue"] (str)

        Raises:
            Raises no exception.
        """
        # This is the return value
        dctReturn = {}
        dctReturn["acTypedefCSharpDataType"] = str("")
        dctReturn["acTypedefComment"] = str("")
        dctReturn["lstEnumerations"] = []

        objRecordElement = None
        lstEnumerationElements = []
        objCommentElement = None
        acTypedefComment = str("")
        acIntAsHexString = str("")

        # This dictionary is used to store Record info
        dctEnumeration = {}
        dctEnumeration["acEnumComment"] = str("")  # This is the Comment tag for which Record is the parent
        dctEnumeration["acEnumName"] = str("")
        dctEnumeration["acEnumValue"] = str("")

        if (dctTypedefEnumPar is None):
            logging.error("dctTypedefEnumPar cannot be None")
            return(dctReturn)

        objCommentElement = dctTypedefEnumPar["objElement"].find("./Comment")

        if ((objCommentElement is not None) and (objCommentElement.text is not None)):
            acTypedefComment = objCommentElement.text
            dctReturn["acTypedefComment"] = clsAutogenToolboxCodeGenerationCSharp.acConvertXmlCommentToCSharpComment(acTypedefComment)

        # Get the Record Element
        objRecordElement = dctTypedefEnumPar["objElement"].find("./Record")

        if (objRecordElement is None):
            logging.error("Enum %s does not have an Record tag", dctTypedefEnumPar["acName"])
            return(dctReturn)

        if (objRecordElement.attrib["Type"] in G_dctEnumTypeToCSharpEnumType.keys()):
            dctReturn["acTypedefCSharpDataType"] = G_dctEnumTypeToCSharpEnumType[objRecordElement.attrib["Type"]]
        else:
            logging.error("Type %s is not in the keys of G_dctEnumTypeToCSharpEnumType", )

        # Get all the Enumeration Elements
        lstEnumerationElements = dctTypedefEnumPar["objElement"].findall("./Record/Enumeration")

        if (not lstEnumerationElements):
            logging.error("Enum %s does not have any Enumeration tags", dctTypedefEnumPar["acName"])
            return(dctReturn)

        # Now that we have gathered the Enumeration Elements we need start preparing the code block

        for objEnumerationElement in lstEnumerationElements:

            # Create a new Record struct with empty values
            dctEnumeration = {}
            dctEnumeration["acEnumComment"] = str("")
            dctEnumeration["acEnumName"] = str("")
            dctEnumeration["acEnumValue"] = str("")

            objCommentElement = objEnumerationElement.find("./Comment")

            # Get the Record Comment if it is not None
            if ((objCommentElement is not None) and (objCommentElement.text is not None)):
                dctEnumeration["acEnumComment"] = clsAutogenToolboxCodeGenerationCSharp.acConvertXmlCommentToCSharpComment(objCommentElement.text)

            if (objRecordElement.attrib["Type"] in G_dctIntTypeToHexStringTotalLength.keys()):
                acIntAsHexString = clsAutogenToolboxCodeGenerationCSharp.acConvertNumberToCSharpFormattedValue(objEnumerationElement.attrib["Value"], objRecordElement.attrib["Type"])

            # Create the line of code for the enumeration value assignment
            dctEnumeration["acEnumName"] = objEnumerationElement.attrib["Name"]
            dctEnumeration["acEnumValue"] = acIntAsHexString

            # Finally add the dictionary to the list
            dctReturn["lstEnumerations"].append(dctEnumeration)

        return(dctReturn)

    @staticmethod
    def dctGenerateTypeStructComplete(dctTypedefStructPar: dict):
        """ This is a public static method which generates a C# struct code.

        Args:
            dctTypedefStructPar (dict): A dictionary containing the information needed to write C# struct files. The keys are:
                * ["acName"] (str)
                * ["acXmlFileName"] (str)
                * ["acXmlFilePath"] (str)
                * ["eTypedefType"] (E_TYPEDEF_XML_FILE_TYPEDEF_TYPE)
                * ["objElement"] (ET.Element)

        Returns:
            (dict): A dictionary with various keys
                * ["acTypedefComment"] (str)
                * ["lstRecords"] (list)
                    * (dict)
                        * ["acRecComment"]
                        * ["acRecName"]
                        * ["acRecDefault"]
                        * ["acRecMin"]
                        * ["acRecMax"]
                        * ["acRecCount"]
                        * ["acRecType"]
                        * ["bRecIsEnum"]

        Raises:
            Raises no exception.
        """
        dctReturn = {}
        dctReturn["acTypedefComment"] = str("")
        dctReturn["acStructName"] = str("")
        dctReturn["lstRecords"] = []

        # This is for the Record(s) in the Struct
        dctRecord = {}
        dctRecord["acRecComment"] = str("")
        dctRecord["acRecName"] = str("")
        dctRecord["acRecDefault"] = str("")
        dctRecord["acRecMin"] = str("")
        dctRecord["acRecMax"] = str("")
        dctRecord["acRecCount"] = "1"
        dctRecord["acRecType"] = str("")
        dctRecord["bRecIsEnum"] = bool(False)

        acTypedefComment = str("")
        objRecordCommentElement = None

        if (dctTypedefStructPar is None):
            logging.error("dctTypedefStructPar cannot be None")
            return(dctReturn)

        objCommentElement = dctTypedefStructPar["objElement"].find("./Comment")

        if ((objCommentElement is not None) and (objCommentElement.text is not None)):
            acTypedefComment = objCommentElement.text
            dctReturn["acTypedefComment"] = clsAutogenToolboxCodeGenerationCSharp.acConvertXmlCommentToCSharpComment(acTypedefComment)

        # Get the Record Element
        lstRecordElements = dctTypedefStructPar["objElement"].findall("./Record")

        if (not lstRecordElements):
            logging.error("Struct %s does not have any Record tags", dctTypedefStructPar["acName"])
            return(dctReturn)

        # Iterate through all the records in the struct
        for objRecord in lstRecordElements:

            # Create a new dictionary for the Record
            dctRecord = {}
            dctRecord["acRecComment"] = str("")
            dctRecord["acRecName"] = str("")
            dctRecord["acRecDefault"] = str("")
            dctRecord["acRecMin"] = str("")
            dctRecord["acRecMax"] = str("")
            dctRecord["acRecCount"] = "1"
            dctRecord["acRecType"] = str("")
            dctRecord["bRecIsEnum"] = bool(False)

            # Get the name of the Record
            dctRecord["acRecName"] = objRecord.attrib["Name"]

            # Get the Default
            if ("Default" in objRecord.attrib):
                dctRecord["acRecDefault"] = objRecord.attrib["Default"]

            # Get Min value
            if ("Min" in objRecord.attrib):
                dctRecord["acRecMin"] = objRecord.attrib["Min"]

            # Get Max value
            if ("Max" in objRecord.attrib):
                dctRecord["acRecMax"] = objRecord.attrib["Max"]

            # Get the Count attribute or set it if it does not exist
            if ("Count" in objRecord.attrib):
                dctRecord["acRecCount"] = objRecord.attrib["Count"]

            # Get the type from the Record
            if (objRecord.attrib["Type"] in G_dctStructRecordTypeToCSharpType.keys()):
                # These are types U1, U2, U4, U8, I1, I2, I4, I8, F4, F8, CH
                dctRecord["acRecType"] = G_dctStructRecordTypeToCSharpType[objRecord.attrib["Type"]]
                dctRecord["bRecIsEnum"] = bool(False)

                # Construct the DataMember DefaultValue, for a base type we can use the Default as is
                if (objRecord.attrib["Default"]):
                    dctRecord["acRecDefault"] = clsAutogenToolboxCodeGenerationCSharp.acConvertNumberToCSharpFormattedValue(objRecord.attrib["Default"], objRecord.attrib["Type"])

                if ("Min" in objRecord.attrib):
                    dctRecord["acRecMin"] = clsAutogenToolboxCodeGenerationCSharp.acConvertNumberToCSharpFormattedValue(objRecord.attrib["Min"], objRecord.attrib["Type"])

                if ("Max" in objRecord.attrib):
                    dctRecord["acRecMax"] = clsAutogenToolboxCodeGenerationCSharp.acConvertNumberToCSharpFormattedValue(objRecord.attrib["Max"], objRecord.attrib["Type"])

            elif (objRecord.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_ENUM)):
                dctRecord["acRecType"] = objRecord.attrib["Type"]
                dctRecord["bRecIsEnum"] = bool(True)

                # Construct the DataMember DefaultValue
                if (dctRecord["acRecDefault"]):
                    dctRecord["acRecDefault"] = dctRecord["acRecDefault"]

            elif (objRecord.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_STRUCT)):
                dctRecord["acRecType"] = objRecord.attrib["Type"]
                dctRecord["bRecIsEnum"] = bool(False)

            # Get the Record Comment child if there is one
            objRecordCommentElement = objRecord.find("./Comment")

            if ((objRecordCommentElement is not None) and (objRecordCommentElement.text is not None)):
                dctRecord["acRecComment"] = clsAutogenToolboxCodeGenerationCSharp.acConvertXmlCommentToCSharpComment(objRecordCommentElement.text)

            # Finally add this dictionary to the list
            dctReturn["lstRecords"].append(dctRecord)

        return(dctReturn)

    @staticmethod
    def dctGenerateMessageComplete(dctMessageHeaderPar: dict, dctMessagePayloadPar: dict, dctModConfMessagePar: dict):
        """ This is a public static method which generates a C# message code.

        Args:
            dctModConfMessagePar (dict): A dictionary containing message header information
            dctMessagePayloadPar (dict): A dictionary containg message payload information
            dctMessageHeaderPar (dict): A dictionary containing the information needed to write C# Definition files

        Returns:
            (dict): A dictionary with various keys
                * ["acMsgComment"] (str)
                * ["acMsgTypeAsString"] (str)
                * ["acMsgTopic"] (str)
                * ["acMsgGroupName"] (str)
                * ["acMsgOwner"] (str)
                * ["lstMsgAccessAttributes"] (list)
                    * (dict)
                        * ["acMsgAccessAttribute"]
                * ["lstMsgHeaderFields"] (list)
                    * (dict)
                        * ["acFieldComment"]
                        * ["acFieldName"]
                        * ["acFieldType"]
                        * ["acFieldDefault"]
                        * ["bFieldIsEnum"]
                * ["lstMsgPayloadFields"] (list)
                    * (dict)
                        * ["acFieldComment"]
                        * ["acFieldName"]
                        * ["acFieldType"]
                        * ["acFieldDefault"]
                        * ["acFieldMin"]
                        * ["acFieldMax"]
                        * ["acFieldCount"]
                        * ["bFieldIsEnum"]

        Raises:
            Raises no exception.
        """
        dctReturn = {}
        dctReturn["acMsgComment"] = str("")
        dctReturn["acMsgOwner"] = str("")
        dctReturn["acMsgTypeAsString"] = str("")
        dctReturn["acMsgTopic"] = str("")
        dctReturn["lstMsgAccessAttributes"] = []
        dctReturn["lstMsgHeaderFields"] = []
        dctReturn["lstMsgPayloadFields"] = []

        dctMsgField = {}
        dctMsgField["acFieldComment"] = str("")
        dctMsgField["acFieldName"] = str("")
        dctMsgField["acFieldType"] = str("")
        dctMsgField["acFieldDefault"] = str("")
        dctMsgField["acFieldMin"] = str("")
        dctMsgField["acFieldMax"] = str("")
        dctMsgField["acFieldCount"] = str("")
        dctMsgField["bFieldIsEnum"] = str("")

        lstMsgTypes = ["Cmd", "CmdRsp", "Req", "ReqRsp", "Unsol"]

        objMessageElement = None
        objMessageCommentElement = None
        objFieldCommentElement = None

        acMessageAccessAttribute = str("")
        lstMsgAccessAttributes = []
        lstMsgHeaderFieldsFields = []
        lstMsgPayloadFieldsFields = []

        # Do some sanity checks

        if (dctMessageHeaderPar is None):
            logging.error("dctMessageHeaderPar cannot be None")
            return(dctReturn)

        if (dctMessagePayloadPar is None):
            logging.error("dctMessagePayloadPar cannot be None")
            return(dctReturn)

        if (dctModConfMessagePar is None):
            logging.error("dctModConfMessagePar cannot be None")
            return(dctReturn)

        # Make sure the message name of the Header is the same as the Payload
        if (dctMessageHeaderPar["acName"] != dctMessagePayloadPar["acName"]):
            logging.error("The message name in the Header and Payload are different - something went wrong")
            return(dctReturn)

        # Look at the postfix of the message name - see if it is Cmd, CmdRsp, Req, ReqRsp, Unsol
        for acFieldType in lstMsgTypes:
            if (dctMessageHeaderPar["acName"].endswith(acFieldType) is True):
                dctReturn["acMsgTypeAsString"] = acFieldType
                break

        # If we don't know what type of message this is then abort
        if (not dctReturn["acMsgTypeAsString"]):
            logging.error("Message name %s is invalid", dctMessageHeaderPar["acName"])
            return(dctReturn)

        # Start the Access Control Attribute definitions (limited to RBAC)
        if (dctModConfMessagePar["lstRoles"]):
            # Iterate through all the roles and add with "Role" prefix to qualify this attribute
            # to a Role based rule check by the HMI
            for acRole in dctModConfMessagePar["lstRoles"]:
                acMessageAccessAttribute = "Role.%s" % (acRole)
                lstMsgAccessAttributes.append(acMessageAccessAttribute)

        # Get the Message Element
        objMessageElement = dctMessageHeaderPar["objMessageElement"]

        # Get the Comment Element as a child of the Message Element
        objMessageCommentElement = objMessageElement.find("./Comment")

        if ((objMessageCommentElement is not None) and (objMessageCommentElement.text is not None)):
            dctReturn["acMsgComment"] = clsAutogenToolboxCodeGenerationCSharp.acConvertXmlCommentToCSharpComment(objMessageCommentElement.text)

        acMsgOwner = dctModConfMessagePar["acMsgDefFileName"][:-8].title()
        dctReturn["acNamespace"] = "%s.%s" % (dctModConfMessagePar["acModule"], dctModConfMessagePar["acMessageName"])
        dctReturn["acMsgOwner"] = acMsgOwner
        dctReturn["acMsgTopic"] = "%s/%s/%s" % (dctModConfMessagePar["acSystem"], dctModConfMessagePar["acModule"], dctModConfMessagePar["acMessageName"])
        dctReturn["acMessageDirection"] = "Subscribe" if dctModConfMessagePar["eMessageFlowDirection"].name == 'MESSAGE_FLOW_DIRECTION_SUBSCRIBE' else "Publish"
        dctReturn["acMessageName"] = dctModConfMessagePar["acMessageName"]

        startsAt = (len(acMsgOwner) if dctReturn["acMessageName"].startswith(acMsgOwner) else 0)
        endsAt = -len(acFieldType) if acFieldType.endswith(acFieldType) else None
        dctReturn["acMsgGroupName"] = dctReturn["acMessageName"][startsAt:endsAt]

        # Iterate through the header fields
        # Iterate through the header fields
        # Iterate through the header fields

        for objHeaderFieldElement in dctMessageHeaderPar["lstFieldElements"]:

            dctMsgField = {}
            dctMsgField["acFieldComment"] = str("")
            dctMsgField["acFieldName"] = str("")
            dctMsgField["acFieldType"] = str("")
            dctMsgField["acFieldDefault"] = str("")
            dctMsgField["bFieldIsEnum"] = str("")

            # Get the field Comment Element
            objFieldCommentElement = objHeaderFieldElement.find("./Comment")

            # Then check if this Field has a Comment child tag
            if ((objFieldCommentElement is not None) and (objFieldCommentElement.text is not None)):
                dctMsgField["acFieldComment"] = clsAutogenToolboxCodeGenerationCSharp.acConvertXmlCommentToCSharpComment(objFieldCommentElement.text)

            # Get the name of the Message
            dctMsgField["acFieldName"] = objHeaderFieldElement.attrib["Name"]

            # Get the Default
            if ("Default" in objHeaderFieldElement.attrib):
                dctMsgField["acFieldDefault"] = objHeaderFieldElement.attrib["Default"]

            # The header will either be a base type or an enumeration - structs are not used
            if (objHeaderFieldElement.attrib["Type"] in G_dctStructRecordTypeToCSharpType.keys()):
                # These are types U1, U2, U4, U8, I1, I2, I4, I8, F4, F8, CH
                dctMsgField["acFieldType"] = G_dctStructRecordTypeToCSharpType[objHeaderFieldElement.attrib["Type"]]
                dctMsgField["bFieldIsEnum"] = bool(False)

                # Construct the DataMember DefaultValue, for a base type we can use the Default as is
                if (objHeaderFieldElement.attrib["Default"]):
                    dctMsgField["acFieldDefault"] = clsAutogenToolboxCodeGenerationCSharp.acConvertNumberToCSharpFormattedValue(objHeaderFieldElement.attrib["Default"], objHeaderFieldElement.attrib["Type"])

            elif (objHeaderFieldElement.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_ENUM)):
                dctMsgField["acFieldType"] = objHeaderFieldElement.attrib["Type"]
                dctMsgField["bFieldIsEnum"] = bool(True)

                # Construct the DataMember DefaultValue
                if (dctMsgField["acFieldDefault"]):
                    dctMsgField["acFieldDefault"] = dctMsgField["acFieldDefault"]

            elif (objHeaderFieldElement.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_STRUCT)):
                dctMsgField["acFieldType"] = objHeaderFieldElement.attrib["Type"]
                dctMsgField["bFieldIsEnum"] = bool(False)

            # Finally add this dictionary to the header fields list
            lstMsgHeaderFieldsFields.append(dctMsgField)

        # Iterate through the payload fields
        # Iterate through the payload fields
        # Iterate through the payload fields

        for objPayloadFieldElement in dctMessagePayloadPar["lstFieldElements"]:

            dctMsgField = {}
            dctMsgField["acFieldComment"] = str("")
            dctMsgField["acFieldName"] = str("")
            dctMsgField["acFieldType"] = str("")
            dctMsgField["acFieldDefault"] = str("")
            dctMsgField["acFieldMin"] = str("")
            dctMsgField["acFieldMax"] = str("")
            dctMsgField["acFieldCount"] = str("")
            dctMsgField["bFieldIsEnum"] = str("")

            # Get the field Comment Element
            objFieldCommentElement = objPayloadFieldElement.find("./Comment")

            # Then check if this Field has a Comment child tag
            if ((objFieldCommentElement is not None) and (objFieldCommentElement.text is not None)):
                dctMsgField["acFieldComment"] = clsAutogenToolboxCodeGenerationCSharp.acConvertXmlCommentToCSharpComment(objFieldCommentElement.text)

            # Get the name of the Message
            dctMsgField["acFieldName"] = objPayloadFieldElement.attrib["Name"]

            # Get the Default
            if ("Default" in objPayloadFieldElement.attrib):
                dctMsgField["acFieldDefault"] = objPayloadFieldElement.attrib["Default"]

            # Get Min value
            if ("Min" in objPayloadFieldElement.attrib):
                dctMsgField["acFieldMin"] = objPayloadFieldElement.attrib["Min"]

            # Get Max value
            if ("Max" in objPayloadFieldElement.attrib):
                dctMsgField["acFieldMax"] = objPayloadFieldElement.attrib["Max"]

            # Get the Count attribute or set it if it does not exist
            if ("Count" in objPayloadFieldElement.attrib):
                dctMsgField["acFieldCount"] = objPayloadFieldElement.attrib["Count"]

            # The header will either be a base type or an enumeration - structs are not used
            if (objPayloadFieldElement.attrib["Type"] in G_dctStructRecordTypeToCSharpType.keys()):
                # These are types U1, U2, U4, U8, I1, I2, I4, I8, F4, F8, CH
                dctMsgField["acFieldType"] = G_dctStructRecordTypeToCSharpType[objPayloadFieldElement.attrib["Type"]]
                dctMsgField["bFieldIsEnum"] = bool(False)

                # Construct the DataMember DefaultValue, for a base type we can use the Default as is
                if (objPayloadFieldElement.attrib["Default"]):
                    dctMsgField["acFieldDefault"] = clsAutogenToolboxCodeGenerationCSharp.acConvertNumberToCSharpFormattedValue(objPayloadFieldElement.attrib["Default"], objPayloadFieldElement.attrib["Type"])

                if ("Mix" in objPayloadFieldElement.attrib):
                    dctMsgField["acFieldMin"] = clsAutogenToolboxCodeGenerationCSharp.acConvertNumberToCSharpFormattedValue(objPayloadFieldElement.attrib["Min"], objPayloadFieldElement.attrib["Type"])

                if ("Max" in objPayloadFieldElement.attrib):
                    dctMsgField["acFieldMax"] = clsAutogenToolboxCodeGenerationCSharp.acConvertNumberToCSharpFormattedValue(objPayloadFieldElement.attrib["Max"], objPayloadFieldElement.attrib["Type"])

            elif (objPayloadFieldElement.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_ENUM)):
                dctMsgField["acFieldType"] = objPayloadFieldElement.attrib["Type"]
                dctMsgField["bFieldIsEnum"] = bool(True)

                # Construct the DataMember DefaultValue
                if (dctMsgField["acFieldDefault"]):
                    dctMsgField["acFieldDefault"] = dctMsgField["acFieldDefault"]

            elif (objPayloadFieldElement.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_STRUCT)):
                dctMsgField["acFieldType"] = objPayloadFieldElement.attrib["Type"]
                dctMsgField["bFieldIsEnum"] = bool(False)

            # Finally add this dictionary to the payload fields list
            lstMsgPayloadFieldsFields.append(dctMsgField)

        dctReturn["lstMsgAccessAttributes"] = lstMsgAccessAttributes
        dctReturn["lstMsgHeaderFields"] = lstMsgHeaderFieldsFields
        dctReturn["lstMsgPayloadFields"] = lstMsgPayloadFieldsFields

        return(dctReturn)
