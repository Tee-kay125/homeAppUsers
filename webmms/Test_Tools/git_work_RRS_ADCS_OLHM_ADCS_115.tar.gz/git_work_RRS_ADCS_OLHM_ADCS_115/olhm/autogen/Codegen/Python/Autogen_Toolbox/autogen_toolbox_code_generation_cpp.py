#!/usr/bin/env python3.6
# -*- coding: utf-8 -*-
""" This module provides a class which provides C++ code generation

"""
import logging
import os  # We need this to split filenames into base and extension
import re  # We need this to split tokens
from Autogen_Toolbox.autogen_toolbox_definition_validation_and_et_finding import E_TYPEDEF_XML_FILE_TYPEDEF_TYPE  # noqa: F401  # pylint: disable=unused-import
from Autogen_Toolbox.autogen_toolbox_definition_validation_and_et_finding import E_FIELD_OR_RECORD_TYPE
from Autogen_Toolbox.autogen_toolbox_definition_validation_and_et_finding import E_COMMS_PROTOCOL
from Autogen_Toolbox.autogen_toolbox_definition_validation_and_et_finding import E_MESSAGE_FLOW_DIRECTION


# This dictionary's key is a tuple
# The tuple's fields are:
#  * The base type (str)
#  * Does the the field have count greater than 1 (bool)
G_dctTypeToCppFieldPrefix = {}
G_dctTypeToCppFieldPrefix[("U1", False)] = str("u1")
G_dctTypeToCppFieldPrefix[("U2", False)] = str("u2")
G_dctTypeToCppFieldPrefix[("U4", False)] = str("u4")
G_dctTypeToCppFieldPrefix[("U8", False)] = str("u8")
G_dctTypeToCppFieldPrefix[("I1", False)] = str("i1")
G_dctTypeToCppFieldPrefix[("I2", False)] = str("i2")
G_dctTypeToCppFieldPrefix[("I4", False)] = str("i4")
G_dctTypeToCppFieldPrefix[("I8", False)] = str("i8")
G_dctTypeToCppFieldPrefix[("F4", False)] = str("f4")
G_dctTypeToCppFieldPrefix[("F8", False)] = str("f8")
G_dctTypeToCppFieldPrefix[("CH", False)] = str("ach")
G_dctTypeToCppFieldPrefix[("U1", True)] = str("au1")
G_dctTypeToCppFieldPrefix[("U2", True)] = str("au2")
G_dctTypeToCppFieldPrefix[("U4", True)] = str("au4")
G_dctTypeToCppFieldPrefix[("U8", True)] = str("au8")
G_dctTypeToCppFieldPrefix[("I1", True)] = str("ai1")
G_dctTypeToCppFieldPrefix[("I2", True)] = str("ai2")
G_dctTypeToCppFieldPrefix[("I4", True)] = str("ai4")
G_dctTypeToCppFieldPrefix[("I8", True)] = str("ai8")
G_dctTypeToCppFieldPrefix[("F4", True)] = str("af4")
G_dctTypeToCppFieldPrefix[("F8", True)] = str("af8")
G_dctTypeToCppFieldPrefix[("CH", True)] = str("ach")


# This dictionary's key is a tuple
# The tuple's fields are:
#  * The base type (str)
#  * Does the the field have count greater than 1 (bool)
G_dctEnumTypeToCppFieldPrefix = {}
G_dctEnumTypeToCppFieldPrefix[("E1", False)] = str("e1")
G_dctEnumTypeToCppFieldPrefix[("E2", False)] = str("e2")
G_dctEnumTypeToCppFieldPrefix[("E4", False)] = str("e4")
G_dctEnumTypeToCppFieldPrefix[("E8", False)] = str("e8")
G_dctEnumTypeToCppFieldPrefix[("E1", True)] = str("ae1")
G_dctEnumTypeToCppFieldPrefix[("E2", True)] = str("ae2")
G_dctEnumTypeToCppFieldPrefix[("E4", True)] = str("ae4")
G_dctEnumTypeToCppFieldPrefix[("E8", True)] = str("ae8")


# This dictionary's key is a tuple
# The tuple's fields are:
#  * Does the the field have count greater than 1 (bool)
G_dctStructTypeToCppFieldPrefix = {}
G_dctStructTypeToCppFieldPrefix[False] = str("s")
G_dctStructTypeToCppFieldPrefix[True] = str("as")


class clsAutogenToolboxCodeGenerationCpp():
    """ This class provides a class which provides C++ code generation


    """

    @staticmethod
    def acMessageNamePascalCaseToCapUnderscores(acMessageNamePar: str):
        """ This is a public static method takes a struct name and converts into a Pascal case name

        Args:
            acStructNamePar (str): The enum name to converted into Pascal case.

        Returns:
            (str): The Pascal case result

        Raises:
            Raises no exception.
        """
        acCapUnderscoresResult = str("")
        lstTokens = []
        lstUppercaseTokens = []

        if (acMessageNamePar is None):
            logging.error("acMessageNamePar cannot be None")
            return(acCapUnderscoresResult)

        if (isinstance(acMessageNamePar, str) is False):
            logging.error("acMessageNamePar must be a string")
            return(acCapUnderscoresResult)

        if (not acMessageNamePar):
            return(acCapUnderscoresResult)

        # See if there are any uppercase letters - create a generator
        if (sum(1 for acChar in acMessageNamePar if acChar.isupper()) == 0):
            acCapUnderscoresResult = acMessageNamePar
            return(acCapUnderscoresResult)

        # Split the tokens on an uppercase letter
        lstTokens = re.findall('[a-zA-Z][^A-Z]*', acMessageNamePar)
        # Turn the tokens into uppercase
        lstUppercaseTokens = [acToken.upper() for acToken in lstTokens]
        # Join the tokens with an underscore
        acCapUnderscoresResult = "_".join(lstUppercaseTokens)

        return(acCapUnderscoresResult)

    @staticmethod
    def acGenerateTypeEnumComplete(dctTypedefEnumPar: dict):
        """ This is a public static method which generates a C++ typedef code.

        Args:
            dctTypedefEnumPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["acName"] (str)
                * ["acXmlFileName"] (str)
                * ["acXmlFilePath"] (str)
                * ["eTypedefType"] (E_TYPEDEF_XML_FILE_TYPEDEF_TYPE)
                * ["objElement"] (ET.Element)

        Returns:
            (str): A string with the entire code block which represents the enum type in C++

        Raises:
            Raises no exception.
        """
        acCodeBlock = str("")  # String to store the entire code block
        objRecordElement = None
        lstEnumerationElements = []

        if (dctTypedefEnumPar is None):
            logging.error("dctTypedefEnumPar cannot be None")
            return(acCodeBlock)

        # Get the Record Element
        objRecordElement = dctTypedefEnumPar["objElement"].find("./Record")

        if (objRecordElement is None):
            logging.error("Enum %s does not have an Record tag", dctTypedefEnumPar["acName"])
            return(acCodeBlock)

        # Get all the Enumeration Elements
        lstEnumerationElements = dctTypedefEnumPar["objElement"].findall("./Record/Enumeration")

        if (not lstEnumerationElements):
            logging.error("Enum %s does not have any Enumeration tags", dctTypedefEnumPar["acName"])
            return(acCodeBlock)

        # Now that we have gathered the Enumeration Elements we need start preparing the code block
        acCodeBlock = str("typedef enum: %s\n" % objRecordElement.attrib["Type"])
        acCodeBlock += str("{\n")

        for objEnumerationElement in lstEnumerationElements:
            acCodeBlock += "  %s = %s,\n" % (objEnumerationElement.attrib["Name"], objEnumerationElement.attrib["Value"])

        acCodeBlock += str("} %s;\n" % (dctTypedefEnumPar["acName"]))

        return(acCodeBlock)

    @staticmethod
    def acGenerateTypeStructComplete(dctTypedefStructPar: dict, bGenerateConstructor: bool = True, bGenerateValidationMethods: bool = True):
        """ This is a public static method which generates a C++ typedef struct code.

        Args:
            dctTypedefStructPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["acName"] (str)
                * ["acXmlFileName"] (str)
                * ["acXmlFilePath"] (str)
                * ["eTypedefType"] (E_TYPEDEF_XML_FILE_TYPEDEF_TYPE)
                * ["objElement"] (ET.Element)
            bGenerateConstructor (bool): Flag to indicate if a constructor should be generated.

        Returns:
            (str): A string with the entire code block which represents the enum type in C++

        Raises:
            Raises no exception.
        """
        acCodeBlock = str("")  # String to store the entire code block
        lstRecordElements = []
        tplTypeToCppFieldPrefix = ("U1", bool(False))  # These are just startup values see G_dctTypeToCppFieldPrefix for detail description
        acArrayParenthesesText = str("")
        acNamePrefix = str("")
        bIsCountGreaterThanOne = bool(False)
        iCount = int(0)
        lstConstructorLines = []
        acConstructorLine = str("")
        lstDefinitionLines = []
        acDefinitionLine = str("")
        lstValidationLines = []
        acValidationLine = str("")
        lstStrToStringLines = []
        acStrToStringLine = str("")

        if (dctTypedefStructPar is None):
            logging.error("dctTypedefStructPar cannot be None")
            return(acCodeBlock)

        # Get the Record Element

        lstRecordElements = dctTypedefStructPar["objElement"].findall("./Record")

        if (not lstRecordElements):
            logging.error("Struct %s does not have any Record tags", dctTypedefStructPar["acName"])
            return(acCodeBlock)

        # Iterate through all the records in the struct
        for objRecord in lstRecordElements:

            acNamePrefix = str("")
            acArrayParenthesesText = str("")
            acDefinitionLine = str("")
            acConstructorLine = str("")
            acValidationLine = str("")
            acStrToStringLine = str("")

            # Make sure the Count attribute is there
            if ("Count" not in objRecord.attrib):
                logging.error("Attribute Count missing from %s", objRecord.attrib["Name"])
                continue

            try:
                iCount = int(objRecord.attrib["Count"])
            except Exception as E:
                logging.error("Attribute Count from %s is probably not an int - Exception %s", objRecord.attrib["Name"], str(E))
                continue

            if (iCount <= 0):
                logging.error("Attribute Count from %s is not allowed to be less than 1", objRecord.attrib["Name"])
                continue

            bIsCountGreaterThanOne = iCount > 1

            if ((bIsCountGreaterThanOne is True) or (objRecord.attrib["Type"] == "CH")):
                acArrayParenthesesText = "[%s]" % objRecord.attrib["Count"]

            # This attribute "eRecordType" came from autogen_toolbox_definition_validation_and_et_finding.py methods bValidateFieldOrRecordElementRecursively() and tplValidateMsgDefPayloadFromRootElement() and bValidateTypedefOfTypeStruct()
            if (objRecord.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_ENUM)):
                acNamePrefix = G_dctEnumTypeToCppFieldPrefix[(objRecord.attrib["Type"][:2], bIsCountGreaterThanOne)]
                acDefinitionLine += "  %s %s%s%s;\n" % (objRecord.attrib["Type"], acNamePrefix, objRecord.attrib["Name"], acArrayParenthesesText)

                acValidationLine += "    {\n"
                acValidationLine += "      bool bReturnEnumValid = false;\n"
                acValidationLine += "      %s aeValid%s[%s] = {" % (objRecord.attrib["Type"], objRecord.attrib["Name"], str(len(objRecord.attrib["lstAllEnumValuesAsStr"])))

                for acEnumValue in objRecord.attrib["lstAllEnumValuesAsStr"]:
                    acValidationLine += "%s," % (acEnumValue)

                acValidationLine += "};\n"

                if (iCount <= 1):
                    acValidationLine += "      for (U4 u4EnumCounter = 0; u4EnumCounter < %s; u4EnumCounter++)\n" % (str(len(objRecord.attrib["lstAllEnumValuesAsStr"])))
                    acValidationLine += "      {\n"
                    acValidationLine += "        bReturnEnumValid |= (%s%s == aeValid%s[u4EnumCounter]);\n" % (acNamePrefix, objRecord.attrib["Name"], objRecord.attrib["Name"])
                    acValidationLine += "      }\n"
                    acValidationLine += "      bReturn &= bReturnEnumValid;\n"
                    acValidationLine += "      if (bReturn == false)\n"
                    acValidationLine += "      {\n"
                    acValidationLine += "        errorMsg += \".%s%s: \" + std::to_string(%s%s) + \" is invalid\\n\";\n" % (acNamePrefix, objRecord.attrib["Name"], acNamePrefix, objRecord.attrib["Name"])
                    acValidationLine += "        return(bReturn);\n"
                    acValidationLine += "      }\n"

                else:
                    acValidationLine += "      for (U4 u4Counter = 0; u4Counter < %s; u4Counter++)\n" % (iCount)
                    acValidationLine += "      {\n"
                    acValidationLine += "        bReturnEnumValid = false;\n"
                    acValidationLine += "        for (U4 u4EnumCounter = 0; u4EnumCounter < %s; u4EnumCounter++)\n" % (str(len(objRecord.attrib["lstAllEnumValuesAsStr"])))
                    acValidationLine += "        {\n"
                    acValidationLine += "          bReturnEnumValid |= (%s%s[u4Counter] == aeValid%s[u4EnumCounter]);\n" % (acNamePrefix, objRecord.attrib["Name"], objRecord.attrib["Name"])
                    acValidationLine += "        }\n"
                    acValidationLine += "        bReturn &= bReturnEnumValid;\n"
                    acValidationLine += "        if (bReturn == false)\n"
                    acValidationLine += "        {\n"
                    acValidationLine += "          errorMsg += \".%s%s[\" + std::to_string(u4Counter) + \"]: \" + std::to_string(%s%s[u4Counter]) + \" is invalid\\n\";\n" % (acNamePrefix, objRecord.attrib["Name"], acNamePrefix, objRecord.attrib["Name"])
                    acValidationLine += "          return(bReturn);\n"
                    acValidationLine += "        }\n"

                    acValidationLine += "      }\n"

                acValidationLine += "    }\n"

                if (iCount <= 1):
                    acConstructorLine += "    %s%s = %s;\n" % (acNamePrefix, objRecord.attrib["Name"], objRecord.attrib["Default"])

                    acStrToStringLine += "    strReturn += strParentPar + \".%s%s: \" + std::to_string(%s%s) + \"\\n\";\n" % (acNamePrefix, objRecord.attrib["Name"], acNamePrefix, objRecord.attrib["Name"])

                else:
                    acConstructorLine += "    for (U4 u4Counter = 0; u4Counter < %s; u4Counter++)\n" % (iCount)
                    acConstructorLine += "    {\n"
                    acConstructorLine += "      %s%s[u4Counter] = %s;\n" % (acNamePrefix, objRecord.attrib["Name"], objRecord.attrib["Default"])
                    acConstructorLine += "    }\n"

                    acStrToStringLine += "    for (U4 u4Counter = 0; u4Counter < %s; u4Counter++)\n" % (iCount)
                    acStrToStringLine += "    {\n"
                    acStrToStringLine += "      strReturn += strParentPar + \".%s%s[\" + std::to_string(u4Counter) + \"]: \" + std::to_string(%s%s[u4Counter]) + \"\\n\";\n" % (acNamePrefix, objRecord.attrib["Name"], acNamePrefix, objRecord.attrib["Name"])
                    acStrToStringLine += "    }\n"

            elif (objRecord.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_STRUCT)):
                acNamePrefix = G_dctStructTypeToCppFieldPrefix[bIsCountGreaterThanOne]
                acDefinitionLine += "  %s %s%s%s;\n" % (objRecord.attrib["Type"], acNamePrefix, objRecord.attrib["Name"], acArrayParenthesesText)

                # Generate code for the constructor
                if (iCount <= 1):
                    acConstructorLine += "    %s%s = %s();\n" % (acNamePrefix, objRecord.attrib["Name"], objRecord.attrib["Type"])

                    acValidationLine += "    tmpErrorMsg = errorMsg + \".%s%s\";\n" % (acNamePrefix, objRecord.attrib["Name"])
                    acValidationLine += "    bReturn &= %s%s.bValidate(tmpErrorMsg);\n" % (acNamePrefix, objRecord.attrib["Name"])
                    acValidationLine += "    if (bReturn == false)\n"
                    acValidationLine += "    {\n"
                    acValidationLine += "      errorMsg = tmpErrorMsg;\n"
                    acValidationLine += "      return(bReturn);\n"
                    acValidationLine += "    }\n"

                    acStrToStringLine += "    strReturn += strParentPar + %s%s.strToString(strParentPar + \".%s%s\");\n" % (acNamePrefix, objRecord.attrib["Name"], acNamePrefix, objRecord.attrib["Name"])

                else:
                    acConstructorLine += "    for (U4 u4Counter = 0; u4Counter < %s; u4Counter++)\n" % (iCount)
                    acConstructorLine += "    {\n"
                    acConstructorLine += "      %s%s[u4Counter] = %s();\n" % (acNamePrefix, objRecord.attrib["Name"], objRecord.attrib["Type"])
                    acConstructorLine += "    }\n"

                    acValidationLine += "    for (U4 u4Counter = 0; u4Counter < %s; u4Counter++)\n" % (iCount)
                    acValidationLine += "    {\n"
                    acValidationLine += "      tmpErrorMsg = errorMsg + \".%s%s[\" + std::to_string(u4Counter) + \"]\";\n" % (acNamePrefix, objRecord.attrib["Name"])
                    acValidationLine += "      bReturn &= %s%s[u4Counter].bValidate(tmpErrorMsg);\n" % (acNamePrefix, objRecord.attrib["Name"])
                    acValidationLine += "      if (bReturn == false)\n"
                    acValidationLine += "      {\n"
                    acValidationLine += "        errorMsg = tmpErrorMsg;\n"
                    acValidationLine += "        return(bReturn);\n"
                    acValidationLine += "      }\n"

                    acValidationLine += "    }\n"

                    acStrToStringLine += "    for (U4 u4Counter = 0; u4Counter < %s; u4Counter++)\n" % (iCount)
                    acStrToStringLine += "    {\n"
                    acStrToStringLine += "      strReturn += strParentPar + %s%s[u4Counter].strToString(strParentPar + \".%s%s[\" + std::to_string(u4Counter) + \"]\");\n" % (acNamePrefix, objRecord.attrib["Name"], acNamePrefix, objRecord.attrib["Name"])
                    acStrToStringLine += "    }\n"

            elif (objRecord.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_BASE)):
                tplTypeToCppFieldPrefix = (objRecord.attrib["Type"], objRecord.attrib["Count"] != "1")
                acDefinitionLine += "  %s %s%s%s;\n" % (objRecord.attrib["Type"], G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"], acArrayParenthesesText)

                if (objRecord.attrib["Type"] == "CH"):

                    if ("Default" in objRecord.attrib):
                        acConstructorLine += "    strncpy(%s%s,\"%s\",%s);\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"], objRecord.attrib["Default"], objRecord.attrib["Count"])
                    else:
                        logging.error("Record with name %s does not have a Default", objRecord.attrib["Name"])

                    acValidationLine += "    // No validity check on %s%s because it is a char array - nothing to check\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"])

                    acStrToStringLine += "    strReturn += strParentPar + \".%s%s: \" + std::string(%s%s, %s) + \"\\n\";\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"], G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"], objRecord.attrib["Count"])

                elif (bIsCountGreaterThanOne is False):
                    acConstructorLine += "    %s%s = %s;\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"], objRecord.attrib["Default"])

                    if ("Min" in objRecord.attrib):
                        acValidationLine += "    bReturn &= (%s%s >= %s);\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"], objRecord.attrib["Min"])
                        acValidationLine += "    if (bReturn == false)\n"
                        acValidationLine += "    {\n"
                        acValidationLine += "      errorMsg += \".%s%s: \" + std::to_string(%s%s) + \" is invalid\\n\";\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"], G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"])
                        acValidationLine += "      return(bReturn);\n"
                        acValidationLine += "    }\n"

                    if ("Max" in objRecord.attrib):
                        acValidationLine += "    bReturn &= (%s%s <= %s);\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"], objRecord.attrib["Max"])
                        acValidationLine += "    if (bReturn == false)\n"
                        acValidationLine += "    {\n"
                        acValidationLine += "      errorMsg += \".%s%s: \" + std::to_string(%s%s) + \" is invalid\\n\";\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"], G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"])
                        acValidationLine += "      return(bReturn);\n"
                        acValidationLine += "    }\n"

                    acStrToStringLine += "    strReturn += strParentPar + \".%s%s: \" + std::to_string(%s%s) + \"\\n\";\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"], G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"])

                else:
                    acConstructorLine += "    for (U4 u4Counter = 0; u4Counter < %s; u4Counter++)\n" % (iCount)
                    acConstructorLine += "    {\n"
                    acConstructorLine += "      %s%s[u4Counter] = %s;\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"], objRecord.attrib["Default"])
                    acConstructorLine += "    }\n"

                    acValidationLine += "    for (U4 u4Counter = 0; u4Counter < %s; u4Counter++)\n" % (iCount)
                    acValidationLine += "    {\n"

                    if ("Min" in objRecord.attrib):
                        acValidationLine += "      bReturn &= (%s%s[u4Counter] >= %s);\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"], objRecord.attrib["Min"])
                        acValidationLine += "      if (bReturn == false)\n"
                        acValidationLine += "      {\n"
                        acValidationLine += "        errorMsg += \".%s%s[\" + std::to_string(u4Counter) + \"]: \" + std::to_string(%s%s[u4Counter]) + \" is invalid\\n\";\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"], G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"])
                        acValidationLine += "        return(bReturn);\n"
                        acValidationLine += "      }\n"

                    if ("Max" in objRecord.attrib):
                        acValidationLine += "      bReturn &= (%s%s[u4Counter] <= %s);\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"], objRecord.attrib["Max"])
                        acValidationLine += "      if (bReturn == false)\n"
                        acValidationLine += "      {\n"
                        acValidationLine += "        errorMsg += \".%s%s[\" + std::to_string(u4Counter) + \"]: \" + std::to_string(%s%s[u4Counter]) + \" is invalid\\n\";\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"], G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"])
                        acValidationLine += "        return(bReturn);\n"
                        acValidationLine += "      }\n"

                    acValidationLine += "    }\n"

                    acStrToStringLine += "    for (U4 u4Counter = 0; u4Counter < %s; u4Counter++)\n" % (iCount)
                    acStrToStringLine += "    {\n"
                    acStrToStringLine += "      strReturn += strParentPar + \".%s%s[\" + std::to_string(u4Counter) + \"]: \" + std::to_string(%s%s[u4Counter]) + \"\\n\";\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"], G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objRecord.attrib["Name"])
                    acStrToStringLine += "    }\n"

            lstDefinitionLines.append(acDefinitionLine)
            lstConstructorLines.append(acConstructorLine)
            lstValidationLines.append(acValidationLine)
            lstStrToStringLines.append(acStrToStringLine)

        # Now that we have gathered the Record Elements we need start preparing the code block
        acCodeBlock = str("typedef struct %s\n" % (dctTypedefStructPar["acName"]))
        acCodeBlock += str("{\n")

        for acDefinitionLine in lstDefinitionLines:

            # Add each line of definition
            acCodeBlock += acDefinitionLine

        # Add the constructor code is enabled
        if (bGenerateConstructor is True):
            acCodeBlock += "\n"
            acCodeBlock += "  %s()\n" % (dctTypedefStructPar["acName"])
            acCodeBlock += "  {\n"

            for acConstructorLine in lstConstructorLines:
                acCodeBlock += acConstructorLine

            acCodeBlock += "  }\n"
            acCodeBlock += "\n"

        # Add the validation code if enabled
        if (bGenerateValidationMethods is True):
            acCodeBlock += "\n"
            acCodeBlock += "  bool bValidate(std::string& errorMsg)\n"
            acCodeBlock += "  {\n"
            acCodeBlock += "    bool bReturn = true; //We always start as valid\n"
            acCodeBlock += "    std::string tmpErrorMsg = \"\";\n"

            for acValidationLine in lstValidationLines:
                acCodeBlock += acValidationLine

            acCodeBlock += "    return(bReturn);\n"
            acCodeBlock += "  }\n"
            acCodeBlock += "\n"

        # Add the strToString() code
        acCodeBlock += "\n"
        acCodeBlock += "  std::string strToString(std::string strParentPar)\n"
        acCodeBlock += "  {\n"
        acCodeBlock += "    std::string strReturn = \"\";\n"

        for acStrToStringLine in lstStrToStringLines:
            acCodeBlock += acStrToStringLine

        acCodeBlock += "    return(strReturn);\n"
        acCodeBlock += "  }\n"
        acCodeBlock += "\n"

        acCodeBlock += str("} __attribute__ ((packed)) %s;\n" % (dctTypedefStructPar["acName"]))

        return(acCodeBlock)

    @staticmethod
    def acGenerateTypeEnumEnumeration(dctTypedefEnumPar: dict):
        """ This is a public static method which generates a C++ Enumeration line inside a Enum Typedef code block

        Args:
            dctTypedefEnumPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["acName"] (str)
                * ["acXmlFileName"] (str)
                * ["acXmlFilePath"] (str)
                * ["eTypedefType"] (E_TYPEDEF_XML_FILE_TYPEDEF_TYPE)
                * ["objElement"] (ET.Element)

        Returns:
            (str): A string with the entire code block which represents the enum type in C++

        Raises:
            Raises no exception.
        """
        acCodeBlock = str("typedef enum\n")
        acCodeBlock += str("{\n")
        acCodeBlock += str("} %s;\n" % (dctTypedefEnumPar["acName"]))

        return(acCodeBlock)

    @staticmethod
    def lstGenerateCppHeaders(dctMsgDefXmlFilePar: dict, bGenerateConstructorPar: bool = True, bGenerateValidationMethodsPar: bool = True):
        """ This is a public static method which generates C++ header code.

        Args:
            dctMsgDefXmlFilePar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["objElementTreeRoot"] (str)
            bGenerateConstructorPar (bool): A flag to indicate if constructors should be generated.
            bGenerateValidationMethodsPar (bool): A flag to indicate if validation methods should be generated

        Returns:
            (str): A string with the entire code block which represents the enum type in C++

        Raises:
            Raises no exception.
        """
        acReturnCodeBlock = str("")
        lstReturnHeaders = []
        lstFieldElements = []
        acArrayParenthesesText = str("")
        lstConstructorLines = []
        acConstructorLine = str("")
        lstDefinitionLines = []
        acDefinitionLine = str("")
        lstValidationLines = []
        acValidationLine = str("")
        lstStrToStringLines = []
        acStrToStringLine = str("")
        lstMessageHeaderDictItems = []
        acNamePrefix = str("")

        if (dctMsgDefXmlFilePar is None):
            logging.error("dctMsgDefXmlFilePar cannot be None")
            return(lstReturnHeaders)

        if ("tplValidMessageHeaders" not in dctMsgDefXmlFilePar):
            logging.error("Key tplValidMessageHeaders not in dctMsgDefXmlFilePar for %s", dctMsgDefXmlFilePar["acFileName"])
            return(lstReturnHeaders)

        if (dctMsgDefXmlFilePar["tplValidMessageHeaders"][0] is False):
            logging.error("Key tplValidMessageHeaders not in dctMsgDefXmlFilePar for %s", dctMsgDefXmlFilePar["acFileName"])
            return(lstReturnHeaders)

        lstMessageHeaderDictItems = dctMsgDefXmlFilePar["tplValidMessageHeaders"][1]

        if (not lstMessageHeaderDictItems):
            return(lstReturnHeaders)

        for dctMessageHeaderDictItem in lstMessageHeaderDictItems:

            lstDefinitionLines = []
            lstConstructorLines = []
            lstValidationLines = []
            lstStrToStringLines = []

            lstFieldElements = dctMessageHeaderDictItem["lstFieldElements"]

            if (not lstFieldElements):
                logging.error("There are no Fields in the first Header tag")
                return(acReturnCodeBlock)

            for objFieldElement in lstFieldElements:

                acDefinitionLine = str("")
                acValidationLine = str("")
                acConstructorLine = str("")
                acStrToStringLine = str("")

                # This attribute "eRecordType" came from autogen_toolbox_definition_validation_and_et_finding.py methods bValidateFieldOrRecordElementRecursively() and tplValidateMsgDefPayloadFromRootElement() and bValidateTypedefOfTypeStruct()
                if (objFieldElement.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_ENUM)):
                    acNamePrefix = objFieldElement.attrib["Type"][:2].lower()
                    acDefinitionLine = "  %s %s%s%s;\n" % (objFieldElement.attrib["Type"], acNamePrefix, objFieldElement.attrib["Name"], acArrayParenthesesText)

                    acValidationLine += "    {\n"
                    acValidationLine += "      bool bReturnEnumValid = false;\n"
                    acValidationLine += "      %s aeValid%s[%s] = {" % (objFieldElement.attrib["Type"], objFieldElement.attrib["Name"], str(len(objFieldElement.attrib["lstAllEnumValuesAsStr"])))

                    for acEnumValue in objFieldElement.attrib["lstAllEnumValuesAsStr"]:
                        acValidationLine += "%s," % (acEnumValue)

                    acValidationLine += "};\n"

                    acValidationLine += "      for (U4 u4EnumCounter = 0; u4EnumCounter < %s; u4EnumCounter++)\n" % (str(len(objFieldElement.attrib["lstAllEnumValuesAsStr"])))
                    acValidationLine += "      {\n"
                    acValidationLine += "        bReturnEnumValid |= (%s%s == aeValid%s[u4EnumCounter]);\n" % (acNamePrefix, objFieldElement.attrib["Name"], objFieldElement.attrib["Name"])
                    acValidationLine += "      }\n"
                    acValidationLine += "      bReturn &= bReturnEnumValid;\n"
                    acValidationLine += "      if (bReturn == false)\n"
                    acValidationLine += "      {\n"
                    acValidationLine += "        errorMsg += \".%s%s: \" + std::to_string(%s%s) + \" is invalid\\n\";\n" % (acNamePrefix, objFieldElement.attrib["Name"], acNamePrefix, objFieldElement.attrib["Name"])
                    acValidationLine += "        return(bReturn);\n"
                    acValidationLine += "      }\n"

                    acValidationLine += "    }\n"

                    acConstructorLine = "    %s%s = %s;\n" % (acNamePrefix, objFieldElement.attrib["Name"], objFieldElement.attrib["Default"])

                    acStrToStringLine = "    strReturn += strParentPar + \".%s%s%s: \" + std::to_string(%s%s%s) + \"\\n\";\n" % (acNamePrefix, objFieldElement.attrib["Name"], acArrayParenthesesText, acNamePrefix, objFieldElement.attrib["Name"], acArrayParenthesesText)

                elif (objFieldElement.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_BASE)):
                    tplTypeToCppFieldPrefix = (objFieldElement.attrib["Type"], objFieldElement.attrib["Count"] != "1")
                    acDefinitionLine = "  %s %s%s%s;\n" % (objFieldElement.attrib["Type"], G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objFieldElement.attrib["Name"], acArrayParenthesesText)

                    acConstructorLine = "    %s%s = %s;\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objFieldElement.attrib["Name"], objFieldElement.attrib["Default"])

                    acStrToStringLine = "    strReturn += strParentPar + \".%s%s%s: \" + std::to_string(%s%s%s) + \"\\n\";\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objFieldElement.attrib["Name"], acArrayParenthesesText, G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objFieldElement.attrib["Name"], acArrayParenthesesText)

                lstDefinitionLines.append(acDefinitionLine)
                lstConstructorLines.append(acConstructorLine)
                lstValidationLines.append(acValidationLine)
                lstStrToStringLines.append(acStrToStringLine)

            acReturnCodeBlock = "typedef struct s%s_MESSAGE_HEADER\n" % (dctMessageHeaderDictItem["objHeaderElement"].attrib["acNameAsCapitalisedUnderscores"])
            acReturnCodeBlock += "{\n"

            for acDefinitionLine in lstDefinitionLines:

                # Add each line of definition
                acReturnCodeBlock += acDefinitionLine

            if (bGenerateConstructorPar is True):
                acReturnCodeBlock += "\n"
                acReturnCodeBlock += "  s%s_MESSAGE_HEADER()\n" % (dctMessageHeaderDictItem["objHeaderElement"].attrib["acNameAsCapitalisedUnderscores"])
                acReturnCodeBlock += "  {\n"

                for acConstructorLine in lstConstructorLines:
                    acReturnCodeBlock += acConstructorLine

                acReturnCodeBlock += "  }\n"
                acReturnCodeBlock += "\n"

            if (bGenerateValidationMethodsPar is True):
                acReturnCodeBlock += "\n"
                acReturnCodeBlock += "  bool bValidate(std::string& errorMsg)\n"
                acReturnCodeBlock += "  {\n"
                acReturnCodeBlock += "    bool bReturn = true; //We always start as valid\n"
                acReturnCodeBlock += "    std::string tmpErrorMsg = \"\";\n"

                for acValidationLine in lstValidationLines:
                    acReturnCodeBlock += acValidationLine

                acReturnCodeBlock += "    return(bReturn);\n"
                acReturnCodeBlock += "  }\n"
                acReturnCodeBlock += "\n"

            # Add the strToString() code
            acReturnCodeBlock += "\n"
            acReturnCodeBlock += "  std::string strToString(std::string strParentPar)\n"
            acReturnCodeBlock += "  {\n"
            acReturnCodeBlock += "    std::string strReturn = \"\";\n"

            for acStrToStringLine in lstStrToStringLines:
                acReturnCodeBlock += acStrToStringLine

            acReturnCodeBlock += "    return(strReturn);\n"
            acReturnCodeBlock += "  }\n"
            acReturnCodeBlock += "\n"

            acReturnCodeBlock += "} __attribute__ ((packed)) s%s_MESSAGE_HEADER;\n" % (dctMessageHeaderDictItem["objHeaderElement"].attrib["acNameAsCapitalisedUnderscores"])
            acReturnCodeBlock += "\n"

            lstReturnHeaders.append(acReturnCodeBlock)

        return(lstReturnHeaders)

    @staticmethod
    def lstGenerateCppPayloads(dctMsgDefXmlFilePar: dict, bGenerateConstructorPar: bool = True, bGenerateValidationMethodsPar: bool = True):
        """ This is a public static method which generates a C++ payload code.

        Args:
            dctMsgDefXmlFilePar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["objElementTreeRoot"] (str)
            bGenerateConstructorPar (bool): A flag to indicate if constructors should be generated.
            bGenerateValidationMethodsPar (bool): A flag to indicate if validation methods should be generated

        Returns:
            (list): A list string payloads

        Raises:
            Raises no exception.
        """
        lstReturnPayloads = []
        objPayloadElement = None
        acCodeBlock = str("")
        lstFieldElements = []
        acArrayParenthesesText = str("")
        acNamePrefix = str("")
        bIsCountGreaterThanOne = bool(False)
        acPayloadCppName = str("")
        tplValidMessagePayloads = (bool(False), [])

        iCount = int(0)  # Stores the Field Count as an int
        lstDefinitionLines = []  # Stores all the definition lines
        acDefinitionLine = str("")
        lstConstructorLines = []  # Stores all the constructor lines
        acConstructorLine = str("")
        lstValidationLines = []  # Stores all the validation lines
        acValidationLine = str("")
        lstStrToStringLines = []  # Stores all the strToString lines
        acStrToStringLine = str("")

        # Do some checks
        if (dctMsgDefXmlFilePar is None):
            logging.error("dctMsgDefXmlFilePar cannot be None")
            return(lstReturnPayloads)

        if ("tplValidMessagePayloads" not in dctMsgDefXmlFilePar):
            logging.error("tplValidMessagePayloads not in dctMsgDefXmlFilePar")
            return(lstReturnPayloads)

        tplValidMessagePayloads = dctMsgDefXmlFilePar["tplValidMessagePayloads"]

        if (tplValidMessagePayloads[0] is False):
            logging.error("File %s Message Payloads are invalid", dctMsgDefXmlFilePar["acFileName"])
            return(lstReturnPayloads)

        for dctMessageDictItem in tplValidMessagePayloads[1]:

            if ("objPayloadElement" not in dctMessageDictItem):
                logging.error("Message %s does not have a Payload Element object", dctMessageDictItem["acName"])
                continue

            objPayloadElement = dctMessageDictItem["objPayloadElement"]

            # Do not generate code for a payload if there are no Fields - an empty struct in C++ is the sizeof of 1 which is not good for us
            if (objPayloadElement.attrib["bPayloadWithNoFields"] is True):
                continue

            if (objPayloadElement is None):
                logging.error("Message %s does not have a Payload tag", dctMessageDictItem["acName"])
                continue

            if ("acNameAsCapitalisedUnderscores" not in objPayloadElement.attrib):
                logging.error("Message %s Payload does not have the acNameAsCapitalisedUnderscores attribute", dctMessageDictItem["acName"])
                continue

            # This attribute came from autogen_toolbox_definition_validation_and_et_finding.py method lstFindMessagePayloadPairElementsFromMsgDefRootElement()
            acPayloadCppName = objPayloadElement.attrib["acNameAsCapitalisedUnderscores"]

            lstFieldElements = objPayloadElement.findall("./Field")

            lstConstructorLines = []
            lstDefinitionLines = []
            lstValidationLines = []
            lstStrToStringLines = []

            for objFieldElement in lstFieldElements:

                acNamePrefix = str("")
                acArrayParenthesesText = str("")
                acConstructorLine = str("")
                acDefinitionLine = str("")
                acValidationLine = str("")
                acStrToStringLine = str("")

                # The Count attribute was forced when it was validated even if it was not defined
                if ("Count" not in objFieldElement.attrib):
                    logging.error("No Count attribute for Field %s of type %s", objFieldElement.attrib["Name"], str(objFieldElement.attrib["Type"]))
                    continue

                try:
                    iCount = int(objFieldElement.attrib["Count"])
                except Exception as E:
                    logging.error("The Count attribute for Field %s is probably not an int - Exception %s", objFieldElement.attrib["Name"], str(E))
                    continue

                if (iCount > 1):
                    bIsCountGreaterThanOne = bool(True)
                else:
                    bIsCountGreaterThanOne = bool(False)

                # The eRecordType attribute was added during validation
                if ("eRecordType" not in objFieldElement.attrib):
                    logging.error("No Count attribute for Field %s of type %s", objFieldElement.attrib["Name"], str(objFieldElement.attrib["Type"]))
                    continue

                if ((bIsCountGreaterThanOne is True) or (objFieldElement.attrib["Type"] == "CH")):
                    acArrayParenthesesText = "[%s]" % objFieldElement.attrib["Count"]

                # This attribute "eRecordType" came from autogen_toolbox_definition_validation_and_et_finding.py methods bValidateFieldOrRecordElementRecursively() and tplValidateMsgDefPayloadFromRootElement() and bValidateTypedefOfTypeStruct()
                if (objFieldElement.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_ENUM)):
                    acNamePrefix = G_dctEnumTypeToCppFieldPrefix[(objFieldElement.attrib["Type"][:2], bIsCountGreaterThanOne)]
                    acDefinitionLine += "  %s %s%s%s;\n" % (objFieldElement.attrib["Type"], acNamePrefix.lower(), objFieldElement.attrib["Name"], acArrayParenthesesText)

                    acValidationLine += "    {\n"
                    acValidationLine += "      bool bReturnEnumValid = false;\n"
                    acValidationLine += "      %s aeValid%s[%s] = {" % (objFieldElement.attrib["Type"], objFieldElement.attrib["Name"], str(len(objFieldElement.attrib["lstAllEnumValuesAsStr"])))

                    for acEnumValue in objFieldElement.attrib["lstAllEnumValuesAsStr"]:
                        acValidationLine += "%s," % (acEnumValue)

                    acValidationLine += "};\n"

                    if (iCount <= 1):
                        acValidationLine += "      for (U4 u4EnumCounter = 0; u4EnumCounter < %s; u4EnumCounter++)\n" % (str(len(objFieldElement.attrib["lstAllEnumValuesAsStr"])))
                        acValidationLine += "      {\n"
                        acValidationLine += "        bReturnEnumValid |= (%s%s == aeValid%s[u4EnumCounter]);\n" % (acNamePrefix, objFieldElement.attrib["Name"], objFieldElement.attrib["Name"])
                        acValidationLine += "      }\n"
                        acValidationLine += "      bReturn &= bReturnEnumValid;\n"
                        acValidationLine += "      if (bReturn == false)\n"
                        acValidationLine += "      {\n"
                        acValidationLine += "        errorMsg += \".%s%s: \" + std::to_string(%s%s) + \" is invalid\\n\";\n" % (acNamePrefix, objFieldElement.attrib["Name"], acNamePrefix, objFieldElement.attrib["Name"])
                        acValidationLine += "        return(bReturn);\n"
                        acValidationLine += "      }\n"
                    else:
                        acValidationLine += "      for (U4 u4Counter = 0; u4Counter < %s; u4Counter++)\n" % (iCount)
                        acValidationLine += "      {\n"
                        acValidationLine += "        bReturnEnumValid = false;\n"
                        acValidationLine += "        for (U4 u4EnumCounter = 0; u4EnumCounter < %s; u4EnumCounter++)\n" % (str(len(objFieldElement.attrib["lstAllEnumValuesAsStr"])))
                        acValidationLine += "        {\n"
                        acValidationLine += "          bReturnEnumValid |= (%s%s[u4Counter] == aeValid%s[u4EnumCounter]);\n" % (acNamePrefix, objFieldElement.attrib["Name"], objFieldElement.attrib["Name"])
                        acValidationLine += "        }\n"
                        acValidationLine += "        bReturn &= bReturnEnumValid;\n"
                        acValidationLine += "        if (bReturn == false)\n"
                        acValidationLine += "        {\n"
                        acValidationLine += "          errorMsg += \".%s%s[\" + std::to_string(u4Counter) + \"]: \" + std::to_string(%s%s[u4Counter]) + \" is invalid\\n\";\n" % (acNamePrefix, objFieldElement.attrib["Name"], acNamePrefix, objFieldElement.attrib["Name"])
                        acValidationLine += "          return(bReturn);\n"
                        acValidationLine += "        }\n"

                        acValidationLine += "      }\n"

                    acValidationLine += "    }\n"

                    if (iCount <= 1):
                        acConstructorLine += "    %s%s = %s;\n" % (acNamePrefix, objFieldElement.attrib["Name"], objFieldElement.attrib["Default"])

                        acStrToStringLine += "    strReturn += strParentPar + \".%s%s: \" + std::to_string(%s%s) + \"\\n\";\n" % (acNamePrefix, objFieldElement.attrib["Name"], acNamePrefix, objFieldElement.attrib["Name"])

                    else:
                        acConstructorLine += "    for (U4 u4Counter = 0; u4Counter < %s; u4Counter++)\n" % (iCount)
                        acConstructorLine += "    {\n"
                        acConstructorLine += "      %s%s[u4Counter] = %s;\n" % (acNamePrefix, objFieldElement.attrib["Name"], objFieldElement.attrib["Default"])
                        acConstructorLine += "    }\n"

                        acStrToStringLine += "    for (U4 u4Counter = 0; u4Counter < %s; u4Counter++)\n" % (iCount)
                        acStrToStringLine += "    {\n"
                        acStrToStringLine += "      strReturn += strParentPar + \".%s%s[\" + std::to_string(u4Counter) + \"]: \" + std::to_string(%s%s[u4Counter]) + \"\\n\";\n" % (acNamePrefix, objFieldElement.attrib["Name"], acNamePrefix, objFieldElement.attrib["Name"])
                        acStrToStringLine += "    }\n"

                elif (objFieldElement.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_STRUCT)):

                    # Determine the prefix of the field name
                    acNamePrefix = G_dctStructTypeToCppFieldPrefix[bIsCountGreaterThanOne]
                    # Make the line of code for the field
                    acDefinitionLine += "  %s %s%s%s;\n" % (objFieldElement.attrib["Type"], acNamePrefix, objFieldElement.attrib["Name"], acArrayParenthesesText)

                    # Generate code for the constructor
                    if (iCount <= 1):
                        acConstructorLine += "    %s%s = %s();\n" % (acNamePrefix, objFieldElement.attrib["Name"], objFieldElement.attrib["Type"])

                        acValidationLine += "    tmpErrorMsg = errorMsg + \".%s%s\";\n" % (acNamePrefix, objFieldElement.attrib["Name"])
                        acValidationLine += "    bReturn &= %s%s.bValidate(tmpErrorMsg);\n" % (acNamePrefix, objFieldElement.attrib["Name"])
                        acValidationLine += "    if (bReturn == false)\n"
                        acValidationLine += "    {\n"
                        acValidationLine += "      errorMsg = tmpErrorMsg;\n"
                        acValidationLine += "      return(bReturn);\n"
                        acValidationLine += "    }\n"

                        acStrToStringLine += "    strReturn += strParentPar + %s%s.strToString(strParentPar + \".%s%s\");\n" % (acNamePrefix, objFieldElement.attrib["Name"], acNamePrefix, objFieldElement.attrib["Name"])

                    else:
                        acConstructorLine += "    for (U4 u4Counter = 0; u4Counter < %s; u4Counter++)\n" % (iCount)
                        acConstructorLine += "    {\n"
                        acConstructorLine += "      %s%s[u4Counter] = %s();\n" % (acNamePrefix, objFieldElement.attrib["Name"], objFieldElement.attrib["Type"])
                        acConstructorLine += "    }\n"

                        acValidationLine += "    for (U4 u4Counter = 0; u4Counter < %s; u4Counter++)\n" % (iCount)
                        acValidationLine += "    {\n"
                        acValidationLine += "      tmpErrorMsg = errorMsg + \".%s%s[\" + std::to_string(u4Counter) + \"]\";\n" % (acNamePrefix, objFieldElement.attrib["Name"])
                        acValidationLine += "      bReturn &= %s%s[u4Counter].bValidate(tmpErrorMsg);\n" % (acNamePrefix, objFieldElement.attrib["Name"])
                        acValidationLine += "      if (bReturn == false)\n"
                        acValidationLine += "      {\n"
                        acValidationLine += "        errorMsg = tmpErrorMsg;\n"
                        acValidationLine += "        return(bReturn);\n"
                        acValidationLine += "      }\n"

                        acValidationLine += "    }\n"

                        acStrToStringLine += "    for (U4 u4Counter = 0; u4Counter < %s; u4Counter++)\n" % (iCount)
                        acStrToStringLine += "    {\n"
                        acStrToStringLine += "      strReturn += strParentPar + %s%s[u4Counter].strToString(strParentPar + \".%s%s[\" + std::to_string(u4Counter) + \"]\");\n" % (acNamePrefix, objFieldElement.attrib["Name"], acNamePrefix, objFieldElement.attrib["Name"])
                        acStrToStringLine += "    }\n"

                elif (objFieldElement.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_BASE)):

                    # Use a lookup to determine the field name prefix - combine the type and count as a lookup key
                    tplTypeToCppFieldPrefix = (objFieldElement.attrib["Type"], bIsCountGreaterThanOne)

                    # Look up the prefix we need
                    acNamePrefix = G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix]

                    # Make the line of code for the field
                    acDefinitionLine += "  %s %s%s%s;\n" % (objFieldElement.attrib["Type"], acNamePrefix, objFieldElement.attrib["Name"], acArrayParenthesesText)

                    if (objFieldElement.attrib["Type"] == "CH"):
                        if ("Default" in objFieldElement.attrib):
                            acConstructorLine += "    strncpy(%s%s,\"%s\",%s);\n" % (acNamePrefix, objFieldElement.attrib["Name"], objFieldElement.attrib["Default"], objFieldElement.attrib["Count"])
                        else:
                            logging.error("Record with name %s does not have a Default", objFieldElement.attrib["Name"])

                        acValidationLine += "    // No validity check on %s%s because it is a char array - nothing to check\n" % (acNamePrefix, objFieldElement.attrib["Name"])

                        acStrToStringLine += "    strReturn += strParentPar + \".%s%s: \" + std::string(%s%s, %s) + \"\\n\";\n" % (acNamePrefix, objFieldElement.attrib["Name"], acNamePrefix, objFieldElement.attrib["Name"], objFieldElement.attrib["Count"])

                    elif (bIsCountGreaterThanOne is False):
                        acConstructorLine += "    %s%s = %s;\n" % (acNamePrefix, objFieldElement.attrib["Name"], objFieldElement.attrib["Default"])

                        if ("Min" in objFieldElement.attrib):
                            acValidationLine += "    bReturn &= (%s%s >= %s);\n" % (acNamePrefix, objFieldElement.attrib["Name"], objFieldElement.attrib["Min"])
                            acValidationLine += "    if (bReturn == false)\n"
                            acValidationLine += "    {\n"
                            acValidationLine += "      errorMsg += \".%s%s: \" + std::to_string(%s%s) + \" is invalid\\n\";\n" % (acNamePrefix, objFieldElement.attrib["Name"], acNamePrefix, objFieldElement.attrib["Name"])
                            acValidationLine += "      return(bReturn);\n"
                            acValidationLine += "    }\n"

                        if ("Max" in objFieldElement.attrib):
                            acValidationLine += "    bReturn &= (%s%s <= %s);\n" % (acNamePrefix, objFieldElement.attrib["Name"], objFieldElement.attrib["Max"])
                            acValidationLine += "    if (bReturn == false)\n"
                            acValidationLine += "    {\n"
                            acValidationLine += "      errorMsg += \".%s%s: \" + std::to_string(%s%s) + \" is invalid\\n\";\n" % (acNamePrefix, objFieldElement.attrib["Name"], acNamePrefix, objFieldElement.attrib["Name"])
                            acValidationLine += "      return(bReturn);\n"
                            acValidationLine += "    }\n"

                        acStrToStringLine += "    strReturn += strParentPar + \".%s%s: \" + std::to_string(%s%s) + \"\\n\";\n" % (acNamePrefix, objFieldElement.attrib["Name"], acNamePrefix, objFieldElement.attrib["Name"])

                    else:
                        acConstructorLine += "    for (U4 u4Counter = 0; u4Counter < %s; u4Counter++)\n" % (iCount)
                        acConstructorLine += "    {\n"
                        acConstructorLine += "      %s%s[u4Counter] = %s;\n" % (acNamePrefix, objFieldElement.attrib["Name"], objFieldElement.attrib["Default"])
                        acConstructorLine += "    }\n"

                        acValidationLine += "    for (U4 u4Counter = 0; u4Counter < %s; u4Counter++)\n" % (iCount)
                        acValidationLine += "    {\n"

                        if ("Min" in objFieldElement.attrib):
                            acValidationLine += "      bReturn &= (%s%s[u4Counter] >= %s);\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objFieldElement.attrib["Name"], objFieldElement.attrib["Min"])
                            acValidationLine += "      if (bReturn == false)\n"
                            acValidationLine += "      {\n"
                            acValidationLine += "        errorMsg += \".%s%s[\" + std::to_string(u4Counter) + \"]: \" + std::to_string(%s%s[u4Counter]) + \" is invalid\\n\";\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objFieldElement.attrib["Name"], G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objFieldElement.attrib["Name"])
                            acValidationLine += "        return(bReturn);\n"
                            acValidationLine += "      }\n"

                        if ("Max" in objFieldElement.attrib):
                            acValidationLine += "      bReturn &= (%s%s[u4Counter] <= %s);\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objFieldElement.attrib["Name"], objFieldElement.attrib["Max"])
                            acValidationLine += "      if (bReturn == false)\n"
                            acValidationLine += "      {\n"
                            acValidationLine += "        errorMsg += \".%s%s[\" + std::to_string(u4Counter) + \"]: \" + std::to_string(%s%s[u4Counter]) + \" is invalid\\n\";\n" % (G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objFieldElement.attrib["Name"], G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix], objFieldElement.attrib["Name"])
                            acValidationLine += "        return(bReturn);\n"
                            acValidationLine += "      }\n"

                        acValidationLine += "    }\n"

                        acStrToStringLine += "    for (U4 u4Counter = 0; u4Counter < %s; u4Counter++)\n" % (iCount)
                        acStrToStringLine += "    {\n"
                        acStrToStringLine += "      strReturn += strParentPar + \".%s%s[\" + std::to_string(u4Counter) + \"]: \" + std::to_string(%s%s[u4Counter]) + \"\\n\";\n" % (acNamePrefix, objFieldElement.attrib["Name"], acNamePrefix, objFieldElement.attrib["Name"])
                        acStrToStringLine += "    }\n"

                lstDefinitionLines.append(acDefinitionLine)
                lstConstructorLines.append(acConstructorLine)
                lstValidationLines.append(acValidationLine)
                lstStrToStringLines.append(acStrToStringLine)

            acCodeBlock = str("typedef struct %s_PL\n" % (acPayloadCppName))
            acCodeBlock += str("{\n")

            for acDefinitionLine in lstDefinitionLines:
                # Add each line of definition
                acCodeBlock += acDefinitionLine

            if (bGenerateConstructorPar is True):
                acCodeBlock += "\n"
                acCodeBlock += "  %s_PL()\n" % (acPayloadCppName)
                acCodeBlock += "  {\n"

                for acConstructorLine in lstConstructorLines:
                    acCodeBlock += acConstructorLine

                acCodeBlock += "  }\n"
                acCodeBlock += "\n"

            if (bGenerateValidationMethodsPar is True):
                acCodeBlock += "\n"
                acCodeBlock += "  bool bValidate(std::string& errorMsg)\n"
                acCodeBlock += "  {\n"
                acCodeBlock += "    bool bReturn = true; //We always start as valid\n"
                acCodeBlock += "    std::string tmpErrorMsg = \"\";\n"

                for acValidationLine in lstValidationLines:
                    acCodeBlock += acValidationLine

                acCodeBlock += "    return(bReturn);\n"
                acCodeBlock += "  }\n"
                acCodeBlock += "\n"

            # Add the strToString() code
            acCodeBlock += "\n"
            acCodeBlock += "  std::string strToString(std::string strParentPar)\n"
            acCodeBlock += "  {\n"
            acCodeBlock += "    std::string strReturn = \"\";\n"

            for acStrToStringLine in lstStrToStringLines:
                acCodeBlock += acStrToStringLine

            acCodeBlock += "    return(strReturn);\n"
            acCodeBlock += "  }\n"
            acCodeBlock += "\n"

            acCodeBlock += str("} __attribute__ ((packed)) s%s_PL;\n" % (acPayloadCppName))

            lstReturnPayloads.append(acCodeBlock)

        return(lstReturnPayloads)

    @staticmethod
    def lstGenerateCppMessages(dctMsgDefXmlFilePar: dict, bGenerateConstructorPar: bool = True, bGenerateValidationMethodsPar: bool = True):
        """ This is a public static method which generates a C++ Message code

        Args:
            dctMsgDefXmlFilePar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["objElementTreeRoot"] (str)
            bGenerateConstructorPar (bool): A flag to indicate if constructors should be generated.
            bGenerateValidationMethodsPar (bool): A flag to indicate if validation methods should be generated

        Returns:
            (list): A list of C++ Message blocks

        Raises:
            Raises no exception.
        """
        lstReturnMessageBlocks = []
        acMessgeCodeBlock = str("")
        tplValidMessagePayloads = (bool(False), [])
        objMessageElement = None
        objPayloadElement = None

        # Do some checks
        if (dctMsgDefXmlFilePar is None):
            logging.error("dctMsgDefXmlFilePar cannot be None")
            return(lstReturnMessageBlocks)

        if ("tplValidMessagePayloads" not in dctMsgDefXmlFilePar):
            logging.error("Key tplValidMessagePayloads is missing from dctMsgDefXmlFilePar for %s", dctMsgDefXmlFilePar["acFileName"])
            return(lstReturnMessageBlocks)

        tplValidMessagePayloads = dctMsgDefXmlFilePar["tplValidMessagePayloads"]

        if (tplValidMessagePayloads[0] is False):
            logging.error("Payloads for %s is invalid", dctMsgDefXmlFilePar["acFileName"])
            return(lstReturnMessageBlocks)

        if (not tplValidMessagePayloads[1]):
            return(lstReturnMessageBlocks)

        for dctMessageDictItem in tplValidMessagePayloads[1]:
            objMessageElement = dctMessageDictItem["objMessageElement"]
            objPayloadElement = dctMessageDictItem["objPayloadElement"]

            acMessgeCodeBlock = "typedef struct s%s\n" % (objMessageElement.attrib["acNameAsCapitalisedUnderscores"])
            acMessgeCodeBlock += "{\n"

            acMessgeCodeBlock += "  s%s_MESSAGE_HEADER sMsgHeader;\n" % (dctMessageDictItem["objMessageElement"].attrib["acNameAsCapitalisedUnderscores"])

            # Only define a payload if the payload contain fields because in C++ an empty struct has a size of 1 byte which is not good for us
            if (objPayloadElement.attrib["bPayloadWithNoFields"] is False):
                acMessgeCodeBlock += "  s%s_PL sMsgPayload;\n" % (objMessageElement.attrib["acNameAsCapitalisedUnderscores"])

            if (bGenerateConstructorPar is True):
                acMessgeCodeBlock += "\n"
                acMessgeCodeBlock += "  s%s()\n" % (objMessageElement.attrib["acNameAsCapitalisedUnderscores"])
                acMessgeCodeBlock += "  {\n"
                acMessgeCodeBlock += "    sMsgHeader = s%s_MESSAGE_HEADER();\n" % (dctMessageDictItem["objMessageElement"].attrib["acNameAsCapitalisedUnderscores"])
                acMessgeCodeBlock += "    sMsgHeader.u2MsgLength = sizeof(s%s) - sizeof(sMsgHeader.u2MsgLength);\n" % (objMessageElement.attrib["acNameAsCapitalisedUnderscores"])

                if (objPayloadElement.attrib["bPayloadWithNoFields"] is False):
                    acMessgeCodeBlock += "    sMsgPayload = s%s_PL();\n" % (objMessageElement.attrib["acNameAsCapitalisedUnderscores"])

                acMessgeCodeBlock += "  }\n"
                acMessgeCodeBlock += "\n"

            if (bGenerateValidationMethodsPar is True):
                acMessgeCodeBlock += "\n"
                acMessgeCodeBlock += "  bool bValidate(std::string& errorMsg)\n"
                acMessgeCodeBlock += "  {\n"
                acMessgeCodeBlock += "    bool bReturn = true;\n"
                acMessgeCodeBlock += "    std::string tmpErrorMsg = \"\";\n"
                acMessgeCodeBlock += "    tmpErrorMsg = errorMsg + \".sMsgHeader\";\n"
                acMessgeCodeBlock += "    bReturn &= sMsgHeader.bValidate(tmpErrorMsg);\n"
                acMessgeCodeBlock += "    if (bReturn == false)\n"
                acMessgeCodeBlock += "    {\n"
                acMessgeCodeBlock += "      errorMsg = tmpErrorMsg;\n"
                acMessgeCodeBlock += "      return(bReturn);\n"
                acMessgeCodeBlock += "    }\n"

                if (objPayloadElement.attrib["bPayloadWithNoFields"] is False):
                    acMessgeCodeBlock += "    tmpErrorMsg = errorMsg + \".sMsgPayload\";\n"
                    acMessgeCodeBlock += "    bReturn &= sMsgPayload.bValidate(tmpErrorMsg);\n"
                    acMessgeCodeBlock += "    if (bReturn == false)\n"
                    acMessgeCodeBlock += "    {\n"
                    acMessgeCodeBlock += "      errorMsg = tmpErrorMsg;\n"
                    acMessgeCodeBlock += "      return(bReturn);\n"
                    acMessgeCodeBlock += "    }\n"

                acMessgeCodeBlock += "    return(bReturn);\n"
                acMessgeCodeBlock += "  }\n"
                acMessgeCodeBlock += "\n"

            # Add the strToString() code
            acMessgeCodeBlock += "\n"
            acMessgeCodeBlock += "  std::string strToString(std::string strParentPar)\n"
            acMessgeCodeBlock += "  {\n"
            acMessgeCodeBlock += "    std::string strReturn = \"\";\n"
            acMessgeCodeBlock += "    strReturn += strParentPar + sMsgHeader.strToString(strParentPar + \".sMsgHeader\");\n"

            if (objPayloadElement.attrib["bPayloadWithNoFields"] is False):
                acMessgeCodeBlock += "    strReturn += strParentPar + sMsgPayload.strToString(strParentPar + \".sMsgPayload\");\n"

            acMessgeCodeBlock += "    return(strReturn);\n"
            acMessgeCodeBlock += "  }\n"
            acMessgeCodeBlock += "\n"

            # Create the strMessageName() method
            acMessgeCodeBlock += "\n"
            acMessgeCodeBlock += "  static std::string strMessageName()\n"
            acMessgeCodeBlock += "  {\n"
            acMessgeCodeBlock += "    std::string strMessageName = \"%s\";\n" % (objMessageElement.attrib["Name"])
            acMessgeCodeBlock += "    return(strMessageName);\n"
            acMessgeCodeBlock += "  }\n"
            acMessgeCodeBlock += "\n"

            # This attribute "acNameAsCapitalisedUnderscores" came from autogen_toolbox_definition_validation_and_et_finding.py methods lstFindMessageHeaderPairElementsFromMsgDefRootElement() and lstFindMessagePayloadPairElementsFromMsgDefRootElement()
            acMessgeCodeBlock += str("} __attribute__ ((packed)) s%s;\n" % (objMessageElement.attrib["acNameAsCapitalisedUnderscores"]))

            lstReturnMessageBlocks.append(acMessgeCodeBlock)

        return(lstReturnMessageBlocks)

    @staticmethod
    def acModInterConfHFileGeneratePrecompileIfdef(dctModInterConfDictItemPar: dict):
        """ This is a public static method which generates a C++ precompiler ifdef for the Mod Inter Conf

        Args:
            dctModInterConfDictItemPar (dict):
                * acFileName (str)

        Returns:
            (str): The ifdef precompiler name

        Raises:
            Raises no exception.
        """
        acReturn = str("")

        # Make precompiler if name that is capatilised underscores + _H
        acReturn = (dctModInterConfDictItemPar["acFileName"].upper()).replace("XML", "H").replace(".", "_")

        return(acReturn)

    @staticmethod
    def lstModInterConfHFileGenerateIncludes(dctModInterConfDictItemPar: dict):
        """ This is a public static method which generates a list of C++ includes

        Args:
            dctModInterConfDictItemPar (dict):
                * sttRequiredMsgDefFilenames (set): A set of string which are the definition header files we must include

        Returns:
            (list): A list of include C++ source lines

        Raises:
            Raises no exception.
        """
        lstReturn = []

        for acFileName in dctModInterConfDictItemPar["sttRequiredMsgDefFilenames"]:
            lstReturn.append("#include \"%s\"" % (clsAutogenToolboxCodeGenerationCpp.acMsgDefFilenameToHeaderFilename(acFileName)))

        return(lstReturn)

    @staticmethod
    def acModInterConfHFileGenerateClass(dctModInterConfDictItemPar: dict):
        """ This is a public static method which generates a class for the mod inter conf file

        Args:
            dctModInterConfDictItemPar (dict):
                * ["acFileNameAsCapUnderscores"] -> The filename as cap. underscores

        Returns:
            (str): A code block which contains a class

        Raises:
            Raises no exception.
        """
        acReturn = str("")

        acReturn += "class cl%s\n" % (dctModInterConfDictItemPar["acFileNameAsCapUnderscores"])
        acReturn += "{\n"
        acReturn += "  public:\n"
        acReturn += "    cl%s();\n" % (dctModInterConfDictItemPar["acFileNameAsCapUnderscores"])
        acReturn += "    std::vector<std::string> vecTopics;\n"
        acReturn += "};\n"

        return(acReturn)

    @staticmethod
    def acModInterConfCppFilePrecompileInclude(dctModInterConfDictItemPar: dict):
        """ This is a public static method which generates an include line for a

        Args:
            dctModInterConfDictItemPar (dict):
                * ["acFileNameAsCapUnderscores"] -> The filename as cap. underscores

        Returns:
            (str): A code block which contains a class

        Raises:
            Raises no exception.
        """
        acReturn = str("")

        acReturn += "#include \"cl%s.h\"" % (dctModInterConfDictItemPar["acFileNameAsCapUnderscores"])

        return(acReturn)

    @staticmethod
    def acModInterConfCppFileClass(dctModInterConfDictItemPar: dict):
        """ This is a public static method which generates an include line for a

        Args:
            dctModInterConfDictItemPar (dict):
                * ["acFileNameAsCapUnderscores"] -> The filename as cap. underscores

        Returns:
            (str): A code block which contains a class

        Raises:
            Raises no exception.
        """
        acReturn = str("")
        iCount = int(0)
        iVectorSize = int(0)

        # First iterate throught the topics and work out how big the STL vector should be
        for dctFullMessageTopic in dctModInterConfDictItemPar["lstFullTopicPartsForThisModConfInterface"]:
            if (not dctFullMessageTopic["lstRoles"]):
                iVectorSize += 1
            else:
                for acRole in dctFullMessageTopic["lstRoles"]:
                    iVectorSize += 1

        acReturn += "cl%s::cl%s()\n" % (dctModInterConfDictItemPar["acFileNameAsCapUnderscores"], dctModInterConfDictItemPar["acFileNameAsCapUnderscores"])
        acReturn += "{\n"
        acReturn += "  vecTopics.resize(%s);\n" % (iVectorSize)

        for dctFullMessageTopic in dctModInterConfDictItemPar["lstFullTopicPartsForThisModConfInterface"]:

            if (not dctFullMessageTopic["lstRoles"]):
                acReturn += "  vecTopics[%s] = std::string(\"%s\\\\%s\\\\%s\");\n" % (iCount, dctFullMessageTopic["acSystem"], dctFullMessageTopic["acModule"], dctFullMessageTopic["acMessageName"])
                iCount += 1
            else:
                for acRole in dctFullMessageTopic["lstRoles"]:
                    acReturn += "  vecTopics[%s] = std::string(\"%s\\\\%s\\\\%s\\\\%s\");\n" % (iCount, dctFullMessageTopic["acSystem"], dctFullMessageTopic["acModule"], dctFullMessageTopic["acMessageName"], acRole)
                    iCount += 1

        acReturn += "}\n"

        return(acReturn)

    @staticmethod
    def acModInterConfTopicsZmqSubscribeHFile(dctModInterConfDictItemPar: dict):
        """ This is a public static method which generates an MIC topics ZMQ Subscribe code block

        Args:
            dctModInterConfDictItemPar (dict):
                * ["lstFullTopicPartsForThisModConfInterface"] -> The list of topics

        Returns:
            (str): A code block which contains the code

        Raises:
            Raises no exception.
        """
        acReturn = str("")
        eCommsProtocol = E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_ZMQ)
        eMessageFlowDirection = E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE)
        lstFullMessageTopics = []

        # Only keep the ZMQ Subscribe topics
        lstFullMessageTopics = [dctFullMessageTopic for dctFullMessageTopic in dctModInterConfDictItemPar["lstFullTopicPartsForThisModConfInterface"] if ((dctFullMessageTopic["eCommsProtocol"] == eCommsProtocol) and (dctFullMessageTopic["eMessageFlowDirection"] == eMessageFlowDirection))]

        acReturn += "std::vector<std::string> g_vecZmqTopicsSubscribe = \n"
        acReturn += "{\n"

        # Iterate through the list of topics
        for dctFullMessageTopic in lstFullMessageTopics:

            if (not dctFullMessageTopic["lstRoles"]):
                acReturn += "  \"%s/%s/%s\",\n" % (dctFullMessageTopic["acSystem"], dctFullMessageTopic["acModule"], dctFullMessageTopic["acMessageName"])
            else:
                # Add the role if there is one
                for acRole in dctFullMessageTopic["lstRoles"]:
                    acReturn += "  \"%s/%s/%s/%s\",\n" % (dctFullMessageTopic["acSystem"], dctFullMessageTopic["acModule"], dctFullMessageTopic["acMessageName"], acRole)

        acReturn += "};\n"

        return(acReturn)

    @staticmethod
    def acModInterConfTopicsZmqPublishHFile(dctModInterConfDictItemPar: dict):
        """ This is a public static method which generates an MIC topics ZMQ Publish code block

        Args:
            dctModInterConfDictItemPar (dict):
                * ["lstFullTopicPartsForThisModConfInterface"] -> The list of topics

        Returns:
            (str): A code block which contains the code

        Raises:
            Raises no exception.
        """
        acReturn = str("")
        eCommsProtocol = E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_ZMQ)
        eMessageFlowDirection = E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH)
        lstFullMessageTopics = []

        # Only keep the ZMQ Publish topics
        lstFullMessageTopics = [dctFullMessageTopic for dctFullMessageTopic in dctModInterConfDictItemPar["lstFullTopicPartsForThisModConfInterface"] if ((dctFullMessageTopic["eCommsProtocol"] == eCommsProtocol) and (dctFullMessageTopic["eMessageFlowDirection"] == eMessageFlowDirection))]

        acReturn += "std::vector<std::string> g_vecZmqTopicsPublish = \n"
        acReturn += "{\n"

        # Iterate through the list of topics
        for dctFullMessageTopic in lstFullMessageTopics:

            if (not dctFullMessageTopic["lstRoles"]):
                acReturn += "  \"%s/%s/%s\",\n" % (dctFullMessageTopic["acSystem"], dctFullMessageTopic["acModule"], dctFullMessageTopic["acMessageName"])
            else:
                # Add the role if there is one
                for acRole in dctFullMessageTopic["lstRoles"]:
                    acReturn += "  \"%s/%s/%s/%s\",\n" % (dctFullMessageTopic["acSystem"], dctFullMessageTopic["acModule"], dctFullMessageTopic["acMessageName"], acRole)

        acReturn += "};\n"

        return(acReturn)

    @staticmethod
    def acModInterConfTopicsMqttSubscribeHFile(dctModInterConfDictItemPar: dict):
        """ This is a public static method which generates an MIC topics MQTT Subscribe code block

        Args:
            dctModInterConfDictItemPar (dict):
                * ["lstFullTopicPartsForThisModConfInterface"] -> The list of topics

        Returns:
            (str): A code block which contains the code

        Raises:
            Raises no exception.
        """
        acReturn = str("")
        eCommsProtocol = E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT)
        eMessageFlowDirection = E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE)
        lstFullMessageTopics = []

        # Only keep the MQTT Subscribe topics
        lstFullMessageTopics = [dctFullMessageTopic for dctFullMessageTopic in dctModInterConfDictItemPar["lstFullTopicPartsForThisModConfInterface"] if ((dctFullMessageTopic["eCommsProtocol"] == eCommsProtocol) and (dctFullMessageTopic["eMessageFlowDirection"] == eMessageFlowDirection))]

        acReturn += "std::vector<std::string> g_vecMqttTopicsSubscribe = \n"
        acReturn += "{\n"

        # Iterate through the list of topics
        for dctFullMessageTopic in lstFullMessageTopics:

            # Only keep the MQTT topics

            if (not dctFullMessageTopic["lstRoles"]):
                acReturn += "  \"%s/%s/%s\",\n" % (dctFullMessageTopic["acSystem"], dctFullMessageTopic["acModule"], dctFullMessageTopic["acMessageName"])
            else:
                # Add the role if there is one
                for acRole in dctFullMessageTopic["lstRoles"]:
                    acReturn += "  \"%s/%s/%s/%s\",\n" % (dctFullMessageTopic["acSystem"], dctFullMessageTopic["acModule"], dctFullMessageTopic["acMessageName"], acRole)

        acReturn += "};\n"

        return(acReturn)

    @staticmethod
    def acModInterConfTopicsMqttPublishHFile(dctModInterConfDictItemPar: dict):
        """ This is a public static method which generates an MIC topics MQTT Publish code block

        Args:
            dctModInterConfDictItemPar (dict):
                * ["lstFullTopicPartsForThisModConfInterface"] -> The list of topics

        Returns:
            (str): A code block which contains the code

        Raises:
            Raises no exception.
        """
        acReturn = str("")
        eCommsProtocol = E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT)
        eMessageFlowDirection = E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH)
        lstFullMessageTopics = []

        # Only keep the MQTT Publish topics
        lstFullMessageTopics = [dctFullMessageTopic for dctFullMessageTopic in dctModInterConfDictItemPar["lstFullTopicPartsForThisModConfInterface"] if ((dctFullMessageTopic["eCommsProtocol"] == eCommsProtocol) and (dctFullMessageTopic["eMessageFlowDirection"] == eMessageFlowDirection))]

        acReturn += "std::vector<std::string> g_vecMqttTopicsPublish = \n"
        acReturn += "{\n"

        # Iterate through the list of topics
        for dctFullMessageTopic in lstFullMessageTopics:

            # Only keep the MQTT topics

            if (not dctFullMessageTopic["lstRoles"]):
                acReturn += "  \"%s/%s/%s\",\n" % (dctFullMessageTopic["acSystem"], dctFullMessageTopic["acModule"], dctFullMessageTopic["acMessageName"])
            else:
                # Add the role if there is one
                for acRole in dctFullMessageTopic["lstRoles"]:
                    acReturn += "  \"%s/%s/%s/%s\",\n" % (dctFullMessageTopic["acSystem"], dctFullMessageTopic["acModule"], dctFullMessageTopic["acMessageName"], acRole)

        acReturn += "};\n"

        return(acReturn)

    @staticmethod
    def lstModInterConfEventHandlerHFileIncludes(dctModInterConfDictItemPar: dict):
        """ This is a public static method which generates a list of MIC EH includes

        Args:
            dctModInterConfDictItemPar (dict):
            *   ["lstFullTopicPartsForThisModConfInterface"]

        Returns:
            (str): A code block which contains a class

        Raises:
            Raises no exception.
        """
        lstReturn = []
        eMessageFlowDirection = E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE)
        lstSubMessages = []

        # Do sanity checks
        if (dctModInterConfDictItemPar is None):
            logging.error("dctModInterConfDictItemPar cannot be None")
            return(lstReturn)

        # Filter out all the subscribe messages
        lstSubMessages = [dctFullTopicParts for dctFullTopicParts in dctModInterConfDictItemPar["lstFullTopicPartsForThisModConfInterface"] if dctFullTopicParts["eMessageFlowDirection"] == eMessageFlowDirection]
        # For the topic part dict get the name and make it a Cap. Underscores
        lstSubMessageNamesAsCapUnderscores = [clsAutogenToolboxCodeGenerationCpp.acMessageNamePascalCaseToCapUnderscores(dctFullTopicParts["acMessageName"]) for dctFullTopicParts in lstSubMessages]

        lstReturn = lstSubMessageNamesAsCapUnderscores

        return(lstReturn)

    @staticmethod
    def acMsgDefFilenameToHeaderFilename(acMsgDefFileNamePar):
        """ This is a public static method converts a MsgDef filename into a generated header filename

        Args:
            acMsgDefFileNamePar (str): The MsgDef filename

        Returns:
            (list): A list of include C++ source lines

        Raises:
            Raises no exception.
        """
        bReturnFilename = str("")
        tplFileNameBaseAndExt = ()
        lstFileNameBaseTokens = []
        lstFileNameBaseTokensPascalCase = []
        acTokenPascalCase = str("")

        if (acMsgDefFileNamePar is None):
            logging.error("acMsgDefFileNamePar cannot be None")
            return(bReturnFilename)

        if (not acMsgDefFileNamePar):
            logging.error("acMsgDefFileNamePar cannot be empty")
            return(bReturnFilename)

        # Remove the extentsion - get just the base name
        try:
            tplFileNameBaseAndExt = os.path.splitext(acMsgDefFileNamePar)
        except Exception as E:  # noqa: F841  # pylint: disable=unused-variable
            logging.error("acMsgDefFileNamePar cannot be empty")
            return(bReturnFilename)

        # Split the string according to underscores
        try:
            lstFileNameBaseTokens = tplFileNameBaseAndExt[0].split("_")
        except Exception as E:  # noqa: F841
            logging.error("acMsgDefFileNamePar cannot be split")
            return(bReturnFilename)

        # Go through the split token and make them Pascal case
        for acToken in lstFileNameBaseTokens:
            acTokenPascalCase = acToken.lower()

            if (acTokenPascalCase):
                acTokenPascalCase = acTokenPascalCase[0].upper() + acTokenPascalCase[1:]
                lstFileNameBaseTokensPascalCase.append(acTokenPascalCase)
                bReturnFilename += acTokenPascalCase

        bReturnFilename += ".h"

        return(bReturnFilename)
