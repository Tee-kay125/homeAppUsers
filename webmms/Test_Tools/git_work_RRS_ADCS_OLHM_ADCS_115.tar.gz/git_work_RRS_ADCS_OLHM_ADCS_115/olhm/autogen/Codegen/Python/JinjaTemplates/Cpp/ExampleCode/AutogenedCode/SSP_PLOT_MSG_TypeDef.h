/*  Autogen Message PubSub h File  */
/*  Generated using Python 2.7.11 |Anaconda 4.1.0 (64-bit)| (default, Jun 15 2016, 15:21:30) , with Jinja2 2.10 */
/*  Generated on Wednesday, 23 October 2019 SAST 07:08           */

#ifndef SSP_PLOT_MSG_PUB_SUB_H
#define SSP_PLOT_MSG_PUB_SUB_H

#include <stdio.h>

#include "../SSP_Toolbox/Types/C/RrsBaseTypes.h"
#include "../SSP_Toolbox/Enums/C/CCS_Types.h"

//************************************************************************
//Topic Definitions
//************************************************************************
//Topic Length Defines
#define NUM_TOPICS 1


//Topic Name Arrays
extern const CH* G_ppchAllTopics[NUM_TOPICS];


//************************************************************************
//Typedef and Message Structures
//************************************************************************
typedef enum
{
  
  RANGE_NOT_RESOLVED = 0,
  RANGE_RESOLVED = 1,
  
} E4_RANGE_RESOLVED;

typedef enum
{
  
  ELEVATION_NOT_RESOLVED = 0,
  ELEVATION_RESOLVED = 1,
  
} E4_ELEVATION_RESOLVED;

typedef enum
{
  
  DOPPLER_NOT_RESOLVED = 0,
  DOPPLER_RESOLVED = 1,
  DOPPLER_RESOLVED_FAST = 2,
  DOPPLER_RESOLVED_SLOW = 3,
  
} E4_DOPPLER_RESOLVED;

typedef struct
{
  U8 u8TimeMicroS;
  U4 e4RangeResolved;
  F4 f4RangeBin;
  F4 f4RangeBinSizeM;
  F4 f4RangeExtentBins;
  F4 f4AzimuthDeg;
  U4 e4DopplerResolved;
  F4 f4DopplerBin;
  F4 f4DopplerBinSizeMs;
  F4 f4NumberOfDopplerBins;
  F4 f4DopplerExtentFreqABins;
  F4 f4DopplerExtentFreqBBins;
  F4 f4DopplerExtentFreqCBins;
  F4 f4SnrFreqAdB;
  F4 f4SnrFreqBdB;
  F4 f4SnrFreqCdB;
  U8 u8UniquePlotId;
  F4 f4ClutterFlags;
  F4 f4CoastLineMask;
  F4 f4SeaMask;
  F4 f4SeaSpikiness;
  F4 f4NearRoad;
  F4 f4StatsMap;
  F4 f4LastAntennaDirection;
  U4 e4ElevationResolved;
  F4 f4ElevationDeg;
  F4 f4Prf;
  F4 f4ClutterValue;
  F4 f4BladeFlash;
  
} __attribute__ ((packed)) sSSPPLOT;

/* TYPDEFS STOP */


/* MESSAGE STRUCTS START */

/* HEADER OF ALL MESSAGES */

typedef struct
{

  U2 u2MsgLength;
  U2 u2MsgType;
  U2 u2MsgStatus;
  U2 u2ModuleAddress;
  U2 u2MsgId;
  
} __attribute__ ((packed)) sMESSAGE_HEADER_SSP_TTS;

typedef struct
{
  
  U4 u4NumberOfPlots;
  U8 u8TimestampMicroS;
  U4 u4RadarSilence;
  F4 f4LastAzimuthProcessedDeg;
  F4 f4RotationRateRpm;
  U4 u4PlotDataId;
  
} __attribute__ ((packed)) sSSPPLOTDATA_PL;



/* START FULL MESSAGE STRUCTS */


typedef struct
{
  
  sMESSAGE_HEADER_SSP_TTS sMsgHeader;

  /* PAYLOAD START */
  U4 u4NumberOfPlots;
  U8 u8TimestampMicroS;
  U4 u4RadarSilence;
  F4 f4LastAzimuthProcessedDeg;
  F4 f4RotationRateRpm;
  U4 u4PlotDataId;
  
} __attribute__ ((packed)) sSSPPLOTDATA;




#endif

/* END OF FILE */