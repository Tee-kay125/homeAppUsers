/*  Autogen Message Topic List Header */
/*  Generated using Python 2.7.11 |Anaconda 4.1.0 (64-bit)| (default, Jun 15 2016, 15:21:30) , with Jinja2 2.10 */
/*  Generated on Wednesday, 23 October 2019 SAST 07:08           */


#ifndef RMS_SSP_MSG_TOPICS_H
#define RMS_SSP_MSG_TOPICS_H

#include "../SSP_Toolbox/Types/C/RrsBaseTypes.h"
#include "../SSP_Toolbox/Enums/C/CCS_Types.h"

//Topic Length Defines
#define NUM_TOPICS 20
#define NUM_INC_TOPICS 10
#define NUM_RSP_TOPICS 10


//Topic Name Arrays
extern const CH* G_ppchAllTopics[NUM_TOPICS]; 
extern const CH* G_ppchIncTopics[NUM_INC_TOPICS];
extern const CH* G_ppchRspTopics[NUM_RSP_TOPICS];


// Message Header Structure
typedef struct
{
  U2 u2MsgLength;
  U2 u2MsgType;
  U2 u2MsgStatus;
  U2 u2ModuleAddress;
  U2 u2MsgId;
  
} __attribute__ ((packed)) sMESSAGE_HEADER;


// Get Topic Name Function
I4 i4GetTopicName(U1* pu1TopicName, CH* pchMsgPayload);


#endif

/* END OF FILE */