//*********************************************************************
// clRDAC_LUT
// ==========
// This class reads maps a RDAC .dat file to memory and provides easy access
// to the data. The RDAC .dat file can be generated using "../MAT/GenRdacLut.m"
// or can be converted from an existing RDAC .mat file using "../MAT/fRdacMat2Dat".
//
// See "../MAT/fRdacMat2Dat" for details on the format of the .dat file.
//*********************************************************************

#ifndef CL_RDAC_LUT_H
#define CL_RDAC_LUT_H


//--------------------------------------------------------------------
// INCLUDES
//--------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cmath>

//RRS custom includes
#include "../../../../MMF/Utils/C_LIN/MapMmfFile.h"
#include "../../../../Types/C/RrsBaseTypes.h"


//--------------------------------------------------------------------
// STRUCTURES & ENUMS
//--------------------------------------------------------------------
struct sRDAC_LUT
{
    U4  u4NumCellAvgLen;
    U4  u4NumPfaLog10;
    U4  u4EstLen;
    F4 *m3f4MarginLut;
    F4 *af4PfaIdxVals;
    F4 *af4EstOffset;
    F4 *af4EstScale;
    U4 *au4CellAvgLengths;
};

typedef enum
{
  
  RDAC_MAR_NO_CONV    = 0x00,   //Leave margin in dB
  RDAC_MAR_TO_POW     = 0x01,   //Convert margin to power
  RDAC_MAR_TO_VOLTAGE = 0x02,   //Convert margin to voltage
  
} E1_MARGIN_CONVERSION;



//--------------------------------------------------------------------
// Class Definition
//--------------------------------------------------------------------
class clRDAC_LUT
{
    private:
        void*       m_pvRdacLut;
        I4          m_i4RdacLutFid;
        struct stat m_sRdacLutFs;
        sRDAC_LUT   sRdacParams;

        //-----------------------------------------------------------------
        // vConvertToPower()
        // Convert lookup table margins in dB to power (10^(Margin/10))
        //
        //-----------------------------------------------------------------
        void vConvertToPower();

        //-----------------------------------------------------------------
        // vConvertToVoltage()
        // Convert lookup table margins in dB to voltage (10^(Margin/20))
        //
        //-----------------------------------------------------------------
        void vConvertToVoltage();

    public:
        //-----------------------------------------------------------------
        // clRDAC_LUT()
        //
        //-----------------------------------------------------------------
        clRDAC_LUT(void);

        //-----------------------------------------------------------------
        // ~clRDAC_LUT()
        //
        //-----------------------------------------------------------------
        ~clRDAC_LUT();

        //-----------------------------------------------------------------
        // i4Initialize()
        // Initialize and allocate resources for the class
        //
        // Inputs:
        //   pchLutFilename   : Name of the .dat file containing the RDAC Margins LUT
        //   u1ConversionType : Type of conversion to perform on the RDAC margin, E1_MARGIN_CONVERSION has the options
        //
        // Returns:
        //   1 : Success
        //  -1 : Error opening .dat file specified
        //-----------------------------------------------------------------
        I4 i4Initialize(const char* pchLutFilename, U1 u1ConversionType=RDAC_MAR_TO_POW);

        //-----------------------------------------------------------------
        // vShutdown()
        // Release resources allocated for the class
        //
        //-----------------------------------------------------------------
        void vShutdown(void);

        //-----------------------------------------------------------------
        // psGetParams()
        // Get the pointer to the parameters struct with all parameters read
        // from the .dat file.
        //
        // Returns:
        //   Pointer to struct containing RDAC parameters
        //-----------------------------------------------------------------
        sRDAC_LUT* psGetParams();
};

#endif //CL_RDAC_LUT_H