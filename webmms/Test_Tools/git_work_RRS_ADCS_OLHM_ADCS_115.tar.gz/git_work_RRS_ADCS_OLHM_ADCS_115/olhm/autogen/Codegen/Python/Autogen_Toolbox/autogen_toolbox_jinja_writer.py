#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
""" This module provides a class which provides Jinja2 writer functionality

"""
import logging
import os  # Need this to get the Python version
import sys  # Need this to get the Python version
import time  # Need this to get the autogen generation date
import re
from shutil import copyfile  # We need this to copy files
from enum import Enum
from jinja2 import Environment, FileSystemLoader  # We need this to write out autogen using a template file
from jinja2 import __version__ as JinjaVersion  # We need this to get the Jinja2 version
from Autogen_Toolbox.autogen_toolbox_definition_validation_and_et_finding import E_TYPEDEF_XML_FILE_TYPEDEF_TYPE
from Autogen_Toolbox.autogen_toolbox_code_generation_cpp import clsAutogenToolboxCodeGenerationCpp
from Autogen_Toolbox.autogen_toolbox_code_generation_python import clsAutogenToolboxCodeGenerationPython
from Autogen_Toolbox.autogen_toolbox_code_generation_csharp import clsAutogenToolboxCodeGenerationCSharp
from Autogen_Toolbox.autogen_toolbox_code_generation_matlab import clsAutogenToolboxCodeGenerationMatlab


class E_CPP_TYPE_OF_AUTOGEN_FILE(Enum):
    """ This is enum which denotes all the types of Typedefs a Typedef XML can have.

    """
    CPP_AUTOGEN_TYPE_MAIN_MSG_DEF_FILE = 1
    CPP_AUTOGEN_TYPE_INCLUDED_TYPE_FILE = 2


class E_PYTHON_TYPE_OF_AUTOGEN_FILE(Enum):
    """ This is enum which denotes all the types of Typedefs a Typedef XML can have.

    """
    PYTHON_AUTOGEN_TYPE_MAIN_MSG_DEF_FILE = 1
    PYTHON_AUTOGEN_TYPE_INCLUDED_TYPE_FILE = 2


class E_MATLAB_GENERATION_TYPE(Enum):
    """ This is an enum which denotes if the Matlab code
        should be generated into the Structs or Structs_Double directory
    """
    MATLAB_GENERATION_STRUCTS = 1
    MATLAB_GENERATION_STRUCTS_DOUBLE = 2


class clsAutogenToolboxJinjaWriter():
    """ This class provides a class which provides Jinja2 writer functionality


    """

    @staticmethod
    def acFilenameToPascalCaseFile(acFileNamePar: str):
        """ This is a public static method takes a XML filename and coverts it into C++ Pascal case format

        Args:
            acFileNamePar (str): The filename which needs to be converted to Pascal case.

        Returns:
            (str): The resultant Pascal case filename

        Raises:
            Raises no exception.
        """
        bReturnFilename = str("")
        tplFileNameBaseAndExt = ()
        lstFileNameBaseTokens = []
        lstFileNameBaseTokensPascalCase = []
        acTokenPascalCase = str("")

        if (acFileNamePar is None):
            logging.error("acFileNamePar cannot be None")
            return(bReturnFilename)

        if (not acFileNamePar):
            logging.error("acFileNamePar cannot be empty")
            return(bReturnFilename)

        # Remove the extentsion - get just the base name
        try:
            tplFileNameBaseAndExt = os.path.splitext(acFileNamePar)
        except Exception as E:
            logging.error("acFileNamePar cannot be empty")
            return(bReturnFilename)

        # Split the string according to underscores
        try:
            lstFileNameBaseTokens = tplFileNameBaseAndExt[0].split("_")
        except Exception as E:
            logging.error("acFileNamePar cannot be split")
            return(bReturnFilename)

        # Go through the split token and make them Pascal case
        for acToken in lstFileNameBaseTokens:
            acTokenPascalCase = acToken.lower()

            if (acTokenPascalCase):
                acTokenPascalCase = acTokenPascalCase[0].upper() + acTokenPascalCase[1:]
                lstFileNameBaseTokensPascalCase.append(acTokenPascalCase)
                bReturnFilename += acTokenPascalCase

        bReturnFilename += ".h"

        return(bReturnFilename)

    @staticmethod
    def acEnumNameToPascalCase(acEnumNamePar: str):
        """ This is a public static method takes a enum name and converts into a Pascal case name

        Args:
            acEnumNamePar (str): The enum name to converted into Pascal case.

        Returns:
            (str): The Pascal case result

        Raises:
            Raises no exception.
        """
        acPascalCaseResult = str("")
        lstTokens = []
        iTokenCounter = int(0)

        if (acEnumNamePar is None):
            logging.error("acEnumNamePar cannot be None")
            return(acPascalCaseResult)

        if (isinstance(acEnumNamePar, str) is False):
            logging.error("acEnumNamePar must be str")
            return(acPascalCaseResult)

        if (not acEnumNamePar):
            logging.error("acEnumNamePar cannot be empty")
            return(acPascalCaseResult)

        lstTokens = acEnumNamePar.split("_")

        iTokenCounter = -1
        # Iterate throught the tokens
        for acToken in lstTokens:
            iTokenCounter += 1

            if (iTokenCounter == 0):
                continue

            # Check that the token is not empty
            if (not acToken):
                continue

            acPascalCaseResult += acToken[0].upper() + acToken[1:].lower()

        return(acPascalCaseResult)

    @staticmethod
    def acStructNameToPascalCase(acStructNamePar: str):
        """ This is a public static method takes a struct name and converts into a Pascal case name

        Args:
            acStructNamePar (str): The enum name to converted into Pascal case.

        Returns:
            (str): The Pascal case result

        Raises:
            Raises no exception.
        """
        acPascalCaseResult = str("")
        lstTokens = []

        if (acStructNamePar is None):
            logging.error("acStructNamePar cannot be None")
            return(acPascalCaseResult)

        if (isinstance(acStructNamePar, str) is False):
            logging.error("acStructNamePar must be str")
            return(acPascalCaseResult)

        if (not acStructNamePar):
            logging.error("acStructNamePar cannot be empty")
            return(acPascalCaseResult)

        # Remove the lower case s from the name
        if (acStructNamePar[0] == "s"):
            acStructNamePar = acStructNamePar[1:]

        lstTokens = acStructNamePar.split("_")

        # Iterate throught the tokens
        for acToken in lstTokens:

            # Check that the token is not empty
            if (not acToken):
                continue

            acPascalCaseResult += acToken[0].upper() + acToken[1:].lower()

        return(acPascalCaseResult)

    @staticmethod
    def acMessageNamePascalCaseToCapUnderscores(acMessageNamePar: str):
        """ This is a public static method takes a struct name and converts into a Pascal case name

        Args:
            acStructNamePar (str): The enum name to converted into Pascal case.

        Returns:
            (str): The Pascal case result

        Raises:
            Raises no exception.
        """
        acCapUnderscoresResult = str("")
        lstTokens = []
        lstUppercaseTokens = []

        if (acMessageNamePar is None):
            logging.error("acMessageNamePar cannot be None")
            return(acCapUnderscoresResult)

        if (isinstance(acMessageNamePar, str) is False):
            logging.error("acMessageNamePar must be a string")
            return(acCapUnderscoresResult)

        if (not acMessageNamePar):
            return(acCapUnderscoresResult)

        # See if there are any uppercase letters - create a generator
        if (sum(1 for acChar in acMessageNamePar if acChar.isupper()) == 0):
            acCapUnderscoresResult = acMessageNamePar
            return(acCapUnderscoresResult)

        # Split the tokens on an uppercase letter
        lstTokens = re.findall('[a-zA-Z][^A-Z]*', acMessageNamePar)
        # Turn the tokens into uppercase
        lstUppercaseTokens = [acToken.upper() for acToken in lstTokens]
        # Join the tokens with an underscore
        acCapUnderscoresResult = "_".join(lstUppercaseTokens)

        return(acCapUnderscoresResult)

    @staticmethod
    def bPopulateGeneralAutogenRequiredInformationForDefinition(dctWriterContextPar: dict):
        """ This is a public static method which fills information into MsgDef related dictionary
        designated for autogen Jinja rendering with info that will be required agnostic to the
        specific language being generated for.

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["acJinja2Version"] (str)
                * ["acPythonVersion"] (str)
                * ["acDate"] (str)

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        acPythonVersion = str("")
        bReturn = bool(False)

        dctWriterContextPar["acJinja2Version"] = JinjaVersion
        dctWriterContextPar["acPythonVersion"] = str("")

        try:
            acPythonVersion = str(sys.version_info[0]) + "." + str(sys.version_info[1]) + "." + str(sys.version_info[2])
            dctWriterContextPar["acPythonVersion"] = acPythonVersion
        except Exception as E:
            logging.error("Could not get the Python version - Exception %s", str(E))

        dctWriterContextPar["acDate"] = time.strftime("%Y-%m-%d %H:%M:%S %Z")

        bReturn = bool(True)
        return(bReturn)

    @staticmethod
    def bPopulateGeneralAutogenRequiredInformationForModInterConf(dctWriterContextPar: dict):
        """ This is a public static method which fills information into ModInterConf related dictionary
        designated for autogen Jinja rendering with info that will be required agnostic to the
        specific language being generated for.

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["acJinja2Version"] (str)
                * ["acPythonVersion"] (str)
                * ["acDate"] (str)
                * ["acCppDefJinjaTemplatePath"] (str)
                * ["acCppAutogenOutputDirectory"] (str)
                * ["dctProgLangSpecific"] (dict) -> This dict is mostly used in the Jinja template

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        acPythonVersion = str("")
        bReturn = bool(False)

        dctWriterContextPar["acJinja2Version"] = JinjaVersion
        dctWriterContextPar["acPythonVersion"] = str("")

        try:
            acPythonVersion = str(sys.version_info[0]) + "." + str(sys.version_info[1]) + "." + str(sys.version_info[2])
            dctWriterContextPar["acPythonVersion"] = acPythonVersion
        except Exception as E:
            logging.error("Could not get the Python version - Exception %s", str(E))

        dctWriterContextPar["acDate"] = time.strftime("%Y-%m-%d %H:%M:%S %Z")

        bReturn = bool(True)
        return(bReturn)

    @staticmethod
    def bPopulateGeneralAutogenRequiredInformationForPythonMqttClientOnConnect(dctWriterContextPar: dict):
        """ This is a public static method which fills information into the Python MQTT client on connect related dictionary
        designated for autogen Jinja rendering with info that will be required agnostic to the
        specific language being generated for.

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Python Mqtt client on connect. The keys are:
                * ["acJinja2Version"] (str)
                * ["acPythonVersion"] (str)
                * ["acDate"] (str)

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        acPythonVersion = str("")
        bReturn = bool(False)

        dctWriterContextPar["acJinja2Version"] = JinjaVersion
        dctWriterContextPar["acPythonVersion"] = str("")

        try:
            acPythonVersion = str(sys.version_info[0]) + "." + str(sys.version_info[1]) + "." + str(sys.version_info[2])
            dctWriterContextPar["acPythonVersion"] = acPythonVersion
        except Exception as E:
            logging.error("Could not get the Python version - Exception %s", str(E))

        dctWriterContextPar["acDate"] = time.strftime("%Y-%m-%d %H:%M:%S %Z")

        bReturn = bool(True)
        return(bReturn)

    @staticmethod
    def bPopulateGeneralAutogenRequiredInformationForPythonAsyncioMessageProcessing(dctWriterContextPar: dict):
        """ This is a public static method which fills information into the Python asyncion message processing context
        designated for autogen Jinja rendering with info that will be required agnostic to the
        specific language being generated for.

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Python Mqtt client on connect. The keys are:
                * ["acJinja2Version"] (str)
                * ["acPythonVersion"] (str)
                * ["acDate"] (str)

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        acPythonVersion = str("")
        bReturn = bool(False)

        dctWriterContextPar["acJinja2Version"] = JinjaVersion
        dctWriterContextPar["acPythonVersion"] = str("")

        try:
            acPythonVersion = str(sys.version_info[0]) + "." + str(sys.version_info[1]) + "." + str(sys.version_info[2])
            dctWriterContextPar["acPythonVersion"] = acPythonVersion
        except Exception as E:
            logging.error("Could not get the Python version - Exception %s", str(E))

        dctWriterContextPar["acDate"] = time.strftime("%Y-%m-%d %H:%M:%S %Z")

        bReturn = bool(True)
        return(bReturn)

    @staticmethod
    def bPrepareRenderContextForCppDefinition(dctCppDefWriterContext, eCppTypeOfAutogenFile: E_CPP_TYPE_OF_AUTOGEN_FILE, acXmlFilenamePar: str):
        """ This is a public static method which prepares context info for the C++ render for definition

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["dctMsgDefXmlFile"] (dict)
                    * ["acFileName"]
                    * ["dctAllTypesElementsForThisFileIncludingIncludes"] -> Dictionary with all types in this MsgDef file and all the included XML
                    * ["tplCommonIncludeXmlFiles"]
                        * [0] (bool)
                        * [1] (list) -> list of included XML files
                * ["dctProgLangSpecific"] (dict) -> This is used by the Jinja template
            eCppTypeOfAutogenFile (E_CPP_TYPE_OF_AUTOGEN_FILE)
            acXmlFilenamePar (str) -> The name of the XML file being made autogen C++ code of

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        acPreCompIfName = str("")  # Used to store the name of C++ code which combined with the ifndef/define code
        acInclude = str("")  # Used to store the C++ code which is the hash include of another h file
        dctAllTypesElementsForThisFileIncludingIncludes = {}  # To keep a local copy of all the Types used by this MsgDef file (it includes the types from the included files)
        lstOfTypesForThisFile = []  # Will store all the Types for this file
        acTypeSourceBlock = str("")
        acXmlFilename = str("")

        if (dctCppDefWriterContext is None):
            logging.error("dctCppDefWriterContext")

        dctCppDefWriterContext["dctProgLangSpecific"]["Cpp"] = {}
        dctCppDefWriterContext["dctProgLangSpecific"]["Cpp"]["Definition"] = {}
        dctCppDefWriterContext["dctProgLangSpecific"]["Cpp"]["Definition"]["acXmlFilename"] = str("")
        dctCppDefWriterContext["dctProgLangSpecific"]["Cpp"]["Definition"]["acPreCompInclude"] = str("")
        dctCppDefWriterContext["dctProgLangSpecific"]["Cpp"]["Definition"]["lstIncludes"] = []
        dctCppDefWriterContext["dctProgLangSpecific"]["Cpp"]["Definition"]["lstTypes"] = []
        dctCppDefWriterContext["dctProgLangSpecific"]["Cpp"]["Definition"]["lstHeaders"] = []
        dctCppDefWriterContext["dctProgLangSpecific"]["Cpp"]["Definition"]["lstPayloads"] = []
        dctCppDefWriterContext["dctProgLangSpecific"]["Cpp"]["Definition"]["lstMessages"] = []

        if (eCppTypeOfAutogenFile == E_CPP_TYPE_OF_AUTOGEN_FILE(E_CPP_TYPE_OF_AUTOGEN_FILE.CPP_AUTOGEN_TYPE_MAIN_MSG_DEF_FILE)):
            acXmlFilename = dctCppDefWriterContext["dctMsgDefXmlFile"]["acFileName"]
            # Generate the Message header code block
            dctCppDefWriterContext["dctProgLangSpecific"]["Cpp"]["Definition"]["lstHeaders"] = clsAutogenToolboxCodeGenerationCpp.lstGenerateCppHeaders(dctCppDefWriterContext["dctMsgDefXmlFile"])
            # Generate the Message Payload code blocks
            dctCppDefWriterContext["dctProgLangSpecific"]["Cpp"]["Definition"]["lstPayloads"] = clsAutogenToolboxCodeGenerationCpp.lstGenerateCppPayloads(dctCppDefWriterContext["dctMsgDefXmlFile"])
            # Generate the Message code blocks
            dctCppDefWriterContext["dctProgLangSpecific"]["Cpp"]["Definition"]["lstMessages"] = clsAutogenToolboxCodeGenerationCpp.lstGenerateCppMessages(dctCppDefWriterContext["dctMsgDefXmlFile"])

        else:
            acXmlFilename = acXmlFilenamePar

        # Make precompiler if name that is capatilised underscores + _H
        acPreCompIfName = (acXmlFilename.upper()).replace("XML", "H").replace(".", "_")

        dctCppDefWriterContext["dctProgLangSpecific"]["Cpp"]["Definition"]["acPreCompInclude"] = acPreCompIfName

        # Only process what the C++ common includes should be if this is a MsgDef (not Typedef) file
        if (eCppTypeOfAutogenFile == E_CPP_TYPE_OF_AUTOGEN_FILE(E_CPP_TYPE_OF_AUTOGEN_FILE.CPP_AUTOGEN_TYPE_MAIN_MSG_DEF_FILE)):
            if (dctCppDefWriterContext["dctMsgDefXmlFile"]["tplCommonIncludeXmlFiles"][0] is True):
                for acFileName in dctCppDefWriterContext["dctMsgDefXmlFile"]["tplCommonIncludeXmlFiles"][1]:
                    acInclude = str("#include \"") + clsAutogenToolboxJinjaWriter.acFilenameToPascalCaseFile(acFileName) + "\""
                    dctCppDefWriterContext["dctProgLangSpecific"]["Cpp"]["Definition"]["lstIncludes"].append(acInclude)

        # Keep a local copy of all the Types used by this MsgDef file (it includes the types from the included files)
        dctAllTypesElementsForThisFileIncludingIncludes = dctCppDefWriterContext["dctMsgDefXmlFile"]["dctAllTypesElementsForThisFileIncludingIncludes"]

        # Store the name of the XML in the context to be used by the Jinja template
        dctCppDefWriterContext["dctProgLangSpecific"]["Cpp"]["Definition"]["acXmlFilename"] = acXmlFilename

        # Use list comprehension and get all the types for only this MsgDef file
        lstOfTypesForThisFile = [dctItem for acTypeName, dctItem in dctAllTypesElementsForThisFileIncludingIncludes.items() if dctItem["acXmlFileName"] == dctCppDefWriterContext["dctProgLangSpecific"]["Cpp"]["Definition"]["acXmlFilename"]]

        for dctMsgDefTypedefItem in lstOfTypesForThisFile:

            if (dctMsgDefTypedefItem["eTypedefType"] == E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_ENUM)):
                acTypeSourceBlock = clsAutogenToolboxCodeGenerationCpp.acGenerateTypeEnumComplete(dctMsgDefTypedefItem)
                dctCppDefWriterContext["dctProgLangSpecific"]["Cpp"]["Definition"]["lstTypes"].append(acTypeSourceBlock)
            elif (dctMsgDefTypedefItem["eTypedefType"] == E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_STRUCT)):
                acTypeSourceBlock = clsAutogenToolboxCodeGenerationCpp.acGenerateTypeStructComplete(dctMsgDefTypedefItem)
                dctCppDefWriterContext["dctProgLangSpecific"]["Cpp"]["Definition"]["lstTypes"].append(acTypeSourceBlock)

        return(bReturn)

    @staticmethod
    def bPrepareRenderContextForCppDefinitionMessageEventHandler(dctCppDefWriterContextPar: dict):
        """ This is a public static method which prepares context info for the C++ render for definition

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Cpp Definition Message Event Handler file.
                * ["dctProgLangSpecific"] (dict) -> This is used by the Jinja template

        Returns:
            (bool): Flag to indicate if method was succesfull or not

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        acMessageName = str("")
        acMessageNameCapUnderscores = str("")
        acModuleName = str("")

        if (dctCppDefWriterContextPar is None):
            logging.error("dctCppDefWriterContextPar cannot be None")
            return(bReturn)

        if ("acModuleName" not in dctCppDefWriterContextPar):
            logging.error("acModuleName not in dctCppDefWriterContextPar")
            return(bReturn)

        if (not dctCppDefWriterContextPar["acModuleName"]):
            logging.error("Dict key acModuleName cannot be an empty string")
            return(bReturn)

        if ("dctValidMessageHeader" not in dctCppDefWriterContextPar):
            logging.error("dctValidMessageHeader not in dctCppDefWriterContextPar")
            return(bReturn)

        acModuleName = dctCppDefWriterContextPar["acModuleName"].lower()
        acMsgDefInclude = "%sMsg.h" % (acModuleName[0].upper() + acModuleName[1:])

        acMessageName = dctCppDefWriterContextPar["dctValidMessageHeader"]["acName"]
        acMessageNameCapUnderscores = clsAutogenToolboxJinjaWriter.acMessageNamePascalCaseToCapUnderscores(acMessageName)

        dctCppDefWriterContextPar["dctProgLangSpecific"]["Cpp"]["Definition"]["dctMessage"] = {}
        dctCppDefWriterContextPar["dctProgLangSpecific"]["Cpp"]["Definition"]["dctMessage"]["acName"] = acMessageName
        dctCppDefWriterContextPar["dctProgLangSpecific"]["Cpp"]["Definition"]["dctMessage"]["acNameCapUnderscores"] = acMessageNameCapUnderscores
        dctCppDefWriterContextPar["dctProgLangSpecific"]["Cpp"]["Definition"]["dctMessage"]["acMsgDefIncludeFile"] = acMsgDefInclude

        bReturn = bool(True)
        return(bReturn)

    @staticmethod
    def bPrepareRenderContextForCppModInterConf(dctCppModInterConfContextPar: dict, dctModInterConfFileDictItemPar: dict):
        """ This is a public static method which prepares context info for the C++ module interface configuration render

        Args:
            dctCppModInterConfContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["dctProgLangSpecific"] (dict) -> This is used by the Jinja template
            dctModInterConfFileDictItemPar (dict) ->
                * ["acFileName"] (str) -> The Mod Inter Conf filename

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)

        dctCppModInterConfContextPar["dctProgLangSpecific"] = {}
        dctCppModInterConfContextPar["dctProgLangSpecific"]["Cpp"] = {}
        dctCppModInterConfContextPar["dctProgLangSpecific"]["Cpp"]["ModInterConf"] = {}
        dctCppModInterConfContextPar["dctProgLangSpecific"]["Cpp"]["ModInterConf"]["acXmlFilename"] = dctModInterConfFileDictItemPar["acFileName"]
        dctCppModInterConfContextPar["dctProgLangSpecific"]["Cpp"]["ModInterConf"]["acCapatilisedUnderscoresName"] = dctCppModInterConfContextPar["acModInterConfXmlFilenameAsCapUnder"]
        dctCppModInterConfContextPar["dctProgLangSpecific"]["Cpp"]["ModInterConf"]["CppFile"] = {}
        dctCppModInterConfContextPar["dctProgLangSpecific"]["Cpp"]["ModInterConf"]["HFile"] = {}
        dctCppModInterConfContextPar["dctProgLangSpecific"]["Cpp"]["ModInterConf"]["HFile"]["acPreCompInclude"] = str("")
        dctCppModInterConfContextPar["dctProgLangSpecific"]["Cpp"]["ModInterConf"]["HFile"]["acPreCompInclude"] = clsAutogenToolboxCodeGenerationCpp.acModInterConfHFileGeneratePrecompileIfdef(dctModInterConfFileDictItemPar)
        dctCppModInterConfContextPar["dctProgLangSpecific"]["Cpp"]["ModInterConf"]["HFile"]["lstIncludes"] = clsAutogenToolboxCodeGenerationCpp.lstModInterConfHFileGenerateIncludes(dctModInterConfFileDictItemPar)
        dctCppModInterConfContextPar["dctProgLangSpecific"]["Cpp"]["ModInterConf"]["HFile"]["acModInterConfClass"] = clsAutogenToolboxCodeGenerationCpp.acModInterConfHFileGenerateClass(dctModInterConfFileDictItemPar)
        dctCppModInterConfContextPar["dctProgLangSpecific"]["Cpp"]["ModInterConf"]["HFile"]["acModInterConfTopicTopicsZmqSubscribe"] = clsAutogenToolboxCodeGenerationCpp.acModInterConfTopicsZmqSubscribeHFile(dctModInterConfFileDictItemPar)
        dctCppModInterConfContextPar["dctProgLangSpecific"]["Cpp"]["ModInterConf"]["HFile"]["acModInterConfTopicTopicsZmqPublish"] = clsAutogenToolboxCodeGenerationCpp.acModInterConfTopicsZmqPublishHFile(dctModInterConfFileDictItemPar)
        dctCppModInterConfContextPar["dctProgLangSpecific"]["Cpp"]["ModInterConf"]["HFile"]["acModInterConfTopicTopicsMqttSubscribe"] = clsAutogenToolboxCodeGenerationCpp.acModInterConfTopicsMqttSubscribeHFile(dctModInterConfFileDictItemPar)
        dctCppModInterConfContextPar["dctProgLangSpecific"]["Cpp"]["ModInterConf"]["HFile"]["acModInterConfTopicTopicsMqttPublish"] = clsAutogenToolboxCodeGenerationCpp.acModInterConfTopicsMqttPublishHFile(dctModInterConfFileDictItemPar)

        dctCppModInterConfContextPar["dctProgLangSpecific"]["Cpp"]["ModInterConf"]["CppFile"]["acPreCompInclude"] = clsAutogenToolboxCodeGenerationCpp.acModInterConfCppFilePrecompileInclude(dctModInterConfFileDictItemPar)
        dctCppModInterConfContextPar["dctProgLangSpecific"]["Cpp"]["ModInterConf"]["CppFile"]["acModInterConfClass"] = clsAutogenToolboxCodeGenerationCpp.acModInterConfCppFileClass(dctModInterConfFileDictItemPar)

        dctCppModInterConfContextPar["dctProgLangSpecific"]["Cpp"]["ModInterConfEventHandler"] = {}
        dctCppModInterConfContextPar["dctProgLangSpecific"]["Cpp"]["ModInterConfEventHandler"]["lstIncludes"] = clsAutogenToolboxCodeGenerationCpp.lstModInterConfEventHandlerHFileIncludes(dctModInterConfFileDictItemPar)

        bReturn = bool(True)
        return(bReturn)

    @staticmethod
    def bPrepareRenderContextForPythonDefinition(dctPythonDefWriterContext, ePythonTypeOfAutogenFile: E_PYTHON_TYPE_OF_AUTOGEN_FILE, acXmlFilenamePar: str):
        """ This is a public static method which prepares context info for the C++ render

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["dctMsgDefXmlFile"] (dict)
                    * ["acFileName"]
                    * ["dctAllTypesElementsForThisFileIncludingIncludes"] -> Dictionary with all types in this MsgDef file and all the included XML
                    * ["tplCommonIncludeXmlFiles"]
                        * [0] (bool)
                        * [1] (list) -> list of included XML files
                * ["dctProgLangSpecific"] (dict) -> This is used by the Jinja template
            ePythonTypeOfAutogenFile (E_PYTHON_TYPE_OF_AUTOGEN_FILE)
            acXmlFilenamePar (str) -> The name of the XML file being made autogen C++ code of

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        acPreCompIfName = str("")  # Used to store the name of C++ code which combined with the ifndef/define code
        acInclude = str("")  # Used to store the C++ code which is the hash include of another h file
        dctAllTypesElementsForThisFileIncludingIncludes = {}  # To keep a local copy of all the Types used by this MsgDef file (it includes the types from the included files)
        lstOfTypesForThisFile = []  # Will store all the Types for this file
        acTypeSourceBlock = str("")
        acXmlFilename = str("")

        if (dctPythonDefWriterContext is None):
            logging.error("dctPythonDefWriterContext")

        dctPythonDefWriterContext["dctProgLangSpecific"]["Python"] = {}
        dctPythonDefWriterContext["dctProgLangSpecific"]["Python"]["Definition"] = {}
        dctPythonDefWriterContext["dctProgLangSpecific"]["Python"]["Definition"]["acXmlFilename"] = str("")
        dctPythonDefWriterContext["dctProgLangSpecific"]["Python"]["Definition"]["acPreCompInclude"] = str("")
        dctPythonDefWriterContext["dctProgLangSpecific"]["Python"]["Definition"]["lstIncludes"] = []
        dctPythonDefWriterContext["dctProgLangSpecific"]["Python"]["Definition"]["lstTypes"] = []
        dctPythonDefWriterContext["dctProgLangSpecific"]["Python"]["Definition"]["lstHeaders"] = []
        dctPythonDefWriterContext["dctProgLangSpecific"]["Python"]["Definition"]["lstPayloads"] = []
        dctPythonDefWriterContext["dctProgLangSpecific"]["Python"]["Definition"]["lstMessages"] = []

        if (ePythonTypeOfAutogenFile == E_PYTHON_TYPE_OF_AUTOGEN_FILE(E_PYTHON_TYPE_OF_AUTOGEN_FILE.PYTHON_AUTOGEN_TYPE_MAIN_MSG_DEF_FILE)):
            acXmlFilename = dctPythonDefWriterContext["dctMsgDefXmlFile"]["acFileName"]
            # Generate the Message header code block
            dctPythonDefWriterContext["dctProgLangSpecific"]["Python"]["Definition"]["lstHeaders"] = clsAutogenToolboxCodeGenerationPython.lstGeneratePythonHeaders(dctPythonDefWriterContext["dctMsgDefXmlFile"])
            # Generate the Message Payload code blocks
            dctPythonDefWriterContext["dctProgLangSpecific"]["Python"]["Definition"]["lstPayloads"] = clsAutogenToolboxCodeGenerationPython.lstGeneratePythonPayloads(dctPythonDefWriterContext["dctMsgDefXmlFile"])
            # Generate the Message code blocks
            dctPythonDefWriterContext["dctProgLangSpecific"]["Python"]["Definition"]["lstMessages"] = clsAutogenToolboxCodeGenerationPython.lstGeneratePythonMessages(dctPythonDefWriterContext["dctMsgDefXmlFile"])

        else:
            acXmlFilename = acXmlFilenamePar

        # Make precompiler if name that is capatilised underscores + _H
        acPreCompIfName = (acXmlFilename.upper()).replace("XML", "H").replace(".", "_")

        dctPythonDefWriterContext["dctProgLangSpecific"]["Python"]["Definition"]["acPreCompInclude"] = acPreCompIfName

        # Only process what the Python common includes should be if this is a MsgDef (not Typedef) file
        if (ePythonTypeOfAutogenFile == E_PYTHON_TYPE_OF_AUTOGEN_FILE(E_PYTHON_TYPE_OF_AUTOGEN_FILE.PYTHON_AUTOGEN_TYPE_MAIN_MSG_DEF_FILE)):
            if (dctPythonDefWriterContext["dctMsgDefXmlFile"]["tplCommonIncludeXmlFiles"][0] is True):
                for acFileName in dctPythonDefWriterContext["dctMsgDefXmlFile"]["tplCommonIncludeXmlFiles"][1]:
                    acInclude = str("from Autogen.") + acFileName.replace(".xml", "").lower() + " import *"
                    dctPythonDefWriterContext["dctProgLangSpecific"]["Python"]["Definition"]["lstIncludes"].append(acInclude)

        # Keep a local copy of all the Types used by this MsgDef file (it includes the types from the included files)
        dctAllTypesElementsForThisFileIncludingIncludes = dctPythonDefWriterContext["dctMsgDefXmlFile"]["dctAllTypesElementsForThisFileIncludingIncludes"]

        # Store the name of the XML in the context to be used by the Jinja template
        dctPythonDefWriterContext["dctProgLangSpecific"]["Python"]["Definition"]["acXmlFilename"] = acXmlFilename

        # Use list comprehension and get all the types for only this MsgDef file
        lstOfTypesForThisFile = [dctItem for acTypeName, dctItem in dctAllTypesElementsForThisFileIncludingIncludes.items() if dctItem["acXmlFileName"] == dctPythonDefWriterContext["dctProgLangSpecific"]["Python"]["Definition"]["acXmlFilename"]]

        for dctMsgDefTypedefItem in lstOfTypesForThisFile:

            if (dctMsgDefTypedefItem["eTypedefType"] == E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_ENUM)):
                acTypeSourceBlock = clsAutogenToolboxCodeGenerationPython.acGenerateTypeEnumComplete(dctMsgDefTypedefItem)
                dctPythonDefWriterContext["dctProgLangSpecific"]["Python"]["Definition"]["lstTypes"].append(acTypeSourceBlock)
            elif (dctMsgDefTypedefItem["eTypedefType"] == E_TYPEDEF_XML_FILE_TYPEDEF_TYPE(E_TYPEDEF_XML_FILE_TYPEDEF_TYPE.TYPEDEF_XML_FILE_TYPEDEF_TYPE_STRUCT)):
                acTypeSourceBlock = clsAutogenToolboxCodeGenerationPython.acGenerateTypeStructComplete(dctMsgDefTypedefItem)
                dctPythonDefWriterContext["dctProgLangSpecific"]["Python"]["Definition"]["lstTypes"].append(acTypeSourceBlock)

        return(bReturn)

    @staticmethod
    def bPrepareRenderContextForPythonModInterConf(dctPythonModInterConfContextPar: dict, dctModInterConfFileDictItemPar: dict):
        """ This is a public static method which prepares context info for the Python module interface configuration render

        Args:
            dctPythonModInterConfContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["dctProgLangSpecific"] (dict) -> This is used by the Jinja template
            dctModInterConfFileDictItemPar (dict) ->
                * ["acFileName"] (str) -> The Mod Inter Conf filename

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)

        dctPythonModInterConfContextPar["dctProgLangSpecific"] = {}
        dctPythonModInterConfContextPar["dctProgLangSpecific"]["Python"] = {}
        dctPythonModInterConfContextPar["dctProgLangSpecific"]["Python"]["ModInterConf"] = {}
        dctPythonModInterConfContextPar["dctProgLangSpecific"]["Python"]["ModInterConf"]["acXmlFilename"] = dctModInterConfFileDictItemPar["acFileName"]
        dctPythonModInterConfContextPar["dctProgLangSpecific"]["Python"]["ModInterConf"]["acCapatilisedUnderscoresName"] = dctPythonModInterConfContextPar["acModInterConfXmlFilenameAsCapUnder"]
        dctPythonModInterConfContextPar["dctProgLangSpecific"]["Python"]["ModInterConf"]["PyFile"] = {}
        dctPythonModInterConfContextPar["dctProgLangSpecific"]["Python"]["ModInterConf"]["PyFile"] = {}
        dctPythonModInterConfContextPar["dctProgLangSpecific"]["Python"]["ModInterConf"]["PyFile"]["acPreCompInclude"] = str("")
        dctPythonModInterConfContextPar["dctProgLangSpecific"]["Python"]["ModInterConf"]["PyFile"]["acModInterConfClass"] = clsAutogenToolboxCodeGenerationPython.acModInterConfGenerateClass(dctModInterConfFileDictItemPar)

        bReturn = bool(True)
        return(bReturn)

    @staticmethod
    def bPrepareRenderContextForPythonMqttClientOnConnect(dctPythonMqttClientOnConnectContextPar: dict, dctModInterConfFileDictItemPar: dict):
        """ This is a public static method which prepares context info for the Python module interface configuration render

        Args:
            dctPythonMqttClientOnConnectContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["dctProgLangSpecific"] (dict) -> This is used by the Jinja template
            dctModInterConfFileDictItemPar (dict) ->
                * ["acFileName"] (str) -> The Mod Inter Conf filename

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)

        dctPythonMqttClientOnConnectContextPar["dctProgLangSpecific"] = {}
        dctPythonMqttClientOnConnectContextPar["dctProgLangSpecific"]["Python"] = {}
        dctPythonMqttClientOnConnectContextPar["dctProgLangSpecific"]["Python"]["MqttClientOnConnect"] = {}
        dctPythonMqttClientOnConnectContextPar["dctProgLangSpecific"]["Python"]["MqttClientOnConnect"]["acXmlFilename"] = dctModInterConfFileDictItemPar["acFileName"]
        dctPythonMqttClientOnConnectContextPar["dctProgLangSpecific"]["Python"]["MqttClientOnConnect"]["acCapatilisedUnderscoresName"] = dctPythonMqttClientOnConnectContextPar["acModInterConfXmlFilenameAsCapUnder"]
        dctPythonMqttClientOnConnectContextPar["dctProgLangSpecific"]["Python"]["MqttClientOnConnect"]["PyFile"] = {}
        dctPythonMqttClientOnConnectContextPar["dctProgLangSpecific"]["Python"]["MqttClientOnConnect"]["PyFile"]["acPreCompInclude"] = str("")
        dctPythonMqttClientOnConnectContextPar["dctProgLangSpecific"]["Python"]["MqttClientOnConnect"]["PyFile"]["acModInterConfClass"] = clsAutogenToolboxCodeGenerationPython.acModInterConfGenerateClass(dctModInterConfFileDictItemPar)

        dctPythonMqttClientOnConnectContextPar["dctProgLangSpecific"]["Python"]["MqttClientOnConnect"]["PyFile"]["lstImports"] = clsAutogenToolboxCodeGenerationPython.lstMqttClientOnConnectImports(dctModInterConfFileDictItemPar)
        dctPythonMqttClientOnConnectContextPar["dctProgLangSpecific"]["Python"]["MqttClientOnConnect"]["PyFile"]["lstMessages"] = clsAutogenToolboxCodeGenerationPython.lstMqttClientOnConnectMessages(dctModInterConfFileDictItemPar)

        bReturn = bool(True)
        return(bReturn)

    @staticmethod
    def bPrepareRenderContextForPythonAsyncioMessageProcessing(dctPythonAsyncioMessageProcessingContextPar: dict, dctModInterConfFileDictItemPar: dict):
        """ This is a public static method which prepares context info for the Python module interface configuration render

        Args:
            dctPythonAsyncioMessageProcessingContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["dctProgLangSpecific"] (dict) -> This is used by the Jinja template
            dctModInterConfFileDictItemPar (dict) ->
                * ["acFileName"] (str) -> The Mod Inter Conf filename

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)

        dctPythonAsyncioMessageProcessingContextPar["dctProgLangSpecific"] = {}
        dctPythonAsyncioMessageProcessingContextPar["dctProgLangSpecific"]["Python"] = {}
        dctPythonAsyncioMessageProcessingContextPar["dctProgLangSpecific"]["Python"]["AsyncioMessageProcessing"] = {}
        dctPythonAsyncioMessageProcessingContextPar["dctProgLangSpecific"]["Python"]["AsyncioMessageProcessing"]["acXmlFilename"] = dctModInterConfFileDictItemPar["acFileName"]
        dctPythonAsyncioMessageProcessingContextPar["dctProgLangSpecific"]["Python"]["AsyncioMessageProcessing"]["acCapatilisedUnderscoresName"] = dctPythonAsyncioMessageProcessingContextPar["acModInterConfXmlFilenameAsCapUnder"]
        dctPythonAsyncioMessageProcessingContextPar["dctProgLangSpecific"]["Python"]["AsyncioMessageProcessing"]["PyFile"] = {}
        dctPythonAsyncioMessageProcessingContextPar["dctProgLangSpecific"]["Python"]["AsyncioMessageProcessing"]["PyFile"]["acPreCompInclude"] = str("")
        dctPythonAsyncioMessageProcessingContextPar["dctProgLangSpecific"]["Python"]["AsyncioMessageProcessing"]["PyFile"]["acModInterConfClass"] = clsAutogenToolboxCodeGenerationPython.acModInterConfGenerateClass(dctModInterConfFileDictItemPar)

        dctPythonAsyncioMessageProcessingContextPar["dctProgLangSpecific"]["Python"]["AsyncioMessageProcessing"]["PyFile"]["lstImports"] = clsAutogenToolboxCodeGenerationPython.lstPythonAsyncioMessageProcessingImports(dctModInterConfFileDictItemPar)
        dctPythonAsyncioMessageProcessingContextPar["dctProgLangSpecific"]["Python"]["AsyncioMessageProcessing"]["PyFile"]["lstMessages"] = clsAutogenToolboxCodeGenerationPython.lstPythonAsyncioMessageProcessingMessages(dctModInterConfFileDictItemPar)

        bReturn = bool(True)
        return(bReturn)

    @staticmethod
    def bPrepareRenderContextForCSharpDefinitionEnum(dctWriterContextPar: dict, acEnumTypedefNamePar: str):
        """ This is a public static method which prepares context info for the C# definition enumeration render

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["dctMsgDefXmlFile"] (dict)
                    * ["dctAllTypesElementsForThisFileIncludingIncludes"] -> Dictionary with all types in this MsgDef file and all the included XML
                * ["dctProgLangSpecific"] (dict) -> This is used by the Jinja template
            acEnumTypedefNamePar (str): The name of enumeration typedef to prepare

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        dctTypedefItem = {}
        dctEnumParsedInfo = {}

        if (dctWriterContextPar is None):
            logging.error("dctWriterContextPar")
            return(bReturn)

        dctWriterContextPar["dctProgLangSpecific"]["CSharp"] = {}
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"] = {}
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Enum"] = {}
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Enum"]["acEnumerationNameCapUnder"] = acEnumTypedefNamePar

        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Enum"]["lstEnumerations"] = []

        dctTypedefItem = dctWriterContextPar["dctMsgDefXmlFile"]["dctAllTypesElementsForThisFileIncludingIncludes"][acEnumTypedefNamePar]
        dctEnumParsedInfo = clsAutogenToolboxCodeGenerationCSharp.dctGenerateTypeEnumComplete(dctTypedefItem)
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Enum"]["acTypedefComment"] = dctEnumParsedInfo["acTypedefComment"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Enum"]["lstEnumerations"] = dctEnumParsedInfo["lstEnumerations"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Enum"]["acEnumCSharpType"] = dctEnumParsedInfo["acTypedefCSharpDataType"]

        bReturn = bool(True)
        return(bReturn)

    @staticmethod
    def bPrepareRenderContextForCSharpDefinitionStruct(dctWriterContextPar: dict, acStructTypedefNamePar: str):
        """ This is a public static method which prepares context info for the C# definition struct render

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["dctMsgDefXmlFile"] (dict)
                    * ["dctAllTypesElementsForThisFileIncludingIncludes"] -> Dictionary with all types in this MsgDef file and all the included XML
                * ["dctProgLangSpecific"] (dict) -> This is used by the Jinja template
            acStructTypedefNamePar (str): The name of struct typedef to prepare

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        dctTypedefItem = {}
        dctStructParsedInfo = {}

        if (dctWriterContextPar is None):
            logging.error("dctWriterContextPar")
            return(bReturn)

        dctWriterContextPar["dctProgLangSpecific"]["CSharp"] = {}
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"] = {}
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Struct"] = {}
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Struct"]["acStructNameCapUnder"] = acStructTypedefNamePar
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Struct"]["lstRecords"] = []

        dctTypedefItem = dctWriterContextPar["dctMsgDefXmlFile"]["dctAllTypesElementsForThisFileIncludingIncludes"][acStructTypedefNamePar]

        # Parse the ElementTree elements for this Typedef
        dctStructParsedInfo = clsAutogenToolboxCodeGenerationCSharp.dctGenerateTypeStructComplete(dctTypedefItem)

        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Struct"]["acTypedefComment"] = dctStructParsedInfo["acTypedefComment"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Struct"]["lstRecords"] = dctStructParsedInfo["lstRecords"]

        bReturn = bool(True)
        return(bReturn)

    @staticmethod
    def bPrepareRenderContextForCSharpDefinitionControl(dctWriterContextPar: dict, dctModConfMessagePar: dict, dctMessageHeaderPar: dict, dctMessagePayloadPar: dict):
        """ This is a public static method which prepares context info for the C# definition control render

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["dctMsgDefXmlFile"] (dict)
                    * ["dctAllTypesElementsForThisFileIncludingIncludes"] -> Dictionary with all types in this MsgDef file and all the included XML
                * ["dctProgLangSpecific"] (dict) -> This is used by the Jinja template
            dctModConfMessagePar (dict): A dict containing info on the message
                * ["acMessageName"] (str) : The name of the message
            dctMessageHeaderPar (dict): A dict containing message header info
            dctMessagePayloadPar (dict): A dict containing message payload info

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)

        dctControlParsedInfo = {}

        if (dctWriterContextPar is None):
            logging.error("dctWriterContextPar cannot be None")
            return(bReturn)

        if (dctModConfMessagePar is None):
            logging.error("dctModConfMessagePar cannot be None")
            return(bReturn)

        if (dctMessageHeaderPar is None):
            logging.error("dctMessageHeaderPar cannot be None")
            return(bReturn)

        if (dctMessagePayloadPar is None):
            logging.error("dctMessagePayloadPar cannot be None")
            return(bReturn)

        dctWriterContextPar["dctProgLangSpecific"]["CSharp"] = {}
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"] = {}
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"] = {}
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["acMsgOwner"] = str("")
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["acMsgTopic"] = str("")
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["acMsgDirection"] = "Subscribe" if dctModConfMessagePar["eMessageFlowDirection"].name == 'MESSAGE_FLOW_DIRECTION_SUBSCRIBE' else "Publish"
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["acMsgName"] = dctModConfMessagePar["acMessageName"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["acMsgGroupName"] = str("")
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["acMsgComment"] = str("")
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["acMsgTypeAsString"] = str("")
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["lstMsgAccessAttributes"] = []
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["lstMsgHeaderFields"] = []
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["lstMsgPayloadFields"] = []

        # Parse the info required for this control message
        dctControlParsedInfo = clsAutogenToolboxCodeGenerationCSharp.dctGenerateMessageComplete(dctMessageHeaderPar, dctMessagePayloadPar, dctModConfMessagePar)

        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["acMsgComment"] = dctControlParsedInfo["acMsgComment"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["acMsgTypeAsString"] = dctControlParsedInfo["acMsgTypeAsString"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["acMsgName"] = dctModConfMessagePar["acMessageName"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["acMsgTopic"] = dctControlParsedInfo["acMsgTopic"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["acMsgGroupName"] = dctControlParsedInfo["acMsgGroupName"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["acMsgOwner"] = dctControlParsedInfo["acMsgOwner"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["lstMsgAccessAttributes"] = dctControlParsedInfo["lstMsgAccessAttributes"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["lstMsgHeaderFields"] = dctControlParsedInfo["lstMsgHeaderFields"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["lstMsgPayloadFields"] = dctControlParsedInfo["lstMsgPayloadFields"]

        bReturn = bool(True)
        return(bReturn)

    @staticmethod
    def bPrepareRenderContextForCSharpDefinitionData(dctWriterContextPar: dict, dctModConfMessagePar: dict, dctMessageHeaderPar: dict, dctMessagePayloadPar: dict):
        """ This is a public static method which prepares context info for the C# definition data render

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["dctMsgDefXmlFile"] (dict)
                    * ["dctAllTypesElementsForThisFileIncludingIncludes"] -> Dictionary with all types in this MsgDef file and all the included XML
                * ["dctProgLangSpecific"] (dict) -> This is used by the Jinja template
            dctModConfMessagePar (dict): A dict containing info on the message
                * ["acMessageName"] (str) : The name of the message
            dctMessageHeaderPar (dict): A dict containing message header info
            dctMessagePayloadPar (dict): A dict containing message payload info

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)

        dctDataParsedInfo = {}

        if (dctWriterContextPar is None):
            logging.error("dctWriterContextPar cannot be None")
            return(bReturn)

        if (dctModConfMessagePar is None):
            logging.error("dctModConfMessagePar cannot be None")
            return(bReturn)

        if (dctMessageHeaderPar is None):
            logging.error("dctMessageHeaderPar cannot be None")
            return(bReturn)

        if (dctMessagePayloadPar is None):
            logging.error("dctMessagePayloadPar cannot be None")
            return(bReturn)

        dctWriterContextPar["dctProgLangSpecific"]["CSharp"] = {}
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"] = {}
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"] = {}
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["acMsgOwner"] = str("")
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["acMsgTopic"] = str("")
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["acMsgName"] = dctModConfMessagePar["acMessageName"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["acMsgGroupName"] = str("")
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["acMsgComment"] = str("")
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["acMsgTypeAsString"] = str("")
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["lstMsgAccessAttributes"] = []
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["lstMsgHeaderFields"] = []
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["lstMsgPayloadFields"] = []

        # Parse the info required for this data message
        dctDataParsedInfo = clsAutogenToolboxCodeGenerationCSharp.dctGenerateMessageComplete(dctMessageHeaderPar, dctMessagePayloadPar, dctModConfMessagePar)

        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["acMsgComment"] = dctDataParsedInfo["acMsgComment"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["acMsgTypeAsString"] = dctDataParsedInfo["acMsgTypeAsString"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["acMsgOwner"] = dctDataParsedInfo["acMsgOwner"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["acMsgTopic"] = dctDataParsedInfo["acMsgTopic"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["acMsgGroupName"] = dctDataParsedInfo["acMsgGroupName"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["lstMsgAccessAttributes"] = dctDataParsedInfo["lstMsgAccessAttributes"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["lstMsgHeaderFields"] = dctDataParsedInfo["lstMsgHeaderFields"]
        dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["lstMsgPayloadFields"] = dctDataParsedInfo["lstMsgPayloadFields"]

        bReturn = bool(True)
        return(bReturn)

    @staticmethod
    def bPrepareRenderContextForMatlabDefinition(dctWriterContextPar: dict):
        """ This is a public static method which prepares context info for the Matlab definition

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Matlab Definition files. The keys are:

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)

        if (dctWriterContextPar is None):
            logging.error("dctWriterContextPar cannot be None")
            return(bReturn)

        dctWriterContextPar["dctProgLangSpecific"]["Matlab"] = {}
        dctWriterContextPar["dctProgLangSpecific"]["Matlab"]["Definition"] = {}
        dctWriterContextPar["dctProgLangSpecific"]["Matlab"]["Definition"]["acStructureName"] = dctWriterContextPar["dctValidMessageHeader"]["acName"]
        dctWriterContextPar["dctProgLangSpecific"]["Matlab"]["Definition"]["acOutputFilename"] = dctWriterContextPar["dctProgLangSpecific"]["Matlab"]["Definition"]["acStructureName"] + ".m"
        dctWriterContextPar["dctProgLangSpecific"]["Matlab"]["Definition"]["lstFields"] = clsAutogenToolboxCodeGenerationMatlab.lstGenerateMessageFields(dctWriterContextPar["dctValidMessageHeader"], dctWriterContextPar["dctValidMessagePayload"])

        dctWriterContextPar["dctProgLangSpecific"]["Matlab"]["Definition"]["lstTypes"] = clsAutogenToolboxCodeGenerationMatlab.lstGenerateTypedefs(dctWriterContextPar["dctMsgDefXmlFile"])

        bReturn = bool(True)
        return(bReturn)

    @staticmethod
    def bWriteCppDefinition(dctWriterContextPar):
        """ This is a public static method to write out a C++ definition file

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["acCppDefJinjaTemplatePath"] (str)
                * ["acCppAutogenOutputDirectory"] (str)
                * ["dctProgLangSpecific"] (dict)
                * ["acCppBaseTypesHeaderFilePath"] (str) -> The path to the C++ base types header file

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        objJinja2Environment = None
        objJinja2FileSystemLoader = None
        acJinjaDirectoryPath = str("")
        acCppDefJinjaTemplateCppDefinitionFilename = str("")
        acCppBaseTypesHeaderFileName = str("")
        acCppBaseTypesHeaderFilePathDestination = str("")
        acOutputPath = str("")
        objOutputFile = None
        acOutputFileContent = str("")
        acOutputFileName = str("")
        bRenderSuccess = bool(False)

        # Do some basic checks
        if (dctWriterContextPar is None):
            logging.error("dctWriterContextPar cannot be None")
            return(bReturn)

        # Split the C++ base types header file path - we want just the filename
        try:
            _, acCppBaseTypesHeaderFileName = os.path.split(dctWriterContextPar["acCppBaseTypesHeaderFilePath"])
        except Exception as E:
            logging.error("Could not split path %s - Exception %s", dctWriterContextPar["acCppBaseTypesHeaderFilePath"], str(E))
            return(bReturn)

        # Combine the output directory with the name of the base types file to act as a destination file for the copy
        acCppBaseTypesHeaderFilePathDestination = os.path.join(dctWriterContextPar["acCppAutogenOutputDirectory"], acCppBaseTypesHeaderFileName)

        # Copy the C++ base types header file to the output directory
        try:
            copyfile(dctWriterContextPar["acCppBaseTypesHeaderFilePath"], acCppBaseTypesHeaderFilePathDestination)
        except Exception as E:
            logging.error("Could not copy %s to %s - Exceptions %s", dctWriterContextPar["acCppBaseTypesHeaderFilePath"], acCppBaseTypesHeaderFilePathDestination, str(E))
            return(bReturn)

        if (os.path.isfile(dctWriterContextPar["acCppDefJinjaTemplatePath"]) is False):
            logging.error("Jinja template %s does not exist", dctWriterContextPar["acCppDefJinjaTemplatePath"])
            return(bReturn)

        try:
            acJinjaDirectoryPath, acCppDefJinjaTemplateCppDefinitionFilename = os.path.split(os.path.realpath(dctWriterContextPar["acCppDefJinjaTemplatePath"]))
        except Exception as E:
            logging.error("Cannot get the directory path of where the Jinja template is located")
            return(bReturn)

        try:
            # Note!!! The Jinja2 firsts needs to know about the folder where all the templates live
            objJinja2FileSystemLoader = FileSystemLoader(acJinjaDirectoryPath)
        except Exception as E:
            logging.error("Could not create Jinja2 FileSystemLoader - Exception %s", str(E))
            return(bReturn)

        # context.update({"PyVersion": sys.version.split("\n")[0], "JinjaVersion": JinjaVersion})
        # trim_blocks is is by default - we set it to True. If this is set to True the first newline after a block is removed (block, not variable tag!)
        objJinja2Environment = Environment(loader=objJinja2FileSystemLoader, trim_blocks=True)

        # We can add some terms to the Jinja environment to make sure Python and Jinja syntax is in sync
        objJinja2Environment.globals["len"] = len  # This means we can use the term len in Jinja template

        # Keep a local copy of this MsgDef filename
        acOutputFileName = dctWriterContextPar["dctProgLangSpecific"]["Cpp"]["Definition"]["acXmlFilename"]

        # Convert the filename into Pascal case as per C++ standard
        acOutputFileName = clsAutogenToolboxJinjaWriter.acFilenameToPascalCaseFile(acOutputFileName)

        if (not acOutputFileName):
            logging.error("Filename to be written to %s is invalid", acOutputFileName)
            return(bReturn)

        # Join the output path to filename we are intending to generate into
        # This is the path of the MsgDef file
        acOutputPath = os.path.join(dctWriterContextPar["acCppAutogenOutputDirectory"], acOutputFileName)

        try:
            objOutputFile = open(acOutputPath, "w")
        except Exception as E:
            logging.error("")
            return(bReturn)

        # At this stage the output file is open
        try:
            acOutputFileContent = objJinja2Environment.get_template(acCppDefJinjaTemplateCppDefinitionFilename).render(dctWriterContextPar)
            bRenderSuccess = bool(True)
        except Exception as E:
            bRenderSuccess = bool(False)
            logging.error("Could not Jinja render from the template into autogen content - Exception %s", str(E))

        try:
            objOutputFile.write(acOutputFileContent)
        except Exception as E:
            logging.error("Could not write to file %s", acOutputPath)

        try:
            objOutputFile.close()
        except Exception as E:
            logging.error("Could not close file %s", acOutputPath)
            bReturn = bool(False)

        return(bReturn)

    @staticmethod
    def bWriteCppDefinitionMessageEventHandler(dctWriterContextPar):
        """ This is a public static method to write out a C++ definition message event handler file

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["acCppDefJinjaTemplatePath"] (str)
                * ["acCppAutogenOutputDirectory"] (str)
                * ["dctProgLangSpecific"] (dict)
                * ["acCppBaseTypesHeaderFilePath"] (str) -> The path to the C++ base types header file
                * ["acCppDefMessageEventHanderTemplatePath"] (str) -> The path to the C++ MsgDef message event handler template
                * ["dctValidMessageHeader"] (dict) -> One message header

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        objJinja2Environment = None
        objJinja2FileSystemLoader = None
        acJinjaDirectoryPath = str("")
        acCppDefJinjaTemplateCppDefinitionMessageEventHandlerFilename = str("")
        acOutputPathHFile = str("")
        acOutputFileNameHFile = str("")
        objOutputFileHFile = None
        bRenderSuccess = bool(False)
        acMessageName = str("")
        acMessageNameAsCapUnderscores = str("")

        # Do some basic checks
        if (dctWriterContextPar is None):
            logging.error("dctWriterContextPar cannot be None")
            return(bReturn)

        if ("acCppDefMessageEventHanderTemplatePath" not in dctWriterContextPar):
            logging.error("acCppDefMessageEventHanderTemplatePath not in dctWriterContextPar")
            return(bReturn)

        if ("dctValidMessageHeader" not in dctWriterContextPar):
            logging.error("dctValidMessageHeader not in dctWriterContextPar")
            return(bReturn)

        try:
            acJinjaDirectoryPath, acCppDefJinjaTemplateCppDefinitionMessageEventHandlerFilename = os.path.split(dctWriterContextPar["acCppDefMessageEventHanderTemplatePath"])
        except Exception as E:
            logging.error("Could not split path %s - Exception %s", dctWriterContextPar["acCppDefMessageEventHanderTemplatePath"], str(E))
            return(bReturn)

        try:
            # Note!!! The Jinja2 firsts needs to know about the folder where all the templates live
            objJinja2FileSystemLoader = FileSystemLoader(acJinjaDirectoryPath)
        except Exception as E:
            logging.error("Could not create Jinja2 FileSystemLoader - Exception %s", str(E))
            return(bReturn)

        # context.update({"PyVersion": sys.version.split("\n")[0], "JinjaVersion": JinjaVersion})
        # trim_blocks is is by default - we set it to True. If this is set to True the first newline after a block is removed (block, not variable tag!)
        objJinja2Environment = Environment(loader=objJinja2FileSystemLoader, trim_blocks=True)

        # We can add some terms to the Jinja environment to make sure Python and Jinja syntax is in sync
        objJinja2Environment.globals["len"] = len  # This means we can use the term len in Jinja template

        acMessageName = dctWriterContextPar["dctValidMessageHeader"]["acName"]
        acMessageNameAsCapUnderscores = clsAutogenToolboxJinjaWriter.acMessageNamePascalCaseToCapUnderscores(acMessageName)

        # Keep a local copy of this MsgDef filename
        acOutputFileNameHFile = "cl%s_EH.h" % (acMessageNameAsCapUnderscores)

        if (not acOutputFileNameHFile):
            logging.error("Filename to be written to %s is invalid", acOutputFileNameHFile)
            return(bReturn)

        # Join the output path to filename we are intending to generate into
        # This is the path of the Mod Inter Conf h file
        acOutputPathHFile = os.path.join(dctWriterContextPar["acCppAutogenOutputDirectory"], acOutputFileNameHFile)

        try:
            objOutputFileHFile = open(acOutputPathHFile, "w")
        except Exception as E:
            logging.error("Could not open file %s - Exception %s", acOutputPathHFile, str(E))
            return(bReturn)

        try:
            acOutputFileContentHFile = objJinja2Environment.get_template(acCppDefJinjaTemplateCppDefinitionMessageEventHandlerFilename).render(dctWriterContextPar)
            bRenderSuccess = bool(True)
        except Exception as E:
            bRenderSuccess = bool(False)
            logging.error("Could not Jinja render from the template into autogen content - Exception %s", str(E))

        try:
            objOutputFileHFile.write(acOutputFileContentHFile)
        except Exception as E:
            logging.error("Could not write to file %s", acOutputPathHFile)

        if (objOutputFileHFile is not None):
            try:
                objOutputFileHFile.close()
            except Exception as E:
                logging.error("Could not close file %s", acOutputPathHFile)
                bReturn = bool(False)

        return(bReturn)

    @staticmethod
    def bWriteCppModInterConf(dctWriterContextPar):
        """ This is a public static method to write out a C++ MIC H file

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["acCppModInterConfJinjaTemplatePathHFile"] (str)
                * ["acCppModInterConfJinjaTemplatePathCppFile"] (str)
                * ["acCppAutogenOutputDirectory"] (str)
                * ["dctProgLangSpecific"] (dict)
                * ["acCppBaseTypesHeaderFilePath"] (str) -> The path to the C++ base types header file

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        objJinja2Environment = None
        objJinja2FileSystemLoader = None
        acJinjaDirectoryPath = str("")
        acCppJinjaTemplateModInterConfHFilename = str("")
        acCppJinjaTemplateModInterConfCppFilename = str("")
        acOutputPathHFile = str("")
        acOutputPathCppFile = str("")
        objOutputFileHFile = None
        objOutputFileCppFile = None
        acOutputFileContentHFile = str("")
        acOutputFileContentCppFile = str("")
        acOutputFileNameHFile = str("")
        acOutputFileNameCppFile = str("")
        bRenderSuccess = bool(False)

        # Do some basic checks
        if (dctWriterContextPar is None):
            logging.error("dctWriterContextPar cannot be None")
            return(bReturn)

        if (os.path.isfile(dctWriterContextPar["acCppModInterConfJinjaTemplatePathHFile"]) is False):
            logging.error("Jinja template %s does not exist", dctWriterContextPar["acCppModInterConfJinjaTemplatePathHFile"])
            return(bReturn)

        try:
            acJinjaDirectoryPath, acCppJinjaTemplateModInterConfHFilename = os.path.split(os.path.realpath(dctWriterContextPar["acCppModInterConfJinjaTemplatePathHFile"]))
        except Exception as E:
            logging.error("Cannot get the directory path of where the Jinja template is located")
            return(bReturn)

        try:
            acJinjaDirectoryPath, acCppJinjaTemplateModInterConfCppFilename = os.path.split(os.path.realpath(dctWriterContextPar["acCppModInterConfJinjaTemplatePathCppFile"]))
        except Exception as E:
            logging.error("Cannot get the directory path of where the Jinja template is located")
            return(bReturn)

        try:
            # Note!!! The Jinja2 firsts needs to know about the folder where all the templates live
            objJinja2FileSystemLoader = FileSystemLoader(acJinjaDirectoryPath)
        except Exception as E:
            logging.error("Could not create Jinja2 FileSystemLoader - Exception %s", str(E))
            return(bReturn)

        # context.update({"PyVersion": sys.version.split("\n")[0], "JinjaVersion": JinjaVersion})
        # trim_blocks is is by default - we set it to True. If this is set to True the first newline after a block is removed (block, not variable tag!)
        objJinja2Environment = Environment(loader=objJinja2FileSystemLoader, trim_blocks=True)

        # We can add some terms to the Jinja environment to make sure Python and Jinja syntax is in sync
        objJinja2Environment.globals["len"] = len  # This means we can use the term len in Jinja template

        # Keep a local copy of this MsgDef filename
        acOutputFileNameHFile = "cl" + dctWriterContextPar["dctProgLangSpecific"]["Cpp"]["ModInterConf"]["acCapatilisedUnderscoresName"] + ".h"
        acOutputFileNameCppFile = "cl" + dctWriterContextPar["dctProgLangSpecific"]["Cpp"]["ModInterConf"]["acCapatilisedUnderscoresName"] + ".cpp"

        if (not acOutputFileNameHFile):
            logging.error("Filename to be written to %s is invalid", acOutputFileNameHFile)
            return(bReturn)

        if (not acOutputFileNameCppFile):
            logging.error("Filename to be written to %s is invalid", acOutputFileNameCppFile)
            return(bReturn)

        # Join the output path to filename we are intending to generate into
        # This is the path of the Mod Inter Conf h file
        acOutputPathHFile = os.path.join(dctWriterContextPar["acCppAutogenOutputDirectory"], acOutputFileNameHFile)
        acOutputPathCppFile = os.path.join(dctWriterContextPar["acCppAutogenOutputDirectory"], acOutputFileNameCppFile)

        try:
            objOutputFileHFile = open(acOutputPathHFile, "w")
        except Exception as E:
            logging.error("Could not open file %s - Exception %s", acOutputPathHFile, str(E))
            return(bReturn)

        try:
            acOutputPathCppFile = open(acOutputPathCppFile, "w")
        except Exception as E:
            logging.error("Could not open file %s - Exception %s", acOutputPathCppFile, str(E))
            return(bReturn)

        # Generate the content for the mod inter conf h file
        try:
            acOutputFileContentHFile = objJinja2Environment.get_template(acCppJinjaTemplateModInterConfHFilename).render(dctWriterContextPar)
            bRenderSuccess = bool(True)
        except Exception as E:
            bRenderSuccess = bool(False)
            logging.error("Could not Jinja render from the template into autogen content - Exception %s", str(E))

        # Generate the content for the mod inter conf cpp file
        try:
            acOutputFileContentCppFile = objJinja2Environment.get_template(acCppJinjaTemplateModInterConfCppFilename).render(dctWriterContextPar)
            bRenderSuccess = bool(True)
        except Exception as E:
            bRenderSuccess = bool(False)
            logging.error("Could not Jinja render from the template into autogen content - Exception %s", str(E))

        try:
            objOutputFileHFile.write(acOutputFileContentHFile)
        except Exception as E:
            logging.error("Could not write to file %s", acOutputPathHFile)

        try:
            acOutputPathCppFile.write(acOutputFileContentCppFile)
        except Exception as E:
            logging.error("Could not write to file %s", acOutputPathHFile)

        if (objOutputFileHFile is not None):
            try:
                objOutputFileHFile.close()
            except Exception as E:
                logging.error("Could not close file %s", acOutputPathHFile)
                bReturn = bool(False)

        if (objOutputFileCppFile is not None):
            try:
                objOutputFileCppFile.close()
            except Exception as E:
                logging.error("Could not close file %s", acOutputPathCppFile)
                bReturn = bool(False)

        return(bReturn)

    @staticmethod
    def bWriteCppModInterConfTopicH(dctWriterContextPar):
        """ This is a public static method to write out a C++ MIC Topic H file

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["acCppModInterConfJinjaTemplatePathHFile"] (str)
                * ["acCppModInterConfJinjaTemplatePathCppFile"] (str)
                * ["acCppModInterConfTopicJinjaTemplatePathHFile"] (str)
                * ["acCppAutogenOutputDirectory"] (str)
                * ["dctProgLangSpecific"] (dict)
                * ["acCppBaseTypesHeaderFilePath"] (str) -> The path to the C++ base types header file
                * ["acModuleName"] (str) -> The name of the module being processed

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        objJinja2Environment = None
        objJinja2FileSystemLoader = None
        acJinjaDirectoryPath = str("")
        acCppJinjaTemplateModInterConfTopicHFilename = str("")
        acOutputPathHFile = str("")
        bRenderSuccess = bool(False)

        # Do some basic checks
        if (dctWriterContextPar is None):
            logging.error("dctWriterContextPar cannot be None")
            return(bReturn)

        if (os.path.isfile(dctWriterContextPar["acCppModInterConfTopicJinjaTemplatePathHFile"]) is False):
            logging.error("Jinja template %s does not exist", dctWriterContextPar["acCppModInterConfTopicJinjaTemplatePathHFile"])
            return(bReturn)

        if ("acModuleName" not in dctWriterContextPar):
            logging.error("acModuleName not in dctWriterContextPar")
            return(bReturn)

        try:
            acJinjaDirectoryPath, acCppJinjaTemplateModInterConfTopicHFilename = os.path.split(os.path.realpath(dctWriterContextPar["acCppModInterConfTopicJinjaTemplatePathHFile"]))
        except Exception as E:
            logging.error("Cannot get the directory path of where the Jinja template is located")
            return(bReturn)

        try:
            # Note!!! The Jinja2 firsts needs to know about the folder where all the templates live
            objJinja2FileSystemLoader = FileSystemLoader(acJinjaDirectoryPath)
        except Exception as E:
            logging.error("Could not create Jinja2 FileSystemLoader - Exception %s", str(E))
            return(bReturn)

        # context.update({"PyVersion": sys.version.split("\n")[0], "JinjaVersion": JinjaVersion})
        # trim_blocks is is by default - we set it to True. If this is set to True the first newline after a block is removed (block, not variable tag!)
        objJinja2Environment = Environment(loader=objJinja2FileSystemLoader, trim_blocks=True)

        # We can add some terms to the Jinja environment to make sure Python and Jinja syntax is in sync
        objJinja2Environment.globals["len"] = len  # This means we can use the term len in Jinja template

        # Keep a local copy of this MsgDef filename
        acOutputFileNameHFile = "%s_MIC_TOPICS.h" % dctWriterContextPar["acModuleName"]

        if (not acOutputFileNameHFile):
            logging.error("Filename to be written to %s is invalid", acOutputFileNameHFile)
            return(bReturn)

        # Join the output path to filename we are intending to generate into
        # This is the path of the Mod Inter Conf topic h file
        acOutputPathHFile = os.path.join(dctWriterContextPar["acCppAutogenOutputDirectory"], acOutputFileNameHFile)

        try:
            objOutputFileHFile = open(acOutputPathHFile, "w")
        except Exception as E:
            logging.error("Could not open file %s - Exception %s", acOutputPathHFile, str(E))
            return(bReturn)

        # Generate the content for the mod inter conf topic h file
        try:
            acOutputFileContentHFile = objJinja2Environment.get_template(acCppJinjaTemplateModInterConfTopicHFilename).render(dctWriterContextPar)
            bRenderSuccess = bool(True)
        except Exception as E:
            bRenderSuccess = bool(False)
            logging.error("Could not Jinja render from the template into autogen content - Exception %s", str(E))

        try:
            objOutputFileHFile.write(acOutputFileContentHFile)
        except Exception as E:
            logging.error("Could not write to file %s", acOutputPathHFile)

        if (objOutputFileHFile is not None):
            try:
                objOutputFileHFile.close()
            except Exception as E:
                logging.error("Could not close file %s", acOutputPathHFile)
                bReturn = bool(False)

        return(bReturn)

    @staticmethod
    def bWriteCppModInterConfEventHandlerH(dctWriterContextPar):
        """ This is a public static method to write out a C++ MIC Event Handler H file

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["acCppModInterConfJinjaTemplatePathHFile"] (str)
                * ["acCppModInterConfJinjaTemplatePathCppFile"] (str)
                * ["acCppModInterConfTopicJinjaTemplatePathHFile"] (str)
                * ["acCppAutogenOutputDirectory"] (str)
                * ["dctProgLangSpecific"] (dict)
                * ["acCppBaseTypesHeaderFilePath"] (str) -> The path to the C++ base types header file
                * ["acModuleName"] (str) -> The name of the module being processed

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        objJinja2Environment = None
        objJinja2FileSystemLoader = None
        acJinjaDirectoryPath = str("")
        acCppJinjaTemplateModInterConfEventHandlerHFilename = str("")
        acOutputPathHFile = str("")
        bRenderSuccess = bool(False)

        # Do some basic checks
        if (dctWriterContextPar is None):
            logging.error("dctWriterContextPar cannot be None")
            return(bReturn)

        if (os.path.isfile(dctWriterContextPar["acCppModInterConfEventHandlerJinjaTemplatePathHFile"]) is False):
            logging.error("Jinja template %s does not exist", dctWriterContextPar["acCppModInterConfEventHandlerJinjaTemplatePathHFile"])
            return(bReturn)

        if ("acModuleName" not in dctWriterContextPar):
            logging.error("acModuleName not in dctWriterContextPar")
            return(bReturn)

        try:
            acJinjaDirectoryPath, acCppJinjaTemplateModInterConfEventHandlerHFilename = os.path.split(os.path.realpath(dctWriterContextPar["acCppModInterConfEventHandlerJinjaTemplatePathHFile"]))
        except Exception as E:
            logging.error("Cannot get the directory path of where the Jinja template is located")
            return(bReturn)

        try:
            # Note!!! The Jinja2 firsts needs to know about the folder where all the templates live
            objJinja2FileSystemLoader = FileSystemLoader(acJinjaDirectoryPath)
        except Exception as E:
            logging.error("Could not create Jinja2 FileSystemLoader - Exception %s", str(E))
            return(bReturn)

        # context.update({"PyVersion": sys.version.split("\n")[0], "JinjaVersion": JinjaVersion})
        # trim_blocks is is by default - we set it to True. If this is set to True the first newline after a block is removed (block, not variable tag!)
        objJinja2Environment = Environment(loader=objJinja2FileSystemLoader, trim_blocks=True)

        # We can add some terms to the Jinja environment to make sure Python and Jinja syntax is in sync
        objJinja2Environment.globals["len"] = len  # This means we can use the term len in Jinja template

        # Keep a local copy of this MsgDef filename
        acOutputFileNameHFile = "%s_MIC_EH.h" % dctWriterContextPar["acModuleName"]

        if (not acOutputFileNameHFile):
            logging.error("Filename to be written to %s is invalid", acOutputFileNameHFile)
            return(bReturn)

        # Join the output path to filename we are intending to generate into
        # This is the path of the Mod Inter Conf topic h file
        acOutputPathHFile = os.path.join(dctWriterContextPar["acCppAutogenOutputDirectory"], acOutputFileNameHFile)

        try:
            objOutputFileHFile = open(acOutputPathHFile, "w")
        except Exception as E:
            logging.error("Could not open file %s - Exception %s", acOutputPathHFile, str(E))
            return(bReturn)

        # Generate the content for the mod inter conf topic h file
        try:
            acOutputFileContentHFile = objJinja2Environment.get_template(acCppJinjaTemplateModInterConfEventHandlerHFilename).render(dctWriterContextPar)
            bRenderSuccess = bool(True)
        except Exception as E:
            bRenderSuccess = bool(False)
            logging.error("Could not Jinja render from the template into autogen content - Exception %s", str(E))

        try:
            objOutputFileHFile.write(acOutputFileContentHFile)
        except Exception as E:
            logging.error("Could not write to file %s", acOutputPathHFile)

        if (objOutputFileHFile is not None):
            try:
                objOutputFileHFile.close()
            except Exception as E:
                logging.error("Could not close file %s", acOutputPathHFile)
                bReturn = bool(False)

        return(bReturn)

    @staticmethod
    def bWritePythonModInterConf(dctWriterContextPar):
        """ This is a public static method to write out a C++ definition file

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["acPythonModInterConfJinjaTemplatePath"] (str)
                * ["acPythonAutogenOutputDirectory"] (str)
                * ["dctProgLangSpecific"] (dict)

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        objJinja2Environment = None
        objJinja2FileSystemLoader = None
        acJinjaDirectoryPath = str("")
        acPythonJinjaTemplateModInterConfFilename = str("")
        acOutputPathFile = str("")
        objOutputFile = None
        acOutputFileContent = str("")
        acOutputFileName = str("")
        bRenderSuccess = bool(False)

        # Do some basic checks
        if (dctWriterContextPar is None):
            logging.error("dctWriterContextPar cannot be None")
            return(bReturn)

        if (os.path.isfile(dctWriterContextPar["acPythonModInterConfJinjaTemplatePath"]) is False):
            logging.error("Jinja template %s does not exist", dctWriterContextPar["acPythonModInterConfJinjaTemplatePath"])
            return(bReturn)

        try:
            acJinjaDirectoryPath, acPythonJinjaTemplateModInterConfFilename = os.path.split(os.path.realpath(dctWriterContextPar["acPythonModInterConfJinjaTemplatePath"]))
        except Exception as E:
            logging.error("Cannot get the directory path of where the Jinja template is located")
            return(bReturn)

        try:
            # Note!!! The Jinja2 firsts needs to know about the folder where all the templates live
            objJinja2FileSystemLoader = FileSystemLoader(acJinjaDirectoryPath)
        except Exception as E:
            logging.error("Could not create Jinja2 FileSystemLoader - Exception %s", str(E))
            return(bReturn)

        # context.update({"PyVersion": sys.version.split("\n")[0], "JinjaVersion": JinjaVersion})
        # trim_blocks is is by default - we set it to True. If this is set to True the first newline after a block is removed (block, not variable tag!)
        objJinja2Environment = Environment(loader=objJinja2FileSystemLoader, trim_blocks=True)

        # We can add some terms to the Jinja environment to make sure Python and Jinja syntax is in sync
        objJinja2Environment.globals["len"] = len  # This means we can use the term len in Jinja template

        # Keep a local copy of this MsgDef filename
        acOutputFileName = dctWriterContextPar["dctProgLangSpecific"]["Python"]["ModInterConf"]["acCapatilisedUnderscoresName"].lower() + ".py"

        if (not acOutputFileName):
            logging.error("Filename to be written to %s is invalid", acOutputFileName)
            return(bReturn)

        # Join the output path to filename we are intending to generate into
        # This is the path of the Mod Inter Conf h file
        acOutputPathFile = os.path.join(dctWriterContextPar["acPythonAutogenOutputDirectory"], acOutputFileName)

        try:
            objOutputFile = open(acOutputPathFile, "w")
        except Exception as E:
            logging.error("Could not open file %s - Exception %s", acOutputPathFile, str(E))
            return(bReturn)

        # Generate the content for the mod inter conf h file
        try:
            acOutputFileContent = objJinja2Environment.get_template(acPythonJinjaTemplateModInterConfFilename).render(dctWriterContextPar)
            bRenderSuccess = bool(True)
        except Exception as E:
            bRenderSuccess = bool(False)
            logging.error("Could not Jinja render from the template into autogen content - Exception %s", str(E))

        try:
            objOutputFile.write(acOutputFileContent)
        except Exception as E:
            logging.error("Could not write to file %s", acOutputPathFile)

        if (objOutputFile is not None):
            try:
                objOutputFile.close()
            except Exception as E:
                logging.error("Could not close file %s", acOutputPathFile)

        if (objOutputFile is not None):
            try:
                objOutputFile.close()
            except Exception as E:
                logging.error("Could not close file %s", acOutputPathFile)

        return(bRenderSuccess)

    @staticmethod
    def bWritePythonDefinition(dctWriterContextPar):
        """ This is a public static method to write out a Python definition file

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["acPythonDefJinjaTemplatePath"] (str)
                * ["acPythonAutogenOutputDirectory"] (str)
                * ["dctProgLangSpecific"] (dict)
                * ["acPythonBaseTypesHeaderFilePath"] (str) -> The path to the C++ base types header file

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        objJinja2Environment = None
        objJinja2FileSystemLoader = None
        acJinjaDirectoryPath = str("")
        acPythonDefJinjaTemplateCppDefinitionFilename = str("")
        acPythonBaseTypesHeaderFileName = str("")
        acPythonBaseTypesHeaderFilePathDestination = str("")
        acOutputPath = str("")
        objOutputFile = None
        acOutputFileContent = str("")
        acOutputFileName = str("")
        bRenderSuccess = bool(False)

        # Do some basic checks
        if (dctWriterContextPar is None):
            logging.error("dctWriterContextPar cannot be None")
            return(bReturn)

        # Split the Python base types header file path - we want just the filename
        try:
            _, acPythonBaseTypesHeaderFileName = os.path.split(dctWriterContextPar["acPythonBaseTypesHeaderFilePath"])
        except Exception as E:
            logging.error("Could not split path %s - Exception %s", dctWriterContextPar["acPythonBaseTypesHeaderFilePath"], str(E))
            return(bReturn)

        # Combine the output directory with the name of the base types file to act as a destination file for the copy
        acPythonBaseTypesHeaderFilePathDestination = os.path.join(dctWriterContextPar["acPythonAutogenOutputDirectory"], acPythonBaseTypesHeaderFileName)

        # Copy the Python base types header file to the output directory
        try:
            copyfile(dctWriterContextPar["acPythonBaseTypesHeaderFilePath"], acPythonBaseTypesHeaderFilePathDestination)
        except Exception as E:
            logging.error("Could not copy %s to %s - Exceptions %s", dctWriterContextPar["acPythonBaseTypesHeaderFilePath"], acPythonBaseTypesHeaderFilePathDestination, str(E))
            return(bReturn)

        if (os.path.isfile(dctWriterContextPar["acPythonDefJinjaTemplatePath"]) is False):
            logging.error("Jinja template %s does not exist", dctWriterContextPar["acPythonDefJinjaTemplatePath"])
            return(bReturn)

        try:
            acJinjaDirectoryPath, acPythonDefJinjaTemplateCppDefinitionFilename = os.path.split(os.path.realpath(dctWriterContextPar["acPythonDefJinjaTemplatePath"]))
        except Exception as E:
            logging.error("Cannot get the directory path of where the Jinja template is located")
            return(bReturn)

        try:
            # Note!!! The Jinja2 firsts needs to know about the folder where all the templates live
            objJinja2FileSystemLoader = FileSystemLoader(acJinjaDirectoryPath)
        except Exception as E:
            logging.error("Could not create Jinja2 FileSystemLoader - Exception %s", str(E))
            return(bReturn)

        # context.update({"PyVersion": sys.version.split("\n")[0], "JinjaVersion": JinjaVersion})
        # trim_blocks is is by default - we set it to True. If this is set to True the first newline after a block is removed (block, not variable tag!)
        objJinja2Environment = Environment(loader=objJinja2FileSystemLoader, trim_blocks=True)

        # We can add some terms to the Jinja environment to make sure Python and Jinja syntax is in sync
        objJinja2Environment.globals["len"] = len  # This means we can use the term len in Jinja template

        # Keep a local copy of this MsgDef filename
        acOutputFileName = dctWriterContextPar["dctProgLangSpecific"]["Python"]["Definition"]["acXmlFilename"]

        # Convert the filename into the correct letter casing for python
        acOutputFileName = acOutputFileName.replace(".xml", ".py").lower()

        if (not acOutputFileName):
            logging.error("Filename to be written to %s is invalid", acOutputFileName)
            return(bReturn)

        # Join the output path to filename we are intending to generate into
        # This is the path of the MsgDef file
        acOutputPath = os.path.join(dctWriterContextPar["acPythonAutogenOutputDirectory"], acOutputFileName)

        try:
            objOutputFile = open(acOutputPath, "w")
        except Exception as E:
            logging.error("")
            return(bReturn)

        # At this stage the output file is open
        try:
            acOutputFileContent = objJinja2Environment.get_template(acPythonDefJinjaTemplateCppDefinitionFilename).render(dctWriterContextPar)
            bRenderSuccess = bool(True)
        except Exception as E:
            bRenderSuccess = bool(False)
            logging.error("Could not Jinja render from the template into autogen content - Exception %s", str(E))

        try:
            objOutputFile.write(acOutputFileContent)
        except Exception as E:
            logging.error("Could not write to file %s", acOutputPath)

        try:
            objOutputFile.close()
        except Exception as E:
            logging.error("Could not close file %s", acOutputPath)
            bReturn = bool(False)

        return(bReturn)

    @staticmethod
    def bWritePythonMqttClientOnConnect(dctWriterContextPar):
        """ This is a public static method to write out a Python MQTT client on connect class

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Python MQTT client on connect class. The keys are:
                * ["acPythonModInterConfJinjaTemplatePath"] (str)
                * ["acPythonAutogenOutputDirectory"] (str)
                * ["dctProgLangSpecific"] (dict)

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        objJinja2Environment = None
        objJinja2FileSystemLoader = None
        acJinjaDirectoryPath = str("")
        acPythonJinjaTemplateMqttClientOnConnetFilename = str("")
        acOutputPathFile = str("")
        objOutputFile = None
        acOutputFileContent = str("")
        acOutputFileName = str("")
        bRenderSuccess = bool(False)

        # Do some basic checks
        if (dctWriterContextPar is None):
            logging.error("dctWriterContextPar cannot be None")
            return(bReturn)

        if (os.path.isfile(dctWriterContextPar["acPathJinjaTemplatePythonMqttClientOnConnect"]) is False):
            logging.error("Jinja template %s does not exist", dctWriterContextPar["acPathJinjaTemplatePythonMqttClientOnConnect"])
            return(bReturn)

        try:
            acJinjaDirectoryPath, acPythonJinjaTemplateMqttClientOnConnetFilename = os.path.split(os.path.realpath(dctWriterContextPar["acPathJinjaTemplatePythonMqttClientOnConnect"]))
        except Exception as E:
            logging.error("Cannot get the directory path of where the Jinja template is located")
            return(bReturn)

        try:
            # Note!!! The Jinja2 firsts needs to know about the folder where all the templates live
            objJinja2FileSystemLoader = FileSystemLoader(acJinjaDirectoryPath)
        except Exception as E:
            logging.error("Could not create Jinja2 FileSystemLoader - Exception %s", str(E))
            return(bReturn)

        # context.update({"PyVersion": sys.version.split("\n")[0], "JinjaVersion": JinjaVersion})
        # trim_blocks is is by default - we set it to True. If this is set to True the first newline after a block is removed (block, not variable tag!)
        objJinja2Environment = Environment(loader=objJinja2FileSystemLoader, trim_blocks=True)

        # We can add some terms to the Jinja environment to make sure Python and Jinja syntax is in sync
        objJinja2Environment.globals["len"] = len  # This means we can use the term len in Jinja template

        acOutputFileName = "mqtt_client_on_connect_" + dctWriterContextPar["acModuleName"].lower() + ".py"

        if (not acOutputFileName):
            logging.error("Filename to be written to %s is invalid", acOutputFileName)
            return(bReturn)

        # Join the output path to filename we are intending to generate into
        # This is the path of the Mod Inter Conf h file
        acOutputPathFile = os.path.join(dctWriterContextPar["acPythonAutogenOutputDirectory"], acOutputFileName)

        try:
            objOutputFile = open(acOutputPathFile, "w")
        except Exception as E:
            logging.error("Could not open file %s - Exception %s", acOutputPathFile, str(E))
            return(bReturn)

        # Generate the content for the mod inter conf h file
        try:
            acOutputFileContent = objJinja2Environment.get_template(acPythonJinjaTemplateMqttClientOnConnetFilename).render(dctWriterContextPar)
            bRenderSuccess = bool(True)
        except Exception as E:
            bRenderSuccess = bool(False)
            logging.error("Could not Jinja render from the template into autogen content - Exception %s", str(E))

        try:
            objOutputFile.write(acOutputFileContent)
        except Exception as E:
            logging.error("Could not write to file %s", acOutputPathFile)

        if (objOutputFile is not None):
            try:
                objOutputFile.close()
            except Exception as E:
                logging.error("Could not close file %s", acOutputPathFile)

        if (objOutputFile is not None):
            try:
                objOutputFile.close()
            except Exception as E:
                logging.error("Could not close file %s", acOutputPathFile)

        return(bRenderSuccess)

    @staticmethod
    def bWritePythonAsyncioMessageProcessing(dctWriterContextPar):
        """ This is a public static method to write out a Python asyncio message processing class

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Python MQTT client on connect class. The keys are:
                * ["acPathJinjaTemplatePythonAsyncioMessageProcessing"] (str)
                * ["acPythonAutogenOutputDirectory"] (str)
                * ["dctProgLangSpecific"] (dict)

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        objJinja2Environment = None
        objJinja2FileSystemLoader = None
        acJinjaDirectoryPath = str("")
        acPythonJinjaTemplateMqttClientOnConnetFilename = str("")
        acOutputPathFile = str("")
        objOutputFile = None
        acOutputFileContent = str("")
        acOutputFileName = str("")
        bRenderSuccess = bool(False)

        # Do some basic checks
        if (dctWriterContextPar is None):
            logging.error("dctWriterContextPar cannot be None")
            return(bReturn)

        if (os.path.isfile(dctWriterContextPar["acPathJinjaTemplatePythonAsyncioMessageProcessing"]) is False):
            logging.error("Jinja template %s does not exist", dctWriterContextPar["acPathJinjaTemplatePythonAsyncioMessageProcessing"])
            return(bReturn)

        try:
            acJinjaDirectoryPath, acPythonJinjaTemplateMqttClientOnConnetFilename = os.path.split(os.path.realpath(dctWriterContextPar["acPathJinjaTemplatePythonAsyncioMessageProcessing"]))
        except Exception as E:
            logging.error("Cannot get the directory path of where the Jinja template is located")
            return(bReturn)

        try:
            # Note!!! The Jinja2 firsts needs to know about the folder where all the templates live
            objJinja2FileSystemLoader = FileSystemLoader(acJinjaDirectoryPath)
        except Exception as E:
            logging.error("Could not create Jinja2 FileSystemLoader - Exception %s", str(E))
            return(bReturn)

        # context.update({"PyVersion": sys.version.split("\n")[0], "JinjaVersion": JinjaVersion})
        # trim_blocks is is by default - we set it to True. If this is set to True the first newline after a block is removed (block, not variable tag!)
        objJinja2Environment = Environment(loader=objJinja2FileSystemLoader, trim_blocks=True)

        # We can add some terms to the Jinja environment to make sure Python and Jinja syntax is in sync
        objJinja2Environment.globals["len"] = len  # This means we can use the term len in Jinja template

        acOutputFileName = "asyncio_message_processing_" + dctWriterContextPar["acModuleName"].lower() + ".py"

        if (not acOutputFileName):
            logging.error("Filename to be written to %s is invalid", acOutputFileName)
            return(bReturn)

        # Join the output path to filename we are intending to generate into
        # This is the path of the Mod Inter Conf h file
        acOutputPathFile = os.path.join(dctWriterContextPar["acPythonAutogenOutputDirectory"], acOutputFileName)

        try:
            objOutputFile = open(acOutputPathFile, "w")
        except Exception as E:
            logging.error("Could not open file %s - Exception %s", acOutputPathFile, str(E))
            return(bReturn)

        # Generate the content for the mod inter conf h file
        try:
            acOutputFileContent = objJinja2Environment.get_template(acPythonJinjaTemplateMqttClientOnConnetFilename).render(dctWriterContextPar)
            bRenderSuccess = bool(True)
        except Exception as E:
            bRenderSuccess = bool(False)
            logging.error("Could not Jinja render from the template into autogen content - Exception %s", str(E))

        try:
            objOutputFile.write(acOutputFileContent)
        except Exception as E:
            logging.error("Could not write to file %s", acOutputPathFile)

        if (objOutputFile is not None):
            try:
                objOutputFile.close()
            except Exception as E:
                logging.error("Could not close file %s", acOutputPathFile)

        if (objOutputFile is not None):
            try:
                objOutputFile.close()
            except Exception as E:
                logging.error("Could not close file %s", acOutputPathFile)

        return(bRenderSuccess)

    @staticmethod
    def bWriteCSharpEnum(dctWriterContextPar):
        """ This is a public static method to write out a CSharp enum class

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write C# enum. The keys are:
                * ["acCSharpDefEnumJinjaTemplatePath"] (str)
                * ["acPythonAutogenOutputDirectory"] (str)
                * ["dctProgLangSpecific"] (dict)

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        objJinja2Environment = None
        objJinja2FileSystemLoader = None
        acJinjaDirectoryPath = str("")
        acPythonJinjaTemplateMqttClientOnConnetFilename = str("")
        acOutputPathFile = str("")
        objOutputFile = None
        acOutputFileContent = str("")
        acOutputFileName = str("")
        bRenderSuccess = bool(False)

        # Do some basic checks
        if (dctWriterContextPar is None):
            logging.error("dctWriterContextPar cannot be None")
            return(bReturn)

        if (os.path.isfile(dctWriterContextPar["acCSharpDefEnumJinjaTemplatePath"]) is False):
            logging.error("Jinja template %s does not exist", dctWriterContextPar["acCSharpDefEnumJinjaTemplatePath"])
            return(bReturn)

        try:
            acJinjaDirectoryPath, acPythonJinjaTemplateMqttClientOnConnetFilename = os.path.split(os.path.realpath(dctWriterContextPar["acCSharpDefEnumJinjaTemplatePath"]))
        except Exception as E:
            logging.error("Cannot get the directory path of where the Jinja template is located")
            return(bReturn)

        try:
            # Note!!! The Jinja2 firsts needs to know about the folder where all the templates live
            objJinja2FileSystemLoader = FileSystemLoader(acJinjaDirectoryPath)
        except Exception as E:
            logging.error("Could not create Jinja2 FileSystemLoader - Exception %s", str(E))
            return(bReturn)

        # context.update({"PyVersion": sys.version.split("\n")[0], "JinjaVersion": JinjaVersion})
        # trim_blocks is is by default - we set it to True. If this is set to True the first newline after a block is removed (block, not variable tag!)
        objJinja2Environment = Environment(loader=objJinja2FileSystemLoader, trim_blocks=True)

        # We can add some terms to the Jinja environment to make sure Python and Jinja syntax is in sync
        objJinja2Environment.globals["len"] = len  # This means we can use the term len in Jinja template

        acOutputFileName = dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Enum"]["acEnumerationNameCapUnder"] + ".codegen.cs"

        if (not acOutputFileName):
            logging.error("Filename to be written to %s is invalid", acOutputFileName)
            return(bReturn)

        acOutputPathFile = os.path.join(dctWriterContextPar["acCSharpAutogenOutputDirectory"], "%s/Enums" % (dctWriterContextPar["acModuleInterfaceName"]))

        # Join the output path to filename we are intending to generate into
        # This is the path of the Mod Inter Conf h file
        acOutputPathFile = os.path.join(acOutputPathFile, acOutputFileName)

        try:
            objOutputFile = open(acOutputPathFile, "w")
        except Exception as E:
            logging.error("Could not open file %s - Exception %s", acOutputPathFile, str(E))
            return(bReturn)

        # Generate the content for the mod inter conf h file
        try:
            acOutputFileContent = objJinja2Environment.get_template(acPythonJinjaTemplateMqttClientOnConnetFilename).render(dctWriterContextPar)
            bRenderSuccess = bool(True)
        except Exception as E:
            bRenderSuccess = bool(False)
            logging.error("Could not Jinja render from the template into autogen content - Exception %s", str(E))

        try:
            objOutputFile.write(acOutputFileContent)
        except Exception as E:
            logging.error("Could not write to file %s", acOutputPathFile)

        if (objOutputFile is not None):
            try:
                objOutputFile.close()
            except Exception as E:
                logging.error("Could not close file %s", acOutputPathFile)

        if (objOutputFile is not None):
            try:
                objOutputFile.close()
            except Exception as E:
                logging.error("Could not close file %s", acOutputPathFile)

        return(bRenderSuccess)

    @staticmethod
    def bWriteCSharpStruct(dctWriterContextPar):
        """ This is a public static method to write out a CSharp struct

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write C# struct. The keys are:
                * ["acCSharpDefStructJinjaTemplatePath"] (str)
                * ["acPythonAutogenOutputDirectory"] (str)
                * ["dctProgLangSpecific"] (dict)

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        objJinja2Environment = None
        objJinja2FileSystemLoader = None
        acJinjaDirectoryPath = str("")
        acPythonJinjaTemplateMqttClientOnConnetFilename = str("")
        acOutputPathFile = str("")
        objOutputFile = None
        acOutputFileContent = str("")
        acOutputFileName = str("")
        bRenderSuccess = bool(False)

        # Do some basic checks
        if (dctWriterContextPar is None):
            logging.error("dctWriterContextPar cannot be None")
            return(bReturn)

        if (os.path.isfile(dctWriterContextPar["acCSharpDefStructJinjaTemplatePath"]) is False):
            logging.error("Jinja template %s does not exist", dctWriterContextPar["acCSharpDefStructJinjaTemplatePath"])
            return(bReturn)

        try:
            acJinjaDirectoryPath, acPythonJinjaTemplateMqttClientOnConnetFilename = os.path.split(os.path.realpath(dctWriterContextPar["acCSharpDefStructJinjaTemplatePath"]))
        except Exception as E:
            logging.error("Cannot get the directory path of where the Jinja template is located")
            return(bReturn)

        try:
            # Note!!! The Jinja2 firsts needs to know about the folder where all the templates live
            objJinja2FileSystemLoader = FileSystemLoader(acJinjaDirectoryPath)
        except Exception as E:
            logging.error("Could not create Jinja2 FileSystemLoader - Exception %s", str(E))
            return(bReturn)

        # context.update({"PyVersion": sys.version.split("\n")[0], "JinjaVersion": JinjaVersion})
        # trim_blocks is is by default - we set it to True. If this is set to True the first newline after a block is removed (block, not variable tag!)
        objJinja2Environment = Environment(loader=objJinja2FileSystemLoader, trim_blocks=True)

        # We can add some terms to the Jinja environment to make sure Python and Jinja syntax is in sync
        objJinja2Environment.globals["len"] = len  # This means we can use the term len in Jinja template

        acOutputFileName = dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Struct"]["acStructNameCapUnder"] + ".codegen.cs"

        if (not acOutputFileName):
            logging.error("Filename to be written to %s is invalid", acOutputFileName)
            return(bReturn)

        acOutputPathFile = os.path.join(dctWriterContextPar["acCSharpAutogenOutputDirectory"], "%s/Structs" % (dctWriterContextPar["acModuleInterfaceName"]))

        # Join the output path to filename we are intending to generate into
        # This is the path of the Mod Inter Conf h file
        acOutputPathFile = os.path.join(acOutputPathFile, acOutputFileName)

        try:
            objOutputFile = open(acOutputPathFile, "w")
        except Exception as E:
            logging.error("Could not open file %s - Exception %s", acOutputPathFile, str(E))
            return(bReturn)

        # Generate the content for the mod inter conf h file
        try:
            acOutputFileContent = objJinja2Environment.get_template(acPythonJinjaTemplateMqttClientOnConnetFilename).render(dctWriterContextPar)
            bRenderSuccess = bool(True)
        except Exception as E:
            bRenderSuccess = bool(False)
            logging.error("Could not Jinja render from the template into autogen content - Exception %s", str(E))

        try:
            objOutputFile.write(acOutputFileContent)
        except Exception as E:
            logging.error("Could not write to file %s", acOutputPathFile)

        if (objOutputFile is not None):
            try:
                objOutputFile.close()
            except Exception as E:
                logging.error("Could not close file %s", acOutputPathFile)

        if (objOutputFile is not None):
            try:
                objOutputFile.close()
            except Exception as E:
                logging.error("Could not close file %s", acOutputPathFile)

        return(bRenderSuccess)

    @staticmethod
    def bWriteCSharpControl(dctWriterContextPar):
        """ This is a public static method to write out a CSharp control

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write C# control. The keys are:
                * ["acCSharpDefControlJinjaTemplatePath"] (str)
                * ["acPythonAutogenOutputDirectory"] (str)
                * ["dctProgLangSpecific"] (dict)

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        objJinja2Environment = None
        objJinja2FileSystemLoader = None
        acJinjaDirectoryPath = str("")
        acPythonJinjaTemplateMqttClientOnConnetFilename = str("")
        acOutputPathFile = str("")
        objOutputFile = None
        acOutputFileContent = str("")
        acOutputFileName = str("")
        bRenderSuccess = bool(False)

        # Do some basic checks
        if (dctWriterContextPar is None):
            logging.error("dctWriterContextPar cannot be None")
            return(bReturn)

        if (os.path.isfile(dctWriterContextPar["acCSharpDefControlJinjaTemplatePath"]) is False):
            logging.error("Jinja template %s does not exist", dctWriterContextPar["acCSharpDefControlJinjaTemplatePath"])
            return(bReturn)

        try:
            acJinjaDirectoryPath, acPythonJinjaTemplateMqttClientOnConnetFilename = os.path.split(os.path.realpath(dctWriterContextPar["acCSharpDefControlJinjaTemplatePath"]))
        except Exception as E:
            logging.error("Cannot get the directory path of where the Jinja template is located")
            return(bReturn)

        try:
            # Note!!! The Jinja2 firsts needs to know about the folder where all the templates live
            objJinja2FileSystemLoader = FileSystemLoader(acJinjaDirectoryPath)
        except Exception as E:
            logging.error("Could not create Jinja2 FileSystemLoader - Exception %s", str(E))
            return(bReturn)

        # context.update({"PyVersion": sys.version.split("\n")[0], "JinjaVersion": JinjaVersion})
        # trim_blocks is is by default - we set it to True. If this is set to True the first newline after a block is removed (block, not variable tag!)
        objJinja2Environment = Environment(loader=objJinja2FileSystemLoader, trim_blocks=True)

        # We can add some terms to the Jinja environment to make sure Python and Jinja syntax is in sync
        objJinja2Environment.globals["len"] = len  # This means we can use the term len in Jinja template

        acMessageType = dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["acMsgTypeAsString"]
        acOutputFileName = acMessageType + ".codegen.cs"

        if (not acOutputFileName):
            logging.error("Filename to be written to %s is invalid", acOutputFileName)
            return(bReturn)

        acModuleInterfaceName = dctWriterContextPar["acModuleInterfaceName"]
        acMsgOwner = dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["acMsgOwner"]
        acMsgGroupName = dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Control"]["acMsgGroupName"]

        acOutputPathFile = os.path.join(dctWriterContextPar["acCSharpAutogenOutputDirectory"], "%s/Control/%s/%s" % (acModuleInterfaceName, acMsgOwner, acMsgGroupName))
        os.makedirs(acOutputPathFile, exist_ok=True)

        # Join the output path to filename we are intending to generate into
        # This is the path of the Mod Inter Conf h file
        acOutputPathFile = os.path.join(acOutputPathFile, acOutputFileName)

        try:
            objOutputFile = open(acOutputPathFile, "w")
        except Exception as E:
            logging.error("Could not open file %s - Exception %s", acOutputPathFile, str(E))
            return(bReturn)

        # Generate the content for the mod inter conf h file
        try:
            acOutputFileContent = objJinja2Environment.get_template(acPythonJinjaTemplateMqttClientOnConnetFilename).render(dctWriterContextPar)
            bRenderSuccess = bool(True)
        except Exception as E:
            bRenderSuccess = bool(False)
            logging.error("Could not Jinja render from the template into autogen content - Exception %s", str(E))

        try:
            objOutputFile.write(acOutputFileContent)
        except Exception as E:
            logging.error("Could not write to file %s", acOutputPathFile)

        if (objOutputFile is not None):
            try:
                objOutputFile.close()
            except Exception as E:
                logging.error("Could not close file %s", acOutputPathFile)

        if (objOutputFile is not None):
            try:
                objOutputFile.close()
            except Exception as E:
                logging.error("Could not close file %s", acOutputPathFile)

        return(bRenderSuccess)

    @staticmethod
    def bWriteCSharpData(dctWriterContextPar):
        """ This is a public static method to write out a CSharp data

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write C# data. The keys are:
                * ["acCSharpDefDataJinjaTemplatePath"] (str)
                * ["acPythonAutogenOutputDirectory"] (str)
                * ["dctProgLangSpecific"] (dict)

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        objJinja2Environment = None
        objJinja2FileSystemLoader = None
        acJinjaDirectoryPath = str("")
        acPythonJinjaTemplateMqttClientOnConnetFilename = str("")
        acOutputPathFile = str("")
        objOutputFile = None
        acOutputFileContent = str("")
        acOutputFileName = str("")
        bRenderSuccess = bool(False)

        # Do some basic checks
        if (dctWriterContextPar is None):
            logging.error("dctWriterContextPar cannot be None")
            return(bReturn)

        if (os.path.isfile(dctWriterContextPar["acCSharpDefDataJinjaTemplatePath"]) is False):
            logging.error("Jinja template %s does not exist", dctWriterContextPar["acCSharpDefDataJinjaTemplatePath"])
            return(bReturn)

        try:
            acJinjaDirectoryPath, acPythonJinjaTemplateMqttClientOnConnetFilename = os.path.split(os.path.realpath(dctWriterContextPar["acCSharpDefDataJinjaTemplatePath"]))
        except Exception as E:
            logging.error("Cannot get the directory path of where the Jinja template is located")
            return(bReturn)

        try:
            # Note!!! The Jinja2 firsts needs to know about the folder where all the templates live
            objJinja2FileSystemLoader = FileSystemLoader(acJinjaDirectoryPath)
        except Exception as E:
            logging.error("Could not create Jinja2 FileSystemLoader - Exception %s", str(E))
            return(bReturn)

        # context.update({"PyVersion": sys.version.split("\n")[0], "JinjaVersion": JinjaVersion})
        # trim_blocks is is by default - we set it to True. If this is set to True the first newline after a block is removed (block, not variable tag!)
        objJinja2Environment = Environment(loader=objJinja2FileSystemLoader, trim_blocks=True)

        # We can add some terms to the Jinja environment to make sure Python and Jinja syntax is in sync
        objJinja2Environment.globals["len"] = len  # This means we can use the term len in Jinja template

        acModuleInterfaceName = dctWriterContextPar["acModuleInterfaceName"]
        acMsgName = dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["acMsgName"]
        acMsgOwner = dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["acMsgOwner"]
        acMessageGroup = dctWriterContextPar["dctProgLangSpecific"]["CSharp"]["Definition"]["Data"]["acMsgGroupName"]

        acMessageGroup = acMsgName[(len(acMsgOwner) if acMsgName.startswith(acMsgOwner) else 0):-5]
        acOutputFileName = acMessageGroup + ".codegen.cs"

        if (not acOutputFileName):
            logging.error("Filename to be written to %s is invalid", acOutputFileName)
            return(bReturn)

        acOutputPathFile = os.path.join(dctWriterContextPar["acCSharpAutogenOutputDirectory"], "%s/Data/%s" % (acModuleInterfaceName, acMsgOwner))
        os.makedirs(acOutputPathFile, exist_ok=True)

        # Join the output path to filename we are intending to generate into
        # This is the path of the Mod Inter Conf h file
        acOutputPathFile = os.path.join(acOutputPathFile, acOutputFileName)

        try:
            objOutputFile = open(acOutputPathFile, "w")
        except Exception as E:
            logging.error("Could not open file %s - Exception %s", acOutputPathFile, str(E))
            return(bReturn)

        # Generate the content for the mod inter conf h file
        try:
            acOutputFileContent = objJinja2Environment.get_template(acPythonJinjaTemplateMqttClientOnConnetFilename).render(dctWriterContextPar)
            bRenderSuccess = bool(True)
        except Exception as E:
            bRenderSuccess = bool(False)
            logging.error("Could not Jinja render from the template into autogen content - Exception %s", str(E))

        try:
            objOutputFile.write(acOutputFileContent)
        except Exception as E:
            logging.error("Could not write to file %s", acOutputPathFile)

        if (objOutputFile is not None):
            try:
                objOutputFile.close()
            except Exception as E:
                logging.error("Could not close file %s", acOutputPathFile)

        if (objOutputFile is not None):
            try:
                objOutputFile.close()
            except Exception as E:
                logging.error("Could not close file %s", acOutputPathFile)

        return(bRenderSuccess)

    @staticmethod
    def bWriteMatlabDefinition(dctWriterContextPar: dict, eMatlabGenerationTypePar: E_MATLAB_GENERATION_TYPE):
        """ This is a public static method to write out a Matlab definition file

        Args:
            dctWriterContextPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["acCppDefJinjaTemplatePath"] (str)
                * ["acCppAutogenOutputDirectory"] (str)
                * ["dctProgLangSpecific"] (dict)
                * ["acCppBaseTypesHeaderFilePath"] (str) -> The path to the C++ base types header file

        Returns:
            (bool): Flag to indicate if validation passed or failed.

        Raises:
            Raises no exception.
        """
        bReturn = bool(False)
        objJinja2Environment = None
        objJinja2FileSystemLoader = None
        acJinjaDirectoryPath = str("")
        acMatlabDefJinjaTemplateMatlabDefinitionFilename = str("")
        acOutputPath = str("")
        objOutputFile = None
        acOutputFileContent = str("")
        acOutputFileName = str("")
        bRenderSuccess = bool(False)

        # Do some basic checks
        if (dctWriterContextPar is None):
            logging.error("dctWriterContextPar cannot be None")
            return(bReturn)

        if (os.path.isfile(dctWriterContextPar["acMatlabDefJinjaTemplatePath"]) is False):
            logging.error("Jinja template %s does not exist", dctWriterContextPar["acMatlabDefJinjaTemplatePath"])
            return(bReturn)

        try:
            acJinjaDirectoryPath, acMatlabDefJinjaTemplateMatlabDefinitionFilename = os.path.split(os.path.realpath(dctWriterContextPar["acMatlabDefJinjaTemplatePath"]))
        except Exception as E:
            logging.error("Cannot get the directory path of where the Jinja template is located")
            return(bReturn)

        try:
            # Note!!! The Jinja2 firsts needs to know about the folder where all the templates live
            objJinja2FileSystemLoader = FileSystemLoader(acJinjaDirectoryPath)
        except Exception as E:
            logging.error("Could not create Jinja2 FileSystemLoader - Exception %s", str(E))
            return(bReturn)

        # context.update({"PyVersion": sys.version.split("\n")[0], "JinjaVersion": JinjaVersion})
        # trim_blocks is is by default - we set it to True. If this is set to True the first newline after a block is removed (block, not variable tag!)
        objJinja2Environment = Environment(loader=objJinja2FileSystemLoader, trim_blocks=True)

        # We can add some terms to the Jinja environment to make sure Python and Jinja syntax is in sync
        objJinja2Environment.globals["len"] = len  # This means we can use the term len in Jinja template

        # Keep a local copy of this MsgDef filename
        acOutputFileName = dctWriterContextPar["dctProgLangSpecific"]["Matlab"]["Definition"]["acOutputFilename"]

        if (not acOutputFileName):
            logging.error("Filename to be written to %s is invalid", acOutputFileName)
            return(bReturn)

        # Join the output path to filename we are intending to generate into
        if (eMatlabGenerationTypePar == E_MATLAB_GENERATION_TYPE.MATLAB_GENERATION_STRUCTS):
            acOutputPath = os.path.join(dctWriterContextPar["acMatlabAutogenOutputDirectoryTypeSizeMatched"], acOutputFileName)
        else:
            acOutputPath = os.path.join(dctWriterContextPar["acMatlabAutogenOutputDirectoryTypesAsDoubles"], acOutputFileName)

        try:
            objOutputFile = open(acOutputPath, "w")
        except Exception as E:
            logging.error("")
            return(bReturn)

        # At this stage the output file is open
        try:
            acOutputFileContent = objJinja2Environment.get_template(acMatlabDefJinjaTemplateMatlabDefinitionFilename).render(dctWriterContextPar)
            bRenderSuccess = bool(True)
        except Exception as E:
            bRenderSuccess = bool(False)
            logging.error("Could not Jinja render from the template into autogen content - Exception %s", str(E))

        try:
            objOutputFile.write(acOutputFileContent)
        except Exception as E:
            logging.error("Could not write to file %s", acOutputPath)

        try:
            objOutputFile.close()
        except Exception as E:
            logging.error("Could not close file %s", acOutputPath)
            bReturn = bool(False)

        return(bReturn)
