//*************************************************************************
// Class clSHM_GEO_MAP
// This class creates a shared memory object to store and manage a geo map defined in signal processor
// resolution cells.
// The RRS Map server software is used to generate the source radar geographical map from numerous
// standard formatted maps and is unique for each system. Once the map is generated, the resolution cell size
// cannot be changed.
//
// The format of the Shm and generated GeoMap file will be the same. The definition
// of the format can be found in "../../../GeoMaps/MapGeneration/Docs/Architecture/Geo Maps Generation.pdf"
// on slides 7 and 8. Each feature map will be stored in a 2D array with dimensions [NumRangeCells, NumAzCells].
//
// The generated maps will have the following feature order:
//   1) Coastline
//   2) Roads
//   3) Railway
//   4) Airports
//   5) Land
//
//*************************************************************************
#ifndef clSHM_GEO_MAP_h
#define clSHM_GEO_MAP_h

//-------------------------------------------------------------------------
// Includes
//-------------------------------------------------------------------------
#include "../../../Types/C/RrsBaseTypes.h"
#include "../../Base_Class/C_LIN/clSHARED_MEMORY.h"
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <algorithm>

//-------------------------------------------------------------------------
// Definitions
//-------------------------------------------------------------------------
#define GEO_FEATURE_NAME_LENGTH 256

typedef enum
{
    GFM_SHM_COASTLINE = 0,
    GFM_SHM_ROADS     = 1,
    GFM_SHM_RAILWAY   = 2,
    GFM_SHM_AIRPORTS  = 3,
    GFM_SHM_LAND_SEA  = 4,
    GFM_SHM_UNKNOWN   = 5,
} E1_GFM_SHM_MAP_TYPES;

//-------------------------------------------------------------------------
// Structure definition
//-------------------------------------------------------------------------
//Shm header
typedef struct
{
    U4 u4NumAzResCells;
    U4 u4NumRangeResCells;
    F8 f8LatitudeDeg;
    F8 f8LongitudeDeg;
    F8 f8AltitudeM;
    U4 u4NumMaps;
    F8 f8RangeBinSizeM;
    F8 f8RangeWinM;
    F8 f8AzWinDeg;
    U8 u8TimestampMs;
} __attribute__ ((packed)) sSHM_GEO_MAP_HEADER;

class clSHM_GEO_MAP
{
    private:
        clSHARED_MEMORY      m_clSharedMemory; //Base class for all shared memory related functions
        sSHM_GEO_MAP_HEADER* m_psShmHeader;
        U4                   m_u4SizeOfGeoMapPageBytes;
        U4                   m_u4SizeOfGeoMapBytes;
        U4                   m_u4SizeOfShmBytes;
        U4                   m_u4NrOfAzResCells;
        U4                   m_u4NrOfRangeResCells;
        U4                   m_u4NrOfFeatures;
        U4                   m_u4NrOfGeoMaps;
        bool                 m_bInitialized;

    public:
        //-----------------------------------------------------------------
        //Constructor
        //-----------------------------------------------------------------
        clSHM_GEO_MAP();

        //-----------------------------------------------------------------
        //Destructor
        //-----------------------------------------------------------------
        ~clSHM_GEO_MAP();

        //-----------------------------------------------------------------
        // iCreate()
        //
        // Create a shm object to store decoded geo map data;
        //
        // Inputs:
        //   pcName          : Pointer to shared memory object name
        //   u4NumRangeCells : Number of range resolution cells geo map
        //   u4NumAzCells    : Number of Azimuth resolution cells for geo map
        //   u4NumFeatures   : Number of geo features to add to each map in the shm
        //   u4NumGeoMaps    : Number of geo maps to add to the shm
        //
        // Returns  1 = OK
        //         -1 = Failed
        //-----------------------------------------------------------------
        I4 i4Create(const CH *pcName, U4 u4NumRangeCells, U4 u4NumAzCells, U4 u4NumFeatures, U4 u4NumGeoMaps=1);

        //-----------------------------------------------------------------
        // iOpen()
        //
        // Open an existing geo map as a shared memory object if the
        // shared memory object exists.
        //
        // Inputs:
        //   pcName          : Pointer to shared memory object name
        //
        // Returns  1 = OK
        //         -1 = Failed to open Shm
        //         -2 = Shared memory size too small or
        //              large (map in memory's az/range res cells difffer).
        //-----------------------------------------------------------------
        I4 i4Open(const CH *pcName);

        //-----------------------------------------------------------------
        // pu1GetDataPtr()
        //
        // Get a map data pointer for a specified geo feature from a specified geo map in SHM.
        //
        // Inputs:
        //   u4FeatureNum : ID of the selected geo feature far the pointer
        //   u4MapNum     : ID of the selected geo map for the pointer
        //
        // Returns  Success : Pointer to map data in shared memory (skips shm header)
        //          Failure : NULL
        //-----------------------------------------------------------------
        U1* pu1GetDataPtr(U4 u4FeatureNum = 0, U4 u4MapNum = 0);

        //-----------------------------------------------------------------
        // pchGetMapName()
        //
        // Get the map name for a specified geo feature from a specified geo map in SHM.
        //
        // Inputs:
        //   u4FeatureNum : ID of the selected geo feature far the pointer
        //   u4MapNum     : ID of the selected geo map for the pointer
        //
        // Returns  Success : Pointer to name of the map in shared memory (skips shm header)
        //          Failure : NULL
        //-----------------------------------------------------------------
        CH* pchGetMapName(U4 u4FeatureNum = 0, U4 u4MapNum = 0);

        //-----------------------------------------------------------------
        // u4GetNumRangeCells
        //
        // Returns U4 number of range cells
        //-----------------------------------------------------------------
        U4 u4NumRangeResCells()
        {  return m_u4NrOfRangeResCells;}

        //-----------------------------------------------------------------
        // u4GetNumAzCells
        //
        // Returns U4 number of Azimuth cells
        //-----------------------------------------------------------------
        U4 u4GetNumAzCells()
        {  return m_u4NrOfAzResCells;}

        //-----------------------------------------------------------------
        // u4GetNumGeoInfo
        //
        // Returns U4 number of geographical data features
        //-----------------------------------------------------------------
        U4 u4GetNumGeoFeatures()
        {  return m_u4NrOfFeatures;}

        //-----------------------------------------------------------------
        // u4GetNumGeoMaps
        //
        // Returns U4 number of geographical maps
        //-----------------------------------------------------------------
        U4 u4GetNumGeoMaps()
        {  return m_u4NrOfGeoMaps;}

        //-----------------------------------------------------------------
        // i4LoadMapsFromFile()
        //
        // Loads a specified map into shared memory if it is valid.
        //
        // Inputs:
        //   pchMapSrcName : Name of the GeoMap source file to load into shared memory
        //
        // Returns  1 = OK
        //         -1 = Unable to open file, problem with path to file
        //         -2 = Validation failed
        //-----------------------------------------------------------------
        I4 i4LoadMapsFromFile(const CH* pchMapSrcName);

        //-----------------------------------------------------------------
        // i4ValidateMapsFile()
        //
        // Validates the file against the size allocated for the shared memory.
        //
        // Inputs:
        //   pchMapSrcName   : Name of the GeoMap source file to load into shared memory
        //   pfMapFileHandle : Optional pointer to handle of already opened file. 
        //
        // Returns >0 = OK, number of geomaps in the file
        //         -1 = Unable to open file, problem with path to file
        //         -2 = Validation failed
        //         -3 = Invalid number of geo maps read with current map parameters
        //-----------------------------------------------------------------
        I4 i4ValidateMapsFile(const CH* pchMapSrcName, FILE* psMapFileHandle=NULL);

        //-----------------------------------------------------------------
        // vCreateDefaultMapFile()
        //
        // Create a default GeoMap source file in the same format as that of a
        // GeoMap file generated by the GeoMapGen process and write it to the
        // specified path.
        //
        // Inputs:
        //   pchDefaultMapFilename : Name of file to write default data to.
        //-----------------------------------------------------------------
        void vCreateDefaultMapFile(const CH* pchDefaultMapFilename);

        //-----------------------------------------------------------------
        // vDispHeader()
        //
        // Display the header information currently loaded in the shared memory.
        //-----------------------------------------------------------------
        void vDispHeader();

        //-----------------------------------------------------------------
        // bIsInitialized()
        //
        // Get initialized status of the class.
        //-----------------------------------------------------------------
        bool bIsInitialized() { return( m_bInitialized ); };

};

#endif
