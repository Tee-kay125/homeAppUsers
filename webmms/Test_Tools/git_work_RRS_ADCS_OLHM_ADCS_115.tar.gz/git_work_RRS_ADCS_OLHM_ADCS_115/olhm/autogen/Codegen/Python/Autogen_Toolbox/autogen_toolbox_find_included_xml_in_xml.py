#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
""" This module provides a class which provides functionality to find common included XML files 
    in XML files. It parses a XML and then lists as output all the XML file which were included.
    We cannot do this with ElementTree or lxml so we have to do it manually.


"""
import logging
import os
from lxml import etree  # lxml is a PyPi package and not native in Python


class clsAutogenToolboxFindIncludedXmlInXml():
    """ This class provides functionality to find common included XML files 
    in XML files. It parses a XML and then lists as output all the XML file which were included.
    We cannot do this with ElementTree or lxml so we have to do it manually.

    """

    @staticmethod
    def tplFindIncludedXmlFilesInsideXmlFile(acXmlFilePathPar: str):
        """ This static method provides functionality to find common included XML files 
        in XML files. It parses a XML and then lists as output all the XML file which were included.
        We cannot do this with ElementTree or lxml so we have to do it manually.

        Args:
            acXmlFilePathPar (str): The filepath to the XML file

        Returns:
            (tuple): (bSuccess:bool, lstOfIncludedXmlFiles: list)

        Raises:
            Raises no exception.
        """
        bSuccess = bool(False)  # This will indicate if method was successful
        lstIncludeXmlFiles = []  # This will contain the list of XML file that were listed in the DOCTYPE section
        tplReturn = (bSuccess, lstIncludeXmlFiles)
        objFileHandler = None  # Handler for the XML file which will be read and parsed
        acXmlFileContents = str("")  # This will store the entire contents of the XML file after being read
        lstXmlFileContents = []  # This will store the entire contents of the XML file after being split on newlines
        iLineInFileCounter = int(0)  # This counter will keep track of which line of text we are busy with
        iNumberOfDoctypeLinesParsed = int(0)  # This counter will be used to keep track of the line we are busy with in the DOCTYPE section
        iMaxThresholdOfDoctypeLinesAllowed = int(50)  # We will only read so many DOCTYPE lines and then give up for safety reasons
        bDocTypeSectionEmpty = bool(False)  # Used to indicate that the DOCTYPE section is empty or does not exist
        acFilename = str("")  # Will be used later to store the name of the XML file in the DOCTYPE section

        # Check if not None or empty string
        if (not acXmlFilePathPar):
            logging.error("acXmlFilePathPar is invalid")
            return(tplReturn)

        # Check that it's a str
        if (isinstance(acXmlFilePathPar, str) is False):
            logging.error("acXmlFilePathPar is not a str")
            return(tplReturn)

        # Check that file exists
        if (os.path.isfile(acXmlFilePathPar) is False):
            logging.error("File %s does not exist", acXmlFilePathPar)
            return(tplReturn)

        try:
            objFileHandler = open(acXmlFilePathPar, "r")
        except Exception as E:
            logging.error("Could not open XML file %s", acXmlFilePathPar)
            return(tplReturn)

        try:
            acXmlFileContents = objFileHandler.read()
        except Exception as E:
            # Do not return here so we can close the file
            logging.error("Could not read contents of %s", acXmlFilePathPar)

        try:
            objFileHandler.close()
        except Exception as E:
            logging.error("Could not close file %s", acXmlFilePathPar)
            # We could not close the file so we might as well return
            return(tplReturn)

        try:
            lstXmlFileContents = acXmlFileContents.splitlines()
        except Exception as E:
            logging.error("Could not split string content of %s into lines", acXmlFilePathPar)
            return(tplReturn)

        bDocTypeSectionEmpty = bool(True)  # Assume the DOCTYPE section is empty for now
        for acLineOfText in lstXmlFileContents:
            # We need to check where the <!DOCTYPE starts
            if "<!DOCTYPE" in acLineOfText:
                # If we also have a "greater-than" character in this line then the DOCTYPE section is empty

                if (acLineOfText.count(">") > 0):
                    bDocTypeSectionEmpty = bool(True)
                else:
                    bDocTypeSectionEmpty = bool(False)

                # We have found the DOCTYPE line so we can stop reading lines for now
                break

            iLineInFileCounter += 1  # We need to count which line we are on now

        # If the DOCTYPE section is empty or there isn't one then exit
        if (bDocTypeSectionEmpty is True):
            return(tplReturn)

        # At this stage we have found the DOCTYPE section/lines and need to get all the XML filenames

        if (len(lstXmlFileContents) <= iLineInFileCounter):
            return(tplReturn)

        # Continued where we left of in the list of lines we were parsing
        for acLineOfText in lstXmlFileContents[iLineInFileCounter:]:

            # We are only going to read a reasonable amount of lines and then give up for safety reasons
            if (iNumberOfDoctypeLinesParsed > iMaxThresholdOfDoctypeLinesAllowed):
                break

            # Look for lines with .xml in them
            # There must be:
            #  * Be a string
            #  * Be at least 4 chars long
            #  * Have 2 x " character
            #  * Contain the string ".xml\""
            if ((isinstance(acLineOfText, str) is True) and (len(acLineOfText) > 4) and (acLineOfText.count("\"") == 2) and (".xml\"" in acLineOfText)):

                # Note the Python call find will find the fist character
                acFilename = acLineOfText[acLineOfText.find('"') + 1:acLineOfText.rfind('"')]

                lstIncludeXmlFiles.append(acFilename)

            # When we reach the end of the DOCTYPE part we stop
            if "]>" in acLineOfText:
                break

            # We want to count how many lines we have read since DOCTYPE section started
            iLineInFileCounter += 1  # We need to count which line we are on now
            iNumberOfDoctypeLinesParsed += 1  # We need to count how many DOCTYPE lines we have parsed 

        # Now fill in the return value
        bSuccess = bool(True)
        tplReturn = (bSuccess, lstIncludeXmlFiles)

        return(tplReturn)
