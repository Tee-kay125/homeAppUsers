//*************************************************************************
// Class clSHM_GEO_MAP
// Refer to clSHM_GEO_MAP.h for description
//*************************************************************************

//-------------------------------------------------------------------------
// Includes
//-------------------------------------------------------------------------
#include "clSHM_GEO_MAP.h"
#include "../../../Macros/C/ShowDebugInfoMacro.h"


//-----------------------------------------------------------------
//Constructor
//-----------------------------------------------------------------
clSHM_GEO_MAP::clSHM_GEO_MAP()
{
    DEBUG1(("\n"););
    m_bInitialized            = false;
    m_u4SizeOfShmBytes        = 0;
    m_u4SizeOfGeoMapPageBytes = 0;
    m_u4SizeOfGeoMapBytes     = 0;
    m_u4NrOfAzResCells        = 0;
    m_u4NrOfRangeResCells     = 0;
    m_u4NrOfFeatures          = 0;
    m_u4NrOfGeoMaps           = 0;
    m_psShmHeader             = NULL;
}

//-----------------------------------------------------------------
// Destructor
//-----------------------------------------------------------------
clSHM_GEO_MAP::~clSHM_GEO_MAP()
{
    DEBUG1(("\n"););
    //if (m_bInitialized)
    //{
    //   free(apu1ResCells);
    //}
}


//-----------------------------------------------------------------
// Create internal shared memory space to store map data
//-----------------------------------------------------------------
I4 clSHM_GEO_MAP::i4Create(const CH *pcName, U4 u4NumRangeCells, U4 u4NumAzCells, U4 u4NumFeatures, U4 u4NumGeoMaps)
{
    DEBUG1(("\n"););

    m_u4SizeOfGeoMapPageBytes = u4NumRangeCells*u4NumAzCells + GEO_FEATURE_NAME_LENGTH;
    m_u4SizeOfGeoMapBytes     = sizeof(sSHM_GEO_MAP_HEADER) + (m_u4SizeOfGeoMapPageBytes*u4NumFeatures);
    m_u4SizeOfShmBytes        = m_u4SizeOfGeoMapBytes*u4NumGeoMaps;
    m_u4NrOfAzResCells        = u4NumAzCells;
    m_u4NrOfRangeResCells     = u4NumRangeCells;
    m_u4NrOfFeatures          = u4NumFeatures;
    m_u4NrOfGeoMaps           = u4NumGeoMaps;
    I4 i4ShmStatus = m_clSharedMemory.iCreate(pcName, m_u4SizeOfShmBytes);

    if (i4ShmStatus > 0)
    {
        memset(m_clSharedMemory.pvGetPtr(), 0, m_u4SizeOfShmBytes);

        for (U4 u4MapNum = 0; u4MapNum < u4NumGeoMaps; u4MapNum++)
        {
            m_psShmHeader = (sSHM_GEO_MAP_HEADER*) (((U1*)m_clSharedMemory.pvGetPtr()) + u4MapNum*m_u4SizeOfGeoMapBytes);
            m_psShmHeader->u4NumAzResCells    = m_u4NrOfAzResCells;
            m_psShmHeader->u4NumRangeResCells = m_u4NrOfRangeResCells;
            m_psShmHeader->u4NumMaps          = m_u4NrOfFeatures;
        }

        m_bInitialized = true;
        return(1);
    }

    DEBUG1(("SHM Create failed\n"););
    return(-1);
}


//-----------------------------------------------------------------
// Open internal shared memory space to read map data
//-----------------------------------------------------------------
I4 clSHM_GEO_MAP::i4Open(const char *pcName)
{
    DEBUG1(("\n"););

    I4 i4ShmStatus = m_clSharedMemory.iOpen(pcName);
    if (i4ShmStatus > 0)
    {
        //Update class member variables
        m_psShmHeader             = (sSHM_GEO_MAP_HEADER*) m_clSharedMemory.pvGetPtr();
        m_u4NrOfAzResCells        = m_psShmHeader->u4NumAzResCells;
        m_u4NrOfRangeResCells     = m_psShmHeader->u4NumRangeResCells;
        m_u4NrOfFeatures          = m_psShmHeader->u4NumMaps;
        m_u4SizeOfGeoMapPageBytes = m_u4NrOfRangeResCells*m_u4NrOfAzResCells + GEO_FEATURE_NAME_LENGTH;
        m_u4SizeOfGeoMapBytes     = sizeof(sSHM_GEO_MAP_HEADER) + (m_u4SizeOfGeoMapPageBytes*m_u4NrOfFeatures);
        m_u4SizeOfShmBytes        = m_clSharedMemory.uiGetSizeBytes();
        m_u4NrOfGeoMaps           = m_u4SizeOfShmBytes/m_u4SizeOfGeoMapBytes;

        m_bInitialized            = true;
        return(1);
    }

    DEBUG1(("SHM Open failed\n"););
    return(-1);
}


//-----------------------------------------------------------------
// Get data pointer to specified feature within a specified map
//-----------------------------------------------------------------
U1* clSHM_GEO_MAP::pu1GetDataPtr(U4 u4FeatureNum, U4 u4MapNum)
{
    if ((!m_bInitialized) && (u4FeatureNum < m_u4NrOfFeatures) && (u4MapNum < m_u4NrOfGeoMaps))
        return(NULL);

    return((U1*)m_clSharedMemory.pvGetPtr() + sizeof(sSHM_GEO_MAP_HEADER)
                                            + u4MapNum*m_u4SizeOfGeoMapBytes
                                            + u4FeatureNum*m_u4SizeOfGeoMapPageBytes 
                                            + GEO_FEATURE_NAME_LENGTH);
}


//-----------------------------------------------------------------
// Get map name pointer to specified feature within a specified map
//-----------------------------------------------------------------
CH* clSHM_GEO_MAP::pchGetMapName(U4 u4FeatureNum, U4 u4MapNum)
{
    if ((!m_bInitialized) && (u4FeatureNum < m_u4NrOfFeatures) && (u4MapNum < m_u4NrOfGeoMaps))
        return(NULL);

    return((CH*)m_clSharedMemory.pvGetPtr() + sizeof(sSHM_GEO_MAP_HEADER)
                                            + u4MapNum*m_u4SizeOfGeoMapBytes
                                            + u4FeatureNum*m_u4SizeOfGeoMapPageBytes);
}


//-----------------------------------------------------------------
// Load maps from file to shm
//-----------------------------------------------------------------
I4 clSHM_GEO_MAP::i4LoadMapsFromFile(const CH* pchMapSrcName)
{
    DEBUG1(("\n"););
    FILE *psMapHandle = fopen(pchMapSrcName, "rb");

    if (psMapHandle)
    {
        //Validate the header
        I4 i4ValidateStatus = i4ValidateMapsFile(pchMapSrcName, psMapHandle);
        if (i4ValidateStatus < 1)
        {
            DEBUG1(("Map validation failed\n"););
            return(i4ValidateStatus);
        }

        rewind(psMapHandle);
        fread(m_clSharedMemory.pvGetPtr(), m_u4SizeOfGeoMapBytes, i4ValidateStatus, psMapHandle);

        fclose(psMapHandle);
        return(1);
    }

    return(-1);
}


//-----------------------------------------------------------------
// Validate specified GeoMap file
//-----------------------------------------------------------------
I4 clSHM_GEO_MAP::i4ValidateMapsFile(const CH* pchMapSrcName,  FILE* psMapFileHandle)
{
    DEBUG1(("\n"););
    
    //Open map file if file not already opened
    bool bCloseMapFile = true;
    if (!psMapFileHandle)
        psMapFileHandle = fopen(pchMapSrcName, "rb");
    else
        bCloseMapFile = false;

    if (psMapFileHandle)
    {
        //Calculate number of geo maps in the file
        fseek(psMapFileHandle, 0, SEEK_END);
        I4 i4NrOfMaps = ftell(psMapFileHandle)/m_u4SizeOfGeoMapBytes;
        printf("Validation: NrOfMaps = %d\n", i4NrOfMaps);
        rewind(psMapFileHandle);
        if (i4NrOfMaps < 1)
        {
            DEBUG1(("Input file size does not match current setup parameters\n"););
            fclose(psMapFileHandle);
            return(-3);
        }

        //Validate the header
        sSHM_GEO_MAP_HEADER sMapSrcHeader;
        I4 i4Offset = 0;

        for (I4 i4MapId = 0; i4MapId < i4NrOfMaps; i4MapId++)
        {
            fseek(psMapFileHandle, i4Offset, SEEK_SET);
            fread(&sMapSrcHeader, sizeof(sMapSrcHeader), 1, psMapFileHandle);

            if ((sMapSrcHeader.u4NumAzResCells != m_u4NrOfAzResCells) ||
                (sMapSrcHeader.u4NumRangeResCells != m_u4NrOfRangeResCells) ||
                (sMapSrcHeader.u4NumMaps != m_u4NrOfFeatures))
            {
                DEBUG1(("Input file header does not match the current setup parameters\n"););
                fclose(psMapFileHandle);
                return(-2);
            }
            i4Offset += m_u4SizeOfGeoMapBytes;
        }
    
        if (bCloseMapFile)
            fclose(psMapFileHandle);

        return(std::min(i4NrOfMaps, (I4)m_u4NrOfGeoMaps));
    }

    return(-1);
}


//-----------------------------------------------------------------
// Create a default GeoMap file
//-----------------------------------------------------------------
void clSHM_GEO_MAP::vCreateDefaultMapFile(const CH* pchDefaultMapFilename)
{
    if (m_bInitialized)
    {
        U4 u4FeatureMapSizeBytes = m_u4SizeOfGeoMapPageBytes-GEO_FEATURE_NAME_LENGTH;
        U1* pu1MapBuffer = (U1*) malloc(u4FeatureMapSizeBytes);
        CH achMapName[GEO_FEATURE_NAME_LENGTH];
        memset(pu1MapBuffer, 0, m_u4SizeOfGeoMapPageBytes);
        

        FILE* psFileHandle = fopen(pchDefaultMapFilename, "wb");

        if (psFileHandle)
        {
            //Write header
            sSHM_GEO_MAP_HEADER sMapHeader;
            memset(&sMapHeader, 0, sizeof(sMapHeader));
            sMapHeader.u4NumAzResCells    = m_u4NrOfAzResCells;
            sMapHeader.u4NumRangeResCells = m_u4NrOfRangeResCells;
            sMapHeader.u4NumMaps          = m_u4NrOfFeatures;

            for (U4 u4MapId = 0; u4MapId < m_u4NrOfGeoMaps; u4MapId++)
            {
                fwrite(&sMapHeader, sizeof(sSHM_GEO_MAP_HEADER), 1, psFileHandle);

                //Write Coastline feature
                memset(achMapName, 0, GEO_FEATURE_NAME_LENGTH);
                sprintf(achMapName, "Coastline");
                fwrite(achMapName, GEO_FEATURE_NAME_LENGTH, 1, psFileHandle);
                fwrite(pu1MapBuffer, u4FeatureMapSizeBytes, 1, psFileHandle);

                //Write Roads feature
                memset(achMapName, 0, GEO_FEATURE_NAME_LENGTH);
                sprintf(achMapName, "Roads");
                fwrite(achMapName, GEO_FEATURE_NAME_LENGTH, 1, psFileHandle);
                fwrite(pu1MapBuffer, u4FeatureMapSizeBytes, 1, psFileHandle);

                //Write Railway feature
                memset(achMapName, 0, GEO_FEATURE_NAME_LENGTH);
                sprintf(achMapName, "Railway");
                fwrite(achMapName, GEO_FEATURE_NAME_LENGTH, 1, psFileHandle);
                fwrite(pu1MapBuffer, u4FeatureMapSizeBytes, 1, psFileHandle);

                //Write Land feature
                memset(achMapName, 0, GEO_FEATURE_NAME_LENGTH);
                sprintf(achMapName, "Land");
                fwrite(achMapName, GEO_FEATURE_NAME_LENGTH, 1, psFileHandle);
                memset(pu1MapBuffer, 1, m_u4SizeOfGeoMapPageBytes);
                fwrite(pu1MapBuffer, u4FeatureMapSizeBytes, 1, psFileHandle);

                //Write Airport feature
                memset(achMapName, 0, GEO_FEATURE_NAME_LENGTH);
                sprintf(achMapName, "Airport");
                fwrite(achMapName, GEO_FEATURE_NAME_LENGTH, 1, psFileHandle);
                memset(pu1MapBuffer, 0, m_u4SizeOfGeoMapPageBytes);
                fwrite(pu1MapBuffer, u4FeatureMapSizeBytes, 1, psFileHandle);
            }

            fclose(psFileHandle);
        }
    }
}


//-----------------------------------------------------------------
// Display header info
//-----------------------------------------------------------------
void clSHM_GEO_MAP::vDispHeader()
{
    if (m_bInitialized)
    {
        for (U4 u4MapId = 0; u4MapId < m_u4NrOfGeoMaps; u4MapId++)
        {
            m_psShmHeader = (sSHM_GEO_MAP_HEADER*) (((U1*)m_clSharedMemory.pvGetPtr()) + u4MapId*m_u4SizeOfGeoMapBytes);
            printf("Map %u:\n", u4MapId);
            printf("   Num Az Cells    = %u\n",   m_psShmHeader->u4NumAzResCells);
            printf("   Num Range Cells = %u\n",   m_psShmHeader->u4NumRangeResCells);
            printf("   Latitude        = %.3f\n", m_psShmHeader->f8LatitudeDeg);
            printf("   Longitude       = %.3f\n", m_psShmHeader->f8LongitudeDeg);
            printf("   Altitude        = %.3f\n", m_psShmHeader->f8AltitudeM);
            printf("   Num Maps        = %u\n",   m_psShmHeader->u4NumMaps);
            printf("   Range Bin Size  = %.3f\n", m_psShmHeader->f8RangeBinSizeM);
            printf("   Range Win Size  = %.3f\n", m_psShmHeader->f8RangeWinM);
            printf("   Az Win Size     = %.3f\n", m_psShmHeader->f8AzWinDeg);
            printf("   Timestamp       = %lu\n",  m_psShmHeader->u8TimestampMs);
            printf("\n");
        }
    }
    else
        printf("GeoMap Shm class not initlaized yet..\n");
}

