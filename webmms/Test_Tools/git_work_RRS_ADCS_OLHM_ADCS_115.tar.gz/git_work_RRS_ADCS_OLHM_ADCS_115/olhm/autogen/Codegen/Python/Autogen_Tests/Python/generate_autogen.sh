#!/bin/bash

rm -rf Autogen/*
cd ../../
./copy_test_xmls_to_sicd.sh ; ./validate_data_model_and_do_autogen.py autogen_configuration.xml
cp Output/Python/*.py Autogen_Tests/Python/Autogen/