//*******************************************************************************
// GeoMap Shm Loader
// =================
// This application loads GeoMap Data from a specified file into shared memory and
// will wait on a message queue. The message queue received by this application will
// contain information about the new map that will be loaded. Once the new map is 
// loaded, a semaphore will be posted signaling that new data has been loaded.
//
// At startup, this application will load the default map and any subsequent maps
// received will be loaded into the default map before being loaded into shm.
// This way next time the app starts up, it will load the last used Geo Map data
// into shm.
//
// This application takes command line parameters in order to configure itself.
// The command line parameters are:
//    --recv_msgq_name   : Name of the Message Queue used to receive the load map command from. \n"
//    --send_msgq_name   : Name of the Message Queue used to send the load map command response to. \n"
//    --shm_name         : Name of the Shared Memory to which the GeoMap will be loaded to.\n"
//    --watch_path       : Path to watch in order to get the new generated maps from.\n"
//    --default_map_name : Name of the default map to load at startup\n"
//    --sem_name         : Name of the Semaphore used to post to the Process using GeoMap Shm \n"
//    --num_range_cells  : Number of range cells in the GeoMap.\n"
//    --num_az_cells     : Number of azimuth cells in the GeoMap.\n"
//    --num_features     : Number of features in the GeoMap.\n"
//
// All of the command line parameters are necessary for the this application to run.
// No meaningful set of parameters is set inside this application.
//
//*******************************************************************************


//*******************************************************************************
// INCLUDES
//*******************************************************************************
//Standard Includes
//-----------------
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>

//Toolbox Includes
//----------------
#include "../../../Shared_Memory/Geo_Maps/C_LIN/clSHM_GEO_MAP.h"
#include "../../../Semaphore/Base_Class/C_LIN/clSEMAPHORE.h"
#include "../../../Semaphore/Utils/C_LIN/SemaphoreUtils.h"
#include "../../../MessageQueue/clMSGQ/C_LIN/clMSGQ.h"
#include "../../../Console/Utils/C/clSAFE_EXIT.h"
#include "../../../Console/Utils/C/RabbitUtils.h"


//*******************************************************************************
// DEFINES & GLOBALS
//*******************************************************************************
#define GMAP_FILE_DOESNT_EXIST_MSG "Filename specified does not exits."
#define GMAP_INVALID_FORMAT_MSG    "Specified file has invalid format."
#define GMAP_SUCCESS_MSG           "Successfully loaded new GMap."
#define MQ_BUFF_STRING_SIZE        128

clMSGQ         G_clRecvLoadCmdMq;
clMSGQ         G_clSendLoadCmdRspMq;
clSEMAPHORE    G_clNewGmapSem;
clSHM_GEO_MAP  G_clGmapShm;

typedef enum
{
  GML_NOTIFICATION_SEVERITY_NORMAL  = 0,
  GML_NOTIFICATION_SEVERITY_WARNING = 1,
  GML_NOTIFICATION_SEVERITY_ERROR   = 2,
  GML_NOTIFICATION_SEVERITY_ALARM   = 3,
} E1_NOTIFICATION_SEVERITY;

typedef struct
{
    CH achGeoMapFilename[MQ_BUFF_STRING_SIZE];
    U1 u1Severity;
    CH achStatusMessage[MQ_BUFF_STRING_SIZE];
} __attribute__ ((packed)) sGMAP_MQ_BUFFER;




//*******************************************************************************
// FUNCTIONS START
//*******************************************************************************

//*******************************************************************************
// Print Usage
// -----------
// Displays the usage of this application and its command line parameters.
//*******************************************************************************
void vPrintUsage()
{
    printf("\n"
           "GeoMapShmLoader -- Load GeoMap data from a generated map file to shared memory.\n"
           "\n"
           "Usage: ./GeoMapShmLoader {property-value pair}\n"
           "\n"
           "Properties:\n"
           "  --recv_msgq_name   : Name of the Message Queue used to receive the load map command from. \n"
           "  --send_msgq_name   : Name of the Message Queue used to send the load map command response to. \n"
           "  --shm_name         : Name of the Shared Memory to which the GeoMap will be loaded to.\n"
           "  --watch_path       : Path to watch in order to get the new generated maps from.\n"
           "  --default_map_name : Name of the default map to load at startup\n"
           "  --sem_name         : Name of the Semaphore used to post to the Process using GeoMap Shm \n"
           "  --num_range_cells  : Number of range cells in the GeoMap.\n"
           "  --num_az_cells     : Number of azimuth cells in the GeoMap.\n"
           "  --num_features     : Number of features in the GeoMap.\n"
           "  --num_maps         : Number of maps in the GeoMap. (Optional, Default=1)\n"
           "\n");
}

//*******************************************************************************
// MAIN FUNCTION
//*******************************************************************************
int main(int argc, char** argv)
{
    //================================================================================
    // Set default parameters
    //================================================================================
    CH* pchRecvMsgQName   = NULL;  //Name of Message Queue to receive load command from
    CH* pchSendMsgQName   = NULL;  //Name of Message Queue to send load command response to
    CH* pchGeoMapShmName  = NULL;  //Name of Shm to load new map to
    CH* pchMapWatchPath   = NULL;  //Name of path to watch for new maps
    CH* pchSemName        = NULL;  //Name of Sem to post to DP when map load is complete
    CH* pchDefaultMapName = NULL;  //Name, including path, of default map to load at startup
    U4  u4NumRangeCells   = 0;     //Number of range cells for GeoMaps Shm
    U4  u4NumAzCells      = 0;     //Number of azimuth cells for GeoMaps Shm
    U4  u4NumFeatures     = 0;     //Number of features for GeoMaps Shm
    U4  u4NumMaps         = 1;     //Number of maps in GeoMaps Shm

    //================================================================================
    // Get command line parameters
    //================================================================================
    if (argc >= 19)
    {
        for (I4 i4ArgId = 1; i4ArgId < argc-1; i4ArgId += 2)
        {
            if (!strcmp(argv[i4ArgId], "--recv_msgq_name")) 
                pchRecvMsgQName = argv[i4ArgId+1];
            else if (!strcmp(argv[i4ArgId], "--send_msgq_name")) 
                pchSendMsgQName = argv[i4ArgId+1];
            else if (!strcmp(argv[i4ArgId], "--shm_name")) 
                pchGeoMapShmName = argv[i4ArgId+1];
            else if (!strcmp(argv[i4ArgId], "--watch_path")) 
                pchMapWatchPath = argv[i4ArgId+1];
            else if (!strcmp(argv[i4ArgId], "--sem_name")) 
                pchSemName = argv[i4ArgId+1];
            else if (!strcmp(argv[i4ArgId], "--num_range_cells")) 
                u4NumRangeCells = strtoul(argv[i4ArgId+1], NULL, 0);
            else if (!strcmp(argv[i4ArgId], "--num_az_cells")) 
                u4NumAzCells = strtoul(argv[i4ArgId+1], NULL, 0);
            else if (!strcmp(argv[i4ArgId], "--num_features")) 
                u4NumFeatures = strtoul(argv[i4ArgId+1], NULL, 0);
            else if (!strcmp(argv[i4ArgId], "--default_map_name")) 
                pchDefaultMapName = argv[i4ArgId+1];
            else if (!strcmp(argv[i4ArgId], "--num_maps")) 
                u4NumMaps = strtoul(argv[i4ArgId+1], NULL, 0);
        }
    }
    else if (argc == 1)
    {
        vPrintUsage();
        return(0);
    }
    else
    {
        printf("\nInvalid usage, only got %d of 9 input paramters.\n\n", argc);
        vPrintUsage();
        return(0);
    }

    //================================================================================
    // Initialize all memory and classes
    //================================================================================
    //Create GeoMaps Shm
    I4 i4ShmStatus = G_clGmapShm.i4Create(pchGeoMapShmName, u4NumRangeCells, u4NumAzCells, u4NumFeatures, u4NumMaps);
    if (i4ShmStatus < 1)
    {
        printf("Error (%d): Unable to create GeoMaps Shm named '%s'\n", i4ShmStatus, pchGeoMapShmName);
    }

    //Create Semaphore
    I4 i4SemStatus = G_clNewGmapSem.iOpen(pchSemName, 0);
    if (i4SemStatus < 1)
    {
        printf("Error (%d): Unable to create semaphore named '%s'\n", i4SemStatus, pchSemName);
        return(0);
    }

    //Open Receive Message Queue
    I4 i4MqStatus = i4OpenSharedMemorySem(G_clRecvLoadCmdMq, pchRecvMsgQName); //G_clRecvLoadCmdMq.i4Open(pchRecvMsgQName);
    if (i4MqStatus < 1)
    {
        printf("Error (%d): Unable to open message queue named '%s'\n", i4MqStatus, pchRecvMsgQName);
        return(0);
    }

    //Open Send Message Queue
    i4MqStatus = i4OpenSharedMemorySem(G_clSendLoadCmdRspMq, pchSendMsgQName);
    if (i4MqStatus < 1)
    {
        printf("Error (%d): Unable to open message queue named '%s'\n", i4MqStatus, pchSendMsgQName);
        return(0);
    }

    //If default file does not exist or is invalid, create new default file with default settings
    if (G_clGmapShm.i4ValidateMapsFile(pchDefaultMapName) < 1)
    {
        G_clGmapShm.vCreateDefaultMapFile(pchDefaultMapName);
    }

    //================================================================================
    // Start load GeoMap
    //================================================================================
    bool bLoadMap   = true;
    bool bFirstTime = true;
    CH   achNewMapName[256];
    CH   achCopyCommand[512];
    sGMAP_MQ_BUFFER sMqBuffer;
    U4 u4MsgPriority=0;
    I4 i4TimeoutMs = 1000;
    U4 u4MsgSizeBytes = sizeof(sGMAP_MQ_BUFFER);
    while (G_clSafeExit.bRunning)
    {
        if (!bLoadMap)
        {
            //Wait for MQ
            i4MqStatus = G_clRecvLoadCmdMq.i4Receive((U1*) &sMqBuffer, u4MsgSizeBytes, &u4MsgPriority, i4TimeoutMs);
            if (i4MqStatus == (I4)u4MsgSizeBytes)
            {
                printf("Received MQ, loading new map...\n");
                bLoadMap = true;
            }
            else
                vShowRabbit();
        }

        //Load new map
        if (bLoadMap)
        {
            if (!bFirstTime)
            {
                memset(achNewMapName, 0, 256);
                sprintf(achNewMapName, "%s/%s.gfmap", pchMapWatchPath, sMqBuffer.achGeoMapFilename);
                printf("Loading %s into shm\n", achNewMapName);
            }
            else
            {
                sprintf(achNewMapName, "%s", pchDefaultMapName);
                printf("Loading default Map\n");
            }

            //Load Map
            i4ShmStatus = G_clGmapShm.i4ValidateMapsFile(achNewMapName);
            if (i4ShmStatus < 1)
            {
                //Update response MQ buffer
                memset(&sMqBuffer, 0, u4MsgSizeBytes);
                sprintf(sMqBuffer.achGeoMapFilename, "Default");
                sMqBuffer.u1Severity = GML_NOTIFICATION_SEVERITY_WARNING;
                if (i4ShmStatus == -1)
                    sprintf(sMqBuffer.achStatusMessage, GMAP_FILE_DOESNT_EXIST_MSG);
                else if (i4ShmStatus == -2)
                    sprintf(sMqBuffer.achStatusMessage, GMAP_INVALID_FORMAT_MSG);

                printf("Unable to load new map to Shm\n");
            }
            else
            {
                //Copy new map file to default
                if (!bFirstTime)
                {
                    memset(achCopyCommand, 0, 512);
                    sprintf(achCopyCommand, "cp -f %s %s", achNewMapName, pchDefaultMapName);
                    //printf("Command = '%s'\n", achCopyCommand);
                    system(achCopyCommand);
                }

                //Load file into shm. Return does not need to be checked since the validation check
                //was already successful at this stage.
                G_clGmapShm.i4LoadMapsFromFile(pchDefaultMapName);
                G_clGmapShm.vDispHeader();

                //Post semaphore
                i4SemStatus = G_clNewGmapSem.iPost();

                //Update response MQ buffer
                sMqBuffer.u1Severity = GML_NOTIFICATION_SEVERITY_NORMAL;
                memset(sMqBuffer.achStatusMessage, 0, MQ_BUFF_STRING_SIZE);
                sprintf(sMqBuffer.achStatusMessage, GMAP_SUCCESS_MSG);

                printf("%s\n\n", GMAP_SUCCESS_MSG);
            }

            //Sent reponse MQ
            if (!bFirstTime)
                i4MqStatus = G_clSendLoadCmdRspMq.i4Send((U1*)&sMqBuffer, u4MsgSizeBytes, u4MsgPriority, i4TimeoutMs);

            bFirstTime = false;
            bLoadMap = false;
        }

    }
}