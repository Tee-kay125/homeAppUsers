/*  Autogen Message Topic List Source */
/*  Generated using Python 2.7.11 |Anaconda 4.1.0 (64-bit)| (default, Jun 15 2016, 15:21:30) , with Jinja2 2.10 */
/*  Generated on Wednesday, 23 October 2019 SAST 07:08           */

/* INCLUDES */
#include <stdio.h>
#include "RMS_SSP_MSG_Topics.h"


/* GLOBALS */
const CH* G_ppchAllTopics[] = {
    "RSR906/SSP/SspStatusReq",
    "RSR906/SSP/SspStatusReqRsp",
    "RSR906/SSP/SspSetupCmd",
    "RSR906/SSP/SspSetupCmdRsp",
    "RSR906/SSP/SspEndOfSetupCmd",
    "RSR906/SSP/SspEndOfSetupCmdRsp",
    "RSR906/SSP/SspResetCmd",
    "RSR906/SSP/SspResetCmdRsp",
    "RSR906/SSP/SspShutdownCmd",
    "RSR906/SSP/SspShutdownCmdRsp",
    "RSR906/SSP/SspSetActiveProfileCmd",
    "RSR906/SSP/SspSetActiveProfileCmdRsp",
    "RSR906/SSP/SspInitClutterMapsCmd",
    "RSR906/SSP/SspInitClutterMapsCmdRsp",
    "RSR906/SSP/SspSetSensitivityControlCmd",
    "RSR906/SSP/SspSetSensitivityControlCmdRsp",
    "RSR906/SSP/SspSetDeploymentPositionCmd",
    "RSR906/SSP/SspSetDeploymentPositionCmdRsp",
    "RSR906/SSP/SspLoadGeoMapCmd",
    "RSR906/SSP/SspLoadGeoMapCmdRsp",
};

const CH* G_ppchIncTopics[] = {
    "RSR906/SSP/SspStatusReq",
    "RSR906/SSP/SspSetupCmd",
    "RSR906/SSP/SspEndOfSetupCmd",
    "RSR906/SSP/SspResetCmd",
    "RSR906/SSP/SspShutdownCmd",
    "RSR906/SSP/SspSetActiveProfileCmd",
    "RSR906/SSP/SspInitClutterMapsCmd",
    "RSR906/SSP/SspSetSensitivityControlCmd",
    "RSR906/SSP/SspSetDeploymentPositionCmd",
    "RSR906/SSP/SspLoadGeoMapCmd",
};

const CH* G_ppchRspTopics[] = {
    "RSR906/SSP/SspStatusReqRsp",
    "RSR906/SSP/SspSetupCmdRsp",
    "RSR906/SSP/SspEndOfSetupCmdRsp",
    "RSR906/SSP/SspResetCmdRsp",
    "RSR906/SSP/SspShutdownCmdRsp",
    "RSR906/SSP/SspSetActiveProfileCmdRsp",
    "RSR906/SSP/SspInitClutterMapsCmdRsp",
    "RSR906/SSP/SspSetSensitivityControlCmdRsp",
    "RSR906/SSP/SspSetDeploymentPositionCmdRsp",
    "RSR906/SSP/SspLoadGeoMapCmdRsp",
};


/* FUNCTIONS */
I4 i4GetTopicName(U1* pu1TopicName, CH* pchMsgPayload)
{
    sMESSAGE_HEADER* psHeader = (sMESSAGE_HEADER*) pchMsgPayload;
    CH* pchTopicName = (CH*) pu1TopicName;

    switch (((U4) psHeader->u2MsgId << 8) | psHeader->u2MsgType)
    {
        case 0x000002:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspStatusReq"); break;
        case 0x000003:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspStatusReqRsp"); break;
        case 0x000100:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspSetupCmd"); break;
        case 0x000101:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspSetupCmdRsp"); break;
        case 0x000200:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspEndOfSetupCmd"); break;
        case 0x000201:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspEndOfSetupCmdRsp"); break;
        case 0x000E00:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspResetCmd"); break;
        case 0x000E01:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspResetCmdRsp"); break;
        case 0x000F00:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspShutdownCmd"); break;
        case 0x000F01:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspShutdownCmdRsp"); break;
        case 0x001000:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspSetActiveProfileCmd"); break;
        case 0x001001:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspSetActiveProfileCmdRsp"); break;
        case 0x001100:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspInitClutterMapsCmd"); break;
        case 0x001101:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspInitClutterMapsCmdRsp"); break;
        case 0x001200:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspSetSensitivityControlCmd"); break;
        case 0x001201:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspSetSensitivityControlCmdRsp"); break;
        case 0x001300:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspSetDeploymentPositionCmd"); break;
        case 0x001301:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspSetDeploymentPositionCmdRsp"); break;
        case 0x001500:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspLoadGeoMapCmd"); break;
        case 0x001501:  sprintf(pchTopicName, "%s", "RSR906/SSP/SspLoadGeoMapCmdRsp"); break;
        default: 
            printf("Unable to assign topic for (%u, %u) key\n", psHeader->u2MsgId, psHeader->u2MsgType);
            return(-1);
    }
    return(0);
}

/* END OF FILE */