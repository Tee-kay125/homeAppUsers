
#!/usr/bin/env python3.6
# -*- coding: utf-8 -*-
""" This module provides a class which provides Python code generation

"""
import logging
import os  # We need this to split filenames into base and extension
import re  # We need this to split tokens
from Autogen_Toolbox.autogen_toolbox_definition_validation_and_et_finding import E_TYPEDEF_XML_FILE_TYPEDEF_TYPE
from Autogen_Toolbox.autogen_toolbox_definition_validation_and_et_finding import E_FIELD_OR_RECORD_TYPE
from Autogen_Toolbox.autogen_toolbox_definition_validation_and_et_finding import E_COMMS_PROTOCOL
from Autogen_Toolbox.autogen_toolbox_definition_validation_and_et_finding import E_MESSAGE_FLOW_DIRECTION


# This dictionary's key is a tuple
# The tuple's fields are:
#  * The base type (str)
#  * Does the the field have count greater than 1 (bool)
G_dctTypeToCppFieldPrefix = {}
G_dctTypeToCppFieldPrefix[("U1", False)] = str("u1")
G_dctTypeToCppFieldPrefix[("U2", False)] = str("u2")
G_dctTypeToCppFieldPrefix[("U4", False)] = str("u4")
G_dctTypeToCppFieldPrefix[("U8", False)] = str("u8")
G_dctTypeToCppFieldPrefix[("I1", False)] = str("i1")
G_dctTypeToCppFieldPrefix[("I2", False)] = str("i2")
G_dctTypeToCppFieldPrefix[("I4", False)] = str("i4")
G_dctTypeToCppFieldPrefix[("I8", False)] = str("i8")
G_dctTypeToCppFieldPrefix[("F4", False)] = str("f4")
G_dctTypeToCppFieldPrefix[("F8", False)] = str("f8")
G_dctTypeToCppFieldPrefix[("CH", False)] = str("ac")
G_dctTypeToCppFieldPrefix[("U1", True)] = str("au1")
G_dctTypeToCppFieldPrefix[("U2", True)] = str("au2")
G_dctTypeToCppFieldPrefix[("U4", True)] = str("au4")
G_dctTypeToCppFieldPrefix[("U8", True)] = str("au8")
G_dctTypeToCppFieldPrefix[("I1", True)] = str("ai1")
G_dctTypeToCppFieldPrefix[("I2", True)] = str("ai2")
G_dctTypeToCppFieldPrefix[("I4", True)] = str("ai4")
G_dctTypeToCppFieldPrefix[("I8", True)] = str("ai8")
G_dctTypeToCppFieldPrefix[("F4", True)] = str("af4")
G_dctTypeToCppFieldPrefix[("F8", True)] = str("af8")
G_dctTypeToCppFieldPrefix[("CH", True)] = str("ac")


# This dictionary's key is a tuple
# The tuple's fields are:
#  * The base type (str)
#  * Does the the field have count greater than 1 (bool)
G_dctEnumTypeToCppFieldPrefix = {}
G_dctEnumTypeToCppFieldPrefix[("E1", False)] = str("e1")
G_dctEnumTypeToCppFieldPrefix[("E2", False)] = str("e2")
G_dctEnumTypeToCppFieldPrefix[("E4", False)] = str("e4")
G_dctEnumTypeToCppFieldPrefix[("E8", False)] = str("e8")
G_dctEnumTypeToCppFieldPrefix[("E1", True)] = str("ae1")
G_dctEnumTypeToCppFieldPrefix[("E2", True)] = str("ae2")
G_dctEnumTypeToCppFieldPrefix[("E4", True)] = str("ae4")
G_dctEnumTypeToCppFieldPrefix[("E8", True)] = str("ae8")


# This dictionary's key is a tuple
# The tuple's fields are:
#  * Does the the field have count greater than 1 (bool)
G_dctStructTypeToCppFieldPrefix = {}
G_dctStructTypeToCppFieldPrefix[False] = str("s")
G_dctStructTypeToCppFieldPrefix[True] = str("as")


class clsAutogenToolboxCodeGenerationPython():
    """ This class provides a class which provides Python code generation


    """

    @staticmethod
    def acCapUnderscoresToPascalCase(acCapUnderscoresPar: str):
        """ This is a public static method takes a capitilised underscores string into a Pascal case string

        Args:
            acCapUnderscoresPar (str): The string to convert to Pascal case.

        Returns:
            (str): The Pascal case result

        Raises:
            Raises no exception.
        """
        acPascalCaseResult = str("")
        lstTokens = []
        iTokenCounter = int(0)

        if (acCapUnderscoresPar is None):
            logging.error("acCapUnderscoresPar cannot be None")
            return(acPascalCaseResult)

        if (isinstance(acCapUnderscoresPar, str) is False):
            logging.error("acCapUnderscoresPar must be str")
            return(acPascalCaseResult)

        if (not acCapUnderscoresPar):
            logging.error("acCapUnderscoresPar cannot be empty")
            return(acPascalCaseResult)

        lstTokens = acCapUnderscoresPar.split("_")

        iTokenCounter = -1
        # Iterate throught the tokens
        for acToken in lstTokens:
            iTokenCounter += 1

            # Check that the token is not empty
            if (not acToken):
                continue

            acPascalCaseResult += acToken[0].upper() + acToken[1:].lower()

        return(acPascalCaseResult)

    @staticmethod
    def acGenerateTypeEnumComplete(dctTypedefEnumPar: dict):
        """ This is a public static method which generates a Python typedef code.

        Args:
            dctTypedefEnumPar (dict): A dictionary containing the information needed to write Python Definition files. The keys are:
                * ["acName"] (str)
                * ["acXmlFileName"] (str)
                * ["acXmlFilePath"] (str)
                * ["eTypedefType"] (E_TYPEDEF_XML_FILE_TYPEDEF_TYPE)
                * ["objElement"] (ET.Element)

        Returns:
            (str): A string with the entire code block which represents the enum type in Python

        Raises:
            Raises no exception.
        """
        acCodeBlock = str("")  # String to store the entire code block
        objRecordElement = None
        lstEnumerationElements = []

        if (dctTypedefEnumPar is None):
            logging.error("dctTypedefEnumPar cannot be None")
            return(acCodeBlock)

        # Get the Record Element
        objRecordElement = dctTypedefEnumPar["objElement"].find("./Record")

        if (objRecordElement is None):
            logging.error("Enum %s does not have an Record tag", dctTypedefEnumPar["acName"])
            return(acCodeBlock)

        # Get all the Enumeration Elements
        lstEnumerationElements = dctTypedefEnumPar["objElement"].findall("./Record/Enumeration")

        if (not lstEnumerationElements):
            logging.error("Enum %s does not have any Enumeration tags", dctTypedefEnumPar["acName"])
            return(acCodeBlock)

        # Now that we have gathered the Enumeration Elements we need start preparing the code block
        acCodeBlock = str("class %s(clsAdcsEnumType):\n" % dctTypedefEnumPar["acName"])
        acCodeBlock += str("    \"\"\"Public class definition of type %s\n" % dctTypedefEnumPar["acName"])
        acCodeBlock += str("    \"\"\"\n")
        acCodeBlock += str("    def __init__(self, defaultValue=0):\n")
        acCodeBlock += str("        super().__init__(\"%s\", defaultValue)\n" % (objRecordElement.attrib["Type"]))

        for objEnumerationElement in lstEnumerationElements:
            acCodeBlock += "    %s = %s\n" % (objEnumerationElement.attrib["Name"], objEnumerationElement.attrib["Value"])

        acCodeBlock += "\n"
        acCodeBlock += "\n"
        acCodeBlock += str("vAddEnum(\"%s\", %s)\n" % (dctTypedefEnumPar["acName"], dctTypedefEnumPar["acName"]))
        acCodeBlock += "\n"

        return(acCodeBlock)

    @staticmethod
    def acGenerateTypeStructComplete(dctTypedefStructPar: dict):
        """ This is a public static method which generates a Python typedef struct code.

        Args:
            dctTypedefStructPar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["acName"] (str)
                * ["acXmlFileName"] (str)
                * ["acXmlFilePath"] (str)
                * ["eTypedefType"] (E_TYPEDEF_XML_FILE_TYPEDEF_TYPE)
                * ["objElement"] (ET.Element)
            bGenerateConstructor (bool): Flag to indicate if a constructor should be generated.

        Returns:
            (str): A string with the entire code block which represents the enum type in Python

        Raises:
            Raises no exception.
        """
        acCodeBlock = str("")  # String to store the entire code block
        lstRecordElements = []
        tplTypeToCppFieldPrefix = ("U1", bool(False))  # These are just startup values see G_dctTypeToCppFieldPrefix for detail description
        acBaseTypeWithCountOneOrMore = str("")
        acNamePrefix = str("")
        acFullMemberName = str("")
        bIsCountGreaterThanOne = bool(False)
        iCount = int(0)
        lstDefinitionLines = []
        acDefinitionLine = str("")

        if (dctTypedefStructPar is None):
            logging.error("dctTypedefStructPar cannot be None")
            return(acCodeBlock)

        # Get the Record Element

        lstRecordElements = dctTypedefStructPar["objElement"].findall("./Record")

        if (not lstRecordElements):
            logging.error("Struct %s does not have any Record tags", dctTypedefStructPar["acName"])
            return(acCodeBlock)

        # Iterate through all the records in the struct
        for objRecord in lstRecordElements:

            acNamePrefix = str("")
            acDefinitionLine = str("")

            # Make sure the Count attribute is there
            if ("Count" not in objRecord.attrib):
                logging.error("Attribute Count missing from %s", objRecord.attrib["Name"])
                continue

            try:
                iCount = int(objRecord.attrib["Count"])
            except Exception as E:
                logging.error("Attribute Count from %s is probably not an int - Exception %s", objRecord.attrib["Name"], str(E))
                continue

            if (iCount <= 0):
                logging.error("Attribute Count from %s is not allowed to be less than 1", objRecord.attrib["Name"])
                continue

            bIsCountGreaterThanOne = iCount > 1

            # This attribute "eRecordType" came from autogen_toolbox_definition_validation_and_et_finding.py methods bValidateFieldOrRecordElementRecursively() and tplValidateMsgDefPayloadFromRootElement() and bValidateTypedefOfTypeStruct()
            if (objRecord.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_ENUM)):
                acNamePrefix = G_dctEnumTypeToCppFieldPrefix[(objRecord.attrib["Type"][:2], bIsCountGreaterThanOne)]
                acFullMemberName = acNamePrefix + objRecord.attrib["Name"]

                if (bIsCountGreaterThanOne is False):
                    acDefinitionLine += "        self.%s = %s(%s.%s)\n" % (acFullMemberName, objRecord.attrib["Type"], objRecord.attrib["Type"], objRecord.attrib["Default"])
                else:
                    acDefinitionLine += "        self.%s = clsAdcsEnumArrayType(\"%s:%s\", %s.%s)\n" % (acFullMemberName, objRecord.attrib["Type"], objRecord.attrib["Count"],  objRecord.attrib["Type"], objRecord.attrib["Default"])

            elif (objRecord.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_STRUCT)):
                acNamePrefix = G_dctStructTypeToCppFieldPrefix[bIsCountGreaterThanOne]
                acFullMemberName = acNamePrefix + objRecord.attrib["Name"]

                if (bIsCountGreaterThanOne is False):
                    acDefinitionLine += "        self.%s = %s()\n" % (acFullMemberName, objRecord.attrib["Type"])
                else:
                    acDefinitionLine += "        self.%s = clsAdcsStructArrayType(\"%s:%s\")\n" % (acFullMemberName, objRecord.attrib["Type"], objRecord.attrib["Count"])

            elif (objRecord.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_BASE)):
                tplTypeToCppFieldPrefix = (objRecord.attrib["Type"], objRecord.attrib["Count"] != "1")
                acFullMemberName = G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix] + objRecord.attrib["Name"]

                if (objRecord.attrib["Type"] == "CH"):
                    acBaseTypeWithCountOneOrMore = ":%s" % (objRecord.attrib["Count"])
                    acDefinitionLine += "        self.%s = clsAdcsBaseType(\"%s%s\", \"%s\")\n" % (acFullMemberName, objRecord.attrib["Type"], acBaseTypeWithCountOneOrMore, objRecord.attrib["Default"])
                else:

                    if (bIsCountGreaterThanOne is True):
                        acBaseTypeWithCountOneOrMore = ":%s" % (objRecord.attrib["Count"])
                    else:
                        acBaseTypeWithCountOneOrMore = ""

                    acDefinitionLine += "        self.%s = clsAdcsBaseType(\"%s%s\", %s)\n" % (acFullMemberName, objRecord.attrib["Type"], acBaseTypeWithCountOneOrMore, objRecord.attrib["Default"])

                if ("Min" in objRecord.attrib):
                    acDefinitionLine += "        self.%s.vSetMin(%s)\n" % (acFullMemberName, objRecord.attrib["Min"])

                if ("Max" in objRecord.attrib):
                    acDefinitionLine += "        self.%s.vSetMax(%s)\n" % (acFullMemberName, objRecord.attrib["Max"])

            acDefinitionLine += "        self.vAddType(\"%s\")\n" % (acFullMemberName)

            lstDefinitionLines.append(acDefinitionLine)

        # Now that we have gathered the Record Elements we need start preparing the code block
        acCodeBlock = str("class %s(clsAdcsStructType):\n" % (dctTypedefStructPar["acName"]))
        acCodeBlock += str("    \"\"\"Public class definition of type %s\n" % (dctTypedefStructPar["acName"]))
        acCodeBlock += str("    \"\"\"\n")
        acCodeBlock += str("    def __init__(self, defaultValue=0):\n")
        acCodeBlock += str("        super().__init__(\"%s\")\n" % (dctTypedefStructPar["acName"]))

        for acDefinitionLine in lstDefinitionLines:

            # Add each line of definition
            acCodeBlock += acDefinitionLine

        acCodeBlock += "\n"
        acCodeBlock += "\n"
        acCodeBlock += "vAddClass(\"%s\",%s)\n" % (dctTypedefStructPar["acName"], dctTypedefStructPar["acName"])
        acCodeBlock += "\n"

        return(acCodeBlock)

    @staticmethod
    def lstGeneratePythonPayloads(dctMsgDefXmlFilePar: dict):
        """ This is a public static method which generates a Python payload code.

        Args:
            dctMsgDefXmlFilePar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["objElementTreeRoot"] (str)
                * ["acFileName"] (str)
                * ["tplValidMessagePayloads"] (tuple)

        Returns:
            (list): A list string payloads

        Raises:
            Raises no exception.
        """
        lstReturnPayloads = []
        objPayloadElement = None
        acCodeBlock = str("")
        lstFieldElements = []
        acNamePrefix = str("")
        bIsCountGreaterThanOne = bool(False)
        acPayloadCppName = str("")
        tplValidMessagePayloads = (bool(False), [])

        iCount = int(0)  # Stores the Field Count as an int
        lstDefinitionLines = []  # Stores all the definition lines
        acDefinitionLine = str("")
        acFullMemberName = str("")

        # Do some checks
        if (dctMsgDefXmlFilePar is None):
            logging.error("dctMsgDefXmlFilePar cannot be None")
            return(lstReturnPayloads)

        if ("tplValidMessagePayloads" not in dctMsgDefXmlFilePar):
            logging.error("tplValidMessagePayloads not in dctMsgDefXmlFilePar")
            return(lstReturnPayloads)

        tplValidMessagePayloads = dctMsgDefXmlFilePar["tplValidMessagePayloads"]

        if (tplValidMessagePayloads[0] is False):
            logging.error("File %s Message Payloads are invalid", dctMsgDefXmlFilePar["acFileName"])
            return(lstReturnPayloads)

        for dctMessageDictItem in tplValidMessagePayloads[1]:

            if ("objPayloadElement" not in dctMessageDictItem):
                logging.error("Message %s does not have a Payload Element object", dctMessageDictItem["acName"])
                continue

            objPayloadElement = dctMessageDictItem["objPayloadElement"]

            # Do not generate code for a payload if there are no Fields - an empty struct in C++ is the sizeof of 1 which is not good for us
            if (objPayloadElement.attrib["bPayloadWithNoFields"] is True):
                continue

            if (objPayloadElement is None):
                logging.error("Message %s does not have a Payload tag", dctMessageDictItem["acName"])
                continue

            if ("acNameAsCapitalisedUnderscores" not in objPayloadElement.attrib):
                logging.error("Message %s Payload does not have the acNameAsCapitalisedUnderscores attribute", dctMessageDictItem["acName"])
                continue

            # This attribute came from autogen_toolbox_definition_validation_and_et_finding.py method lstFindMessagePayloadPairElementsFromMsgDefRootElement()
            acPayloadCppName = objPayloadElement.attrib["acNameAsCapitalisedUnderscores"]

            lstFieldElements = objPayloadElement.findall("./Field")

            lstDefinitionLines = []

            for objFieldElement in lstFieldElements:

                acNamePrefix = str("")
                acDefinitionLine = str("")

                # The Count attribute was forced when it was validated even if it was not defined
                if ("Count" not in objFieldElement.attrib):
                    logging.error("No Count attribute for Field %s of type %s", objFieldElement.attrib["Name"], str(objFieldElement.attrib["Type"]))
                    continue

                try:
                    iCount = int(objFieldElement.attrib["Count"])
                except Exception as E:
                    logging.error("The Count attribute for Field %s is probably not an int - Exception %s", objFieldElement.attrib["Name"], str(E))
                    continue

                if (iCount > 1):
                    bIsCountGreaterThanOne = bool(True)
                else:
                    bIsCountGreaterThanOne = bool(False)

                # The eRecordType attribute was added during validation
                if ("eRecordType" not in objFieldElement.attrib):
                    logging.error("No Count attribute for Field %s of type %s", objFieldElement.attrib["Name"], str(objFieldElement.attrib["Type"]))
                    continue

                # This attribute "eRecordType" came from autogen_toolbox_definition_validation_and_et_finding.py methods bValidateFieldOrRecordElementRecursively() and tplValidateMsgDefPayloadFromRootElement() and bValidateTypedefOfTypeStruct()
                if (objFieldElement.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_ENUM)):
                    acNamePrefix = G_dctEnumTypeToCppFieldPrefix[(objFieldElement.attrib["Type"][:2], bIsCountGreaterThanOne)]
                    acFullMemberName = acNamePrefix.lower() + objFieldElement.attrib["Name"]

                    if (bIsCountGreaterThanOne is False):
                        acDefinitionLine += "        self.%s = %s(%s.%s)\n" % (acFullMemberName, objFieldElement.attrib["Type"], objFieldElement.attrib["Type"], objFieldElement.attrib["Default"])
                    else:
                        acDefinitionLine += "        self.%s = clsAdcsEnumArrayType(\"%s:%s\", %s.%s)\n" % (acFullMemberName, objFieldElement.attrib["Type"], objFieldElement.attrib["Count"], objFieldElement.attrib["Type"], objFieldElement.attrib["Default"])

                elif (objFieldElement.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_STRUCT)):

                    # Determine the prefix of the field name
                    acNamePrefix = G_dctStructTypeToCppFieldPrefix[bIsCountGreaterThanOne]
                    acFullMemberName = acNamePrefix + objFieldElement.attrib["Name"]

                    # Make the line of code for the field
                    if (bIsCountGreaterThanOne is False):
                        acDefinitionLine += "        self.%s = %s()\n" % (acFullMemberName, objFieldElement.attrib["Type"])
                    else:
                        acDefinitionLine += "        self.%s = clsAdcsStructArrayType(\"%s:%s\")\n" % (acFullMemberName, objFieldElement.attrib["Type"], objFieldElement.attrib["Count"])

                elif (objFieldElement.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_BASE)):

                    # Use a lookup to determine the field name prefix - combine the type and count as a lookup key
                    tplTypeToCppFieldPrefix = (objFieldElement.attrib["Type"], bIsCountGreaterThanOne)

                    # Look up the prefix we need
                    acNamePrefix = G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix]
                    acFullMemberName = acNamePrefix + objFieldElement.attrib["Name"]

                    if (objFieldElement.attrib["Type"] == "CH"):
                        acDefinitionLine += "        self.%s = clsAdcsBaseType(\"%s:%s\",\"%s\")\n" % (acFullMemberName, objFieldElement.attrib["Type"], objFieldElement.attrib["Count"], objFieldElement.attrib["Default"])
                    else:
                        if (bIsCountGreaterThanOne is False):
                            acDefinitionLine += "        self.%s = clsAdcsBaseType(\"%s\", %s)\n" % (acFullMemberName, objFieldElement.attrib["Type"], objFieldElement.attrib["Default"])
                        else:
                            acDefinitionLine += "        self.%s = clsAdcsBaseType(\"%s:%s\", %s)\n" % (acFullMemberName, objFieldElement.attrib["Type"], objFieldElement.attrib["Count"], objFieldElement.attrib["Default"])

                if ("Min" in objFieldElement.attrib):
                    acDefinitionLine += "        self.%s.vSetMin(%s)\n" % (acFullMemberName, objFieldElement.attrib["Min"])

                if ("Max" in objFieldElement.attrib):
                    acDefinitionLine += "        self.%s.vSetMax(%s)\n" % (acFullMemberName, objFieldElement.attrib["Max"])

                acDefinitionLine += "        self.vAddType(\"%s\")\n" % (acFullMemberName)

                lstDefinitionLines.append(acDefinitionLine)

            acCodeBlock = str("class s%s_PL(clsAdcsMessageStructType):\n" % (acPayloadCppName))
            acCodeBlock += str("    \"\"\"Public class definition of type s%s_PL\n" % (acPayloadCppName))
            acCodeBlock += str("    \"\"\"\n")
            acCodeBlock += str("    def __init__(self, formatType=None):\n")
            acCodeBlock += str("        super().__init__(formatType)\n")

            for acDefinitionLine in lstDefinitionLines:
                # Add each line of definition
                acCodeBlock += acDefinitionLine

            acCodeBlock += "\n"
            acCodeBlock += "\n"
            acCodeBlock += "vAddClass(\"s%s_PL\", s%s_PL)\n" % (acPayloadCppName, acPayloadCppName)
            acCodeBlock += "\n"

            lstReturnPayloads.append(acCodeBlock)

        return(lstReturnPayloads)

    @staticmethod
    def lstGeneratePythonHeaders(dctMsgDefXmlFilePar: dict):
        """ This is a public static method which generates Python header code.

        Args:
            dctMsgDefXmlFilePar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["objElementTreeRoot"] (str)

        Returns:
            (str): A string with the entire code block which represents the enum type in C++

        Raises:
            Raises no exception.
        """
        acReturnCodeBlock = str("")
        lstReturnHeaders = []
        lstFieldElements = []
        lstDefinitionLines = []
        acDefinitionLine = str("")
        lstMessageHeaderDictItems = []
        acNamePrefix = str("")
        acFullMemberName = str("")

        if (dctMsgDefXmlFilePar is None):
            logging.error("dctMsgDefXmlFilePar cannot be None")
            return(lstReturnHeaders)

        if ("tplValidMessageHeaders" not in dctMsgDefXmlFilePar):
            logging.error("Key tplValidMessageHeaders not in dctMsgDefXmlFilePar for %s", dctMsgDefXmlFilePar["acFileName"])
            return(lstReturnHeaders)

        if (dctMsgDefXmlFilePar["tplValidMessageHeaders"][0] is False):
            logging.error("Key tplValidMessageHeaders not in dctMsgDefXmlFilePar for %s", dctMsgDefXmlFilePar["acFileName"])
            return(lstReturnHeaders)

        lstMessageHeaderDictItems = dctMsgDefXmlFilePar["tplValidMessageHeaders"][1]

        if (not lstMessageHeaderDictItems):
            return(lstReturnHeaders)

        for dctMessageHeaderDictItem in lstMessageHeaderDictItems:

            lstDefinitionLines = []

            lstFieldElements = dctMessageHeaderDictItem["lstFieldElements"]

            if (not lstFieldElements):
                logging.error("There are no Fields in the first Header tag")
                return(acReturnCodeBlock)

            for objFieldElement in lstFieldElements:

                acDefinitionLine = str("")

                # This attribute "eRecordType" came from autogen_toolbox_definition_validation_and_et_finding.py methods bValidateFieldOrRecordElementRecursively() and tplValidateMsgDefPayloadFromRootElement() and bValidateTypedefOfTypeStruct()
                if (objFieldElement.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_ENUM)):
                    acNamePrefix = objFieldElement.attrib["Type"][:2].lower()
                    acFullMemberName = acNamePrefix + objFieldElement.attrib["Name"]
                    acDefinitionLine = "        self.%s = %s(%s.%s)\n" % (acFullMemberName, objFieldElement.attrib["Type"], objFieldElement.attrib["Type"], objFieldElement.attrib["Default"])

                elif (objFieldElement.attrib["eRecordType"] == E_FIELD_OR_RECORD_TYPE(E_FIELD_OR_RECORD_TYPE.FIELD_OR_RECORD_IS_BASE)):
                    tplTypeToCppFieldPrefix = (objFieldElement.attrib["Type"], objFieldElement.attrib["Count"] != "1")
                    acFullMemberName = G_dctTypeToCppFieldPrefix[tplTypeToCppFieldPrefix] + objFieldElement.attrib["Name"]
                    acDefinitionLine = "        self.%s = clsAdcsBaseType(\"%s\", %s)\n" % (acFullMemberName, objFieldElement.attrib["Type"], objFieldElement.attrib["Default"])

                acDefinitionLine += "        self.vAddType(\"%s\")\n" % (acFullMemberName)

                lstDefinitionLines.append(acDefinitionLine)

            acReturnCodeBlock = "class s%s_MESSAGE_HEADER(clsAdcsHeaderStructType):\n" % (dctMessageHeaderDictItem["objHeaderElement"].attrib["acNameAsCapitalisedUnderscores"])
            acReturnCodeBlock += "    \"\"\"Public class definition of type s%s\n" % (dctMessageHeaderDictItem["objHeaderElement"].attrib["acNameAsCapitalisedUnderscores"])
            acReturnCodeBlock += "    \"\"\"\n"
            acReturnCodeBlock += "    def __init__(self):\n"
            acReturnCodeBlock += "        super().__init__()\n"

            for acDefinitionLine in lstDefinitionLines:

                # Add each line of definition
                acReturnCodeBlock += acDefinitionLine

            acReturnCodeBlock += "\n"
            acReturnCodeBlock += "\n"
            acReturnCodeBlock += "vAddClass(\"s%s_MESSAGE_HEADER\", s%s_MESSAGE_HEADER)\n" % (dctMessageHeaderDictItem["objHeaderElement"].attrib["acNameAsCapitalisedUnderscores"], dctMessageHeaderDictItem["objHeaderElement"].attrib["acNameAsCapitalisedUnderscores"])
            acReturnCodeBlock += "\n"

            lstReturnHeaders.append(acReturnCodeBlock)

        return(lstReturnHeaders)

    @staticmethod
    def lstGeneratePythonMessages(dctMsgDefXmlFilePar: dict):
        """ This is a public static method which generates Python Message code

        Args:
            dctMsgDefXmlFilePar (dict): A dictionary containing the information needed to write Cpp Definition files. The keys are:
                * ["objElementTreeRoot"] (str)

        Returns:
            (list): A list of C++ Message blocks

        Raises:
            Raises no exception.
        """
        lstReturnMessageBlocks = []
        acMessgeCodeBlock = str("")
        tplValidMessagePayloads = (bool(False), [])
        objMessageElement = None
        objPayloadElement = None

        # Do some checks
        if (dctMsgDefXmlFilePar is None):
            logging.error("dctMsgDefXmlFilePar cannot be None")
            return(lstReturnMessageBlocks)

        if ("tplValidMessagePayloads" not in dctMsgDefXmlFilePar):
            logging.error("Key tplValidMessagePayloads is missing from dctMsgDefXmlFilePar for %s", dctMsgDefXmlFilePar["acFileName"])
            return(lstReturnMessageBlocks)

        tplValidMessagePayloads = dctMsgDefXmlFilePar["tplValidMessagePayloads"]

        if (tplValidMessagePayloads[0] is False):
            logging.error("Payloads for %s is invalid", dctMsgDefXmlFilePar["acFileName"])
            return(lstReturnMessageBlocks)

        if (not tplValidMessagePayloads[1]):
            return(lstReturnMessageBlocks)

        for dctMessageDictItem in tplValidMessagePayloads[1]:
            objMessageElement = dctMessageDictItem["objMessageElement"]
            objPayloadElement = dctMessageDictItem["objPayloadElement"]

            acMessgeCodeBlock = "class s%s(clsAdcsMessageType):\n" % (objMessageElement.attrib["acNameAsCapitalisedUnderscores"])
            acMessgeCodeBlock += "    \"\"\"Public class definition of type s%s\n" % (objMessageElement.attrib["acNameAsCapitalisedUnderscores"])
            acMessgeCodeBlock += "    \"\"\"\n"
            acMessgeCodeBlock += "    def __init__(self):\n"
            acMessgeCodeBlock += "        super().__init__()\n"

            acMessgeCodeBlock += "        self.sMsgHeader = s%s_MESSAGE_HEADER()\n" % (dctMessageDictItem["objMessageElement"].attrib["acNameAsCapitalisedUnderscores"])

            # Only define a payload if the payload contain fields because in C++ an empty struct has a size of 1 byte which is not good for us
            if (objPayloadElement.attrib["bPayloadWithNoFields"] is False):
                acMessgeCodeBlock += "        self.sMsgPayload = s%s_PL()\n" % (objMessageElement.attrib["acNameAsCapitalisedUnderscores"])

            acMessgeCodeBlock += "        self.sMsgHeader.u2MsgLength.Value = self.iSizeBytes() - 2\n"

            # This attribute "acNameAsCapitalisedUnderscores" came from autogen_toolbox_definition_validation_and_et_finding.py methods lstFindMessageHeaderPairElementsFromMsgDefRootElement() and lstFindMessagePayloadPairElementsFromMsgDefRootElement()
            acMessgeCodeBlock += "\n"
            acMessgeCodeBlock += "        return\n"
            acMessgeCodeBlock += "\n"
            acMessgeCodeBlock += "\n"
            acMessgeCodeBlock += "vAddMessage(\"s%s\", s%s)\n" % (objMessageElement.attrib["acNameAsCapitalisedUnderscores"], objMessageElement.attrib["acNameAsCapitalisedUnderscores"])
            acMessgeCodeBlock += "\n"

            lstReturnMessageBlocks.append(acMessgeCodeBlock)

        return(lstReturnMessageBlocks)

    @staticmethod
    def acModInterConfGenerateClass(dctModInterConfDictItemPar: dict):
        """ This is a public static method which generates a class for the mod inter conf file

        Args:
            dctModInterConfDictItemPar (dict):
                * ["acFileNameAsCapUnderscores"] -> The filename as cap. underscores

        Returns:
            (str): A code block which contains a class

        Raises:
            Raises no exception.
        """
        acReturn = str("")
        acRole = str("")

        dctEnumCommsProtocolToStringLookup = {}
        dctEnumCommsProtocolToStringLookup[E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT)] = "E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT)"
        dctEnumCommsProtocolToStringLookup[E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_ZMQ)] = "E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_ZEROMQ)"

        dctEnumMessageFlowDirectionToStringLookup = {}
        dctEnumMessageFlowDirectionToStringLookup[E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH)] = "E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH)"
        dctEnumMessageFlowDirectionToStringLookup[E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE)] = "E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE)"

        acReturn += "from enum import Enum\n"
        acReturn += "\n"
        acReturn += "\n"
        acReturn += "class E_MESSAGE_FLOW_DIRECTION(Enum):\n"
        acReturn += "    MESSAGE_FLOW_DIRECTION_PUBLISH = 1\n"
        acReturn += "    MESSAGE_FLOW_DIRECTION_SUBSCRIBE = 2\n"
        acReturn += "\n"
        acReturn += "\n"
        acReturn += "class E_COMMS_PROTOCOL(Enum):\n"
        acReturn += "    COMMS_PROTOCOL_MQTT = 1\n"
        acReturn += "    COMMS_PROTOCOL_ZEROMQ = 2\n"
        acReturn += "\n"
        acReturn += "\n"
        acReturn += "class cls%s():\n" % (clsAutogenToolboxCodeGenerationPython.acCapUnderscoresToPascalCase(dctModInterConfDictItemPar["acFileNameAsCapUnderscores"]))
        acReturn += "    lstModInterConfTopicInfo = []\n"

        for dctTopicItem in dctModInterConfDictItemPar["lstFullTopicPartsForThisModConfInterface"]:

            # See if this messages has roles
            if (not dctTopicItem["lstRoles"]):
                acReturn += "    lstModInterConfTopicInfo.append({\"acSystem\": \"%s\", \"acModule\": \"%s\", \"acMessagename\": \"%s\", \"eCommsProtocol\": %s, \"eMessageFlowDirection\": %s, \"acRole\": \"\"})\n" % (dctTopicItem["acSystem"], dctTopicItem["acModule"], dctTopicItem["acMessageName"], dctEnumCommsProtocolToStringLookup[dctTopicItem["eCommsProtocol"]], dctEnumMessageFlowDirectionToStringLookup[dctTopicItem["eMessageFlowDirection"]])
            else:
                # If there are roles then we need to make unique topic using every role
                for acRole in dctTopicItem["lstRoles"]:
                    acReturn += "    lstModInterConfTopicInfo.append({\"acSystem\": \"%s\", \"acModule\": \"%s\", \"acMessagename\": \"%s\", \"eCommsProtocol\": %s, \"eMessageFlowDirection\": %s, \"acRole\": \"%s\"})\n" % (dctTopicItem["acSystem"], dctTopicItem["acModule"], dctTopicItem["acMessageName"], dctEnumCommsProtocolToStringLookup[dctTopicItem["eCommsProtocol"]], dctEnumMessageFlowDirectionToStringLookup[dctTopicItem["eMessageFlowDirection"]], acRole)

        return(acReturn)

    @staticmethod
    def lstMqttClientOnConnectImports(dctModInterConfDictItemPar: dict):
        """ This is a public static method which generates a list of imports for the Python MQTT client on connect class

        Args:
            dctModInterConfDictItemPar (dict):
                * ["sttRequiredMsgDefFilenames"] -> All the Msg Def XML need for the Mod Inter Conf file

        Returns:
            (list): All the MQTT messages we should subscribe to

        Raises:
            Raises no exception.

        """
        lstImports = []
        acImportSourceLine = str("")

        lstMsgDefXmlFiles = list(dctModInterConfDictItemPar["sttRequiredMsgDefFilenames"])

        for acSourceLine in lstMsgDefXmlFiles:
            acImportSourceLine = "from Autogen.%s import *" % (acSourceLine.replace(".xml", "").lower())
            lstImports.append(acImportSourceLine)

        return(lstImports)

    @staticmethod
    def lstMqttClientOnConnectMessages(dctModInterConfDictItemPar: dict):
        """ This is a public static method which generates a list of messages the MQTT client on connect class should subscribe

        Args:
            dctModInterConfDictItemPar (dict):
                * ["lstFullTopicPartsForThisModConfInterface"] -> All the topics in the Module Interface

        Returns:
            (list): All the MQTT messages we should subscribe to

        Raises:
            Raises no exception.
        """
        lstMessages = []
        dctMessage = {}

        lstFullTopicPartsForThisModConfInterface = dctModInterConfDictItemPar["lstFullTopicPartsForThisModConfInterface"]

        # Go through all the Mod Inter Conf topics and find all the MQTT subscribe messages
        # Iterate through all the topics
        for dctFullTopicPart in lstFullTopicPartsForThisModConfInterface:

            # We filter out only the messages which are MQTT and subscribed to
            if (dctFullTopicPart["eCommsProtocol"] == E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT) and dctFullTopicPart["eMessageFlowDirection"] == E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE)):

                if (not dctFullTopicPart["lstRoles"]):
                    dctMessage = {}
                    dctMessage["acMessageName"] = dctFullTopicPart["acMessageName"]
                    dctMessage["acMessageClassName"] = "s" + clsAutogenToolboxCodeGenerationPython.acPascalCaseToCapitalisedUnderscores(dctFullTopicPart["acMessageName"])
                    dctMessage["acFullTopic"] = dctFullTopicPart["acSystem"] + "/" + dctFullTopicPart["acModule"] + "/" + dctFullTopicPart["acMessageName"]
                    dctMessage["acReplyMsgFullTopic"] = dctFullTopicPart["acReplyMsgFullTopic"]
                    dctMessage["acReplyMsg"] = dctFullTopicPart["acReplyMsg"]
                    dctMessage["acReplyMsgClassName"] = "s" + clsAutogenToolboxCodeGenerationPython.acPascalCaseToCapitalisedUnderscores(dctFullTopicPart["acReplyMsg"])
                    dctMessage["acRole"] = str("")

                    lstMessages.append(dctMessage)
                else:
                    for acRole in dctFullTopicPart["lstRoles"]:
                        dctMessage = {}
                        dctMessage["acMessageName"] = dctFullTopicPart["acMessageName"]
                        dctMessage["acMessageClassName"] = "s" + clsAutogenToolboxCodeGenerationPython.acPascalCaseToCapitalisedUnderscores(dctFullTopicPart["acMessageName"])
                        dctMessage["acFullTopic"] = dctFullTopicPart["acSystem"] + "/" + dctFullTopicPart["acModule"] + "/" + dctFullTopicPart["acMessageName"] + "/" + acRole

                        # Only add the role to reply msg full topic is there is a topic
                        if (dctFullTopicPart["acReplyMsgFullTopic"]):
                            dctMessage["acReplyMsgFullTopic"] = dctFullTopicPart["acReplyMsgFullTopic"] + "/" + acRole
                        else:
                            dctMessage["acReplyMsgFullTopic"] = str("")

                        dctMessage["acReplyMsg"] = dctFullTopicPart["acReplyMsg"]
                        dctMessage["acReplyMsgClassName"] = "s" + clsAutogenToolboxCodeGenerationPython.acPascalCaseToCapitalisedUnderscores(dctFullTopicPart["acReplyMsg"])
                        dctMessage["acRole"] = acRole

                        lstMessages.append(dctMessage)

        return(lstMessages)

    @staticmethod
    def lstPythonAsyncioMessageProcessingImports(dctModInterConfDictItemPar: dict):
        """ This is a public static method which generates a list of imports for the Python asyncio message processing

        Args:
            dctModInterConfDictItemPar (dict):
                * ["sttRequiredMsgDefFilenames"] -> All the Msg Def XML need for the Mod Inter Conf file

        Returns:
            (list): All the imports

        Raises:
            Raises no exception.

        """
        lstImports = []
        acImportSourceLine = str("")

        lstMsgDefXmlFiles = list(dctModInterConfDictItemPar["sttRequiredMsgDefFilenames"])

        for acSourceLine in lstMsgDefXmlFiles:
            acImportSourceLine = "from Autogen.%s import *" % (acSourceLine.replace(".xml", "").lower())
            lstImports.append(acImportSourceLine)

        return(lstImports)

    @staticmethod
    def lstPythonAsyncioMessageProcessingMessages(dctPythonAsyncioMessageProcessingDictItemPar: dict):
        """ This is a public static method which generates a list of messages the MQTT client on connect class should subscribe

        Args:
            dctPythonAsyncioMessageProcessingDictItemPar (dict):
                * ["lstFullTopicPartsForThisModConfInterface"] -> All the topics in the Module Interface

        Returns:
            (list): All the MQTT messages we should subscribe to

        Raises:
            Raises no exception.
        """
        lstMessages = []

        lstFullTopicPartsForThisModConfInterface = dctPythonAsyncioMessageProcessingDictItemPar["lstFullTopicPartsForThisModConfInterface"]

        # Go through all the Mod Inter Conf topics and find all the MQTT subscribe messages
        # Iterate through all the topics
        for dctFullTopicPart in lstFullTopicPartsForThisModConfInterface:

            # We filter out only the messages which are MQTT and subscribed to
            if (dctFullTopicPart["eCommsProtocol"] == E_COMMS_PROTOCOL(E_COMMS_PROTOCOL.COMMS_PROTOCOL_MQTT)):

                if (not dctFullTopicPart["lstRoles"]):
                    dctMessage = {}
                    dctMessage["acMessageName"] = dctFullTopicPart["acMessageName"]
                    dctMessage["acMessageClassName"] = "s" + clsAutogenToolboxCodeGenerationPython.acPascalCaseToCapitalisedUnderscores(dctFullTopicPart["acMessageName"])
                    dctMessage["acFullTopic"] = dctFullTopicPart["acSystem"] + "/" + dctFullTopicPart["acModule"] + "/" + dctFullTopicPart["acMessageName"]
                    dctMessage["acReplyMsgFullTopic"] = dctFullTopicPart["acReplyMsgFullTopic"]
                    dctMessage["acReplyMsg"] = dctFullTopicPart["acReplyMsg"]
                    dctMessage["acReplyMsgClassName"] = "s" + clsAutogenToolboxCodeGenerationPython.acPascalCaseToCapitalisedUnderscores(dctFullTopicPart["acReplyMsg"])
                    dctMessage["acRole"] = str("")

                    lstMessages.append(dctMessage)
                else:
                    for acRole in dctFullTopicPart["lstRoles"]:
                        dctMessage = {}
                        dctMessage["acMessageName"] = dctFullTopicPart["acMessageName"]
                        dctMessage["acMessageClassName"] = "s" + clsAutogenToolboxCodeGenerationPython.acPascalCaseToCapitalisedUnderscores(dctFullTopicPart["acMessageName"])
                        dctMessage["acFullTopic"] = dctFullTopicPart["acSystem"] + "/" + dctFullTopicPart["acModule"] + "/" + dctFullTopicPart["acMessageName"] + "/" + acRole

                        # Only add the role to reply msg full topic is there is a topic
                        if (dctFullTopicPart["acReplyMsgFullTopic"]):
                            dctMessage["acReplyMsgFullTopic"] = dctFullTopicPart["acReplyMsgFullTopic"] + "/" + acRole
                        else:
                            dctMessage["acReplyMsgFullTopic"] = str("")

                        dctMessage["acReplyMsg"] = dctFullTopicPart["acReplyMsg"]
                        dctMessage["acReplyMsgClassName"] = "s" + clsAutogenToolboxCodeGenerationPython.acPascalCaseToCapitalisedUnderscores(dctFullTopicPart["acReplyMsg"])
                        dctMessage["acRole"] = acRole

                        lstMessages.append(dctMessage)

        return(lstMessages)

    @staticmethod
    def acPascalCaseToCapitalisedUnderscores(acStringPar: str):
        """ This is a public static method which converts Pascal case into capitalised underscores

        Args:
            acStringPar (str): The Pascal case string

        Returns:
            (str): The resultant capitalised underscores string

        Raises:
            Raises no exception.
        """
        acReturn = str("")
        lstTokens = []

        if (acStringPar is None):
            logging.error("acStringPar cannot be None")
            return(acReturn)

        if (isinstance(acStringPar, str) is False):
            logging.error("acStringPar is not a string")
            return(acReturn)

        if (not acStringPar):
            return(acReturn)

        try:
            lstTokens = re.sub('([A-Z][a-z]+)', r' \1', re.sub('([A-Z]+)', r' \1', acStringPar)).split()
        except Exception as E:
            logging.error("Could not split string %s - Exception %s", acStringPar, str(E))
            return(acReturn)

        acReturn = str("")
        for acToken in lstTokens:
            acReturn += acToken.upper() + "_"

        acReturn = acReturn[:-1]

        return(acReturn)
