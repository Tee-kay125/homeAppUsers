#!/bin/bash

sudo systemctl stop mosquitto