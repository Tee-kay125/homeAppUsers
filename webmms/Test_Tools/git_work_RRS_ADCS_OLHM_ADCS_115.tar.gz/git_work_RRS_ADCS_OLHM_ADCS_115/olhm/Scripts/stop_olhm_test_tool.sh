#!/bin/bash

kill $(pgrep -f ott.py)