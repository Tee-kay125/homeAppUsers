#!/bin/bash

sudo systemctl start mosquitto