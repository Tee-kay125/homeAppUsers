#!/bin/bash

cd ../OLHM_Test_Tool/Source
./generate.sh
cd ../../OLHM/Source
./generate.sh

