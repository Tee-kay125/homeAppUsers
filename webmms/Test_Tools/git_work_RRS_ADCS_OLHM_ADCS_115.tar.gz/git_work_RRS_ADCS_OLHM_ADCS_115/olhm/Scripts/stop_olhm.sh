#!/bin/bash

kill $(pgrep -f olhm.py)