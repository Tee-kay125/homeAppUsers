#!/bin/bash

cd ../OLHM/Source
./olhm.py