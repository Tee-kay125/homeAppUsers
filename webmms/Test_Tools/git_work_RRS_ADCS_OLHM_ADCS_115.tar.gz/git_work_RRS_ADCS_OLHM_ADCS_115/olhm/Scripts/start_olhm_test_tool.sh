#!/bin/bash

cd ../OLHM_Test_Tool/Source
./ott.py -i config.ini