#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module tests the transition rules classes


Todo:

"""
import unittest
import logging
from olhm_transition_rules import clsOlhmTransitionRules


class clsTransitionRulesAssertTesting(unittest.TestCase):
    """ This is the transtion rules unit testing class

    Args:

    """

    def tplTransitionRulesAssert(self) -> bool:
        """ This is a public static method which does some autogen tests.

        Args:

        Returns:
            tuple:
              * (bool) Boolean value which indicates if the method was successful or not.
              * (str) String which contains test report output as text

        Raises:
            Raises no exceptions
        """
        acTestReportOutput = str("")
        bAllTestPassed = bool(True)
        bUnitTestReturn = bool(False)  # This property is used by all unit tests
        tplReturn = (bAllTestPassed, acTestReportOutput)

        # Test 0000
        acTestReportOutput += "Test:   [Expected Behaviour] clsOlhmTransitionRules::bAreSelectedSubunitsASpecificState\t(All are INITIALISE) "

        dctSubUnits = {}
        dctSubUnits["dctDR"] = {}
        dctSubUnits["dctDR"]["objClsDrTransitionsManager"] = clsTestClass()
        dctSubUnits["dctDR"]["objClsDrTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctPDBP"] = {}
        dctSubUnits["dctPDBP"]["objClsPdbpTransitionsManager"] = clsTestClass()
        dctSubUnits["dctPDBP"]["objClsPdbpTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctEIU"] = {}
        dctSubUnits["dctEIU"]["objClsEiuTransitionsManager"] = clsTestClass()
        dctSubUnits["dctEIU"]["objClsEiuTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctTM"] = {}
        dctSubUnits["dctTM"]["objClsTmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctTM"]["objClsTmTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctTEWA"] = {}
        dctSubUnits["dctTEWA"]["objClsTewaTransitionsManager"] = clsTestClass()
        dctSubUnits["dctTEWA"]["objClsTewaTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctSF1"] = {}
        dctSubUnits["dctSF1"]["objClsSf1TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF1"]["objClsSf1TransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctSF2"] = {}
        dctSubUnits["dctSF2"]["objClsSf2TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF2"]["objClsSf2TransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctSF3"] = {}
        dctSubUnits["dctSF3"]["objClsSf3TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF3"]["objClsSf3TransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctHMIAPM"] = {}
        dctSubUnits["dctHMIAPM"]["objClsHmiApmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIAPM"]["objClsHmiApmTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctHMIAPMFCO"] = {}
        dctSubUnits["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctHMIFCO"] = {}
        dctSubUnits["dctHMIFCO"]["objClsHmiFcoTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctHMISPM"] = {}
        dctSubUnits["dctHMISPM"]["objClsHmiSpmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMISPM"]["objClsHmiSpmTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctHMISPMFUFC"] = {}
        dctSubUnits["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctHMIFUFC"] = {}
        dctSubUnits["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctHMIOversight"] = {}
        dctSubUnits["dctHMIOversight"]["objClsHmiOversightTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIOversight"]["objClsHmiOversightTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctHMIMaintainer"] = {}
        dctSubUnits["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"].state = "INITIALISE"

        dctModuleNameToDictKeyLookups = {}
        dctModuleNameToDictKeyLookups["DR"] = ("dctDR", "objClsDrTransitionsManager")
        dctModuleNameToDictKeyLookups["PDBP"] = ("dctPDBP", "objClsPdbpTransitionsManager")
        dctModuleNameToDictKeyLookups["EIU"] = ("dctEIU", "objClsEiuTransitionsManager")
        dctModuleNameToDictKeyLookups["TM"] = ("dctTM", "objClsTmTransitionsManager")
        dctModuleNameToDictKeyLookups["TEWA"] = ("dctTEWA", "objClsTewaTransitionsManager")
        dctModuleNameToDictKeyLookups["SF1"] = ("dctSF1", "objClsSf1TransitionsManager")
        dctModuleNameToDictKeyLookups["SF2"] = ("dctSF2", "objClsSf2TransitionsManager")
        dctModuleNameToDictKeyLookups["SF3"] = ("dctSF3", "objClsSf3TransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_APM"] = ("dctHMIAPM", "objClsHmiApmTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_APM_FCO"] = ("dctHMIAPMFCO", "objClsHmiApmFcoTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_FCO"] = ("dctHMIFCO", "objClsHmiFcoTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_SPM"] = ("dctHMISPM", "objClsHmiSpmTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_SPM_FUFC"] = ("dctHMISPMFUFC", "objClsHmiSpmFufcTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_FUFC"] = ("dctHMIFUFC", "objClsHmiFufcTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_Maintainer"] = ("dctHMIMaintainer", "objClsHmiMaintainerTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_Oversight"] = ("dctHMIOversight", "objClsHmiOversightTransitionsManager")

        lstSelectedModules = []
        lstSelectedModules.append("DR")
        lstSelectedModules.append("PDBP")
        lstSelectedModules.append("EIU")
        lstSelectedModules.append("TM")
        lstSelectedModules.append("TEWA")
        lstSelectedModules.append("SF1")
        lstSelectedModules.append("SF2")
        lstSelectedModules.append("SF3")
        lstSelectedModules.append("HMI_APM")
        lstSelectedModules.append("HMI_APM_FCO")
        lstSelectedModules.append("HMI_FCO")
        lstSelectedModules.append("HMI_SPM")
        lstSelectedModules.append("HMI_SPM_FUFC")
        lstSelectedModules.append("HMI_FUFC")
        lstSelectedModules.append("HMI_Maintainer")
        lstSelectedModules.append("HMI_Oversight")

        try:
            self.assertEqual(clsOlhmTransitionRules.bAreSelectedSubunitsASpecificState(dctSubUnits, dctModuleNameToDictKeyLookups, lstSelectedModules, "INITIALISE"), True)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\tPASS ---- with feedback returned: 'Modules are all INITIALISE'\n"
        except Exception as E:  # noqa: F841  # pylint: disable=unused-variable
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\tFAILED ---- with feedback returned: 'Modules are not all INITIALISE'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0001
        acTestReportOutput += "Test:   [Expected Behaviour] clsOlhmTransitionRules::bAreSelectedSubunitsASpecificState\t(All are OPERATIONAL) "

        dctSubUnits = {}
        dctSubUnits["dctDR"] = {}
        dctSubUnits["dctDR"]["objClsDrTransitionsManager"] = clsTestClass()
        dctSubUnits["dctDR"]["objClsDrTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctPDBP"] = {}
        dctSubUnits["dctPDBP"]["objClsPdbpTransitionsManager"] = clsTestClass()
        dctSubUnits["dctPDBP"]["objClsPdbpTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctEIU"] = {}
        dctSubUnits["dctEIU"]["objClsEiuTransitionsManager"] = clsTestClass()
        dctSubUnits["dctEIU"]["objClsEiuTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctTM"] = {}
        dctSubUnits["dctTM"]["objClsTmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctTM"]["objClsTmTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctTEWA"] = {}
        dctSubUnits["dctTEWA"]["objClsTewaTransitionsManager"] = clsTestClass()
        dctSubUnits["dctTEWA"]["objClsTewaTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctSF1"] = {}
        dctSubUnits["dctSF1"]["objClsSf1TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF1"]["objClsSf1TransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctSF2"] = {}
        dctSubUnits["dctSF2"]["objClsSf2TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF2"]["objClsSf2TransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctSF3"] = {}
        dctSubUnits["dctSF3"]["objClsSf3TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF3"]["objClsSf3TransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctHMIAPM"] = {}
        dctSubUnits["dctHMIAPM"]["objClsHmiApmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIAPM"]["objClsHmiApmTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMIAPMFCO"] = {}
        dctSubUnits["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMIFCO"] = {}
        dctSubUnits["dctHMIFCO"]["objClsHmiFcoTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMISPM"] = {}
        dctSubUnits["dctHMISPM"]["objClsHmiSpmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMISPM"]["objClsHmiSpmTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMISPMFUFC"] = {}
        dctSubUnits["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMIFUFC"] = {}
        dctSubUnits["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMIOversight"] = {}
        dctSubUnits["dctHMIOversight"]["objClsHmiOversightTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIOversight"]["objClsHmiOversightTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMIMaintainer"] = {}
        dctSubUnits["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"].state = "FAILED"

        dctModuleNameToDictKeyLookups = {}
        dctModuleNameToDictKeyLookups["DR"] = ("dctDR", "objClsDrTransitionsManager")
        dctModuleNameToDictKeyLookups["PDBP"] = ("dctPDBP", "objClsPdbpTransitionsManager")
        dctModuleNameToDictKeyLookups["EIU"] = ("dctEIU", "objClsEiuTransitionsManager")
        dctModuleNameToDictKeyLookups["TM"] = ("dctTM", "objClsTmTransitionsManager")
        dctModuleNameToDictKeyLookups["TEWA"] = ("dctTEWA", "objClsTewaTransitionsManager")
        dctModuleNameToDictKeyLookups["SF1"] = ("dctSF1", "objClsSf1TransitionsManager")
        dctModuleNameToDictKeyLookups["SF2"] = ("dctSF2", "objClsSf2TransitionsManager")
        dctModuleNameToDictKeyLookups["SF3"] = ("dctSF3", "objClsSf3TransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_APM"] = ("dctHMIAPM", "objClsHmiApmTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_APM_FCO"] = ("dctHMIAPMFCO", "objClsHmiApmFcoTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_FCO"] = ("dctHMIFCO", "objClsHmiFcoTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_SPM"] = ("dctHMISPM", "objClsHmiSpmTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_SPM_FUFC"] = ("dctHMISPMFUFC", "objClsHmiSpmFufcTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_FUFC"] = ("dctHMIFUFC", "objClsHmiFufcTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_Maintainer"] = ("dctHMIMaintainer", "objClsHmiMaintainerTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_Oversight"] = ("dctHMIOversight", "objClsHmiOversightTransitionsManager")

        lstSelectedModules = []
        lstSelectedModules.append("DR")
        lstSelectedModules.append("PDBP")
        lstSelectedModules.append("EIU")
        lstSelectedModules.append("TM")
        lstSelectedModules.append("TEWA")
        lstSelectedModules.append("SF1")
        lstSelectedModules.append("SF2")
        lstSelectedModules.append("SF3")

        try:
            self.assertEqual(clsOlhmTransitionRules.bAreSelectedSubunitsASpecificState(dctSubUnits, dctModuleNameToDictKeyLookups, lstSelectedModules, "OPERATIONAL"), True)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\tPASS ---- with feedback returned: 'Modules are all OPERATIONAL'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\tFAILED ---- with feedback returned: 'Modules are not all OPERATIONAL'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0002
        acTestReportOutput += "Test:   [Expected Behaviour] clsOlhmTransitionRules::bAreSelectedSubunitsASpecificState\t(All are OPERATIONAL) "

        dctSubUnits = {}
        dctSubUnits["dctDR"] = {}
        dctSubUnits["dctDR"]["objClsDrTransitionsManager"] = clsTestClass()
        dctSubUnits["dctDR"]["objClsDrTransitionsManager"].state = "FAILED"
        dctSubUnits["dctPDBP"] = {}
        dctSubUnits["dctPDBP"]["objClsPdbpTransitionsManager"] = clsTestClass()
        dctSubUnits["dctPDBP"]["objClsPdbpTransitionsManager"].state = "FAILED"
        dctSubUnits["dctEIU"] = {}
        dctSubUnits["dctEIU"]["objClsEiuTransitionsManager"] = clsTestClass()
        dctSubUnits["dctEIU"]["objClsEiuTransitionsManager"].state = "FAILED"
        dctSubUnits["dctTM"] = {}
        dctSubUnits["dctTM"]["objClsTmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctTM"]["objClsTmTransitionsManager"].state = "FAILED"
        dctSubUnits["dctTEWA"] = {}
        dctSubUnits["dctTEWA"]["objClsTewaTransitionsManager"] = clsTestClass()
        dctSubUnits["dctTEWA"]["objClsTewaTransitionsManager"].state = "FAILED"
        dctSubUnits["dctSF1"] = {}
        dctSubUnits["dctSF1"]["objClsSf1TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF1"]["objClsSf1TransitionsManager"].state = "FAILED"
        dctSubUnits["dctSF2"] = {}
        dctSubUnits["dctSF2"]["objClsSf2TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF2"]["objClsSf2TransitionsManager"].state = "FAILED"
        dctSubUnits["dctSF3"] = {}
        dctSubUnits["dctSF3"]["objClsSf3TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF3"]["objClsSf3TransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMIAPM"] = {}
        dctSubUnits["dctHMIAPM"]["objClsHmiApmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIAPM"]["objClsHmiApmTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctHMIAPMFCO"] = {}
        dctSubUnits["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctHMIFCO"] = {}
        dctSubUnits["dctHMIFCO"]["objClsHmiFcoTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctHMISPM"] = {}
        dctSubUnits["dctHMISPM"]["objClsHmiSpmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMISPM"]["objClsHmiSpmTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctHMISPMFUFC"] = {}
        dctSubUnits["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctHMIFUFC"] = {}
        dctSubUnits["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctHMIOversight"] = {}
        dctSubUnits["dctHMIOversight"]["objClsHmiOversightTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIOversight"]["objClsHmiOversightTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctHMIMaintainer"] = {}
        dctSubUnits["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"].state = "OPERATIONAL"

        dctModuleNameToDictKeyLookups = {}
        dctModuleNameToDictKeyLookups["DR"] = ("dctDR", "objClsDrTransitionsManager")
        dctModuleNameToDictKeyLookups["PDBP"] = ("dctPDBP", "objClsPdbpTransitionsManager")
        dctModuleNameToDictKeyLookups["EIU"] = ("dctEIU", "objClsEiuTransitionsManager")
        dctModuleNameToDictKeyLookups["TM"] = ("dctTM", "objClsTmTransitionsManager")
        dctModuleNameToDictKeyLookups["TEWA"] = ("dctTEWA", "objClsTewaTransitionsManager")
        dctModuleNameToDictKeyLookups["SF1"] = ("dctSF1", "objClsSf1TransitionsManager")
        dctModuleNameToDictKeyLookups["SF2"] = ("dctSF2", "objClsSf2TransitionsManager")
        dctModuleNameToDictKeyLookups["SF3"] = ("dctSF3", "objClsSf3TransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_APM"] = ("dctHMIAPM", "objClsHmiApmTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_APM_FCO"] = ("dctHMIAPMFCO", "objClsHmiApmFcoTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_FCO"] = ("dctHMIFCO", "objClsHmiFcoTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_SPM"] = ("dctHMISPM", "objClsHmiSpmTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_SPM_FUFC"] = ("dctHMISPMFUFC", "objClsHmiSpmFufcTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_FUFC"] = ("dctHMIFUFC", "objClsHmiFufcTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_Maintainer"] = ("dctHMIMaintainer", "objClsHmiMaintainerTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_Oversight"] = ("dctHMIOversight", "objClsHmiOversightTransitionsManager")

        lstSelectedModules = []
        lstSelectedModules.append("HMI_APM")
        lstSelectedModules.append("HMI_APM_FCO")
        lstSelectedModules.append("HMI_FCO")
        lstSelectedModules.append("HMI_SPM")
        lstSelectedModules.append("HMI_SPM_FUFC")
        lstSelectedModules.append("HMI_FUFC")
        lstSelectedModules.append("HMI_Maintainer")
        lstSelectedModules.append("HMI_Oversight")

        try:
            self.assertEqual(clsOlhmTransitionRules.bAreSelectedSubunitsASpecificState(dctSubUnits, dctModuleNameToDictKeyLookups, lstSelectedModules, "OPERATIONAL"), True)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\tPASS ---- with feedback returned: 'Modules are all OPERATIONAL'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\tFAILED ---- with feedback returned: 'Modules are not all OPERATIONAL'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0003
        acTestReportOutput += "Test:   [Expected Behaviour] clsOlhmTransitionRules::bAreSelectedSubunitsASpecificState\t(All are SHUTDOWN) "

        dctSubUnits = {}
        dctSubUnits["dctDR"] = {}
        dctSubUnits["dctDR"]["objClsDrTransitionsManager"] = clsTestClass()
        dctSubUnits["dctDR"]["objClsDrTransitionsManager"].state = "SHUTDOWN"
        dctSubUnits["dctPDBP"] = {}
        dctSubUnits["dctPDBP"]["objClsPdbpTransitionsManager"] = clsTestClass()
        dctSubUnits["dctPDBP"]["objClsPdbpTransitionsManager"].state = "SHUTDOWN"
        dctSubUnits["dctEIU"] = {}
        dctSubUnits["dctEIU"]["objClsEiuTransitionsManager"] = clsTestClass()
        dctSubUnits["dctEIU"]["objClsEiuTransitionsManager"].state = "SHUTDOWN"
        dctSubUnits["dctTM"] = {}
        dctSubUnits["dctTM"]["objClsTmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctTM"]["objClsTmTransitionsManager"].state = "SHUTDOWN"
        dctSubUnits["dctTEWA"] = {}
        dctSubUnits["dctTEWA"]["objClsTewaTransitionsManager"] = clsTestClass()
        dctSubUnits["dctTEWA"]["objClsTewaTransitionsManager"].state = "SHUTDOWN"
        dctSubUnits["dctSF1"] = {}
        dctSubUnits["dctSF1"]["objClsSf1TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF1"]["objClsSf1TransitionsManager"].state = "SHUTDOWN"
        dctSubUnits["dctSF2"] = {}
        dctSubUnits["dctSF2"]["objClsSf2TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF2"]["objClsSf2TransitionsManager"].state = "SHUTDOWN"
        dctSubUnits["dctSF3"] = {}
        dctSubUnits["dctSF3"]["objClsSf3TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF3"]["objClsSf3TransitionsManager"].state = "SHUTDOWN"
        dctSubUnits["dctHMIAPM"] = {}
        dctSubUnits["dctHMIAPM"]["objClsHmiApmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIAPM"]["objClsHmiApmTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMIAPMFCO"] = {}
        dctSubUnits["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMIFCO"] = {}
        dctSubUnits["dctHMIFCO"]["objClsHmiFcoTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMISPM"] = {}
        dctSubUnits["dctHMISPM"]["objClsHmiSpmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMISPM"]["objClsHmiSpmTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMISPMFUFC"] = {}
        dctSubUnits["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMIFUFC"] = {}
        dctSubUnits["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMIOversight"] = {}
        dctSubUnits["dctHMIOversight"]["objClsHmiOversightTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIOversight"]["objClsHmiOversightTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMIMaintainer"] = {}
        dctSubUnits["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"].state = "FAILED"

        dctModuleNameToDictKeyLookups = {}
        dctModuleNameToDictKeyLookups["DR"] = ("dctDR", "objClsDrTransitionsManager")
        dctModuleNameToDictKeyLookups["PDBP"] = ("dctPDBP", "objClsPdbpTransitionsManager")
        dctModuleNameToDictKeyLookups["EIU"] = ("dctEIU", "objClsEiuTransitionsManager")
        dctModuleNameToDictKeyLookups["TM"] = ("dctTM", "objClsTmTransitionsManager")
        dctModuleNameToDictKeyLookups["TEWA"] = ("dctTEWA", "objClsTewaTransitionsManager")
        dctModuleNameToDictKeyLookups["SF1"] = ("dctSF1", "objClsSf1TransitionsManager")
        dctModuleNameToDictKeyLookups["SF2"] = ("dctSF2", "objClsSf2TransitionsManager")
        dctModuleNameToDictKeyLookups["SF3"] = ("dctSF3", "objClsSf3TransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_APM"] = ("dctHMIAPM", "objClsHmiApmTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_APM_FCO"] = ("dctHMIAPMFCO", "objClsHmiApmFcoTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_FCO"] = ("dctHMIFCO", "objClsHmiFcoTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_SPM"] = ("dctHMISPM", "objClsHmiSpmTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_SPM_FUFC"] = ("dctHMISPMFUFC", "objClsHmiSpmFufcTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_FUFC"] = ("dctHMIFUFC", "objClsHmiFufcTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_Maintainer"] = ("dctHMIMaintainer", "objClsHmiMaintainerTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_Oversight"] = ("dctHMIOversight", "objClsHmiOversightTransitionsManager")

        lstSelectedModules = []
        lstSelectedModules.append("DR")
        lstSelectedModules.append("PDBP")
        lstSelectedModules.append("EIU")
        lstSelectedModules.append("TM")
        lstSelectedModules.append("TEWA")
        lstSelectedModules.append("SF1")
        lstSelectedModules.append("SF2")
        lstSelectedModules.append("SF3")

        try:
            self.assertEqual(clsOlhmTransitionRules.bAreSelectedSubunitsASpecificState(dctSubUnits, dctModuleNameToDictKeyLookups, lstSelectedModules, "SHUTDOWN"), True)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\tPASS ---- with feedback returned: 'Modules are all SHUTDOWN'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\tFAILED ---- with feedback returned: 'Modules are not all SHUTDOWN'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0004
        acTestReportOutput += "Test:   [Defensive Behaviour] clsOlhmTransitionRules::bAreSelectedSubunitsASpecificState (Not all are OPERATIONAL) "

        dctSubUnits = {}
        dctSubUnits["dctDR"] = {}
        dctSubUnits["dctDR"]["objClsDrTransitionsManager"] = clsTestClass()
        dctSubUnits["dctDR"]["objClsDrTransitionsManager"].state = "READY"
        dctSubUnits["dctPDBP"] = {}
        dctSubUnits["dctPDBP"]["objClsPdbpTransitionsManager"] = clsTestClass()
        dctSubUnits["dctPDBP"]["objClsPdbpTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctEIU"] = {}
        dctSubUnits["dctEIU"]["objClsEiuTransitionsManager"] = clsTestClass()
        dctSubUnits["dctEIU"]["objClsEiuTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctTM"] = {}
        dctSubUnits["dctTM"]["objClsTmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctTM"]["objClsTmTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctTEWA"] = {}
        dctSubUnits["dctTEWA"]["objClsTewaTransitionsManager"] = clsTestClass()
        dctSubUnits["dctTEWA"]["objClsTewaTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctSF1"] = {}
        dctSubUnits["dctSF1"]["objClsSf1TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF1"]["objClsSf1TransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctSF2"] = {}
        dctSubUnits["dctSF2"]["objClsSf2TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF2"]["objClsSf2TransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctSF3"] = {}
        dctSubUnits["dctSF3"]["objClsSf3TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF3"]["objClsSf3TransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctHMIAPM"] = {}
        dctSubUnits["dctHMIAPM"]["objClsHmiApmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIAPM"]["objClsHmiApmTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctHMIAPMFCO"] = {}
        dctSubUnits["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctHMIFCO"] = {}
        dctSubUnits["dctHMIFCO"]["objClsHmiFcoTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctHMISPM"] = {}
        dctSubUnits["dctHMISPM"]["objClsHmiSpmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMISPM"]["objClsHmiSpmTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctHMISPMFUFC"] = {}
        dctSubUnits["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctHMIFUFC"] = {}
        dctSubUnits["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctHMIOversight"] = {}
        dctSubUnits["dctHMIOversight"]["objClsHmiOversightTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIOversight"]["objClsHmiOversightTransitionsManager"].state = "OPERATIONAL"
        dctSubUnits["dctHMIMaintainer"] = {}
        dctSubUnits["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"].state = "OPERATIONAL"

        dctModuleNameToDictKeyLookups = {}
        dctModuleNameToDictKeyLookups["DR"] = ("dctDR", "objClsDrTransitionsManager")
        dctModuleNameToDictKeyLookups["PDBP"] = ("dctPDBP", "objClsPdbpTransitionsManager")
        dctModuleNameToDictKeyLookups["EIU"] = ("dctEIU", "objClsEiuTransitionsManager")
        dctModuleNameToDictKeyLookups["TM"] = ("dctTM", "objClsTmTransitionsManager")
        dctModuleNameToDictKeyLookups["TEWA"] = ("dctTEWA", "objClsTewaTransitionsManager")
        dctModuleNameToDictKeyLookups["SF1"] = ("dctSF1", "objClsSf1TransitionsManager")
        dctModuleNameToDictKeyLookups["SF2"] = ("dctSF2", "objClsSf2TransitionsManager")
        dctModuleNameToDictKeyLookups["SF3"] = ("dctSF3", "objClsSf3TransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_APM"] = ("dctHMIAPM", "objClsHmiApmTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_APM_FCO"] = ("dctHMIAPMFCO", "objClsHmiApmFcoTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_FCO"] = ("dctHMIFCO", "objClsHmiFcoTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_SPM"] = ("dctHMISPM", "objClsHmiSpmTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_SPM_FUFC"] = ("dctHMISPMFUFC", "objClsHmiSpmFufcTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_FUFC"] = ("dctHMIFUFC", "objClsHmiFufcTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_Maintainer"] = ("dctHMIMaintainer", "objClsHmiMaintainerTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_Oversight"] = ("dctHMIOversight", "objClsHmiOversightTransitionsManager")

        lstSelectedModules = []
        lstSelectedModules.append("DR")
        lstSelectedModules.append("PDBP")
        lstSelectedModules.append("EIU")
        lstSelectedModules.append("TM")
        lstSelectedModules.append("TEWA")
        lstSelectedModules.append("SF1")
        lstSelectedModules.append("SF2")
        lstSelectedModules.append("SF3")
        lstSelectedModules.append("HMI_APM")
        lstSelectedModules.append("HMI_APM_FCO")
        lstSelectedModules.append("HMI_FCO")
        lstSelectedModules.append("HMI_SPM")
        lstSelectedModules.append("HMI_SPM_FUFC")
        lstSelectedModules.append("HMI_FUFC")
        lstSelectedModules.append("HMI_Maintainer")
        lstSelectedModules.append("HMI_Oversight")

        try:
            self.assertEqual(clsOlhmTransitionRules.bAreSelectedSubunitsASpecificState(dctSubUnits, dctModuleNameToDictKeyLookups, lstSelectedModules, "OPERATIONAL"), False)
            bUnitTestReturn = True
            acTestReportOutput += "\t\tPASS ---- with feedback returned: 'Modules are not all OPERATIONAL'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\tFAILED ---- with feedback returned: 'Modules are all OPERATIONAL'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0005
        acTestReportOutput += "Test:   [Defensive Behaviour] clsOlhmTransitionRules::bAreSelectedSubunitsASpecificState (Not all are READY) "

        dctSubUnits = {}
        dctSubUnits["dctDR"] = {}
        dctSubUnits["dctDR"]["objClsDrTransitionsManager"] = clsTestClass()
        dctSubUnits["dctDR"]["objClsDrTransitionsManager"].state = "READY"
        dctSubUnits["dctPDBP"] = {}
        dctSubUnits["dctPDBP"]["objClsPdbpTransitionsManager"] = clsTestClass()
        dctSubUnits["dctPDBP"]["objClsPdbpTransitionsManager"].state = "READY"
        dctSubUnits["dctEIU"] = {}
        dctSubUnits["dctEIU"]["objClsEiuTransitionsManager"] = clsTestClass()
        dctSubUnits["dctEIU"]["objClsEiuTransitionsManager"].state = "READY"
        dctSubUnits["dctTM"] = {}
        dctSubUnits["dctTM"]["objClsTmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctTM"]["objClsTmTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctTEWA"] = {}
        dctSubUnits["dctTEWA"]["objClsTewaTransitionsManager"] = clsTestClass()
        dctSubUnits["dctTEWA"]["objClsTewaTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctSF1"] = {}
        dctSubUnits["dctSF1"]["objClsSf1TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF1"]["objClsSf1TransitionsManager"].state = "READY"
        dctSubUnits["dctSF2"] = {}
        dctSubUnits["dctSF2"]["objClsSf2TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF2"]["objClsSf2TransitionsManager"].state = "READY"
        dctSubUnits["dctSF3"] = {}
        dctSubUnits["dctSF3"]["objClsSf3TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF3"]["objClsSf3TransitionsManager"].state = "READY"
        dctSubUnits["dctHMIAPM"] = {}
        dctSubUnits["dctHMIAPM"]["objClsHmiApmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIAPM"]["objClsHmiApmTransitionsManager"].state = "READY"
        dctSubUnits["dctHMIAPMFCO"] = {}
        dctSubUnits["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"].state = "READY"
        dctSubUnits["dctHMIFCO"] = {}
        dctSubUnits["dctHMIFCO"]["objClsHmiFcoTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].state = "READY"
        dctSubUnits["dctHMISPM"] = {}
        dctSubUnits["dctHMISPM"]["objClsHmiSpmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMISPM"]["objClsHmiSpmTransitionsManager"].state = "READY"
        dctSubUnits["dctHMISPMFUFC"] = {}
        dctSubUnits["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"].state = "READY"
        dctSubUnits["dctHMIFUFC"] = {}
        dctSubUnits["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"].state = "READY"
        dctSubUnits["dctHMIOversight"] = {}
        dctSubUnits["dctHMIOversight"]["objClsHmiOversightTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIOversight"]["objClsHmiOversightTransitionsManager"].state = "READY"
        dctSubUnits["dctHMIMaintainer"] = {}
        dctSubUnits["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"].state = "READY"

        dctModuleNameToDictKeyLookups = {}
        dctModuleNameToDictKeyLookups["DR"] = ("dctDR", "objClsDrTransitionsManager")
        dctModuleNameToDictKeyLookups["PDBP"] = ("dctPDBP", "objClsPdbpTransitionsManager")
        dctModuleNameToDictKeyLookups["EIU"] = ("dctEIU", "objClsEiuTransitionsManager")
        dctModuleNameToDictKeyLookups["TM"] = ("dctTM", "objClsTmTransitionsManager")
        dctModuleNameToDictKeyLookups["TEWA"] = ("dctTEWA", "objClsTewaTransitionsManager")
        dctModuleNameToDictKeyLookups["SF1"] = ("dctSF1", "objClsSf1TransitionsManager")
        dctModuleNameToDictKeyLookups["SF2"] = ("dctSF2", "objClsSf2TransitionsManager")
        dctModuleNameToDictKeyLookups["SF3"] = ("dctSF3", "objClsSf3TransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_APM"] = ("dctHMIAPM", "objClsHmiApmTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_APM_FCO"] = ("dctHMIAPMFCO", "objClsHmiApmFcoTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_FCO"] = ("dctHMIFCO", "objClsHmiFcoTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_SPM"] = ("dctHMISPM", "objClsHmiSpmTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_SPM_FUFC"] = ("dctHMISPMFUFC", "objClsHmiSpmFufcTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_FUFC"] = ("dctHMIFUFC", "objClsHmiFufcTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_Maintainer"] = ("dctHMIMaintainer", "objClsHmiMaintainerTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_Oversight"] = ("dctHMIOversight", "objClsHmiOversightTransitionsManager")

        lstSelectedModules = []
        lstSelectedModules.append("DR")
        lstSelectedModules.append("PDBP")
        lstSelectedModules.append("EIU")
        lstSelectedModules.append("TM")
        lstSelectedModules.append("TEWA")
        lstSelectedModules.append("SF1")
        lstSelectedModules.append("SF2")
        lstSelectedModules.append("SF3")

        try:
            self.assertEqual(clsOlhmTransitionRules.bAreSelectedSubunitsASpecificState(dctSubUnits, dctModuleNameToDictKeyLookups, lstSelectedModules, "READY"), False)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\tPASS ---- with feedback returned: 'Modules are not all READY'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\tFAILED ---- with feedback returned: 'Modules are all READY'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0006
        acTestReportOutput += "Test:   [Defensive Behaviour] clsOlhmTransitionRules::bAreSelectedSubunitsASpecificState (Not all are INITIALISE) "

        dctSubUnits = {}
        dctSubUnits["dctDR"] = {}
        dctSubUnits["dctDR"]["objClsDrTransitionsManager"] = clsTestClass()
        dctSubUnits["dctDR"]["objClsDrTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctPDBP"] = {}
        dctSubUnits["dctPDBP"]["objClsPdbpTransitionsManager"] = clsTestClass()
        dctSubUnits["dctPDBP"]["objClsPdbpTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctEIU"] = {}
        dctSubUnits["dctEIU"]["objClsEiuTransitionsManager"] = clsTestClass()
        dctSubUnits["dctEIU"]["objClsEiuTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctTM"] = {}
        dctSubUnits["dctTM"]["objClsTmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctTM"]["objClsTmTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctTEWA"] = {}
        dctSubUnits["dctTEWA"]["objClsTewaTransitionsManager"] = clsTestClass()
        dctSubUnits["dctTEWA"]["objClsTewaTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctSF1"] = {}
        dctSubUnits["dctSF1"]["objClsSf1TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF1"]["objClsSf1TransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctSF2"] = {}
        dctSubUnits["dctSF2"]["objClsSf2TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF2"]["objClsSf2TransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctSF3"] = {}
        dctSubUnits["dctSF3"]["objClsSf3TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF3"]["objClsSf3TransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctHMIAPM"] = {}
        dctSubUnits["dctHMIAPM"]["objClsHmiApmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIAPM"]["objClsHmiApmTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctHMIAPMFCO"] = {}
        dctSubUnits["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctHMIFCO"] = {}
        dctSubUnits["dctHMIFCO"]["objClsHmiFcoTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctHMISPM"] = {}
        dctSubUnits["dctHMISPM"]["objClsHmiSpmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMISPM"]["objClsHmiSpmTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctHMISPMFUFC"] = {}
        dctSubUnits["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctHMIFUFC"] = {}
        dctSubUnits["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctHMIOversight"] = {}
        dctSubUnits["dctHMIOversight"]["objClsHmiOversightTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIOversight"]["objClsHmiOversightTransitionsManager"].state = "INITIALISE"
        dctSubUnits["dctHMIMaintainer"] = {}
        dctSubUnits["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"].state = "FAILED"

        dctModuleNameToDictKeyLookups = {}
        dctModuleNameToDictKeyLookups["DR"] = ("dctDR", "objClsDrTransitionsManager")
        dctModuleNameToDictKeyLookups["PDBP"] = ("dctPDBP", "objClsPdbpTransitionsManager")
        dctModuleNameToDictKeyLookups["EIU"] = ("dctEIU", "objClsEiuTransitionsManager")
        dctModuleNameToDictKeyLookups["TM"] = ("dctTM", "objClsTmTransitionsManager")
        dctModuleNameToDictKeyLookups["TEWA"] = ("dctTEWA", "objClsTewaTransitionsManager")
        dctModuleNameToDictKeyLookups["SF1"] = ("dctSF1", "objClsSf1TransitionsManager")
        dctModuleNameToDictKeyLookups["SF2"] = ("dctSF2", "objClsSf2TransitionsManager")
        dctModuleNameToDictKeyLookups["SF3"] = ("dctSF3", "objClsSf3TransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_APM"] = ("dctHMIAPM", "objClsHmiApmTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_APM_FCO"] = ("dctHMIAPMFCO", "objClsHmiApmFcoTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_FCO"] = ("dctHMIFCO", "objClsHmiFcoTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_SPM"] = ("dctHMISPM", "objClsHmiSpmTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_SPM_FUFC"] = ("dctHMISPMFUFC", "objClsHmiSpmFufcTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_FUFC"] = ("dctHMIFUFC", "objClsHmiFufcTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_Maintainer"] = ("dctHMIMaintainer", "objClsHmiMaintainerTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_Oversight"] = ("dctHMIOversight", "objClsHmiOversightTransitionsManager")

        lstSelectedModules = []
        lstSelectedModules.append("DR")
        lstSelectedModules.append("PDBP")
        lstSelectedModules.append("EIU")
        lstSelectedModules.append("TM")
        lstSelectedModules.append("TEWA")
        lstSelectedModules.append("SF1")
        lstSelectedModules.append("SF2")
        lstSelectedModules.append("SF3")
        lstSelectedModules.append("HMI_APM")
        lstSelectedModules.append("HMI_APM_FCO")
        lstSelectedModules.append("HMI_FCO")
        lstSelectedModules.append("HMI_SPM")
        lstSelectedModules.append("HMI_SPM_FUFC")
        lstSelectedModules.append("HMI_FUFC")
        lstSelectedModules.append("HMI_Maintainer")
        lstSelectedModules.append("HMI_Oversight")

        try:
            self.assertEqual(clsOlhmTransitionRules.bAreSelectedSubunitsASpecificState(dctSubUnits, dctModuleNameToDictKeyLookups, lstSelectedModules, "INITIALISE"), False)
            bUnitTestReturn = True
            acTestReportOutput += "\t\tPASS ---- with feedback returned: 'Modules are not all INITIALISE'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\tFAILED ---- with feedback returned: 'Modules are all INITIALISE'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0007
        acTestReportOutput += "Test:   [Defensive Behaviour] clsOlhmTransitionRules::bAreSelectedSubunitsASpecificState (Not all are FAILED) "

        dctSubUnits = {}
        dctSubUnits["dctDR"] = {}
        dctSubUnits["dctDR"]["objClsDrTransitionsManager"] = clsTestClass()
        dctSubUnits["dctDR"]["objClsDrTransitionsManager"].state = "FAILED"
        dctSubUnits["dctPDBP"] = {}
        dctSubUnits["dctPDBP"]["objClsPdbpTransitionsManager"] = clsTestClass()
        dctSubUnits["dctPDBP"]["objClsPdbpTransitionsManager"].state = "FAILED"
        dctSubUnits["dctEIU"] = {}
        dctSubUnits["dctEIU"]["objClsEiuTransitionsManager"] = clsTestClass()
        dctSubUnits["dctEIU"]["objClsEiuTransitionsManager"].state = "FAILED"
        dctSubUnits["dctTM"] = {}
        dctSubUnits["dctTM"]["objClsTmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctTM"]["objClsTmTransitionsManager"].state = "FAILED"
        dctSubUnits["dctTEWA"] = {}
        dctSubUnits["dctTEWA"]["objClsTewaTransitionsManager"] = clsTestClass()
        dctSubUnits["dctTEWA"]["objClsTewaTransitionsManager"].state = "FAILED"
        dctSubUnits["dctSF1"] = {}
        dctSubUnits["dctSF1"]["objClsSf1TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF1"]["objClsSf1TransitionsManager"].state = "FAILED"
        dctSubUnits["dctSF2"] = {}
        dctSubUnits["dctSF2"]["objClsSf2TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF2"]["objClsSf2TransitionsManager"].state = "FAILED"
        dctSubUnits["dctSF3"] = {}
        dctSubUnits["dctSF3"]["objClsSf3TransitionsManager"] = clsTestClass()
        dctSubUnits["dctSF3"]["objClsSf3TransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMIAPM"] = {}
        dctSubUnits["dctHMIAPM"]["objClsHmiApmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIAPM"]["objClsHmiApmTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMIAPMFCO"] = {}
        dctSubUnits["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMIFCO"] = {}
        dctSubUnits["dctHMIFCO"]["objClsHmiFcoTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMISPM"] = {}
        dctSubUnits["dctHMISPM"]["objClsHmiSpmTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMISPM"]["objClsHmiSpmTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMISPMFUFC"] = {}
        dctSubUnits["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMIFUFC"] = {}
        dctSubUnits["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"].state = "FAILED"
        dctSubUnits["dctHMIOversight"] = {}
        dctSubUnits["dctHMIOversight"]["objClsHmiOversightTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIOversight"]["objClsHmiOversightTransitionsManager"].state = "OFFLINE"
        dctSubUnits["dctHMIMaintainer"] = {}
        dctSubUnits["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"] = clsTestClass()
        dctSubUnits["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"].state = "FAILED"

        dctModuleNameToDictKeyLookups = {}
        dctModuleNameToDictKeyLookups["DR"] = ("dctDR", "objClsDrTransitionsManager")
        dctModuleNameToDictKeyLookups["PDBP"] = ("dctPDBP", "objClsPdbpTransitionsManager")
        dctModuleNameToDictKeyLookups["EIU"] = ("dctEIU", "objClsEiuTransitionsManager")
        dctModuleNameToDictKeyLookups["TM"] = ("dctTM", "objClsTmTransitionsManager")
        dctModuleNameToDictKeyLookups["TEWA"] = ("dctTEWA", "objClsTewaTransitionsManager")
        dctModuleNameToDictKeyLookups["SF1"] = ("dctSF1", "objClsSf1TransitionsManager")
        dctModuleNameToDictKeyLookups["SF2"] = ("dctSF2", "objClsSf2TransitionsManager")
        dctModuleNameToDictKeyLookups["SF3"] = ("dctSF3", "objClsSf3TransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_APM"] = ("dctHMIAPM", "objClsHmiApmTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_APM_FCO"] = ("dctHMIAPMFCO", "objClsHmiApmFcoTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_FCO"] = ("dctHMIFCO", "objClsHmiFcoTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_SPM"] = ("dctHMISPM", "objClsHmiSpmTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_SPM_FUFC"] = ("dctHMISPMFUFC", "objClsHmiSpmFufcTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_FUFC"] = ("dctHMIFUFC", "objClsHmiFufcTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_Maintainer"] = ("dctHMIMaintainer", "objClsHmiMaintainerTransitionsManager")
        dctModuleNameToDictKeyLookups["HMI_Oversight"] = ("dctHMIOversight", "objClsHmiOversightTransitionsManager")

        lstSelectedModules = []
        lstSelectedModules.append("DR")
        lstSelectedModules.append("PDBP")
        lstSelectedModules.append("EIU")
        lstSelectedModules.append("TM")
        lstSelectedModules.append("TEWA")
        lstSelectedModules.append("SF1")
        lstSelectedModules.append("SF2")
        lstSelectedModules.append("SF3")
        lstSelectedModules.append("HMI_APM")
        lstSelectedModules.append("HMI_APM_FCO")
        lstSelectedModules.append("HMI_FCO")
        lstSelectedModules.append("HMI_SPM")
        lstSelectedModules.append("HMI_SPM_FUFC")
        lstSelectedModules.append("HMI_FUFC")
        lstSelectedModules.append("HMI_Maintainer")
        lstSelectedModules.append("HMI_Oversight")

        try:
            self.assertEqual(clsOlhmTransitionRules.bAreSelectedSubunitsASpecificState(dctSubUnits, dctModuleNameToDictKeyLookups, lstSelectedModules, "FAILED"), False)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\tPASS ---- with feedback returned: 'Modules are not all FAILED'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\tFAILED ---- with feedback returned: 'Modules are all FAILED'\n"

        bAllTestPassed &= bUnitTestReturn

        if (bAllTestPassed is True):
            logging.info("All autogen unit test passed")
        else:
            logging.info("One or more autogen unit test failed")

        tplReturn = (bAllTestPassed, acTestReportOutput)
        return(tplReturn)


class clsTestClass():
    """ This is a public class which is used in the clsTransitionRulesAssertTesting class as part of the unit tests.

    This class is used to simulate a transitions class

    Args:

    """
    state = str("")
