#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module tests the transition rules classes


Todo:

"""
import unittest
import logging
from olhm_construct_group_status import clsOlhmConstructGroupStatus
from Autogen.olhm_msg import E1_OLHM_STATE
from Autogen.olhm_msg import E1_OLHM_HEALTH_STATUS


class clsGroupStatusAssertTesting(unittest.TestCase):
    """ This is the group status unit testing class

    Args:

    """

    def tplGroupStatusAssert(self) -> bool:
        """ This is a public static method which does some autogen tests.

        Args:

        Returns:
            tuple:
              * (bool) Boolean value which indicates if the method was successful or not.
              * (str) String which contains test report output as text

        Raises:
            Raises no exceptions
        """
        acTestReportOutput = str("")
        bAllTestPassed = bool(True)
        bUnitTestReturn = bool(False)  # This property is used by all unit tests
        tplReturn = (bAllTestPassed, acTestReportOutput)

        # Test 0000
        acTestReportOutput += "Test:   [Expected Behaviour] clsOlhmConstructGroupStatus::clsOlhmConstructGroupStatus\t(Status structure initialised) "
        objClsOlhmConstructGroupStatus = clsOlhmConstructGroupStatus(None)
        dctOrderedDetailedGroupBit = objClsOlhmConstructGroupStatus._dctOrderedDetailedGroupBit  # pylint: disable=protected-access
        lstModulesFromConstructor = [dctModule[0] for dctModule in dctOrderedDetailedGroupBit.items()]
        lstModulesCorrect = ["OLHM", "TM", "TEWA", "PDBP", "DR", "EIU", "HMI_APM", "HMI_FCO", "HMI_APM_FCO", "HMI_SPM", "HMI_FUFC", "HMI_SPM_FUFC", "HMI_Oversight", "HMI_Maintainer", "SF1", "SF2", "SF3"]

        try:
            self.assertEqual(lstModulesFromConstructor == lstModulesCorrect, True)
            bUnitTestReturn = True
            acTestReportOutput += "\t\tPASS ---- with feedback returned: 'Required modules are present'\n"
        except Exception as E:  # noqa: F841  # pylint: disable=unused-variable
            bUnitTestReturn = False
            acTestReportOutput += "\t\tFAILED ---- with feedback returned: 'Not all required modules are present'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0001
        acTestReportOutput += "Test:   [Expected Behaviour] clsOlhmConstructGroupStatus::clsOlhmConstructGroupStatus\t(Status structure initialised) "
        objClsOlhmConstructGroupStatus = clsOlhmConstructGroupStatus(None)
        dctOrderedDetailedGroupBit = objClsOlhmConstructGroupStatus._dctOrderedDetailedGroupBit  # pylint: disable=protected-access

        try:
            self.assertEqual(self.bIsOrderedGroupStructureCorrectComparedToDefault(dctOrderedDetailedGroupBit), True)
            bUnitTestReturn = True
            acTestReportOutput += "\t\tPASS ---- with feedback returned: 'Group status structure is correct'\n"
        except Exception as E:  # noqa: F841  # pylint: disable=unused-variable
            bUnitTestReturn = False
            acTestReportOutput += "\t\tFAILED ---- with feedback returned: 'Group status structure is not correct'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0002
        acTestReportOutput += "Test:   [Expected Behaviour] clsOlhmConstructGroupStatus::vUpdateDetailedTreeFromListOfEntries\t(Status structure modified) "

        # Make a simulated global dictionary
        dctGlobalDict = {}
        dctGlobalDict["dctMqtt"] = {}
        dctGlobalDict["dctMqtt"]["objClsMessageProcessForMqtt"] = None

        objClsOlhmConstructGroupStatus = clsOlhmConstructGroupStatus(dctGlobalDict)
        dctOrderedDetailedGroupBit = objClsOlhmConstructGroupStatus._dctOrderedDetailedGroupBit  # pylint: disable=protected-access

        # Modify the OLHM branch of the status structure
        lstNewEntries = []
        lstNewEntries.append({"lstTreePath": ["OLHM"], "acValue": "Value0", "e1OlhmHealthStatus": E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_PASSED), "e1OlhmState": E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OPERATIONAL)})
        lstNewEntries.append({"lstTreePath": ["OLHM", "STATUS"], "acValue": "Value1", "e1OlhmHealthStatus": E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_PASSED), "e1OlhmState": E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OPERATIONAL)})

        objClsOlhmConstructGroupStatus.vUpdateDetailedTreeFromListOfEntries(lstNewEntries)

        try:
            self.assertEqual(self.bIsOrderedGroupStructureCorrectTest002(dctOrderedDetailedGroupBit), True)
            bUnitTestReturn = True
            acTestReportOutput += "\tPASS ---- with feedback returned: 'Group status structure is correct'\n"
        except Exception as E:  # noqa: F841  # pylint: disable=unused-variable
            bUnitTestReturn = False
            acTestReportOutput += "\tFAILED ---- with feedback returned: 'Group status structure is not correct'\n"

        bAllTestPassed &= bUnitTestReturn

        if (bAllTestPassed is True):
            logging.info("All autogen unit test passed")
        else:
            logging.info("One or more autogen unit test failed")

        tplReturn = (bAllTestPassed, acTestReportOutput)
        return(tplReturn)

    def bIsOrderedGroupStructureCorrectComparedToDefault(self, dctOrderedDetailedGroupBitPar) -> bool:
        """ This is a public method which verifies if the ordered group status structure is correct

        Args:
            dctOrderedDetailedGroupBitPar (dict)

        Returns:
            (bool): Flag to indicate if the comparison matched

        Raises:
            Raises no exceptions
        """
        bReturn = bool(False)
        lstModules = ["OLHM", "TM", "TEWA", "PDBP", "DR", "EIU", "HMI_APM", "HMI_FCO", "HMI_APM_FCO", "HMI_SPM", "HMI_FUFC", "HMI_SPM_FUFC", "HMI_Oversight", "HMI_Maintainer", "SF1", "SF2", "SF3"]

        for acModule in lstModules:

            if (acModule not in dctOrderedDetailedGroupBitPar):
                return(bReturn)

            if (dctOrderedDetailedGroupBitPar[acModule]["e1OlhmHealthStatus"].Value != E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN):
                return(bReturn)

            if (dctOrderedDetailedGroupBitPar[acModule]["e1OlhmState"].Value != E1_OLHM_STATE.OLHM_STATE_OFFLINE):
                return(bReturn)

            if (dctOrderedDetailedGroupBitPar[acModule]["iLevel"] != 0):
                return(bReturn)

            if ("STATUS" not in dctOrderedDetailedGroupBitPar[acModule]["dctChild"]):
                return(bReturn)

            if (dctOrderedDetailedGroupBitPar[acModule]["dctChild"]["STATUS"]["iLevel"] != 1):
                return(bReturn)

        bReturn = bool(True)
        return(True)

    def bIsOrderedGroupStructureCorrectTest002(self, dctOrderedDetailedGroupBitPar) -> bool:
        """ This is a public method which verifies if the ordered group status structure is correct

        Args:
            dctOrderedDetailedGroupBitPar (dict)

        Returns:
            (bool): Flag to indicate if the comparison matched

        Raises:
            Raises no exceptions
        """
        bReturn = bool(False)

        if ("OLHM" not in dctOrderedDetailedGroupBitPar):
            return(bReturn)

        if (dctOrderedDetailedGroupBitPar["OLHM"]["acValue"] != "Value0"):
            return(bReturn)

        if (dctOrderedDetailedGroupBitPar["OLHM"]["e1OlhmHealthStatus"].Value != E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_PASSED):
            return(bReturn)

        if (dctOrderedDetailedGroupBitPar["OLHM"]["e1OlhmState"].Value != E1_OLHM_STATE.OLHM_STATE_OPERATIONAL):
            return(bReturn)

        if ("STATUS" not in dctOrderedDetailedGroupBitPar["OLHM"]["dctChild"]):
            return(bReturn)

        if (dctOrderedDetailedGroupBitPar["OLHM"]["dctChild"]["STATUS"]["acValue"] != "Value1"):
            return(bReturn)

        if (dctOrderedDetailedGroupBitPar["OLHM"]["dctChild"]["STATUS"]["e1OlhmHealthStatus"].Value != E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_PASSED):
            return(bReturn)

        if (dctOrderedDetailedGroupBitPar["OLHM"]["dctChild"]["STATUS"]["e1OlhmState"].Value != E1_OLHM_STATE.OLHM_STATE_OPERATIONAL):
            return(bReturn)

        bReturn = bool(True)
        return(bReturn)
