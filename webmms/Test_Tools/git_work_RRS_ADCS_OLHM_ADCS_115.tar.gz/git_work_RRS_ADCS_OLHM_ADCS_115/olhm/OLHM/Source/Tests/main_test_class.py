#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module is the main testing class

Todo:

"""
import logging
import datetime
from Tests.autogen_assert_testing import clsAutogenAssertTesting
from Tests.toolbox_assert_testing import clsToolboxAssertTesting
from Tests.transition_rules_assert_testing import clsTransitionRulesAssertTesting
from Tests.group_status_assert_testing import clsGroupStatusAssertTesting


class clsMainTestClass():
    """ This is the main test class for running the unit tests.

    Args:

    """

    @staticmethod
    def bMainTestMethod():
        """ This is a public static method which is the main testing method.

        Args:

        Returns:
            (bool): Flag indicating if the tests passed

        Raises:
            Raises no exceptions
        """
        objDatetime = datetime.datetime.now()
        bAllTestPassed = bool(True)
        tplTestResult = (False, "")
        acTestReport = str("\n")
        acTestReport += str("Module: OLHM\n")
        acTestReport += str("Date: %s\n" % (objDatetime.strftime("%Y-%m-%d %H:%M:%S")))
        acTestReport += str("\n")
        acTestReport += str("****** Running Unit Tests ******\n")
        acTestReport += str("\n")

        objClsAutogenAssertTesting = clsAutogenAssertTesting()
        objClsToolboxAssertTesting = clsToolboxAssertTesting()
        objClsTransitionRulesAssertTesting = clsTransitionRulesAssertTesting()
        objClsGroupStatusAssertTesting = clsGroupStatusAssertTesting()

        tplTestResult = objClsAutogenAssertTesting.tplAutogenAssert()
        bAllTestPassed &= tplTestResult[0]
        acTestReport += tplTestResult[1]
        tplTestResult = objClsToolboxAssertTesting.tplToolboxAssert()
        bAllTestPassed &= tplTestResult[0]
        acTestReport += tplTestResult[1]
        tplTestResult = objClsTransitionRulesAssertTesting.tplTransitionRulesAssert()
        bAllTestPassed &= tplTestResult[0]
        acTestReport += tplTestResult[1]
        tplTestResult = objClsGroupStatusAssertTesting.tplGroupStatusAssert()
        bAllTestPassed &= tplTestResult[0]
        acTestReport += tplTestResult[1]

        if (bAllTestPassed is True):
            logging.info("All unit test passed")
        else:
            logging.info("One or more unit test failed")

        acTestReport += "\n"
        print(acTestReport)

        return(bAllTestPassed)
