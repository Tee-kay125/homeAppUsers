#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module tests the autogen classes


Todo:

"""
import unittest
import logging
from Autogen.olhm_msg import sOLHM_END_OF_READY_CMD
from Autogen.olhm_msg import sOLHM_ADCS_STATUS_UNSOL
from Autogen.olhm_msg import sOLHM_DETAILED_STATUS
from Autogen.olhm_msg import sOLHM_ADCS_SHUTDOWN_CMD


class clsAutogenAssertTesting(unittest.TestCase):
    """ This is the autogen unit testing class

    Args:

    """

    def tplAutogenAssert(self) -> bool:
        """ This is a public static method which does some autogen tests.

        Args:

        Returns:
            tuple:
              * (bool) Boolean value which indicates if the method was successful or not.
              * (str) String which contains test report output as text

        Raises:
            Raises no exceptions
        """
        acTestReportOutput = str("")
        bAllTestPassed = bool(True)
        bUnitTestReturn = bool(False)  # This property is used by all unit tests
        tplReturn = (bAllTestPassed, acTestReportOutput)

        # Test 0001
        acTestReportOutput += "Test:   [Expected Behaviour] (Autogen message OlhmEndOfReadyCmd correct u2MsgLength value) "
        objsOLHM_END_OF_READY_CMD = sOLHM_END_OF_READY_CMD()

        try:
            self.assertEqual(objsOLHM_END_OF_READY_CMD.sMsgHeader.u2MsgLength.Value, 20)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\t\t\tPASS ---- with feedback returned: 'Success'\n"
        except Exception as E:  # noqa: F841  # pylint: disable=unused-variable
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\t\t\tFAILED ---- with feedback returned: 'Failed'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0002
        acTestReportOutput += "Test:   [Expected Behaviour] (Autogen message OlhmEndOfReadyCmd correct iSizeBytes() value) "
        objsOLHM_ADCS_STATUS_UNSOL = sOLHM_ADCS_STATUS_UNSOL()
        iMsgHeaderSizeBytes = objsOLHM_ADCS_STATUS_UNSOL.sMsgHeader.iSizeBytes()

        try:
            self.assertEqual(iMsgHeaderSizeBytes, 22)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\t\t\tPASS ---- with feedback returned: 'Success'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\t\t\tFAILED ---- with feedback returned: 'Failed'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0003
        acTestReportOutput += "Test:   [Expected Behaviour] (Autogen message OlhmAdcsStatusUnsol correct u2MsgLength value) "

        try:
            self.assertEqual(objsOLHM_ADCS_STATUS_UNSOL.sMsgHeader.u2MsgLength.Value, 10757)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\t\t\tPASS ---- with feedback returned: 'Success'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\t\t\tFAILED ---- with feedback returned: 'Failed'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0004
        acTestReportOutput += "Test:   [Expected Behaviour] (Autogen struct sOLHM_DETAILED_STATUS correct iSizeBytes() value) "
        objsOLHM_DETAILED_STATUS = sOLHM_DETAILED_STATUS()

        try:
            self.assertEqual(objsOLHM_DETAILED_STATUS.iSizeBytes(), 106)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\t\t\tPASS ---- with feedback returned: 'Success'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\t\t\tFAILED ---- with feedback returned: 'Failed'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0005
        acTestReportOutput += "Test:   [Expected Behaviour] (Autogen message OlhmAdcsShutdownCmd serialised is correct) "
        objsOLHM_ADCS_SHUTDOWN_CMD = sOLHM_ADCS_SHUTDOWN_CMD()
        btaUnitTest004CorrectByteStream = bytes([20, 0, 0, 0, 0, 0, 4, 0, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255])

        try:
            self.assertEqual(objsOLHM_ADCS_SHUTDOWN_CMD.btaSerialise(), btaUnitTest004CorrectByteStream)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\t\t\tPASS ---- with feedback returned: 'Success'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\t\t\tFAILED ---- with feedback returned: 'Failed'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0006
        acTestReportOutput += "Test:   [Expected Behaviour] (Autogen message OlhmAdcsShutdownCmd u2MsgLength value is correct after deserialise) "
        objsOLHM_ADCS_SHUTDOWN_CMD = sOLHM_ADCS_SHUTDOWN_CMD()
        # Fill the byte stream with arbitrary values
        objsOLHM_ADCS_SHUTDOWN_CMD.vDeserialise(bytes([0x2, 0x1, 0x4, 0x3, 0x6, 0x5, 0x8, 0x7, 0xa, 0x9, 0xc, 0xb, 0xe, 0xd, 0x10, 0x0f, 0x12, 0x11, 0x14, 0x13, 0x16, 0x15]))

        try:
            self.assertEqual(objsOLHM_ADCS_SHUTDOWN_CMD.sMsgHeader.u2MsgLength.Value, 0x102)
            bUnitTestReturn = True
            acTestReportOutput += "\t\tPASS ---- with feedback returned: 'Success'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\tFAILED ---- with feedback returned: 'Failed'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0007
        acTestReportOutput += "Test:   [Expected Behaviour] (Autogen message OlhmAdcsShutdownCmd e2MsgType value is correct after deserialise) "
        try:
            self.assertEqual(objsOLHM_ADCS_SHUTDOWN_CMD.sMsgHeader.e2MsgType.Value, 0x304)
            bUnitTestReturn = True
            acTestReportOutput += "\t\tPASS ---- with feedback returned: 'Success'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\tFAILED ---- with feedback returned: 'Failed'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0008
        acTestReportOutput += "Test:   [Expected Behaviour] (Autogen message OlhmAdcsShutdownCmd u8TimeStampMs value is correct after deserialise) "
        try:
            self.assertEqual(objsOLHM_ADCS_SHUTDOWN_CMD.sMsgHeader.u8TimeStampMs.Value, 0x131411120f100d0e)
            bUnitTestReturn = True
            acTestReportOutput += "\t\tPASS ---- with feedback returned: 'Success'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\tFAILED ---- with feedback returned: 'Failed'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0009
        acTestReportOutput += "Test:   [Defensive Behaviour] sOLHM_ADCS_SHUTDOWN_CMD.bValidate()\t(Validation should fail) "
        try:
            self.assertEqual(objsOLHM_ADCS_SHUTDOWN_CMD.bValidate(), False)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\t\tPASS ---- with feedback returned: 'Validation failed'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\t\tFAILED ---- with feedback returned: 'Validation passed'\n"

        bAllTestPassed &= bUnitTestReturn

        if (bAllTestPassed is True):
            logging.info("All autogen unit test passed")
        else:
            logging.info("One or more autogen unit test failed")

        tplReturn = (bAllTestPassed, acTestReportOutput)
        return(tplReturn)
