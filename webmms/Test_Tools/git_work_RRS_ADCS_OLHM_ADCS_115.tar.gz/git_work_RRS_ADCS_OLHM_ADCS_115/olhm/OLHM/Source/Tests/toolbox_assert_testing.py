#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module tests the toolbox classes


Todo:

"""
import unittest
import logging
from python_toolbox.TOML_Utilities.toml_utilities import clsTomlUtilities


class clsToolboxAssertTesting(unittest.TestCase):
    """ This is the toolbox unit testing class

    Args:

    """

    def tplToolboxAssert(self) -> bool:
        """ This is a public static method which does some toolbox tests.

        Args:

        Returns:
            tuple:
              * (bool) Boolean value which indicates if the method was successful or not.
              * (str) String which contains test report output as text

        Raises:
            Raises no exceptions
        """
        acTestReportOutput = str("")
        bAllTestPassed = bool(True)
        tplReturn = (bAllTestPassed, acTestReportOutput)

        # Test 0000
        acTestReportOutput += "Test:   [Expected Behaviour] clsTomlUtilities::bTomlFieldIsValidPort\t(Port should be valid) "

        try:
            self.assertEqual(clsTomlUtilities.bTomlFieldIsValidPort(1234), True)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\t\t\tPASS ---- with feedback returned: 'Port is valid'\n"
        except Exception as E:  # noqa: F841  # pylint: disable=unused-variable
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\t\t\tFAILED ---- with feedback returned: 'Port is invalid'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0001
        acTestReportOutput += "Test:   [Defensive Behaviour] clsTomlUtilities::bTomlFieldIsValidPort\t(Port should be invalid) "

        try:
            self.assertEqual(clsTomlUtilities.bTomlFieldIsValidPort(0), False)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\t\tPASS ---- with feedback returned: 'Port is invalid'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\t\tFAILED ---- with feedback returned: 'Port is valid'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0002
        acTestReportOutput += "Test:   [Defensive Behaviour] clsTomlUtilities::bTomlFieldIsValidPort\t(Port should be invalid) "
        try:
            self.assertEqual(clsTomlUtilities.bTomlFieldIsValidPort(65536), False)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\t\tPASS ---- with feedback returned: 'Port is invalid'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\t\tFAILED ---- with feedback returned: 'Port is valid'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0003
        acTestReportOutput += "Test:   [Expected Behaviour] clsTomlUtilities::bTomlFieldIsValidIpV4Address\t(IP should be valid) "

        try:
            self.assertEqual(clsTomlUtilities.bTomlFieldIsValidIpV4Address("192.168.1.1"), True)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\t\tPASS ---- with feedback returned: 'IP is valid'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\t\tFAILED ---- with feedback returned: 'IP is invalid'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0004
        acTestReportOutput += "Test:   [Defensive Behaviour] clsTomlUtilities::bTomlFieldIsValidIpV4Address\t(IP should be invalid) "

        try:
            self.assertEqual(clsTomlUtilities.bTomlFieldIsValidIpV4Address(""), False)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\t\tPASS ---- with feedback returned: 'IP is invalid'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\t\tFAILED ---- with feedback returned: 'IP is valid'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0005
        acTestReportOutput += "Test:   [Defensive Behaviour] clsTomlUtilities::bTomlFieldIsValidIpV4Address\t(IP should be invalid) "

        try:
            self.assertEqual(clsTomlUtilities.bTomlFieldIsValidIpV4Address("10.0."), False)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\t\tPASS ---- with feedback returned: 'IP is invalid'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\t\tFAILED ---- with feedback returned: 'IP is valid'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0006
        acTestReportOutput += "Test:   [Defensive Behaviour] clsTomlUtilities::bTomlFieldIsValidIpV4Address\t(IP should be invalid) "

        try:
            self.assertEqual(clsTomlUtilities.bTomlFieldIsValidIpV4Address("10.0.0."), False)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\t\tPASS ---- with feedback returned: 'IP is invalid'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\t\tFAILED ---- with feedback returned: 'IP is valid'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0007
        acTestReportOutput += "Test:   [Defensive Behaviour] clsTomlUtilities::bTomlFieldIsValidIpV4Address\t(IP should be invalid) "

        try:
            self.assertEqual(clsTomlUtilities.bTomlFieldIsValidIpV4Address("-10.0.0.1"), False)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\t\tPASS ---- with feedback returned: 'IP is invalid'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\t\tFAILED ---- with feedback returned: 'IP is valid'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0008
        acTestReportOutput += "Test:   [Expected Behaviour] clsTomlUtilities::bTomlObjectContainsPath\t(TOML path should be valid) "

        objTomlObject = {}
        objTomlObject["Subscribers"] = {}
        objTomlObject["Subscribers"]["ADCS"] = None

        try:
            self.assertEqual(clsTomlUtilities.bTomlObjectContainsPath(objTomlObject, ["Subscribers", "ADCS"]), True)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\t\tPASS ---- with feedback returned: 'TOML path is valid'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\t\tFAILED ---- with feedback returned: 'TOML path is invalid'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0009
        acTestReportOutput += "Test:   [Defensive Behaviour] clsTomlUtilities::bTomlObjectContainsPath\t(TOML path should not be invalid) "

        try:
            self.assertEqual(clsTomlUtilities.bTomlObjectContainsPath(objTomlObject, ["Subscriber", "ADCS"]), False)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\tPASS ---- with feedback returned: 'TOML path is invalid'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\tFAILED ---- with feedback returned: 'TOML path is valid'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0010
        acTestReportOutput += "Test:   [Defensive Behaviour] clsTomlUtilities::bTomlObjectContainsPath\t(TOML path should not be invalid) "

        try:
            self.assertEqual(clsTomlUtilities.bTomlObjectContainsPath(objTomlObject, ["Subscribers", "Invalid"]), False)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\tPASS ---- with feedback returned: 'TOML path is invalid'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\tFAILED ---- with feedback returned: 'TOML path is valid'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0011
        acTestReportOutput += "Test:   [Defensive Behaviour] clsTomlUtilities::bTomlObjectContainsPath\t(TOML path should not be invalid) "

        try:
            self.assertEqual(clsTomlUtilities.bTomlObjectContainsPath(objTomlObject, ["Subscribers", "ADCS", "Invalid"]), False)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\tPASS ---- with feedback returned: 'TOML path is invalid'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\tFAILED ---- with feedback returned: 'TOML path is valid'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0012
        acTestReportOutput += "Test:   [Expected Behaviour] clsTomlUtilities::bTomlFieldIsAValidInteger\t(TOML field should be a valid integer) "

        try:
            self.assertEqual(clsTomlUtilities.bTomlFieldIsAValidInteger(int(3000)), True)
            bUnitTestReturn = True
            acTestReportOutput += "\t\tPASS ---- with feedback returned: 'TOML field is an integer'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\tFAILED ---- with feedback returned: 'TOML field is not an integer'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0013
        acTestReportOutput += "Test:   [Defensive Behaviour] clsTomlUtilities::bTomlFieldIsAValidInteger\t(TOML field should not be a valid integer) "

        try:
            self.assertEqual(clsTomlUtilities.bTomlFieldIsAValidInteger(float(3000)), False)
            bUnitTestReturn = True
            acTestReportOutput += "\tPASS ---- with feedback returned: 'TOML field is not an integer'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\tFAILED ---- with feedback returned: 'TOML field is an integer'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0014
        acTestReportOutput += "Test:   [Defensive Behaviour] clsTomlUtilities::bTomlFieldIsAValidInteger\t(TOML field should not be a valid integer) "

        try:
            self.assertEqual(clsTomlUtilities.bTomlFieldIsAValidInteger(None), False)
            bUnitTestReturn = True
            acTestReportOutput += "\tPASS ---- with feedback returned: 'TOML field is not an integer'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\tFAILED ---- with feedback returned: 'TOML field is an integer'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0015
        acTestReportOutput += "Test:   [Defensive Behaviour] clsTomlUtilities::bTomlFieldIsAValidInteger\t(TOML field should not be a valid integer) "

        try:
            self.assertEqual(clsTomlUtilities.bTomlFieldIsAValidInteger(str("3000")), False)
            bUnitTestReturn = True
            acTestReportOutput += "\tPASS ---- with feedback returned: 'TOML field is not an integer'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\tFAILED ---- with feedback returned: 'TOML field is an integer'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0016
        acTestReportOutput += "Test:   [Expected Behaviour] clsTomlUtilities::bTomlFieldIsAValidFloat\t(TOML field should be a valid float) "

        try:
            self.assertEqual(clsTomlUtilities.bTomlFieldIsAValidFloat(float(3000)), True)
            bUnitTestReturn = True
            acTestReportOutput += "\t\t\tPASS ---- with feedback returned: 'TOML field is a float'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\t\tFAILED ---- with feedback returned: 'TOML field is not a float'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0017
        acTestReportOutput += "Test:   [Defensive Behaviour] clsTomlUtilities::bTomlFieldIsAValidFloat\t(TOML field should not be a valid float) "

        try:
            self.assertEqual(clsTomlUtilities.bTomlFieldIsAValidFloat(int("3000")), False)
            bUnitTestReturn = True
            acTestReportOutput += "\t\tPASS ---- with feedback returned: 'TOML field is not a float'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\tFAILED ---- with feedback returned: 'TOML field is a float'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0018
        acTestReportOutput += "Test:   [Defensive Behaviour] clsTomlUtilities::bTomlFieldIsAValidFloat\t(TOML field should not be a valid float) "

        try:
            self.assertEqual(clsTomlUtilities.bTomlFieldIsAValidFloat(None), False)
            bUnitTestReturn = True
            acTestReportOutput += "\t\tPASS ---- with feedback returned: 'TOML field is not a float'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\tFAILED ---- with feedback returned: 'TOML field is a float'\n"

        bAllTestPassed &= bUnitTestReturn

        # Test 0019
        acTestReportOutput += "Test:   [Defensive Behaviour] clsTomlUtilities::bTomlFieldIsAValidFloat\t(TOML field should not be a valid float) "

        try:
            self.assertEqual(clsTomlUtilities.bTomlFieldIsAValidFloat(str("3000.0")), False)
            bUnitTestReturn = True
            acTestReportOutput += "\t\tPASS ---- with feedback returned: 'TOML field is not a float'\n"
        except Exception as E:  # noqa: F841
            bUnitTestReturn = False
            acTestReportOutput += "\t\tFAILED ---- with feedback returned: 'TOML field is a float'\n"

        bAllTestPassed &= bUnitTestReturn

        # Now evaulate all the tests together
        # Now evaulate all the tests together
        # Now evaulate all the tests together

        if (bAllTestPassed is True):
            logging.info("All toolbox unit test passed")
        else:
            logging.info("One or more toolbox unit test failed")

        tplReturn = (bAllTestPassed, acTestReportOutput)
        return(tplReturn)
