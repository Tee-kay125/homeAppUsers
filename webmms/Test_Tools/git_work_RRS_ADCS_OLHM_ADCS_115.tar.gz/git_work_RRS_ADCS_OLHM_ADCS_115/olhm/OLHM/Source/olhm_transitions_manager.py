#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which manages a transitions (PyPi library) state machine.

Todo:

"""
import sys
import logging
import asyncio
import time
from transitions import Machine
from olhm_transition_rules import clsOlhmTransitionRules
from python_toolbox.State_Machine_Utilities.state_machine_utilities import clsStateMachineUtilities

from Autogen.olhm_msg import E1_OLHM_ACTION_STATUS_REPORT
from Autogen.dr_msg import sDR_SHUTDOWN_CMD
from Autogen.dr_msg import sDR_SHUTDOWN_CMD_RSP
from Autogen.pdbp_msg import sPDBP_SHUTDOWN_CMD
from Autogen.pdbp_msg import sPDBP_SHUTDOWN_CMD_RSP
from Autogen.eiu_msg import sEIU_SHUTDOWN_CMD
from Autogen.eiu_msg import sEIU_SHUTDOWN_CMD_RSP
from Autogen.tm_msg import sTM_SHUTDOWN_CMD
from Autogen.tm_msg import sTM_SHUTDOWN_CMD_RSP
from Autogen.tewa_msg import sTEWA_SHUTDOWN_CMD
from Autogen.tewa_msg import sTEWA_SHUTDOWN_CMD_RSP
from Autogen.sf1_msg import sSF1_SHUTDOWN_CMD
from Autogen.sf1_msg import sSF1_SHUTDOWN_CMD_RSP
from Autogen.sf2_msg import sSF2_SHUTDOWN_CMD
from Autogen.sf2_msg import sSF2_SHUTDOWN_CMD_RSP
from Autogen.sf3_msg import sSF3_SHUTDOWN_CMD
from Autogen.sf3_msg import sSF3_SHUTDOWN_CMD_RSP
from Autogen.hmi_msg import sHMI_SHUTDOWN_CMD
from Autogen.hmi_msg import sHMI_SHUTDOWN_CMD_RSP


class clsOlhmTransitionsManager:
    """ This is the periodic monitor manager.

    Args:
        dctGlobalInterfaceDictionaryPar (object): The first parameter. The global interface dictionary.
        acInitialStatePar (str): The second parameter. The initial state
    """
    def __init__(self, dctGlobalInterfaceDictionaryPar: object, acInitialStatePar: str = "OFFLINE"):
        super().__init__()
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar

        # This contains all the modules to be monitored by the OLHM
        self._lstModulesToMonitor = self._dctGloInterDict["dctOLHM"]["lstModulesToMonitor"][:]
        self._lstModulesNotToMonitor = self._dctGloInterDict["dctOLHM"]["lstModulesNotToMonitor"][:]
        self._lstModulesIncludedInStartup = self._dctGloInterDict["dctOLHM"]["lstModulesIncludedInStartup"][:]

        # This list contains all the which must partake in the start-up sequence
        self._lstSelectedModulesForInitialise = self._lstModulesIncludedInStartup[:]

        # The PDBP will already be in READY state so don't check it
        if ("PDBP" in self._lstSelectedModulesForInitialise):
            self._lstSelectedModulesForInitialise.remove("PDBP")

        # These are the python loggger levels
        # Level	Numeric value
        # CRITICAL  50
        # ERROR     40
        # WARNING   30       Transitions uses WARNING level to report when state changes cannot be made - too verbose
        # INFO      20       Transitions uses INFO level to report entries and exits - too verbose
        # DEBUG     10
        # NOTSET    0
        #
        # The transitions library use the logger to display information. Increase the log level to make it less verbose
        logging.getLogger('transitions').setLevel(logging.ERROR)

        self._lstStates = []
        self._lstStates += [{"name": "OFFLINE", "on_enter": self._vOnEnter_OFFLINE}]
        self._lstStates += [{"name": "INITIALISE", "on_enter": self._vOnEnter_INITIALISE}]
        self._lstStates += [{"name": "READY", "on_enter": self._vOnEnter_READY}]
        self._lstStates += [{"name": "OPERATIONAL", "on_enter": self._vOnEnter_OPERATIONAL}]
        self._lstStates += [{"name": "FAILED", "on_enter": self._vOnEnter_FAILED}]
        self._lstStates += [{"name": "SHUTDOWN", "on_enter": self._vOnEnter_SHUTDOWN}]

        # guards are registered using the 'conditions' key
        # You can attach callbacks to transitions as well as states. Every transition has 'before' and 'after' attributes that contain a list of methods to call before and after the transition executes:
        # When a transition is called the guard is called first, then the before and then the after.
        # The before is before the transition
        # The after is after the transition
        self._lstTransitions = []
        self._lstTransitions += [{'trigger': "trgINITIALISE", 'source': ["OFFLINE"], 'dest': "INITIALISE", 'conditions': self._bValidationAndSelfCheckPassed}]
        self._lstTransitions += [{'trigger': "trgREADY", 'source': ["INITIALISE"], 'dest': "READY"}]
        self._lstTransitions += [{'trigger': "trgOPERATIONAL", 'source': ["READY"], 'dest': "OPERATIONAL"}]
        self._lstTransitions += [{'trigger': "trgSHUTDOWN", 'source': ["READY", "OPERATIONAL", "FAILED"], 'dest': "SHUTDOWN"}]
        self._lstTransitions += [{'trigger': "trgFAILED", 'source': ["OFFLINE"], 'dest': "FAILED"}]

        # Initialize the state machine
        self.objTransitionsMachine = Machine(model=self, states=self._lstStates, transitions=self._lstTransitions, initial=acInitialStatePar, ignore_invalid_triggers=True)

        self._acStateCurrent = acInitialStatePar
        self._acStatePrev = acInitialStatePar
        self._acUnit = "OLHM"

        self._bValidationAndSelfCheckPassedProperty = bool(False)

        self._lstMessagesForWhichShutdownIsAllowed = []
        self._lstMessagesForWhichShutdownIsAllowed.append("OlhmAdcsShutdownCmd")
        self._lstMessagesForWhichShutdownIsAllowed.append("MmsShutdownCmd")
        self._lstMessagesForWhichShutdownIsAllowed.append("HmiAdcsShutdownCmdAPM")
        self._lstMessagesForWhichShutdownIsAllowed.append("HmiAdcsShutdownCmdAPM_FCO")
        self._lstMessagesForWhichShutdownIsAllowed.append("HmiAdcsShutdownCmdFCO")
        self._lstMessagesForWhichShutdownIsAllowed.append("HmiAdcsShutdownCmdSPM")
        self._lstMessagesForWhichShutdownIsAllowed.append("HmiAdcsShutdownCmdSPM_FUFC")
        self._lstMessagesForWhichShutdownIsAllowed.append("HmiAdcsShutdownCmdFUFC")
        self._lstMessagesForWhichShutdownIsAllowed.append("HmiAdcsShutdownCmdMaintainer")
        self._lstMessagesForWhichShutdownIsAllowed.append("HmiAdcsShutdownCmdOversight")
        self._acLastShutdownCommandingMessage = str("")
        self._lstModulesNotOfflineOrFailedPriorToShutdown = []

        self._bEndOfReadySentToAllCompleted = bool(False)

        return

    def acPrevState(self):
        """ This is a public method getter which gets the previous state.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        return(self._acStatePrev)

    def _vCapturePreviousState(self):
        """ This is a private method which stores the previous state.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        self._acStatePrev = self._acStateCurrent
        self._acStateCurrent = self.state  # pylint: disable=no-member

        clsStateMachineUtilities.vLogTransitionsStateChange(self._acStatePrev, self._acStateCurrent, "OLHM", acAdditionalMessagePar="", bLogOnlyOnChangePar=False)
        return

    def _vOnEnter_OFFLINE(self):
        """ This is a private method which is called when the state machine enters the OFFLINE state.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        clsStateMachineUtilities.vLogTransitionsStateCurrent(self.state, self._acUnit)  # pylint: disable=no-member
        self._vCapturePreviousState()

        # Update the group status tree if the OLHM state changed
        self._dctGloInterDict["dctOLHM"]["objClsOlhmManager"].vSetOlhmState()

        return

    def _vOnEnter_INITIALISE(self):
        """ This is a private method which is called when the state machine enters the INITIALISE state.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        clsStateMachineUtilities.vLogTransitionsStateCurrent(self.state, self._acUnit)  # pylint: disable=no-member
        self._vCapturePreviousState()

        # Send out the group status tree with unknown values
        self._dctGloInterDict["dctOLHM"]["objClsOlhmConstructGroupStatus"].vSendUnknownOlhmAdcsStatusUnsol()
        self._dctGloInterDict["dctOLHM"]["objClsOlhmConstructGroupStatus"].vSendUnknownOlhmAdcsHmiStatusUnsol()

        # Update the group status tree if the OLHM state changed
        self._dctGloInterDict["dctOLHM"]["objClsOlhmManager"].vSetOlhmState()

        self.trgREADY()  # pylint: disable=no-member

        return

    def _vOnEnter_READY(self):
        """ This is a private method which is called when the state machine enters the INITIALISE state.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        clsStateMachineUtilities.vLogTransitionsStateCurrent(self.state, self._acUnit)  # pylint: disable=no-member
        self._vCapturePreviousState()

        # Update the group status tree if the OLHM state changed
        self._dctGloInterDict["dctOLHM"]["objClsOlhmManager"].vSetOlhmState()

        return

    def _vOnEnter_OPERATIONAL(self):
        """ This is a private method which is called when the state machine enters the OPERATIONAL state.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        clsStateMachineUtilities.vLogTransitionsStateCurrent(self.state, self._acUnit)  # pylint: disable=no-member
        self._vCapturePreviousState()

        e1OlhmActionStatusReport = E1_OLHM_ACTION_STATUS_REPORT(E1_OLHM_ACTION_STATUS_REPORT.OLHM_ACTION_STATUS_REPORT_READY_FOR_ACTION)

        # Now send the action status report
        self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendOlhmActionStatusReportUnsol(e1OlhmActionStatusReport)

        # Update the group status tree if the OLHM state changed
        self._dctGloInterDict["dctOLHM"]["objClsOlhmManager"].vSetOlhmState()

        return

    def _vOnEnter_SHUTDOWN(self):
        """ This is a private method which is called when the state machine enters the SHUTDOWN state.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        clsStateMachineUtilities.vLogTransitionsStateCurrent(self.state, self._acUnit)  # pylint: disable=no-member
        self._vCapturePreviousState()

        # Do some sanity checks

        if (self._dctGloInterDict is None):
            logging.error("self._dctGloInterDict cannot be None")
            return

        if (self._dctGloInterDict["dctOLHM"]["objClsOlhmManager"] is None):
            logging.error("objClsOlhmManager cannot be None")
            return

        if (self._dctGloInterDict["dctAsyncio"]["objAsyncioLoopPar"] is None):
            logging.error("objAsyncioLoopPar cannot be None")
            return

        # Before the start the shutdown find out which modules to shutdown
        if (self._dctGloInterDict["dctSubUnits"]["dctDR"]["objClsDrTransitionsManager"].state not in ["OFFLINE", "FAILED"]):
            self._lstModulesNotOfflineOrFailedPriorToShutdown.append("DR")
        if (self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objClsPdbpTransitionsManager"].state not in ["OFFLINE", "FAILED"]):
            self._lstModulesNotOfflineOrFailedPriorToShutdown.append("PDBP")
        if (self._dctGloInterDict["dctSubUnits"]["dctEIU"]["objClsEiuTransitionsManager"].state not in ["OFFLINE", "FAILED"]):
            self._lstModulesNotOfflineOrFailedPriorToShutdown.append("EIU")
        if (self._dctGloInterDict["dctSubUnits"]["dctTM"]["objClsTmTransitionsManager"].state not in ["OFFLINE", "FAILED"]):
            self._lstModulesNotOfflineOrFailedPriorToShutdown.append("TM")
        if (self._dctGloInterDict["dctSubUnits"]["dctTEWA"]["objClsTewaTransitionsManager"].state not in ["OFFLINE", "FAILED"]):
            self._lstModulesNotOfflineOrFailedPriorToShutdown.append("TEWA")
        if (self._dctGloInterDict["dctSubUnits"]["dctSF1"]["objClsSf1TransitionsManager"].state not in ["OFFLINE", "FAILED"]):
            self._lstModulesNotOfflineOrFailedPriorToShutdown.append("SF1")
        if (self._dctGloInterDict["dctSubUnits"]["dctSF2"]["objClsSf2TransitionsManager"].state not in ["OFFLINE", "FAILED"]):
            self._lstModulesNotOfflineOrFailedPriorToShutdown.append("SF2")
        if (self._dctGloInterDict["dctSubUnits"]["dctSF3"]["objClsSf3TransitionsManager"].state not in ["OFFLINE", "FAILED"]):
            self._lstModulesNotOfflineOrFailedPriorToShutdown.append("SF3")
        if (self._dctGloInterDict["dctSubUnits"]["dctHMIAPM"]["objClsHmiApmTransitionsManager"].state not in ["OFFLINE", "FAILED"]):
            self._lstModulesNotOfflineOrFailedPriorToShutdown.append("HMI_APM")
        if (self._dctGloInterDict["dctSubUnits"]["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"].state not in ["OFFLINE", "FAILED"]):
            self._lstModulesNotOfflineOrFailedPriorToShutdown.append("HMI_APM_FCO")
        if (self._dctGloInterDict["dctSubUnits"]["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].state not in ["OFFLINE", "FAILED"]):
            self._lstModulesNotOfflineOrFailedPriorToShutdown.append("HMI_FCO")
        if (self._dctGloInterDict["dctSubUnits"]["dctHMISPM"]["objClsHmiSpmTransitionsManager"].state not in ["OFFLINE", "FAILED"]):
            self._lstModulesNotOfflineOrFailedPriorToShutdown.append("HMI_SPM")
        if (self._dctGloInterDict["dctSubUnits"]["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"].state not in ["OFFLINE", "FAILED"]):
            self._lstModulesNotOfflineOrFailedPriorToShutdown.append("HMI_SPM_FUFC")
        if (self._dctGloInterDict["dctSubUnits"]["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"].state not in ["OFFLINE", "FAILED"]):
            self._lstModulesNotOfflineOrFailedPriorToShutdown.append("HMI_FUFC")
        if (self._dctGloInterDict["dctSubUnits"]["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"].state not in ["OFFLINE", "FAILED"]):
            self._lstModulesNotOfflineOrFailedPriorToShutdown.append("HMI_Maintainer")
        if (self._dctGloInterDict["dctSubUnits"]["dctHMIOversight"]["objClsHmiOversightTransitionsManager"].state not in ["OFFLINE", "FAILED"]):
            self._lstModulesNotOfflineOrFailedPriorToShutdown.append("HMI_Oversight")

        # Update the group status tree if the OLHM state changed
        self._dctGloInterDict["dctOLHM"]["objClsOlhmManager"].vSetOlhmState()

        # Using the asyncio loop create a task to send out the shutdown commands and wait for their reply
        self._dctGloInterDict["dctAsyncio"]["objAsyncioLoopPar"].create_task(self._vSendOutShutdownCommandsAndWaitForReply())

        return

    def _vOnEnter_FAILED(self):
        """ This is a private method which is called when the state machine enters the FAILED state.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        clsStateMachineUtilities.vLogTransitionsStateCurrent(self.state, self._acUnit)  # pylint: disable=no-member
        self._vCapturePreviousState()

        logging.error("The OLHM is in a FAILED state")

        # Update the group status tree if the OLHM state changed
        self._dctGloInterDict["dctOLHM"]["objClsOlhmManager"].vSetOlhmState()

        logging.info("Shutting down the OLHM because we are in FAILED state")
        time.sleep(0.5)

        # Shut down the OLHM as the SRS describes
        sys.exit()

        return

    def _bValidationAndSelfCheckPassed(self) -> bool:
        """ This is a private method which indicates if the validation and self check passed.

        Args:

        Returns:
            (bool): Bool inidicating if validation and self check passed

        Raises:
            Raises no exception.
        """

        return(self._bValidationAndSelfCheckPassedProperty)

    def vProcessState(self, objDateTimeCurrent=None):  # pylint: disable=unused-argument
        """ This is a public method which monitors and drives the state of the IFF

        Args:
            objDateTimeCurrent (datetime): The first parameter. The current datetime.

        Returns:

        Raises:
            Raises no exception.
        """
        bAllSubUnitsAreReady = bool(False)
        bAllSubUnitsAreOperational = bool(False)
        bAllSubUnitsAreShutdown = bool(False)

        if (self.state == "OFFLINE"):  # pylint: disable=no-member
            # This will only happen the first time we start up
            self.trgINITIALISE()  # pylint: disable=no-member

        # Starting at READY to the OPERATION is the start-up sequence as described by the SRS
        if (self.state == "READY"):  # pylint: disable=no-member

            bAllSubUnitsAreReady = clsOlhmTransitionRules.bAreSelectedSubunitsASpecificState(self._dctGloInterDict["dctSubUnits"], self._dctGloInterDict["dctOLHM"]["dctSubUnitNameToStateMachineLookup"], self._lstModulesIncludedInStartup, "READY")
            bAllSubUnitsAreOperational = clsOlhmTransitionRules.bAreSelectedSubunitsASpecificState(self._dctGloInterDict["dctSubUnits"], self._dctGloInterDict["dctOLHM"]["dctSubUnitNameToStateMachineLookup"], self._lstModulesIncludedInStartup, "OPERATIONAL")

            if (bAllSubUnitsAreReady is True):
                if (self._bEndOfReadySentToAllCompleted is False):
                    self._vSendEndOfReadyToAll(self._lstModulesIncludedInStartup)
                    self._bEndOfReadySentToAllCompleted = bool(True)
            elif (bAllSubUnitsAreOperational is True):
                self.trgOPERATIONAL()  # pylint: disable=no-member

        if (self.state == "SHUTDOWN"):  # pylint: disable=no-member
            bAllSubUnitsAreShutdown = clsOlhmTransitionRules.bAreSelectedSubunitsASpecificState(self._dctGloInterDict["dctSubUnits"], self._dctGloInterDict["dctOLHM"]["dctSubUnitNameToStateMachineLookup"], self._lstModulesNotOfflineOrFailedPriorToShutdown, "SHUTDOWN")

            if (bAllSubUnitsAreShutdown is True):
                logging.info("The OLHM is shutting down now")

                if ((self._dctGloInterDict is not None) and (self._dctGloInterDict["dctOLHM"]["objClsOlhmConstructGroupStatus"] is not None)):
                    self._dctGloInterDict["dctOLHM"]["objClsOlhmConstructGroupStatus"].vSendOlhmAdcsStatusUnsol()
                    self._dctGloInterDict["dctOLHM"]["objClsOlhmConstructGroupStatus"].vSendOlhmAdcsHmiStatusUnsol()

                    self._dctGloInterDict["dctAsyncio"]["objAsyncioLoopPar"].create_task(self._vAsyncWaitAndSysExit())

        return

    def vTriggerShutdown(self, acCommandingMessagePar: str):
        """ This is a public method which calls the trgSHUTDOWN() trigger.

        Args:
            objDateTimeCurrent (datetime): The first parameter. The current datetime.

        Returns:

        Raises:
            Raises no exception.
        """

        if (acCommandingMessagePar in self._lstMessagesForWhichShutdownIsAllowed):
            self._acLastShutdownCommandingMessage = acCommandingMessagePar

        self.trgSHUTDOWN()  # pylint: disable=no-member

        return

    def _bIsAllSubunitsSetupParams(self) -> bool:
        """ This is a private method which checks if all the subunits are SETUP_PARAMS

        Args:

        Returns:
            (bool): Flag to indicate if the units are all SETUP_PARAMS

        Raises:
            Raises no exception.
        """

        if ((self._dctGloInterDict["dctSubUnits"]["dctIFF"]["objClsIffTransitionsManager"].state == "SETUP_PARAMS") and  # noqa: W504
                (self._dctGloInterDict["dctSubUnits"]["dctAIS"]["objClsAisTransitionsManager"].state == "SETUP_PARAMS") and  # noqa: W504
                (self._dctGloInterDict["dctSubUnits"]["dctDEU"]["objClsDeuTransitionsManager"].state == "SETUP_PARAMS") and  # noqa: W504
                (self._dctGloInterDict["dctSubUnits"]["dctDFE"]["objClsDfeTransitionsManager"].state == "SETUP_PARAMS") and  # noqa: W504
                (self._dctGloInterDict["dctSubUnits"]["dctPDU"]["objClsPduTransitionsManager"].state == "SETUP_PARAMS") and  # noqa: W504
                (self._dctGloInterDict["dctSubUnits"]["dctTTS"]["objClsTtsTransitionsManager"].state == "SETUP_PARAMS") and  # noqa: W504
                (self._dctGloInterDict["dctSubUnits"]["dctSSP"]["objClsSspTransitionsManager"].state == "SETUP_PARAMS")):
            return(True)
        else:
            return(False)

        return(False)

    def _vSendEndOfSetupToAll(self, lstSelectedModulesPar: list):
        """ This is a private method which sends EndOfSetup messages to all subunits.

        If the list of selected modules is empty all messages will be sent out.

        Args:
            lstSelectedModulesPar(list): A list of modules to send to

        Returns:

        Raises:
            Raises no exception.
        """

        if (self._dctGloInterDict is None):
            logging.error("self._dctGloInterDict cannot be None")
            return

        if (self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"] is None):
            logging.error("objClsMessageProcessForMqtt cannot be None")
            return

        if ((not lstSelectedModulesPar) or ("DR" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendDrEndOfSetupCmd()

        # The PDBP goes into READY automatically so there is not method call for it here

        if ((not lstSelectedModulesPar) or ("EIU" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendEiuEndOfSetupCmd()
        if ((not lstSelectedModulesPar) or ("TM" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendTmEndOfSetupCmd()
        if ((not lstSelectedModulesPar) or ("TEWA" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendTewaEndOfSetupCmd()
        if ((not lstSelectedModulesPar) or ("SF1" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendSf1EndOfSetupCmd()
        if ((not lstSelectedModulesPar) or ("SF2" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendSf2EndOfSetupCmd()
        if ((not lstSelectedModulesPar) or ("SF3" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendSf3EndOfSetupCmd()
        if ((not lstSelectedModulesPar) or ("HMI_APM" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiEndOfSetupCmdAPM()
        if ((not lstSelectedModulesPar) or ("HMI_APM_FCO" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiEndOfSetupCmdAPM_FCO()
        if ((not lstSelectedModulesPar) or ("HMI_FCO" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiEndOfSetupCmdFCO()
        if ((not lstSelectedModulesPar) or ("HMI_FUFC" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiEndOfSetupCmdFUFC()
        if ((not lstSelectedModulesPar) or ("HMI_SPM_FUFC" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiEndOfSetupCmdSPM_FUFC()
        if ((not lstSelectedModulesPar) or ("HMI_SPM" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiEndOfSetupCmdSPM()
        if ((not lstSelectedModulesPar) or ("HMI_Maintainer" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiEndOfSetupCmdMaintainer()
        if ((not lstSelectedModulesPar) or ("HMI_Oversight" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiEndOfSetupCmdOversight()

        return

    def _vSendEndOfReadyToAll(self, lstSelectedModulesPar: list):
        """ This is a private method which sends EndOfReady messages to all subunits

        If the list of selected modules is empty all messages will be sent out.

        Args:
            lstSelectedModulesPar(list): A list of modules to send to

        Returns:

        Raises:
            Raises no exception.
        """

        if (self._dctGloInterDict is None):
            logging.error("self._dctGloInterDict cannot be None")
            return

        if (self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"] is None):
            logging.error("objClsMessageProcessForMqtt cannot be None")
            return

        if ((not lstSelectedModulesPar) or ("DR" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendDrEndOfReadyCmd()
        if ((not lstSelectedModulesPar) or ("PDBP" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendPdbpEndOfReadyCmd()
        if ((not lstSelectedModulesPar) or ("EIU" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendEiuEndOfReadyCmd()
        if ((not lstSelectedModulesPar) or ("TM" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendTmEndOfReadyCmd()
        if ((not lstSelectedModulesPar) or ("TEWA" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendTewaEndOfReadyCmd()
        if ((not lstSelectedModulesPar) or ("SF1" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendSf1EndOfReadyCmd()
        if ((not lstSelectedModulesPar) or ("SF2" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendSf2EndOfReadyCmd()
        if ((not lstSelectedModulesPar) or ("SF3" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendSf3EndOfReadyCmd()
        if ((not lstSelectedModulesPar) or ("HMI_APM" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiEndOfReadyCmdAPM()
        if ((not lstSelectedModulesPar) or ("HMI_APM_FCO" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiEndOfReadyCmdAPM_FCO()
        if ((not lstSelectedModulesPar) or ("HMI_FCO" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiEndOfReadyCmdFCO()
        if ((not lstSelectedModulesPar) or ("HMI_FUFC" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiEndOfReadyCmdFUFC()
        if ((not lstSelectedModulesPar) or ("HMI_SPM_FUFC" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiEndOfReadyCmdSPM_FUFC()
        if ((not lstSelectedModulesPar) or ("HMI_SPM" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiEndOfReadyCmdSPM()
        if ((not lstSelectedModulesPar) or ("HMI_Maintainer" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiEndOfReadyCmdMaintainer()
        if ((not lstSelectedModulesPar) or ("HMI_Oversight" in lstSelectedModulesPar)):
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiEndOfReadyCmdOversight()

        return

    def vSetValidationAndSelfCheckState(self, bValidationAndSelfCheckPassedPar: bool) -> bool:
        """ This is a public method which sets the self._bValidationAndSelfCheckPassedProperty property

        Args:
            bValidationAndSelfCheckPassedPar (bool): Flag indicating if the validation and self check passed

        Returns:

        Raises:
            Raises no exception.
        """
        self._bValidationAndSelfCheckPassedProperty = bValidationAndSelfCheckPassedPar

        return

    async def _vSendOutShutdownCommandsAndWaitForReply(self):
        """ This is a public async method which sends out shutdown commands and wait for their replies

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        e1OlhmActionStatusReport = E1_OLHM_ACTION_STATUS_REPORT(E1_OLHM_ACTION_STATUS_REPORT.OLHM_ACTION_STATUS_REPORT_OUT_OF_ACTION)
        lstMessageToSendCmd = []
        lstMessageToSendCmdRsp = []  # pylint: disable=unused-variable
        dctMessages = {}
        fShutdownCommandResponseTimeoutThresholdS = 0.5

        # Do some sanity checks

        if (self._dctGloInterDict is None):
            logging.error("self._dctGloInterDict cannot be None")
            return

        if (self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"] is None):
            logging.error("objClsMessageProcessForMqtt cannot be None")
            return

        logging.info("Sending Action Status Report: Out-Of-Action")

        # Now send the action status report
        self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendOlhmActionStatusReportUnsol(e1OlhmActionStatusReport)

        # Build up a list of shutdown commands to send
        dctMessages = {}
        dctMessages["tplMessageTypeRolePairCmd"] = ((sDR_SHUTDOWN_CMD), "")
        dctMessages["tplMessageTypeRolePairRsp"] = ((sDR_SHUTDOWN_CMD_RSP), "")
        dctMessages["objCmdMessage"] = sDR_SHUTDOWN_CMD()
        dctMessages["objCmdRspMessage"] = None
        dctMessages["fTimeoutPeriodS"] = float(fShutdownCommandResponseTimeoutThresholdS)

        if ("DR" in self._lstModulesNotOfflineOrFailedPriorToShutdown):
            lstMessageToSendCmd += [dctMessages]

        dctMessages = {}
        dctMessages["tplMessageTypeRolePairCmd"] = ((sPDBP_SHUTDOWN_CMD), "")
        dctMessages["tplMessageTypeRolePairRsp"] = ((sPDBP_SHUTDOWN_CMD_RSP), "")
        dctMessages["objCmdMessage"] = sPDBP_SHUTDOWN_CMD()
        dctMessages["objCmdRspMessage"] = None
        dctMessages["fTimeoutPeriodS"] = float(fShutdownCommandResponseTimeoutThresholdS)

        if ("PDBP" in self._lstModulesNotOfflineOrFailedPriorToShutdown):
            lstMessageToSendCmd += [dctMessages]

        dctMessages = {}
        dctMessages["tplMessageTypeRolePairCmd"] = ((sEIU_SHUTDOWN_CMD), "")
        dctMessages["tplMessageTypeRolePairRsp"] = ((sEIU_SHUTDOWN_CMD_RSP), "")
        dctMessages["objCmdMessage"] = sEIU_SHUTDOWN_CMD()
        dctMessages["objCmdRspMessage"] = None
        dctMessages["fTimeoutPeriodS"] = float(fShutdownCommandResponseTimeoutThresholdS)

        if ("EIU" in self._lstModulesNotOfflineOrFailedPriorToShutdown):
            lstMessageToSendCmd += [dctMessages]

        dctMessages = {}
        dctMessages["tplMessageTypeRolePairCmd"] = ((sTM_SHUTDOWN_CMD), "")
        dctMessages["tplMessageTypeRolePairRsp"] = ((sTM_SHUTDOWN_CMD_RSP), "")
        dctMessages["objCmdMessage"] = sTM_SHUTDOWN_CMD()
        dctMessages["objCmdRspMessage"] = None
        dctMessages["fTimeoutPeriodS"] = float(fShutdownCommandResponseTimeoutThresholdS)

        if ("TM" in self._lstModulesNotOfflineOrFailedPriorToShutdown):
            lstMessageToSendCmd += [dctMessages]

        dctMessages = {}
        dctMessages["tplMessageTypeRolePairCmd"] = ((sTEWA_SHUTDOWN_CMD), "")
        dctMessages["tplMessageTypeRolePairRsp"] = ((sTEWA_SHUTDOWN_CMD_RSP), "")
        dctMessages["objCmdMessage"] = sTEWA_SHUTDOWN_CMD()
        dctMessages["objCmdRspMessage"] = None
        dctMessages["fTimeoutPeriodS"] = float(fShutdownCommandResponseTimeoutThresholdS)

        if ("TEWA" in self._lstModulesNotOfflineOrFailedPriorToShutdown):
            lstMessageToSendCmd += [dctMessages]

        dctMessages = {}
        dctMessages["tplMessageTypeRolePairCmd"] = ((sSF1_SHUTDOWN_CMD), "")
        dctMessages["tplMessageTypeRolePairRsp"] = ((sSF1_SHUTDOWN_CMD_RSP), "")
        dctMessages["objCmdMessage"] = sSF1_SHUTDOWN_CMD()
        dctMessages["objCmdRspMessage"] = None
        dctMessages["fTimeoutPeriodS"] = float(fShutdownCommandResponseTimeoutThresholdS)

        if ("SF1" in self._lstModulesNotOfflineOrFailedPriorToShutdown):
            lstMessageToSendCmd += [dctMessages]

        dctMessages = {}
        dctMessages["tplMessageTypeRolePairCmd"] = ((sSF2_SHUTDOWN_CMD), "")
        dctMessages["tplMessageTypeRolePairRsp"] = ((sSF2_SHUTDOWN_CMD_RSP), "")
        dctMessages["objCmdMessage"] = sSF2_SHUTDOWN_CMD()
        dctMessages["objCmdRspMessage"] = None
        dctMessages["fTimeoutPeriodS"] = float(fShutdownCommandResponseTimeoutThresholdS)

        if ("SF2" in self._lstModulesNotOfflineOrFailedPriorToShutdown):
            lstMessageToSendCmd += [dctMessages]

        dctMessages = {}
        dctMessages["tplMessageTypeRolePairCmd"] = ((sSF3_SHUTDOWN_CMD), "")
        dctMessages["tplMessageTypeRolePairRsp"] = ((sSF3_SHUTDOWN_CMD_RSP), "")
        dctMessages["objCmdMessage"] = sSF3_SHUTDOWN_CMD()
        dctMessages["objCmdRspMessage"] = None
        dctMessages["fTimeoutPeriodS"] = float(fShutdownCommandResponseTimeoutThresholdS)

        if ("SF3" in self._lstModulesNotOfflineOrFailedPriorToShutdown):
            lstMessageToSendCmd += [dctMessages]

        dctMessages = {}
        dctMessages["tplMessageTypeRolePairCmd"] = ((sHMI_SHUTDOWN_CMD), "APM")
        dctMessages["tplMessageTypeRolePairRsp"] = ((sHMI_SHUTDOWN_CMD_RSP), "APM")
        dctMessages["objCmdMessage"] = sHMI_SHUTDOWN_CMD()
        dctMessages["objCmdRspMessage"] = None
        dctMessages["fTimeoutPeriodS"] = float(fShutdownCommandResponseTimeoutThresholdS)

        if ("HMI_APM" in self._lstModulesNotOfflineOrFailedPriorToShutdown):
            lstMessageToSendCmd += [dctMessages]

        dctMessages = {}
        dctMessages["tplMessageTypeRolePairCmd"] = ((sHMI_SHUTDOWN_CMD), "APM_FCO")
        dctMessages["tplMessageTypeRolePairRsp"] = ((sHMI_SHUTDOWN_CMD_RSP), "APM_FCO")
        dctMessages["objCmdMessage"] = sHMI_SHUTDOWN_CMD()
        dctMessages["objCmdRspMessage"] = None
        dctMessages["fTimeoutPeriodS"] = float(fShutdownCommandResponseTimeoutThresholdS)

        if ("HMI_APM_FCO" in self._lstModulesNotOfflineOrFailedPriorToShutdown):
            lstMessageToSendCmd += [dctMessages]

        dctMessages = {}
        dctMessages["tplMessageTypeRolePairCmd"] = ((sHMI_SHUTDOWN_CMD), "FCO")
        dctMessages["tplMessageTypeRolePairRsp"] = ((sHMI_SHUTDOWN_CMD_RSP), "FCO")
        dctMessages["objCmdMessage"] = sHMI_SHUTDOWN_CMD()
        dctMessages["objCmdRspMessage"] = None
        dctMessages["fTimeoutPeriodS"] = float(fShutdownCommandResponseTimeoutThresholdS)

        if ("HMI_FCO" in self._lstModulesNotOfflineOrFailedPriorToShutdown):
            lstMessageToSendCmd += [dctMessages]

        dctMessages = {}
        dctMessages["tplMessageTypeRolePairCmd"] = ((sHMI_SHUTDOWN_CMD), "SPM")
        dctMessages["tplMessageTypeRolePairRsp"] = ((sHMI_SHUTDOWN_CMD_RSP), "SPM")
        dctMessages["objCmdMessage"] = sHMI_SHUTDOWN_CMD()
        dctMessages["objCmdRspMessage"] = None
        dctMessages["fTimeoutPeriodS"] = float(fShutdownCommandResponseTimeoutThresholdS)

        if ("HMI_SPM" in self._lstModulesNotOfflineOrFailedPriorToShutdown):
            lstMessageToSendCmd += [dctMessages]

        dctMessages = {}
        dctMessages["tplMessageTypeRolePairCmd"] = ((sHMI_SHUTDOWN_CMD), "SPM_FUFC")
        dctMessages["tplMessageTypeRolePairRsp"] = ((sHMI_SHUTDOWN_CMD_RSP), "SPM_FUFC")
        dctMessages["objCmdMessage"] = sHMI_SHUTDOWN_CMD()
        dctMessages["objCmdRspMessage"] = None
        dctMessages["fTimeoutPeriodS"] = float(fShutdownCommandResponseTimeoutThresholdS)

        if ("HMI_SPM_FUFC" in self._lstModulesNotOfflineOrFailedPriorToShutdown):
            lstMessageToSendCmd += [dctMessages]

        dctMessages = {}
        dctMessages["tplMessageTypeRolePairCmd"] = ((sHMI_SHUTDOWN_CMD), "FUFC")
        dctMessages["tplMessageTypeRolePairRsp"] = ((sHMI_SHUTDOWN_CMD_RSP), "FUFC")
        dctMessages["objCmdMessage"] = sHMI_SHUTDOWN_CMD()
        dctMessages["objCmdRspMessage"] = None
        dctMessages["fTimeoutPeriodS"] = float(fShutdownCommandResponseTimeoutThresholdS)

        if ("HMI_FUFC" in self._lstModulesNotOfflineOrFailedPriorToShutdown):
            lstMessageToSendCmd += [dctMessages]

        dctMessages = {}
        dctMessages["tplMessageTypeRolePairCmd"] = ((sHMI_SHUTDOWN_CMD), "Maintainer")
        dctMessages["tplMessageTypeRolePairRsp"] = ((sHMI_SHUTDOWN_CMD_RSP), "Maintainer")
        dctMessages["objCmdMessage"] = sHMI_SHUTDOWN_CMD()
        dctMessages["objCmdRspMessage"] = None
        dctMessages["fTimeoutPeriodS"] = float(fShutdownCommandResponseTimeoutThresholdS)

        if ("HMI_Maintainer" in self._lstModulesNotOfflineOrFailedPriorToShutdown):
            lstMessageToSendCmd += [dctMessages]

        dctMessages = {}
        dctMessages["tplMessageTypeRolePairCmd"] = ((sHMI_SHUTDOWN_CMD), "Oversight")
        dctMessages["tplMessageTypeRolePairRsp"] = ((sHMI_SHUTDOWN_CMD_RSP), "Oversight")
        dctMessages["objCmdMessage"] = sHMI_SHUTDOWN_CMD()
        dctMessages["objCmdRspMessage"] = None
        dctMessages["fTimeoutPeriodS"] = float(fShutdownCommandResponseTimeoutThresholdS)

        if ("HMI_Oversight" in self._lstModulesNotOfflineOrFailedPriorToShutdown):
            lstMessageToSendCmd += [dctMessages]

        lstMessageToSendCmdRsp = await self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].lstSendListOfMessagesAndWaitForResponse(lstMessageToSendCmd)  # noqa: F841

        if (self._acLastShutdownCommandingMessage):
            if (self._acLastShutdownCommandingMessage == "OlhmAdcsShutdownCmd"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendOlhmAdcsShutdownCmdRsp()
                self._acLastShutdownCommandingMessage = str("")
            elif (self._acLastShutdownCommandingMessage == "MmsShutdownCmd"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendMmsShutdownCmdRsp()
                self._acLastShutdownCommandingMessage = str("")
            elif (self._acLastShutdownCommandingMessage == "HmiAdcsShutdownCmdAPM"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiAdcsShutdownCmdRspAPM()
                self._acLastShutdownCommandingMessage = str("")
            elif (self._acLastShutdownCommandingMessage == "HmiAdcsShutdownCmdAPM_FCO"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiAdcsShutdownCmdRspAPM_FCO()
                self._acLastShutdownCommandingMessage = str("")
            elif (self._acLastShutdownCommandingMessage == "HmiAdcsShutdownCmdFCO"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiAdcsShutdownCmdRspFCO()
                self._acLastShutdownCommandingMessage = str("")
            elif (self._acLastShutdownCommandingMessage == "HmiAdcsShutdownCmdSPM"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiAdcsShutdownCmdRspSPM()
                self._acLastShutdownCommandingMessage = str("")
            elif (self._acLastShutdownCommandingMessage == "HmiAdcsShutdownCmdSPM_FUFC"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiAdcsShutdownCmdRspSPM_FUFC()
                self._acLastShutdownCommandingMessage = str("")
            elif (self._acLastShutdownCommandingMessage == "HmiAdcsShutdownCmdFUFC"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiAdcsShutdownCmdRspFUFC()
                self._acLastShutdownCommandingMessage = str("")
            elif (self._acLastShutdownCommandingMessage == "HmiAdcsShutdownCmdMaintainer"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiAdcsShutdownCmdRspMaintainer()
                self._acLastShutdownCommandingMessage = str("")
            elif (self._acLastShutdownCommandingMessage == "HmiAdcsShutdownCmdOversight"):
                self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendHmiAdcsShutdownCmdRspOversight()
                self._acLastShutdownCommandingMessage = str("")

        return

    async def _vAsyncWaitAndSysExit(self):
        """ This is a public async method which asyncio waits and then calls the sys.exit

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        await asyncio.sleep(0.5)

        sys.exit()

        return(None)
