#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which cotains rules related to when transitions should be made

Todo:

"""


class clsOlhmTransitionRules:
    """ This class contains rules related to when transitions should be made

    Args:

    """

    @staticmethod
    def bAreSelectedSubunitsASpecificState(dctSubUnitsPar: dict, dctModuleNameToDictKeyLookupsPar: dict, lstSelectedModulesPar: list, acSelectedStatePar: str) -> bool:
        """ This is a public static method which checks if a selected set of subunits are in a specific state

        Args:
            dctSubUnitsPar (dict): A dictionary with all the subunits
            dctModuleNameToDictKeyLookupsPar (dict): A dictionary with tuple values for each module name
            lstSelectedModulesPar (list): The list of modules for which this applies
            acSelectedStatePar (str): The specific state we are testing for

        Returns:
            (bool): Flag to indicate if the units are all SHUTDOWN

        Raises:
            Raises no exception.
        """

        # Get the dict keys to get to module state machine objects of the selected modules
        lstModuleDictKeys = [dctModuleNameToDictKeyLookupsPar[acModule] for acModule in lstSelectedModulesPar]
        # Get all the state machines for the selected modules
        lstModulesStateMachineObjects = [dctSubUnitsPar[tplKeys[0]][tplKeys[1]] for tplKeys in lstModuleDictKeys]
        # Make a list of states which match the selected state
        lstModuleStatesInSelectedState = [objTrans.state for objTrans in lstModulesStateMachineObjects if objTrans.state == acSelectedStatePar]

        return(len(lstModuleStatesInSelectedState) == len(lstSelectedModulesPar))
