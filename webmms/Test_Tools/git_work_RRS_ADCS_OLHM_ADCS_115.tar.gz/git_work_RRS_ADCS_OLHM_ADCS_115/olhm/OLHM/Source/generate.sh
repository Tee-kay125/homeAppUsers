#!/bin/bash

rm -f Autogen/*.py
rm -f Autogen/*.sha1
cd ../../
./generate_autogen.sh