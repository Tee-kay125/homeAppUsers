#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module manages the lauching, management and killing of external processes.

Todo:

"""
from python_toolbox.Process_Monitoring_And_Management.process_monitoring_and_management import clsProcessMonitoringAndManagement


class clsOlhmLauncherManager():
    """This is a class used to launch, stop and generally manage the external processes needed by the OLHM.

    Args:
        dctGlobalInterfaceDictionaryPar (object): The first parameter. The global interface dictionary.

    """
    def __init__(self, dctGlobalInterfaceDictionaryPar: object):
        super().__init__()
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar

        return

    def vGetGitHash(self):
        """ This is a public method which gets the GIT hash

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        # Run this script to get the current git hash
        clsProcessMonitoringAndManagement.bRunProcessUsingSubprocessRun("./get_git_repo_hash.sh")

        return
