#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which processes messages received

This module provides a class which processes messages received. This class will inherit
autogen class clsMessageProcess from message_processing.py

Todo:

"""
import sys
import os
import logging
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
from External_Interfaces.OLHM.asyncio_msg_processing_class_olhm import clsAsyncioMsgProcessingClassOlhm
from External_Interfaces.DR.asyncio_msg_processing_class_dr import clsAsyncioMsgProcessingClassDr
from External_Interfaces.PDBP.asyncio_msg_processing_class_pdbp import clsAsyncioMsgProcessingClassPdbp
from External_Interfaces.PDBP.asyncio_msg_processing_class_pdbp import E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE
from External_Interfaces.EIU.asyncio_msg_processing_class_eiu import clsAsyncioMsgProcessingClassEiu
from External_Interfaces.TM.asyncio_msg_processing_class_tm import clsAsyncioMsgProcessingClassTm
from External_Interfaces.TEWA.asyncio_msg_processing_class_tewa import clsAsyncioMsgProcessingClassTewa
from External_Interfaces.SF1.asyncio_msg_processing_class_sf1 import clsAsyncioMsgProcessingClassSf1
from External_Interfaces.SF2.asyncio_msg_processing_class_sf2 import clsAsyncioMsgProcessingClassSf2
from External_Interfaces.SF3.asyncio_msg_processing_class_sf3 import clsAsyncioMsgProcessingClassSf3
from External_Interfaces.HMI_APM.asyncio_msg_processing_class_hmi_apm import clsAsyncioMsgProcessingClassHmiApm
from External_Interfaces.HMI_APM_FCO.asyncio_msg_processing_class_hmi_apm_fco import clsAsyncioMsgProcessingClassHmiApmFco
from External_Interfaces.HMI_FCO.asyncio_msg_processing_class_hmi_fco import clsAsyncioMsgProcessingClassHmiFco
from External_Interfaces.HMI_SPM.asyncio_msg_processing_class_hmi_spm import clsAsyncioMsgProcessingClassHmiSpm
from External_Interfaces.HMI_SPM_FUFC.asyncio_msg_processing_class_hmi_spm_fufc import clsAsyncioMsgProcessingClassHmiSpmFufc
from External_Interfaces.HMI_FUFC.asyncio_msg_processing_class_hmi_fufc import clsAsyncioMsgProcessingClassHmiFufc
from External_Interfaces.HMI_Maintainer.asyncio_msg_processing_class_hmi_maintainer import clsAsyncioMsgProcessingClassHmiMaintainer
from External_Interfaces.HMI_Oversight.asyncio_msg_processing_class_hmi_oversight import clsAsyncioMsgProcessingClassHmiOversight
from External_Interfaces.MMS.asyncio_msg_processing_class_mms import clsAsyncioMsgProcessingClassMms
from python_toolbox.Autogen_Utilities.asyncio_utilities import clsAsyncioUtilities

# OLHM
from Autogen.olhm_msg import sOLHM_ADCS_STATUS_UNSOL
from Autogen.olhm_msg import sOLHM_ADCS_HMI_STATUS_UNSOL
from Autogen.olhm_msg import sOLHM_ADCS_SHUTDOWN_CMD_RSP
from Autogen.olhm_msg import sOLHM_ACTION_STATUS_REPORT_UNSOL

# DR
from Autogen.dr_msg import sDR_END_OF_SETUP_CMD
from Autogen.dr_msg import sDR_END_OF_READY_CMD
from Autogen.dr_msg import sDR_SHUTDOWN_CMD

# PDBP
from Autogen.pdbp_msg import sPDBP_END_OF_READY_CMD
from Autogen.pdbp_msg import sPDBP_SHUTDOWN_CMD
from Autogen.pdbp_msg import sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD

# EIU
from Autogen.eiu_msg import sEIU_END_OF_SETUP_CMD
from Autogen.eiu_msg import sEIU_END_OF_READY_CMD
from Autogen.eiu_msg import sEIU_SHUTDOWN_CMD

# TM
from Autogen.tm_msg import sTM_END_OF_SETUP_CMD
from Autogen.tm_msg import sTM_END_OF_READY_CMD
from Autogen.tm_msg import sTM_SHUTDOWN_CMD

# TEWA
from Autogen.tewa_msg import sTEWA_END_OF_SETUP_CMD
from Autogen.tewa_msg import sTEWA_END_OF_READY_CMD
from Autogen.tewa_msg import sTEWA_SHUTDOWN_CMD

# SF1
from Autogen.sf1_msg import sSF1_END_OF_SETUP_CMD
from Autogen.sf1_msg import sSF1_END_OF_READY_CMD
from Autogen.sf1_msg import sSF1_SHUTDOWN_CMD
from Autogen.sf1_msg import sSF1_MODE_CMD_RSP

# SF2
from Autogen.sf2_msg import sSF2_END_OF_SETUP_CMD
from Autogen.sf2_msg import sSF2_END_OF_READY_CMD
from Autogen.sf2_msg import sSF2_SHUTDOWN_CMD

# SF3
from Autogen.sf3_msg import sSF3_END_OF_SETUP_CMD
from Autogen.sf3_msg import sSF3_END_OF_READY_CMD
from Autogen.sf3_msg import sSF3_SHUTDOWN_CMD

# HMI
from Autogen.hmi_msg import sHMI_END_OF_SETUP_CMD
from Autogen.hmi_msg import sHMI_END_OF_READY_CMD
from Autogen.hmi_msg import sHMI_SHUTDOWN_CMD
from Autogen.hmi_msg import sHMI_ADCS_SHUTDOWN_CMD_RSP

# MMS
from Autogen.mms_msg import sMMS_SHUTDOWN_CMD_RSP


# Note!!! In this list of multiple inheritance the clsAsyncioMsgProcessingClassOlhm one must be last in the list!!! This is because it will call the autogen base class constructor which takes less agruments
class clsMessageProcessForMqtt(clsAsyncioUtilities, clsAsyncioMsgProcessingClassDr, clsAsyncioMsgProcessingClassPdbp, clsAsyncioMsgProcessingClassEiu, clsAsyncioMsgProcessingClassTm, clsAsyncioMsgProcessingClassTewa, clsAsyncioMsgProcessingClassSf1, clsAsyncioMsgProcessingClassSf2, clsAsyncioMsgProcessingClassSf3, clsAsyncioMsgProcessingClassHmiApm, clsAsyncioMsgProcessingClassHmiApmFco, clsAsyncioMsgProcessingClassHmiFco, clsAsyncioMsgProcessingClassHmiSpm, clsAsyncioMsgProcessingClassHmiSpmFufc, clsAsyncioMsgProcessingClassHmiFufc, clsAsyncioMsgProcessingClassHmiMaintainer, clsAsyncioMsgProcessingClassHmiOversight, clsAsyncioMsgProcessingClassMms, clsAsyncioMsgProcessingClassOlhm):
    """ This is the message processing class

    This is the message processing class. It inherits clsMessageProcess.

    Args:
        objMqttClientPar (mqtt.Client): The first parameter. The instance of the MQTT client
        dctMessagesPar (dict): The second parameter. A dictionary containing all messages and futures for messages which were automatically processed by the autogen. This must be passed in for the autogen base class.
        objAsyncioLoopPar (object): The fourth parameter. The asyncio loop passed in so tasks can be created and for other asyncio functionality
        dctGlobalInterfaceDictionaryPar (dict): The sixth parameter. The interface's global dictionary.
        bLoggingEnabledPar (bool): The seventh parameter. A boolean flag indicating if logging should be done or not.
    """
    def __init__(self, objMqttClientPar: mqtt.Client, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar: bool = True):
        # Very important!!! The MRO (method resolution order) will not yet call the autogen base because it isn't last in the list of inheritance - therefore pass more parameter than used for the base class
        super(clsMessageProcessForMqtt, self).__init__(objMqttClientPar, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar)
        self._objMqttClient = objMqttClientPar
        self._dctMessages = dctMessagesPar
        # By default tasks are not allowed to run simultaneously for the same topic. To override just for example -> lstTasksAllowedForsimultaneousExecutionMqtt += ["ADCS/DR/DrStatusReportUnsol"]
        # This is a list of tasks which are allowed to have simultaneous execution for mqtt
        # Make the list empty for now - no simultaneous execution is allowed
        self._lstTasksAllowedForsimultaneousExecution = []
        self._dctReverseLookupClassNameToTopic = {}
        self._objAsyncioLoop = objAsyncioLoopPar
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar
        self._lstModulesToMonitor = dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstModulesToMonitor"]
        self._bLoggingEnabled = bLoggingEnabledPar

        self.bGenerateReverseTopicLookupDictionary()

        self.vGenerateMqttSpyJavaScriptFileForGroup()

        self._dctMessageCounters = {}
        # OLHM
        self._dctMessageCounters[(type(sOLHM_ADCS_STATUS_UNSOL()), "")] = int(0)
        self._dctMessageCounters[(type(sOLHM_ADCS_HMI_STATUS_UNSOL()), "")] = int(0)
        self._dctMessageCounters[(type(sOLHM_ADCS_SHUTDOWN_CMD_RSP()), "")] = int(0)
        self._dctMessageCounters[(type(sOLHM_ACTION_STATUS_REPORT_UNSOL()), "")] = int(0)

        # DR
        self._dctMessageCounters[(type(sDR_END_OF_SETUP_CMD()), "")] = int(0)
        self._dctMessageCounters[(type(sDR_END_OF_READY_CMD()), "")] = int(0)
        self._dctMessageCounters[(type(sDR_SHUTDOWN_CMD()), "")] = int(0)

        # PDBP
        self._dctMessageCounters[(type(sPDBP_END_OF_READY_CMD()), "")] = int(0)
        self._dctMessageCounters[(type(sPDBP_SHUTDOWN_CMD()), "")] = int(0)
        self._dctMessageCounters[(type(sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD()), "")] = int(0)

        # EIU
        self._dctMessageCounters[(type(sEIU_END_OF_SETUP_CMD()), "")] = int(0)
        self._dctMessageCounters[(type(sEIU_END_OF_READY_CMD()), "")] = int(0)
        self._dctMessageCounters[(type(sEIU_SHUTDOWN_CMD()), "")] = int(0)

        # TM
        self._dctMessageCounters[(type(sTM_END_OF_SETUP_CMD()), "")] = int(0)
        self._dctMessageCounters[(type(sTM_END_OF_READY_CMD()), "")] = int(0)
        self._dctMessageCounters[(type(sTM_SHUTDOWN_CMD()), "")] = int(0)

        # TEWA
        self._dctMessageCounters[(type(sTEWA_END_OF_SETUP_CMD()), "")] = int(0)
        self._dctMessageCounters[(type(sTEWA_END_OF_READY_CMD()), "")] = int(0)
        self._dctMessageCounters[(type(sTEWA_SHUTDOWN_CMD()), "")] = int(0)

        # SF1
        self._dctMessageCounters[(type(sSF1_END_OF_SETUP_CMD()), "")] = int(0)
        self._dctMessageCounters[(type(sSF1_END_OF_READY_CMD()), "")] = int(0)
        self._dctMessageCounters[(type(sSF1_SHUTDOWN_CMD()), "")] = int(0)
        self._dctMessageCounters[(type(sSF1_MODE_CMD_RSP()), "")] = int(0)

        # SF2
        self._dctMessageCounters[(type(sSF2_END_OF_SETUP_CMD()), "")] = int(0)
        self._dctMessageCounters[(type(sSF2_END_OF_READY_CMD()), "")] = int(0)
        self._dctMessageCounters[(type(sSF2_SHUTDOWN_CMD()), "")] = int(0)

        # SF3
        self._dctMessageCounters[(type(sSF3_END_OF_SETUP_CMD()), "")] = int(0)
        self._dctMessageCounters[(type(sSF3_END_OF_READY_CMD()), "")] = int(0)
        self._dctMessageCounters[(type(sSF3_SHUTDOWN_CMD()), "")] = int(0)

        # HMI_APM
        self._dctMessageCounters[(type(sHMI_END_OF_SETUP_CMD()), "APM")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_READY_CMD()), "APM")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_CMD()), "APM")] = int(0)
        self._dctMessageCounters[(type(sHMI_ADCS_SHUTDOWN_CMD_RSP()), "APM")] = int(0)

        # HMI_APM_FCO
        self._dctMessageCounters[(type(sHMI_END_OF_SETUP_CMD()), "APM_FCO")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_READY_CMD()), "APM_FCO")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_CMD()), "APM_FCO")] = int(0)
        self._dctMessageCounters[(type(sHMI_ADCS_SHUTDOWN_CMD_RSP()), "APM_FCO")] = int(0)

        # HMI_FCO
        self._dctMessageCounters[(type(sHMI_END_OF_SETUP_CMD()), "FCO")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_READY_CMD()), "FCO")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_CMD()), "FCO")] = int(0)
        self._dctMessageCounters[(type(sHMI_ADCS_SHUTDOWN_CMD_RSP()), "FCO")] = int(0)

        # HMI_SPM
        self._dctMessageCounters[(type(sHMI_END_OF_SETUP_CMD()), "SPM")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_READY_CMD()), "SPM")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_CMD()), "SPM")] = int(0)
        self._dctMessageCounters[(type(sHMI_ADCS_SHUTDOWN_CMD_RSP()), "SPM")] = int(0)

        # HMI_SPM_FUFC
        self._dctMessageCounters[(type(sHMI_END_OF_SETUP_CMD()), "SPM_FUFC")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_READY_CMD()), "SPM_FUFC")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_CMD()), "SPM_FUFC")] = int(0)
        self._dctMessageCounters[(type(sHMI_ADCS_SHUTDOWN_CMD_RSP()), "SPM_FUFC")] = int(0)

        # HMI_FUFC
        self._dctMessageCounters[(type(sHMI_END_OF_SETUP_CMD()), "FUFC")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_READY_CMD()), "FUFC")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_CMD()), "FUFC")] = int(0)
        self._dctMessageCounters[(type(sHMI_ADCS_SHUTDOWN_CMD_RSP()), "FUFC")] = int(0)

        # HMI_Maintainer
        self._dctMessageCounters[(type(sHMI_END_OF_SETUP_CMD()), "Maintainer")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_READY_CMD()), "Maintainer")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_CMD()), "Maintainer")] = int(0)
        self._dctMessageCounters[(type(sHMI_ADCS_SHUTDOWN_CMD_RSP()), "Maintainer")] = int(0)

        # HMI_Oversight
        self._dctMessageCounters[(type(sHMI_END_OF_SETUP_CMD()), "Oversight")] = int(0)
        self._dctMessageCounters[(type(sHMI_END_OF_READY_CMD()), "Oversight")] = int(0)
        self._dctMessageCounters[(type(sHMI_SHUTDOWN_CMD()), "Oversight")] = int(0)
        self._dctMessageCounters[(type(sHMI_ADCS_SHUTDOWN_CMD_RSP()), "Oversight")] = int(0)

        # MMS
        self._dctMessageCounters[(type(sMMS_SHUTDOWN_CMD_RSP()), "")] = int(0)

        self._dctPdbpDatabaseMessageResultStateDictionary = {}

        # This method call populates self._dctPdbpDatabaseMessageResultStateDictionary
        self._vPopulatePdbpDatabaseMessageResultStateDictionary()

        return

    async def vProcessDictObj(self, dctObjectPar) -> None:
        """ This is a public method which overloads the vProcessDictObj() method in the autogen base class.

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:

        Raises:
            Raises no exception.
        """
        # Get the module name from the topic
        acModuleName = self._acGetModuleNameFromTopic(dctObjectPar["Topic"])

        # See if we should ignore all messages from this module
        # Always let the OLHM messages through
        if ((acModuleName) and ((acModuleName in self._lstModulesToMonitor) or (acModuleName in ["OLHM", "MMS"]))):
            await super().vProcessDictObj(dctObjectPar)

        return

    def bPublishMqttAutogenObject(self, objAutogenObjectPar: object, acRolePar: str = "") -> bool:
        """ This is a public method which publishes a MQTT by just providing the message object.

        The reverse lookup dictionary is used to resolve an object to a topic. Then when we publish we easily
        know what the topic of the message should be.

        Args:
            objAutogenObjectPar (object): The first parameter. An autogen object containing a message.
            acRolePar (str): The second parameter. The HMI role if there is one.

        Returns:
            (bool): A boolean value indicating if the methods was successful.

        Raises:
            Raises no exception.
        """
        bReturnValue = bool(False)
        acTopic = str("")

        # The object sent in cannot be None
        if (objAutogenObjectPar is None):
            logging.error("objAutogenObjectPar cannot be None")
            return(bReturnValue)

        # The main autogen dictionary cannot be None
        if (self._dctMessages is None):
            logging.error("self._dctMessages cannot be None")
            return(bReturnValue)

        # pylint warning C0123 here is fine because there is no inheritance for this class
        if ((type(objAutogenObjectPar), acRolePar) in self._dctReverseLookupClassNameToTopic):
            # Get the topic of the message by using the reverse lookup dictionary
            acTopic = self._dctReverseLookupClassNameToTopic[(type(objAutogenObjectPar), acRolePar)]

            # To publish provide the topic, raw bytes, and flag to say if message is retained
            bReturnValue = self.bPublishMqttTopicAndData(acTopic, objAutogenObjectPar.btaSerialise())
        else:
            logging.error("The type of objAutogenObjectPar is not in the autogen message dictionary")
            bReturnValue = False

        return(bReturnValue)

    def bGenerateReverseTopicLookupDictionary(self):
        """ This is a public method iterates through the autogen message dictionary (self._dctMessages) and populates a new dictionary
        which will be used to resolve a class name to a topic. This is done so that the topic can be derived from the autogen and
        also so that we can access the self._dctMessages dictionary without searching through it.

        Args:

        Returns:
            (bool): A boolean value indicating if the methods was successful.

        Raises:
            Raises no exception.
        """
        bReturnValue = bool(False)
        lstTopicParts = []

        if (self._dctMessages is None):
            logging.error("self._dctMessages cannot be None")
            return(bReturnValue)

        # Iterate through the autogen message dictionary
        for dctItem in self._dctMessages.items():
            # Split the autogened topic in parts
            lstTopicParts = dctItem[0].split("/")

            # The topic must be made out of 3 or 4 parts
            if (len(lstTopicParts) not in [3, 4]):
                logging.error("The topic %s provided by the autogen is invalid - it must have 3 or 4 parts", dctItem[0])
                sys.exit()

            if (len(lstTopicParts) == 3):
                self._dctReverseLookupClassNameToTopic[(dctItem[1]["Class"], "")] = dctItem[0]
            elif (len(lstTopicParts) == 4):
                self._dctReverseLookupClassNameToTopic[(dctItem[1]["Class"], lstTopicParts[3])] = dctItem[0]

        return(True)

    def vGenerateMqttSpyJavaScriptFile(self, objAutogenObjectPar: object):
        """ This is a public method which generates a MQTT-Spy javascript text for testing purposes.

        Args:
            objAutogenObjectPar (object): The first parameter. An autogen object containing a message.

        Returns:

        Raises:
            Raises no exception.
        """

        bCanOpenForWrite = bool(False)
        btaRawPayload = bytes()
        acTopic = ""
        acOneLine = ""
        acFilename = ""

        acJsText = "// Wrap the script in a method, so that you can do \"return false;\" in case of an error or stop request \nfunction publish()\n{\n        data = ["

        if (objAutogenObjectPar is None):
            logging.error("objAutogenObjectPar cannot be None")
            return

        # pylint warning C0123 here is fine because there is no inheritance for this class
        if (type(objAutogenObjectPar) in self._dctReverseLookupClassNameToTopic):  # pylint: disable=unidiomatic-typecheck
            acTopic = self._dctReverseLookupClassNameToTopic[type(objAutogenObjectPar)]
            btaRawPayload = objAutogenObjectPar.StoreToStream()

            acFilename = os.path.join(self._dctGloInterDict["dctOLHM"]["acCurrentDirectory"], "../Mqtt_Scripts")

            if (os.path.exists(acFilename) is False):
                logging.error("Path does not exists")
                return

            acFilename = os.path.join(acFilename, "{}.js".format(acTopic).replace("/", "_"))

            bCanOpenForWrite = bool(False)
            try:
                file = open(acFilename, "w")
                bCanOpenForWrite = True
            except Exception as E:
                logging.error("Could not open file for write - Exceptions %s", str(E))

            if (bCanOpenForWrite is False):
                return

            for iIndex, u1Byte in enumerate(btaRawPayload):
                acOneLine += "0x{0:02x}".format(u1Byte)
                if (iIndex < (len(btaRawPayload) - 1)):
                    acOneLine += ","
            acOneLine += "]\n"

            acJsText += acOneLine
            acJsText += "        mqttspy.publish(\"{}\", data, 0, false);\n".format(acTopic)
            acJsText += "        return true;\n}\npublish();"
            file.write(acJsText)

            file.close()

        return

    def vGenerateMqttSpyJavaScriptFileForGroup(self):
        """ This is a public method which generates a MQTT-Spy javascripts for a group

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        return

    def vSendOutListOfDatabaseMessagesWithoutNeedingReply(self, lstMessageTopicsPar: list):
        """ This is a public method which retrieves a list of database messages from the database and then sends them out
        without waiting for a reply.

        Args:
            lstMessageTopicsPar (list): The first parameter. A list of strings (message topics).

        Returns:

        Raises:
            Raises no exception.
        """

        if (isinstance(lstMessageTopicsPar, list) is False):
            logging.error("lstMessageTopicsPar must be a list")
            return

        if (self._dctGloInterDict is None):
            logging.error("_dctGloInterDict cannot be None")
            return

        return

    def vIncreaseMessageCounter(self, tplDictKeyPar: tuple):
        """ This is a public method which increases the message counter of a specific message

        Args:
            tplDictKeyPar (tuple): The first parameter. The key we will use for the counter dictionary

        Returns:

        Raises:
            Raises no exception.
        """
        iCountValue = int(0)

        if (tplDictKeyPar is None):
            logging.error("tplDictKeyPar cannot be None")
            return

        if (isinstance(tplDictKeyPar, tuple) is False):
            logging.error("tplDictKeyPar must be a tuple")
            return

        if (len(tplDictKeyPar) != 2):
            logging.error("tplDictKeyPar must be of length 2")
            return

        if (tplDictKeyPar not in self._dctMessageCounters):
            logging.error("tplDictKeyPar is not a key for self._dctMessageCounters")
            return

        # Get the current value
        iCountValue = self._dctMessageCounters[tplDictKeyPar]
        # Increase the value
        iCountValue += 1
        # Check if we are overflowing a U2
        iCountValue = iCountValue if iCountValue <= 65535 else 0
        self._dctMessageCounters[tplDictKeyPar] = iCountValue

        return

    def vCreateAndManageTaskToSendDatabaseMessagesForModule(self, acRequesterModuleNamePar: str):
        """ This is public method which finds all the send database message tasks for a specific
            module and then creates the task for those found. All the task information  is already
            in self._dctPdbpDatabaseMessageResultStateDictionary. In this dictionary the keys are
            tuples (str, int) the requester and the task number. The values of the keys is a dict
            with an enum which indicates the state of task and a str which indicates the module to
            which the database messages belongs to.

        Args:
            acRequesterModuleNamePar (str): The module name which requesting database messages to be sent out.

        Returns:

        Raises:
            Raises no exception.

        """
        lstTuplesWithTaskOwnerAndTaskNumberWithStateNoTask = []

        # Get all the tasks which belongs to the requester module name that was passed in and is in state NO_TASK
        lstTuplesWithTaskOwnerAndTaskNumberWithStateNoTask = [tplTaskOwnerAndTaskNumber for tplTaskOwnerAndTaskNumber, dctValue in self._dctPdbpDatabaseMessageResultStateDictionary.items() if ((tplTaskOwnerAndTaskNumber[0] == acRequesterModuleNamePar) and (dctValue["ePdbpDatabaseMessageSendTaskState"] == E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.NO_TASK)))]

        # Iterate through the tasks and try to create tasks for them
        for tplTaskOwnerAndTaskNumber in lstTuplesWithTaskOwnerAndTaskNumberWithStateNoTask:
            self._vCreateAndManageTaskToSendDatabaseMessagesForModuleAndTaskNumber(tplTaskOwnerAndTaskNumber)

        return

    def bAllTasksToSendDatabaseMessagesForModuleCompleted(self, acRequesterModuleNamePar: str):
        """ This is public method which finds all the send database message tasks for a specific
            module and checks that they were all completed.

        Args:
            acRequesterModuleNamePar (str): The module name which requesting database messages to be sent out.

        Returns:
            (bool): Flag which indicates if all database message send request tasks for this requester were completed.

        Raises:
            Raises no exception.

        """
        lstTuplesWithTaskOwnerAndTaskNumberWithStateCompleted = []

        lstTuplesWithTaskOwnerAndTaskNumberWithStateCompleted = [tplTaskOwnerAndTaskNumber for tplTaskOwnerAndTaskNumber, dctValue in self._dctPdbpDatabaseMessageResultStateDictionary.items() if ((tplTaskOwnerAndTaskNumber[0] == acRequesterModuleNamePar) and (dctValue["ePdbpDatabaseMessageSendTaskState"] != E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.COMPLETED_TASK)))]

        # If this list is empty then all the tasks were completed for this module
        return(len(lstTuplesWithTaskOwnerAndTaskNumberWithStateCompleted) == 0)

    def bModuleDoesNotRequireAnyDatabaseMessageSendRequestTasks(self, acRequesterModuleNamePar: str):
        """ This is public method which finds all the send database message tasks for a specific
            module and check if there are any. If this method returns True then it means no
            database messages were configuted for this module to operate.

        Args:
            acRequesterModuleNamePar (str): The module name for which we are checking if it requires any database messages to be sent.

        Returns:
            (bool): Flag which indicates if this modules has no database message send request tasks.

        Raises:
            Raises no exception.

        """
        lstTuplesWithTaskOwnerAndTaskNumber = []

        # Filter out all the tasks for this requesting module
        lstTuplesWithTaskOwnerAndTaskNumber = [tplTaskOwnerAndTaskNumber for tplTaskOwnerAndTaskNumber in self._dctPdbpDatabaseMessageResultStateDictionary if (tplTaskOwnerAndTaskNumber[0] == acRequesterModuleNamePar)]

        # If this list is empty then this module does not require any database messages to be sent out
        return(len(lstTuplesWithTaskOwnerAndTaskNumber) == 0)

    def _vCreateAndManageTaskToSendDatabaseMessagesForModuleAndTaskNumber(self, tplTaskOwnerAndTaskNumberPar: tuple):
        """ This is a private method which creates and manages tasks related to the PDBP being
            asked to send database messages for a module task number pair. All the task information
            is already in self._dctPdbpDatabaseMessageResultStateDictionary. In this dictionary the
            keys are tuples (str, int) the requester and the task number. The values of the keys is
            a dict with an enum which indicates the state of task and a str which indicates the
            module to which the database messages belongs to.

        Args:
            tplTaskOwnerAndTaskNumberPar (tuple): The requesting module and the task number for that module
                *[0](str): The requesting module
                *[1](int): The task number for that module

        Returns:

        Raises:
            Raises no exception.
        """

        if (self._dctGloInterDict is None):
            logging.error("_dctGloInterDict cannot be None")
            return

        if (tplTaskOwnerAndTaskNumberPar is None):
            logging.error("tplTaskOwnerAndTaskNumberPar cannot be None")
            return

        if (isinstance(tplTaskOwnerAndTaskNumberPar, tuple) is False):
            logging.error("tplTaskOwnerAndTaskNumberPar must be a tuple")
            return

        if (len(tplTaskOwnerAndTaskNumberPar) != 2):
            logging.error("tplTaskOwnerAndTaskNumberPar must be of length 2")
            return

        if (tplTaskOwnerAndTaskNumberPar not in self._dctPdbpDatabaseMessageResultStateDictionary):
            logging.error("tplTaskOwnerAndTaskNumberPar is not a key in _dctPdbpDatabaseMessageResultStateDictionary")
            return

        if (self._dctPdbpDatabaseMessageResultStateDictionary[tplTaskOwnerAndTaskNumberPar]["ePdbpDatabaseMessageSendTaskState"] == E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.NO_TASK)):
            self._dctGloInterDict["dctAsyncio"]["objAsyncioLoopPar"].create_task(self.vSendOutPdbpSendOutModuleDbMessageAndWaitForReply(tplTaskOwnerAndTaskNumberPar=tplTaskOwnerAndTaskNumberPar))
        elif (self._dctPdbpDatabaseMessageResultStateDictionary[tplTaskOwnerAndTaskNumberPar]["ePdbpDatabaseMessageSendTaskState"] == E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.IN_PROGRESS_TASK)):
            pass
        elif (self._dctPdbpDatabaseMessageResultStateDictionary[tplTaskOwnerAndTaskNumberPar]["ePdbpDatabaseMessageSendTaskState"] == E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.FAILED_TASK)):
            pass
        elif (self._dctPdbpDatabaseMessageResultStateDictionary[tplTaskOwnerAndTaskNumberPar]["ePdbpDatabaseMessageSendTaskState"] == E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.COMPLETED_TASK)):
            pass

        return

    def _vPopulatePdbpDatabaseMessageResultStateDictionary(self):
        """ This is a private method which populates the PdbpDatabaseMessageResultStateDictionary
            based on the Factory Config file values. The keys to this dictionary will be made to be
            a tuple which is made of (str, int). The str is the module name of the requester and the
            int is the task number for the requester module.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        iTaskPerModuleCounter = int(0)
        tplCurrentKey = ("", 0)

        if (self._dctGloInterDict is None):
            logging.error("self._dctGloInterDict cannot be None")
            return

        self._dctPdbpDatabaseMessageResultStateDictionary = {}

        iTaskPerModuleCounter = int(0)
        for acModuleName in self._dctGloInterDict["dctSubUnits"]["dctDR"]["lstModulesForWhichToSendOutDatabaseMessages"]:
            tplCurrentKey = ("DR", iTaskPerModuleCounter)
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey] = {}
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["acModuleName"] = acModuleName
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.NO_TASK)
            iTaskPerModuleCounter = iTaskPerModuleCounter + 1

        iTaskPerModuleCounter = int(0)
        for acModuleName in self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["lstModulesForWhichToSendOutDatabaseMessages"]:
            tplCurrentKey = ("PDBP", iTaskPerModuleCounter)
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey] = {}
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["acModuleName"] = acModuleName
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.NO_TASK)
            iTaskPerModuleCounter = iTaskPerModuleCounter + 1

        iTaskPerModuleCounter = int(0)
        for acModuleName in self._dctGloInterDict["dctSubUnits"]["dctEIU"]["lstModulesForWhichToSendOutDatabaseMessages"]:
            tplCurrentKey = ("EIU", iTaskPerModuleCounter)
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey] = {}
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["acModuleName"] = acModuleName
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.NO_TASK)
            iTaskPerModuleCounter = iTaskPerModuleCounter + 1

        iTaskPerModuleCounter = int(0)
        for acModuleName in self._dctGloInterDict["dctSubUnits"]["dctTM"]["lstModulesForWhichToSendOutDatabaseMessages"]:
            tplCurrentKey = ("TM", iTaskPerModuleCounter)
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey] = {}
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["acModuleName"] = acModuleName
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.NO_TASK)
            iTaskPerModuleCounter = iTaskPerModuleCounter + 1

        iTaskPerModuleCounter = int(0)
        for acModuleName in self._dctGloInterDict["dctSubUnits"]["dctTEWA"]["lstModulesForWhichToSendOutDatabaseMessages"]:
            tplCurrentKey = ("TEWA", iTaskPerModuleCounter)
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey] = {}
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["acModuleName"] = acModuleName
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.NO_TASK)
            iTaskPerModuleCounter = iTaskPerModuleCounter + 1

        iTaskPerModuleCounter = int(0)
        for acModuleName in self._dctGloInterDict["dctSubUnits"]["dctSF1"]["lstModulesForWhichToSendOutDatabaseMessages"]:
            tplCurrentKey = ("SF1", iTaskPerModuleCounter)
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey] = {}
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["acModuleName"] = acModuleName
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.NO_TASK)
            iTaskPerModuleCounter = iTaskPerModuleCounter + 1

        iTaskPerModuleCounter = int(0)
        for acModuleName in self._dctGloInterDict["dctSubUnits"]["dctSF2"]["lstModulesForWhichToSendOutDatabaseMessages"]:
            tplCurrentKey = ("SF2", iTaskPerModuleCounter)
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey] = {}
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["acModuleName"] = acModuleName
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.NO_TASK)
            iTaskPerModuleCounter = iTaskPerModuleCounter + 1

        iTaskPerModuleCounter = int(0)
        for acModuleName in self._dctGloInterDict["dctSubUnits"]["dctSF3"]["lstModulesForWhichToSendOutDatabaseMessages"]:
            tplCurrentKey = ("SF3", iTaskPerModuleCounter)
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey] = {}
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["acModuleName"] = acModuleName
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.NO_TASK)
            iTaskPerModuleCounter = iTaskPerModuleCounter + 1

        iTaskPerModuleCounter = int(0)
        for acModuleName in self._dctGloInterDict["dctSubUnits"]["dctHMIAPM"]["lstModulesForWhichToSendOutDatabaseMessages"]:
            tplCurrentKey = ("HMI_APM", iTaskPerModuleCounter)
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey] = {}
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["acModuleName"] = acModuleName
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.NO_TASK)
            iTaskPerModuleCounter = iTaskPerModuleCounter + 1

        iTaskPerModuleCounter = int(0)
        for acModuleName in self._dctGloInterDict["dctSubUnits"]["dctHMIAPMFCO"]["lstModulesForWhichToSendOutDatabaseMessages"]:
            tplCurrentKey = ("HMI_APM_FCO", iTaskPerModuleCounter)
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey] = {}
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["acModuleName"] = acModuleName
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.NO_TASK)
            iTaskPerModuleCounter = iTaskPerModuleCounter + 1

        iTaskPerModuleCounter = int(0)
        for acModuleName in self._dctGloInterDict["dctSubUnits"]["dctHMIFCO"]["lstModulesForWhichToSendOutDatabaseMessages"]:
            tplCurrentKey = ("HMI_FCO", iTaskPerModuleCounter)
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey] = {}
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["acModuleName"] = acModuleName
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.NO_TASK)
            iTaskPerModuleCounter = iTaskPerModuleCounter + 1

        iTaskPerModuleCounter = int(0)
        for acModuleName in self._dctGloInterDict["dctSubUnits"]["dctHMISPM"]["lstModulesForWhichToSendOutDatabaseMessages"]:
            tplCurrentKey = ("HMI_SPM", iTaskPerModuleCounter)
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey] = {}
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["acModuleName"] = acModuleName
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.NO_TASK)
            iTaskPerModuleCounter = iTaskPerModuleCounter + 1

        iTaskPerModuleCounter = int(0)
        for acModuleName in self._dctGloInterDict["dctSubUnits"]["dctHMISPMFUFC"]["lstModulesForWhichToSendOutDatabaseMessages"]:
            tplCurrentKey = ("HMI_SPM_FUFC", iTaskPerModuleCounter)
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey] = {}
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["acModuleName"] = acModuleName
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.NO_TASK)
            iTaskPerModuleCounter = iTaskPerModuleCounter + 1

        iTaskPerModuleCounter = int(0)
        for acModuleName in self._dctGloInterDict["dctSubUnits"]["dctHMIFUFC"]["lstModulesForWhichToSendOutDatabaseMessages"]:
            tplCurrentKey = ("HMI_FUFC", iTaskPerModuleCounter)
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey] = {}
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["acModuleName"] = acModuleName
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.NO_TASK)
            iTaskPerModuleCounter = iTaskPerModuleCounter + 1

        iTaskPerModuleCounter = int(0)
        for acModuleName in self._dctGloInterDict["dctSubUnits"]["dctHMIMaintainer"]["lstModulesForWhichToSendOutDatabaseMessages"]:
            tplCurrentKey = ("HMI_Maintainer", iTaskPerModuleCounter)
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey] = {}
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["acModuleName"] = acModuleName
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.NO_TASK)
            iTaskPerModuleCounter = iTaskPerModuleCounter + 1

        iTaskPerModuleCounter = int(0)
        for acModuleName in self._dctGloInterDict["dctSubUnits"]["dctHMIOversight"]["lstModulesForWhichToSendOutDatabaseMessages"]:
            tplCurrentKey = ("HMI_Oversight", iTaskPerModuleCounter)
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey] = {}
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["acModuleName"] = acModuleName
            self._dctPdbpDatabaseMessageResultStateDictionary[tplCurrentKey]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.NO_TASK)
            iTaskPerModuleCounter = iTaskPerModuleCounter + 1

        return

    def _acGetModuleNameFromTopic(self, acTopicPar):
        """ This is a private method which gets the module name from the topic passed in

        Args:
            acTopicPar (str): The first parameter. The topic.

        Returns:
            (str): The resultant module name

        Raises:
            Raises no exception.
        """
        lstTokens = []
        acReturnModuleName = str("")

        lstTokens = acTopicPar.split("/")

        if (len(lstTokens) == 3):
            return(lstTokens[1])
        elif (len(lstTokens) == 4):
            return(lstTokens[1] + "_" + lstTokens[3])

        return(acReturnModuleName)
