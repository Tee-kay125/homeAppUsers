#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module is the OLHM process.

Example:
    To run this file do the following:

        $ python3.6 olhm.py

Todo:

"""
# ===========================================
# Imports
# ===========================================

import sys  # Needed to append the path
import os  # Needed to check if files exist
import signal
import logging  # Needed for logging
from logging.handlers import RotatingFileHandler  # noqa # pylint: disable=unused-import
import time  # Needed for sleeping
import queue  # Needed for a queue between the main and the MQTT thread
from collections import deque  # We need this to make a FIFO of work to be processed using asyncio. Note this is seperate from the MQTT queue
import asyncio  # Needed for the message processing loop
import argparse  # Needed to help manage command line arguments
import paho.mqtt.client as mqtt  # Needed to send and receive message between the rest of the system using mosquitto
import toml  # Needed to parse the container and factory configuration files

from python_toolbox.Logging.logging_manager import clsLoggingManager
from python_toolbox.Exception_Utilities.exception_utilities import clsExceptionUtilities
from python_toolbox.Process_Monitoring_And_Management.process_monitoring_and_management import clsProcessMonitoringAndManagement
from python_toolbox.Datetime_Utilities.datetime_utilities import clsDatetimeUtilities
from python_toolbox.TOML_Utilities.toml_utilities import clsTomlUtilities
from Tests.main_test_class import clsMainTestClass
from asyncio_msg_processing_class import clsMessageProcessForMqtt  # noqa
from olhm_transitions_manager import clsOlhmTransitionsManager
from olhm_mqtt_autogen_handler import clsOlhmMqttAutogenHandler
from olhm_manager import clsOlhmManager
from olhm_launcher_manager import clsOlhmLauncherManager
from olhm_construct_group_status import clsOlhmConstructGroupStatus

# Import all the module transition managers
from External_Interfaces.DR.dr_transitions_manager import clsDrTransitionsManager
from External_Interfaces.PDBP.pdbp_transitions_manager import clsPdbpTransitionsManager
from External_Interfaces.EIU.eiu_transitions_manager import clsEiuTransitionsManager
from External_Interfaces.TM.tm_transitions_manager import clsTmTransitionsManager
from External_Interfaces.TEWA.tewa_transitions_manager import clsTewaTransitionsManager
from External_Interfaces.SF1.sf1_transitions_manager import clsSf1TransitionsManager
from External_Interfaces.SF2.sf2_transitions_manager import clsSf2TransitionsManager
from External_Interfaces.SF3.sf3_transitions_manager import clsSf3TransitionsManager
from External_Interfaces.HMI_APM.hmi_apm_transitions_manager import clsHmiApmTransitionsManager
from External_Interfaces.HMI_APM_FCO.hmi_apm_fco_transitions_manager import clsHmiApmFcoTransitionsManager
from External_Interfaces.HMI_FCO.hmi_fco_transitions_manager import clsHmiFcoTransitionsManager
from External_Interfaces.HMI_SPM.hmi_spm_transitions_manager import clsHmiSpmTransitionsManager
from External_Interfaces.HMI_SPM_FUFC.hmi_spm_fufc_transitions_manager import clsHmiSpmFufcTransitionsManager
from External_Interfaces.HMI_FUFC.hmi_fufc_transitions_manager import clsHmiFufcTransitionsManager
from External_Interfaces.HMI_Maintainer.hmi_maintainer_transitions_manager import clsHmiMaintainerTransitionsManager
from External_Interfaces.HMI_Oversight.hmi_oversight_transitions_manager import clsHmiOversightTransitionsManager

# Import all the module process message class
from External_Interfaces.DR.dr_process_messages import clsDrProcessMessages
from External_Interfaces.PDBP.pdbp_process_messages import clsPdbpProcessMessages
from External_Interfaces.EIU.eiu_process_messages import clsEiuProcessMessages
from External_Interfaces.TM.tm_process_messages import clsTmProcessMessages
from External_Interfaces.TEWA.tewa_process_messages import clsTewaProcessMessages
from External_Interfaces.SF1.sf1_process_messages import clsSf1ProcessMessages
from External_Interfaces.SF2.sf2_process_messages import clsSf2ProcessMessages
from External_Interfaces.SF3.sf3_process_messages import clsSf3ProcessMessages
from External_Interfaces.HMI_APM.hmi_apm_process_messages import clsHmiApmProcessMessages
from External_Interfaces.HMI_APM_FCO.hmi_apm_fco_process_messages import clsHmiApmFcoProcessMessages
from External_Interfaces.HMI_FCO.hmi_fco_process_messages import clsHmiFcoProcessMessages
from External_Interfaces.HMI_SPM.hmi_spm_process_messages import clsHmiSpmProcessMessages
from External_Interfaces.HMI_SPM_FUFC.hmi_spm_fufc_process_messages import clsHmiSpmFufcProcessMessages
from External_Interfaces.HMI_FUFC.hmi_fufc_process_messages import clsHmiFufcProcessMessages
from External_Interfaces.HMI_Maintainer.hmi_maintainer_process_messages import clsHmiMaintainerProcessMessages
from External_Interfaces.HMI_Oversight.hmi_oversight_process_messages import clsHmiOversightProcessMessages

# Import all the module status messages
from Autogen.dr_msg import sDR_STATUS_REPORT_UNSOL
from Autogen.pdbp_msg import sPDBP_STATUS_REPORT_UNSOL
from Autogen.eiu_msg import sEIU_STATUS_REPORT_UNSOL
from Autogen.tm_msg import sTM_STATUS_REPORT_UNSOL
from Autogen.tewa_msg import sTEWA_STATUS_REPORT_UNSOL
from Autogen.sf1_msg import sSF1_STATUS_REPORT_UNSOL
from Autogen.sf2_msg import sSF2_STATUS_REPORT_UNSOL
from Autogen.sf3_msg import sSF3_STATUS_REPORT_UNSOL
from Autogen.hmi_msg import sHMI_STATUS_REPORT_UNSOL

# Imports from the module interface configuration autogen code
from Autogen.module_interface_config_olhm import clsModuleInterfaceConfigOlhm  # This class contains a list of topics auto-generated by the autogen
from Autogen.module_interface_config_olhm import E_MESSAGE_FLOW_DIRECTION


# Note!!! Don't make any global attributes

# The install this exception hook to catch any uncaught exections so that we can log them
sys.excepthook = clsExceptionUtilities.vExcepthookHandler

# ===========================================
# Async main function
# ===========================================


async def main(objAsyncioLoopPar, objMqttClientPar: mqtt.Client, dctGlobalInterfaceDictionaryPar: dict) -> None:
    """ This is a public method which is called in the main thread as part of the asyncio loop.

    This is a public method which is called in the main thread as part of the asyncio loop. The main focus of this function is to always be
    servicing the queue and process the messages received. The processing of a message must always be done with a asyncio create_task() call.

    Args:
        objAsyncioLoopPar (obj): The first parameter. The asyncio event loop.
        objMqqtClient (obj): The second parameter. The MQTT client. It is needed to publish messages to the mosquitto broker.
        dctGlobalInterfaceDictionaryPar (dict): The third parameter. The global interface dictionary.

    Returns:

    Raises:
        Raises no exceptions
    """

    # Make a local variable for the queue so that the text is shorter
    objMqttQueue = dctGlobalInterfaceDictionaryPar["dctMqtt"]["objQueue"]
    # Make a local variable for the deque so that the text is shorter
    objDequeTasksToCreate = dctGlobalInterfaceDictionaryPar["dctOLHM"]["objDequeAsyncioTasksToBeCreated"]

    # Here class clsMessageProcessForMqtt() inherits from autogen class clsMessageProcess() in message_processing.py
    objClsMessageProcessForMqtt = clsMessageProcessForMqtt(objMqttClientPar, dctGlobalInterfaceDictionaryPar["dctMqtt"]["dctMessagesMqtt"], objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar)
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["objClsMessageProcessForMqtt"] = objClsMessageProcessForMqtt  # Save the message processing derived class in the global dictionary
    dctGlobalInterfaceDictionaryPar["dctAsyncio"]["objAsyncioLoopPar"] = objAsyncioLoopPar  # Now that we have the asyncio loop save it in the global dictionary

    # If we are here then all the validation and self-check passed
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["objClsOlhmTransitionsManager"].vSetValidationAndSelfCheckState(bool(True))

    while True:  # main loop
        # For each asyncio tick/loop call the OlhmManager processing method
        dctGlobalInterfaceDictionaryPar["dctOLHM"]["objClsOlhmManager"].vAsyncioLoopProcess()

        # Check if the MQTT connection is still connected. This is done by getting the result from a publish command.
        # Every time we try to publish the return state is stored in the processing class
        if (objClsMessageProcessForMqtt.bMqttIsConnected() is False):
            logging.error("Disconnected from MQTT broker")
            try:
                objMqttClientPar.reconnect()
                logging.debug("Successfully reconnected to MQTT broker")
                objClsMessageProcessForMqtt.vClearPublishConnectionState()
            except Exception as E:
                logging.error("Could not reconnect to MQTT broker - Exception %s - Sleeping", str(E))
                time.sleep(1)

        # This section processes messages from the mqtt python queue
        # To avoid blocking always first check how many elements are stored in the queue - only get() when something is there
        if (objMqttQueue.qsize() > 0):
            dctObject = objMqttQueue.get()  # get the message from the queue if something is there - get will always return one item at a time

            # To avoid blocking behaviour process the message using a asyncio create_task() call
            objAsyncioLoopPar.create_task(objClsMessageProcessForMqtt.vProcessDictObj(dctObject))

        # This deque stores an ordered list of asyncio methods which must called using the asyncio create_task method
        # First check if the deque is non-empty
        if (objDequeTasksToCreate):
            # Pop one item from the deque - the item will be a tuple with (method, lstMethodParams)
            tplMethodAndParams = objDequeTasksToCreate.pop()
            objAsyncioLoopPar.create_task(tplMethodAndParams[0](tplMethodAndParams[1]))

        # We must always end the while with at least one "await" call. We can use "await asyncio.sleep(0)" but then we use a lot of CPU.
        # We must therefore at least sleep a little bit
        if (objMqttQueue.qsize() > 0):
            await asyncio.sleep(0.002)
        else:
            await asyncio.sleep(0.002)

# ===========================================
# Global functions
# ===========================================


def bValidateConfigFilesAndSetGlobalDict(dctGlobalInterfaceDictionaryPar: dict):
    """ This is a public function which verifies that all the required INI file sections and fields are there.

    Args:
        dctGlobalInterfaceDictionaryPar (dict): The first parameter. The global interface dictionary.

    Returns:
        (bool): Flag indicating if validation passed.

    Raises:
        Raises no exceptions
    """
    bReturn = bool(False)

    dctStringBoolToBoolLookup = {}
    dctStringBoolToBoolLookup["True"] = bool(True)
    dctStringBoolToBoolLookup["False"] = bool(False)
    objContainerConfigTomlObject = None
    objFactoryConfigTomlObject = None
    lstModulesToMonitor = []
    lstModulesNotToMonitor = []

    if (dctGlobalInterfaceDictionaryPar["dctOLHM"]["objContainerConfigTomlObject"] is None):
        logging.error("objContainerConfigTomlObject cannot be None")
        return(bReturn)

    objContainerConfigTomlObject = dctGlobalInterfaceDictionaryPar["dctOLHM"]["objContainerConfigTomlObject"]

    if ("MqttBroker" not in objContainerConfigTomlObject):
        logging.error("TOML key MqttBroker is missing from container configuration file")
        return(bReturn)

    if ("MqttBrokerIp" not in objContainerConfigTomlObject["MqttBroker"]):
        logging.error("TOML key MqttBrokerIp is missing from container configuration file")
        return(bReturn)

    if ("MqttBrokerPort" not in objContainerConfigTomlObject["MqttBroker"]):
        logging.error("TOML key MqttBrokerPort is missing from container configuration file")
        return(bReturn)

    if (clsTomlUtilities.bTomlFieldIsValidIpV4Address(objContainerConfigTomlObject["MqttBroker"]["MqttBrokerIp"]) is False):
        logging.error("TOML value of key MqttBrokerIp is invalid")
        return(bReturn)

    if (clsTomlUtilities.bTomlFieldIsValidPort(objContainerConfigTomlObject["MqttBroker"]["MqttBrokerPort"]) is False):
        logging.error("TOML value of key MqttBrokerPort is invalid")
        return(bReturn)

    if (clsTomlUtilities.bTomlObjectContainsPath(objContainerConfigTomlObject, ["Subscribers", "ADCS"]) is False):
        logging.error("Could not find path %s in TOML object of container config", str(["Subscribers", "ADCS"]))
        return(bReturn)

    # Store the DataModel aka the SICD repo hash if it is available
    if ("DataModel" in objContainerConfigTomlObject["Owner"]):
        dctGlobalInterfaceDictionaryPar["dctOLHM"]["acGitRepoHashSicdFromContainerConfigFile"] = objContainerConfigTomlObject["Owner"]["DataModel"]
        logging.info("The Container Config SICD hash is %s", dctGlobalInterfaceDictionaryPar["dctOLHM"]["acGitRepoHashSicdFromContainerConfigFile"])

    # Now set the MQTT fields in the global dictionary
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["acMosquittoBrokerIp"] = objContainerConfigTomlObject["MqttBroker"]["MqttBrokerIp"]
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["iMosquittoBrokerPort"] = int(objContainerConfigTomlObject["MqttBroker"]["MqttBrokerPort"])

    if (dctGlobalInterfaceDictionaryPar["dctOLHM"]["objFactoryConfigTomlObject"] is None):
        logging.error("objFactoryConfigTomlObject cannot be None")
        return(bReturn)

    objFactoryConfigTomlObject = dctGlobalInterfaceDictionaryPar["dctOLHM"]["objFactoryConfigTomlObject"]

    if ("MqttBroker" not in objFactoryConfigTomlObject):
        logging.error("TOML key MqttBroker is missing from factory configuration file")
        return(bReturn)

    if ("MosquittoBrokerKeepaliveS" not in objFactoryConfigTomlObject["MqttBroker"]):
        logging.error("TOML key MosquittoBrokerKeepaliveS is missing from factory configuration file")
        return(bReturn)

    dctGlobalInterfaceDictionaryPar["dctMqtt"]["iMosquittoBrokerKeepAliveSec"] = int(objFactoryConfigTomlObject["MqttBroker"]["MosquittoBrokerKeepaliveS"])

    # Check if ADCS_Group section is there
    if ("ADCS_Group" not in objFactoryConfigTomlObject):
        logging.error("ADCS_Group section is missing from factory configuration file")
        return(bReturn)

    # Check if ModulePresenceTimeoutThresholdMs field is there
    if ("ModulePresenceTimeoutThresholdMs" not in objFactoryConfigTomlObject["ADCS_Group"]):
        logging.error("TOML key ModulePresenceTimeoutThresholdMs is missing from factory configuration file")
        return(bReturn)

    # Check if HmiModulesAllowedToStartLater fiels is there
    if ("HmiModulesAllowedToStartLater" not in objFactoryConfigTomlObject["ADCS_Group"]):
        logging.error("TOML key HmiModulesAllowedToStartLater is missing from factory configuration file")
        return(bReturn)

    # Check if PreventModulesFromGoingIntoReadyState fiels is there
    if ("PreventModulesFromGoingIntoReadyState" not in objFactoryConfigTomlObject["ADCS_Group"]):
        logging.error("TOML key PreventModulesFromGoingIntoReadyState is missing from factory configuration file")
        return(bReturn)

    # Are the monitor module fields in the Factory Config file

    if ("MonitorModuleDR" not in objFactoryConfigTomlObject["ADCS_Group"]):
        logging.error("TOML key MonitorModuleDR is missing from factory configuration file")
        return(bReturn)

    if ("MonitorModuleEIU" not in objFactoryConfigTomlObject["ADCS_Group"]):
        logging.error("TOML key MonitorModuleEIU is missing from factory configuration file")
        return(bReturn)

    if ("MonitorModulePDBP" not in objFactoryConfigTomlObject["ADCS_Group"]):
        logging.error("TOML key MonitorModulePDBP is missing from factory configuration file")
        return(bReturn)

    if ("MonitorModuleTEWA" not in objFactoryConfigTomlObject["ADCS_Group"]):
        logging.error("TOML key MonitorModuleTEWA is missing from factory configuration file")
        return(bReturn)

    if ("MonitorModuleTM" not in objFactoryConfigTomlObject["ADCS_Group"]):
        logging.error("TOML key MonitorModuleTM is missing from factory configuration file")
        return(bReturn)

    if ("MonitorModuleSF1" not in objFactoryConfigTomlObject["ADCS_Group"]):
        logging.error("TOML key MonitorModuleSF1 is missing from factory configuration file")
        return(bReturn)

    if ("MonitorModuleSF2" not in objFactoryConfigTomlObject["ADCS_Group"]):
        logging.error("TOML key MonitorModuleSF2 is missing from factory configuration file")
        return(bReturn)

    if ("MonitorModuleSF3" not in objFactoryConfigTomlObject["ADCS_Group"]):
        logging.error("TOML key MonitorModuleSF3 is missing from factory configuration file")
        return(bReturn)

    if ("MonitorModuleHMI_APM" not in objFactoryConfigTomlObject["ADCS_Group"]):
        logging.error("TOML key MonitorModuleHMI_APM is missing from factory configuration file")
        return(bReturn)

    if ("MonitorModuleHMI_APM_FCO" not in objFactoryConfigTomlObject["ADCS_Group"]):
        logging.error("TOML key MonitorModuleHMI_APM_FCO is missing from factory configuration file")
        return(bReturn)

    if ("MonitorModuleHMI_FCO" not in objFactoryConfigTomlObject["ADCS_Group"]):
        logging.error("TOML key MonitorModuleHMI_FCO is missing from factory configuration file")
        return(bReturn)

    if ("MonitorModuleHMI_SPM" not in objFactoryConfigTomlObject["ADCS_Group"]):
        logging.error("TOML key MonitorModuleHMI_SPM is missing from factory configuration file")
        return(bReturn)

    if ("MonitorModuleHMI_SPM_FUFC" not in objFactoryConfigTomlObject["ADCS_Group"]):
        logging.error("TOML key MonitorModuleHMI_SPM_FUFC is missing from factory configuration file")
        return(bReturn)

    if ("MonitorModuleHMI_FUFC" not in objFactoryConfigTomlObject["ADCS_Group"]):
        logging.error("TOML key MonitorModuleHMI_FUFC is missing from factory configuration file")
        return(bReturn)

    if ("MonitorModuleHMI_Maintainer" not in objFactoryConfigTomlObject["ADCS_Group"]):
        logging.error("TOML key MonitorModuleHMI_Maintainer is missing from factory configuration file")
        return(bReturn)

    if ("MonitorModuleHMI_Oversight" not in objFactoryConfigTomlObject["ADCS_Group"]):
        logging.error("TOML key MonitorModuleHMI_Oversight is missing from factory configuration file")
        return(bReturn)

    # Are the monitor module fields in the Factory Config file of type boolean

    if (isinstance(objFactoryConfigTomlObject["ADCS_Group"]["ModulePresenceTimeoutThresholdMs"], int) is False):
        logging.error("TOML key ModulePresenceTimeoutThresholdMs from factory configuration file must be an int")
        return(bReturn)

    if (isinstance(objFactoryConfigTomlObject["ADCS_Group"]["HmiModulesAllowedToStartLater"], bool) is False):
        logging.error("TOML key HmiModulesAllowedToStartLater from factory configuration file must be a bool")
        return(bReturn)

    if (isinstance(objFactoryConfigTomlObject["ADCS_Group"]["PreventModulesFromGoingIntoReadyState"], bool) is False):
        logging.error("TOML key PreventModulesFromGoingIntoReadyState from factory configuration file must be a bool")
        return(bReturn)

    if (isinstance(objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleDR"], bool) is False):
        logging.error("TOML key MonitorModuleDR from factory configuration file must be a bool")
        return(bReturn)

    if (isinstance(objFactoryConfigTomlObject["ADCS_Group"]["MonitorModulePDBP"], bool) is False):
        logging.error("TOML key MonitorModulePDBP from factory configuration file must be a bool")
        return(bReturn)

    if (isinstance(objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleEIU"], bool) is False):
        logging.error("TOML key MonitorModuleEIU from factory configuration file must be a bool")
        return(bReturn)

    if (isinstance(objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleTEWA"], bool) is False):
        logging.error("TOML key MonitorModuleTEWA from factory configuration file must be a bool")
        return(bReturn)

    if (isinstance(objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleTM"], bool) is False):
        logging.error("TOML key MonitorModuleTM from factory configuration file must be a bool")
        return(bReturn)

    if (isinstance(objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleSF1"], bool) is False):
        logging.error("TOML key MonitorModuleSF1 from factory configuration file must be a bool")
        return(bReturn)

    if (isinstance(objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleSF2"], bool) is False):
        logging.error("TOML key MonitorModuleSF2 from factory configuration file must be a bool")
        return(bReturn)

    if (isinstance(objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleSF3"], bool) is False):
        logging.error("TOML key MonitorModuleSF3 from factory configuration file must be a bool")
        return(bReturn)

    if (isinstance(objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleHMI_APM"], bool) is False):
        logging.error("TOML key MonitorModuleHMI_APM from factory configuration file must be a bool")
        return(bReturn)

    if (isinstance(objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleHMI_APM_FCO"], bool) is False):
        logging.error("TOML key MonitorModuleHMI_APM_FCO from factory configuration file must be a bool")
        return(bReturn)

    if (isinstance(objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleHMI_FCO"], bool) is False):
        logging.error("TOML key MonitorModuleHMI_FCO from factory configuration file must be a bool")
        return(bReturn)

    if (isinstance(objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleHMI_SPM"], bool) is False):
        logging.error("TOML key MonitorModuleHMI_SPM from factory configuration file must be a bool")
        return(bReturn)

    if (isinstance(objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleHMI_SPM_FUFC"], bool) is False):
        logging.error("TOML key MonitorModuleHMI_SPM_FUFC from factory configuration file must be a bool")
        return(bReturn)

    if (isinstance(objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleHMI_FUFC"], bool) is False):
        logging.error("TOML key MonitorModuleHMI_FUFC from factory configuration file must be a bool")
        return(bReturn)

    if (isinstance(objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleHMI_Oversight"], bool) is False):
        logging.error("TOML key MonitorModuleHMI_Oversight from factory configuration file must be a bool")
        return(bReturn)

    if (isinstance(objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleHMI_Maintainer"], bool) is False):
        logging.error("TOML key MonitorModuleHMI_Maintainer from factory configuration file must be a bool")
        return(bReturn)

    dctGlobalInterfaceDictionaryPar["dctOLHM"]["bHmiModulesAllowedToStartLater"] = objFactoryConfigTomlObject["ADCS_Group"]["HmiModulesAllowedToStartLater"]

    # From the monitor module fields in the Factory Config file build a list of modules to monitor and a list to not monitor

    if (objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleDR"] is True):
        lstModulesToMonitor.append("DR")
    else:
        lstModulesNotToMonitor.append("DR")

    if (objFactoryConfigTomlObject["ADCS_Group"]["MonitorModulePDBP"] is True):
        lstModulesToMonitor.append("PDBP")
    else:
        lstModulesNotToMonitor.append("PDBP")

    if (objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleEIU"] is True):
        lstModulesToMonitor.append("EIU")
    else:
        lstModulesNotToMonitor.append("EIU")

    if (objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleTEWA"] is True):
        lstModulesToMonitor.append("TEWA")
    else:
        lstModulesNotToMonitor.append("TEWA")

    if (objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleTM"] is True):
        lstModulesToMonitor.append("TM")
    else:
        lstModulesNotToMonitor.append("TM")

    if (objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleSF1"] is True):
        lstModulesToMonitor.append("SF1")
    else:
        lstModulesNotToMonitor.append("SF1")

    if (objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleSF2"] is True):
        lstModulesToMonitor.append("SF2")
    else:
        lstModulesNotToMonitor.append("SF2")

    if (objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleSF3"] is True):
        lstModulesToMonitor.append("SF3")
    else:
        lstModulesNotToMonitor.append("SF3")

    if (objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleHMI_APM"] is True):
        lstModulesToMonitor.append("HMI_APM")
    else:
        lstModulesNotToMonitor.append("HMI_APM")

    if (objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleHMI_APM_FCO"] is True):
        lstModulesToMonitor.append("HMI_APM_FCO")
    else:
        lstModulesNotToMonitor.append("HMI_APM_FCO")

    if (objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleHMI_FCO"] is True):
        lstModulesToMonitor.append("HMI_FCO")
    else:
        lstModulesNotToMonitor.append("HMI_FCO")

    if (objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleHMI_SPM"] is True):
        lstModulesToMonitor.append("HMI_SPM")
    else:
        lstModulesNotToMonitor.append("HMI_SPM")

    if (objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleHMI_SPM_FUFC"] is True):
        lstModulesToMonitor.append("HMI_SPM_FUFC")
    else:
        lstModulesNotToMonitor.append("HMI_SPM_FUFC")

    if (objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleHMI_FUFC"] is True):
        lstModulesToMonitor.append("HMI_FUFC")
    else:
        lstModulesNotToMonitor.append("HMI_FUFC")

    if (objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleHMI_Maintainer"] is True):
        lstModulesToMonitor.append("HMI_Maintainer")
    else:
        lstModulesNotToMonitor.append("HMI_Maintainer")

    if (objFactoryConfigTomlObject["ADCS_Group"]["MonitorModuleHMI_Oversight"] is True):
        lstModulesToMonitor.append("HMI_Oversight")
    else:
        lstModulesNotToMonitor.append("HMI_Oversight")

    dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstModulesToMonitor"] = lstModulesToMonitor
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstModulesNotToMonitor"] = lstModulesNotToMonitor

    dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstHmiModules"] = [acModule for acModule in dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstHmiModules"] if acModule in lstModulesToMonitor]

    # From the TOML file see if the HMIs are allowed to start later
    if (dctGlobalInterfaceDictionaryPar["dctOLHM"]["bHmiModulesAllowedToStartLater"] is True):
        dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstModulesIncludedInStartup"] = [acModule for acModule in lstModulesToMonitor if acModule not in dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstHmiModules"]]
    else:
        dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstModulesIncludedInStartup"] = lstModulesToMonitor[:]

    if (clsTomlUtilities.bTomlObjectContainsPath(objFactoryConfigTomlObject, ["ADCS_Group", "ModulePresenceTimeoutThresholdMs"]) is False):
        logging.error("Could not find path %s in TOML object of factory config", str(["ADCS_Group", "ModulePresenceTimeoutThresholdMs"]))
        return(bReturn)

    # See if this field is an int
    bValidInt = clsTomlUtilities.bTomlFieldIsAValidInteger(objFactoryConfigTomlObject["ADCS_Group"]["ModulePresenceTimeoutThresholdMs"])
    # See if this field is a float
    bValidFloat = clsTomlUtilities.bTomlFieldIsAValidFloat(objFactoryConfigTomlObject["ADCS_Group"]["ModulePresenceTimeoutThresholdMs"])

    # If it is an int or a float
    if (any([bValidInt, bValidFloat]) is True):
        dctGlobalInterfaceDictionaryPar["dctOLHM"]["fModulePresenceTimeoutThresholdMs"] = float(objFactoryConfigTomlObject["ADCS_Group"]["ModulePresenceTimeoutThresholdMs"])
    else:
        logging.error("Factory config file field ModulePresenceTimeoutThresholdMs must be an int or a float")
        return(bReturn)

    dctGlobalInterfaceDictionaryPar["dctOLHM"]["bPreventModulesFromGoingIntoReadyState"] = objFactoryConfigTomlObject["ADCS_Group"]["PreventModulesFromGoingIntoReadyState"]

    # Check if PDBP section is there
    if ("PDBP" not in objFactoryConfigTomlObject):
        logging.error("PDBP section is missing from factory configuration file")
        return(bReturn)

    # Check if CommandThePdbpToSendOutDatabaseMessages field is there
    if ("CommandThePdbpToSendOutDatabaseMessages" not in objFactoryConfigTomlObject["PDBP"]):
        logging.error("TOML key CommandThePdbpToSendOutDatabaseMessages is missing from factory configuration file")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForDR field is there
    if ("ModuleMessagesToBeSentForDR" not in objFactoryConfigTomlObject["PDBP"]):
        logging.error("TOML key ModuleMessagesToBeSentForDR is missing from factory configuration file")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForPDBP field is there
    if ("ModuleMessagesToBeSentForPDBP" not in objFactoryConfigTomlObject["PDBP"]):
        logging.error("TOML key ModuleMessagesToBeSentForPDBP is missing from factory configuration file")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForEIU field is there
    if ("ModuleMessagesToBeSentForEIU" not in objFactoryConfigTomlObject["PDBP"]):
        logging.error("TOML key ModuleMessagesToBeSentForEIU is missing from factory configuration file")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForTEWA field is there
    if ("ModuleMessagesToBeSentForTEWA" not in objFactoryConfigTomlObject["PDBP"]):
        logging.error("TOML key ModuleMessagesToBeSentForTEWA is missing from factory configuration file")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForTM field is there
    if ("ModuleMessagesToBeSentForTM" not in objFactoryConfigTomlObject["PDBP"]):
        logging.error("TOML key ModuleMessagesToBeSentForTM is missing from factory configuration file")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForSF1 field is there
    if ("ModuleMessagesToBeSentForSF1" not in objFactoryConfigTomlObject["PDBP"]):
        logging.error("TOML key ModuleMessagesToBeSentForSF1 is missing from factory configuration file")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForSF2 field is there
    if ("ModuleMessagesToBeSentForSF2" not in objFactoryConfigTomlObject["PDBP"]):
        logging.error("TOML key ModuleMessagesToBeSentForSF2 is missing from factory configuration file")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForSF3 field is there
    if ("ModuleMessagesToBeSentForSF3" not in objFactoryConfigTomlObject["PDBP"]):
        logging.error("TOML key ModuleMessagesToBeSentForSF3 is missing from factory configuration file")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForHMI_APM field is there
    if ("ModuleMessagesToBeSentForHMI_APM" not in objFactoryConfigTomlObject["PDBP"]):
        logging.error("TOML key ModuleMessagesToBeSentForHMI_APM is missing from factory configuration file")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForHMI_APM_FCO field is there
    if ("ModuleMessagesToBeSentForHMI_APM_FCO" not in objFactoryConfigTomlObject["PDBP"]):
        logging.error("TOML key ModuleMessagesToBeSentForHMI_APM_FCO is missing from factory configuration file")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForHMI_FCO field is there
    if ("ModuleMessagesToBeSentForHMI_FCO" not in objFactoryConfigTomlObject["PDBP"]):
        logging.error("TOML key ModuleMessagesToBeSentForHMI_FCO is missing from factory configuration file")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForHMI_SPM field is there
    if ("ModuleMessagesToBeSentForHMI_SPM" not in objFactoryConfigTomlObject["PDBP"]):
        logging.error("TOML key ModuleMessagesToBeSentForHMI_SPM is missing from factory configuration file")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForHMI_SPM_FUFC field is there
    if ("ModuleMessagesToBeSentForHMI_SPM_FUFC" not in objFactoryConfigTomlObject["PDBP"]):
        logging.error("TOML key ModuleMessagesToBeSentForHMI_SPM_FUFC is missing from factory configuration file")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForHMI_FUFC field is there
    if ("ModuleMessagesToBeSentForHMI_FUFC" not in objFactoryConfigTomlObject["PDBP"]):
        logging.error("TOML key ModuleMessagesToBeSentForHMI_FUFC is missing from factory configuration file")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForHMI_Maintainer field is there
    if ("ModuleMessagesToBeSentForHMI_Maintainer" not in objFactoryConfigTomlObject["PDBP"]):
        logging.error("TOML key ModuleMessagesToBeSentForHMI_Maintainer is missing from factory configuration file")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForHMI_Oversight field is there
    if ("ModuleMessagesToBeSentForHMI_Oversight" not in objFactoryConfigTomlObject["PDBP"]):
        logging.error("TOML key ModuleMessagesToBeSentForHMI_Oversight is missing from factory configuration file")
        return(bReturn)

    # Check if CommandThePdbpToSendOutDatabaseMessages field is a bool
    if (isinstance(objFactoryConfigTomlObject["PDBP"]["CommandThePdbpToSendOutDatabaseMessages"], bool) is False):
        logging.error("TOML key CommandThePdbpToSendOutDatabaseMessages from factory configuration file must be a bool")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForDR field is a list
    if (isinstance(objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForDR"], list) is False):
        logging.error("TOML key ModuleMessagesToBeSentForDR from factory configuration file must be a list")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForPDBP field is a list
    if (isinstance(objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForPDBP"], list) is False):
        logging.error("TOML key ModuleMessagesToBeSentForPDBP from factory configuration file must be a list")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForEIU field is a list
    if (isinstance(objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForEIU"], list) is False):
        logging.error("TOML key ModuleMessagesToBeSentForEIU from factory configuration file must be a list")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForTEWA field is a list
    if (isinstance(objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForTEWA"], list) is False):
        logging.error("TOML key ModuleMessagesToBeSentForTEWA from factory configuration file must be a list")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForTM field is a list
    if (isinstance(objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForTM"], list) is False):
        logging.error("TOML key ModuleMessagesToBeSentForTM from factory configuration file must be a list")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForSF1 field is a list
    if (isinstance(objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForSF1"], list) is False):
        logging.error("TOML key ModuleMessagesToBeSentForSF1 from factory configuration file must be a list")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForSF2 field is a list
    if (isinstance(objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForSF2"], list) is False):
        logging.error("TOML key ModuleMessagesToBeSentForSF2 from factory configuration file must be a list")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForSF3 field is a list
    if (isinstance(objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForSF3"], list) is False):
        logging.error("TOML key ModuleMessagesToBeSentForSF3 from factory configuration file must be a list")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForHMI_APM field is a list
    if (isinstance(objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForHMI_APM"], list) is False):
        logging.error("TOML key ModuleMessagesToBeSentForHMI_APM from factory configuration file must be a list")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForHMI_APM_FCO field is a list
    if (isinstance(objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForHMI_APM_FCO"], list) is False):
        logging.error("TOML key ModuleMessagesToBeSentForHMI_APM_FCO from factory configuration file must be a list")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForHMI_FCO field is a list
    if (isinstance(objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForHMI_FCO"], list) is False):
        logging.error("TOML key ModuleMessagesToBeSentForHMI_FCO from factory configuration file must be a list")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForHMI_SPM field is a list
    if (isinstance(objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForHMI_SPM"], list) is False):
        logging.error("TOML key ModuleMessagesToBeSentForHMI_SPM from factory configuration file must be a list")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForHMI_SPM_FUFC field is a list
    if (isinstance(objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForHMI_SPM_FUFC"], list) is False):
        logging.error("TOML key ModuleMessagesToBeSentForHMI_SPM_FUFC from factory configuration file must be a list")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForHMI_FUFC field is a list
    if (isinstance(objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForHMI_FUFC"], list) is False):
        logging.error("TOML key ModuleMessagesToBeSentForHMI_FUFC from factory configuration file must be a list")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForHMI_Maintainer field is a list
    if (isinstance(objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForHMI_Maintainer"], list) is False):
        logging.error("TOML key ModuleMessagesToBeSentForHMI_Maintainer from factory configuration file must be a list")
        return(bReturn)

    # Check if ModuleMessagesToBeSentForHMI_Oversight field is a list
    if (isinstance(objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForHMI_Oversight"], list) is False):
        logging.error("TOML key ModuleMessagesToBeSentForHMI_Oversight from factory configuration file must be a list")
        return(bReturn)

    # Set the global dictionary
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["bCommandThePdbpToSendOutDatabaseMessages"] = objFactoryConfigTomlObject["PDBP"]["CommandThePdbpToSendOutDatabaseMessages"]
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctDR"]["lstModulesForWhichToSendOutDatabaseMessages"] = objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForDR"]
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctPDBP"]["lstModulesForWhichToSendOutDatabaseMessages"] = objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForPDBP"]
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctEIU"]["lstModulesForWhichToSendOutDatabaseMessages"] = objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForEIU"]
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTEWA"]["lstModulesForWhichToSendOutDatabaseMessages"] = objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForTEWA"]
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTM"]["lstModulesForWhichToSendOutDatabaseMessages"] = objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForTM"]
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF1"]["lstModulesForWhichToSendOutDatabaseMessages"] = objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForSF1"]
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF2"]["lstModulesForWhichToSendOutDatabaseMessages"] = objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForSF2"]
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF3"]["lstModulesForWhichToSendOutDatabaseMessages"] = objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForSF3"]
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPM"]["lstModulesForWhichToSendOutDatabaseMessages"] = objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForHMI_APM"]
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPMFCO"]["lstModulesForWhichToSendOutDatabaseMessages"] = objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForHMI_APM_FCO"]
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFCO"]["lstModulesForWhichToSendOutDatabaseMessages"] = objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForHMI_FCO"]
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPM"]["lstModulesForWhichToSendOutDatabaseMessages"] = objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForHMI_SPM"]
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPMFUFC"]["lstModulesForWhichToSendOutDatabaseMessages"] = objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForHMI_SPM_FUFC"]
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFUFC"]["lstModulesForWhichToSendOutDatabaseMessages"] = objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForHMI_FUFC"]
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIMaintainer"]["lstModulesForWhichToSendOutDatabaseMessages"] = objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForHMI_Maintainer"]
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIOversight"]["lstModulesForWhichToSendOutDatabaseMessages"] = objFactoryConfigTomlObject["PDBP"]["ModuleMessagesToBeSentForHMI_Oversight"]

    if ("Debug" in objFactoryConfigTomlObject):
        if ("LogLevel" in objFactoryConfigTomlObject["Debug"]):
            dctGlobalInterfaceDictionaryPar["dctOLHM"]["acLogLevel"] = objFactoryConfigTomlObject["Debug"]["LogLevel"]

    return(True)


def bCheckIfFilesAndDirectoriesExist(dctGlobalInterfaceDictionaryPar: dict):
    """ This is a public function which checks if mandatory directories and files exists.

    Args:
        dctGlobalInterfaceDictionaryPar (dict): The first parameter. The global interface dictionary.

    Returns:
        (bool): Flag to indicate if files and directories exist.

    Raises:
        Raises no exceptions
    """
    bReturn = bool(False)

    # Work out the full path of the container config file
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["acContainerConfigAbsolutePath"] = os.path.join(dctGlobalInterfaceDictionaryPar["dctOLHM"]["acCurrentDirectory"], dctGlobalInterfaceDictionaryPar["dctOLHM"]["acContainerConfigFilename"])
    logging.debug("The full path of the container configuration file is %s", dctGlobalInterfaceDictionaryPar["dctOLHM"]["acContainerConfigAbsolutePath"])

    # Verify if the container configuration file exists
    if (os.path.exists(dctGlobalInterfaceDictionaryPar["dctOLHM"]["acContainerConfigAbsolutePath"]) is False):
        logging.error("Cannot open container configuration file")
        return(bReturn)

    dctGlobalInterfaceDictionaryPar["dctOLHM"]["bContainerConfigFileExists"] = bool(True)

    # Work out the full path of the factory config file
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["acFactoryConfigAbsolutePath"] = os.path.join(dctGlobalInterfaceDictionaryPar["dctOLHM"]["acCurrentDirectory"], dctGlobalInterfaceDictionaryPar["dctOLHM"]["acFactoryConfigFilename"])
    logging.debug("The full path of the INI file is %s", dctGlobalInterfaceDictionaryPar["dctOLHM"]["acFactoryConfigAbsolutePath"])

    # Verify if the factory config file exists
    if (os.path.exists(dctGlobalInterfaceDictionaryPar["dctOLHM"]["acFactoryConfigAbsolutePath"]) is False):
        logging.error("Cannot open INI file")
        return(bReturn)

    dctGlobalInterfaceDictionaryPar["dctOLHM"]["bFactoryConfigFileExists"] = bool(True)

    return(True)


def vInitialiseGlobalDictionarySkeleton(dctGlobalInterfaceDictionaryPar: dict):
    """ This is a public function which sets up the global dictionary skeleton. This will not set up complex instances of classes because it might be
    premature given the design of the code.

    Args:
        dctGlobalInterfaceDictionaryPar (dict): The first parameter. The global interface dictionary.

    Returns:

    Raises:
        Raises no exceptions
    """

    # Things related to MQTT
    dctGlobalInterfaceDictionaryPar["dctMqtt"] = {}
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["objQueue"] = None  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["acMosquittoBrokerIp"] = ""  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["iMosquittoBrokerPort"] = int(0)  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["iMosquittoBrokerKeepAliveSec"] = int(0)  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["acMqttId"] = ""  # Will be set later
    # This is the main message received dictionary for mqtt. It must be defined and passed in because it is integral to the auto generated code.
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["dctMessagesMqtt"] = {}  # This is the main dictionary into which all received MQTT messages will be stored - it will start empty
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["objClsMessageProcessForMqtt"] = None  # Will be assigned later - it's base class will use ["dctMessagesMqtt"]
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["objMqttClientPar"] = None  # Will be assigned later when the client is connected
    dctGlobalInterfaceDictionaryPar["dctMqtt"]["lstTasksAllowedForsimultaneousExecution"] = []  # This list starts empty - it isn't normally used

    # Things related to Asyncio
    dctGlobalInterfaceDictionaryPar["dctAsyncio"] = {}
    dctGlobalInterfaceDictionaryPar["dctAsyncio"]["objAsyncioLoopPar"] = None  # Will be set later

    # Things related to OLHM state
    dctGlobalInterfaceDictionaryPar["dctOLHM"] = {}
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["objArgs"] = None  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["iVersionMajor"] = int(0)  # The OLHM unit major version number
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["iVersionMinor"] = int(1)  # The OLHM unit minor version number
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["iVersionInternal"] = int(4)  # The OLHM unit minor version number
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["acGitRepoHashOlhmFromGit"] = str("")  # This will be filled in when the read the text file containing the hash as text
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["acGitRepoHashSicdFromAutogen"] = str("")  # This is used to store the SICD GIT hash from the Autogen
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["acGitRepoHashSicdFromContainerConfigFile"] = str("")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["acPartNumber"] = str("5850-BS-5000")  # The OLHM part number
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["bDebugMode"] = bool(False)
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["acLogLevel"] = "INFO"
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["objClsOlhmManager"] = None  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["objClsOlhmTransitionsManager"] = None  # Will be set later

    dctGlobalInterfaceDictionaryPar["dctOLHM"]["objClsOlhmLauncherManager"] = None  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["objClsOlhmConstructSystemStatus"] = None  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["acCurrentDirectory"] = ""  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["acContainerConfigFilename"] = "olhm_container_config.toml"
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["acContainerConfigAbsolutePath"] = ""  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["bContainerConfigFileExists"] = bool(False)
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["objContainerConfigTomlObject"] = None
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["acContainerConfigFileContents"] = ""
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["acFactoryConfigFilename"] = "olhm_factory_config.toml"
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["acFactoryConfigAbsolutePath"] = ""  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["bFactoryConfigFileExists"] = bool(False)
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["objFactoryConfigTomlObject"] = None
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["objDequeAsyncioTasksToBeCreated"] = deque(maxlen=20)  # This is a FIFO for storing tasks which must be created usign asyncio loop
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["bConfigFilesAndSelfCheckPassed"] = bool(True)  # Set this true for now
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["fModulePresenceTimeoutThresholdMs"] = int(0)  # Set to zero for now
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstModulesToMonitor"] = []  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstModulesNotToMonitor"] = []  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["bHmiModulesAllowedToStartLater"] = bool(False)  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["bCommandThePdbpToSendOutDatabaseMessages"] = bool(True)  # Will be set later
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["bPreventModulesFromGoingIntoReadyState"] = bool(False)  # Will be set later
    # Keep a list of HMI modules - they are special in that if configured so are allowed to start later
    # Note!!! This list of HMI modules might change after the Factory TOML file is parsed
    # HMI modules configured to not be monitored will be removed from this list
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstHmiModules"] = []
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstHmiModules"].append("HMI_APM")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstHmiModules"].append("HMI_APM_FCO")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstHmiModules"].append("HMI_FCO")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstHmiModules"].append("HMI_SPM")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstHmiModules"].append("HMI_SPM_FUFC")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstHmiModules"].append("HMI_FUFC")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstHmiModules"].append("HMI_Maintainer")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstHmiModules"].append("HMI_Oversight")

    # self._dctGloInterDict["dctOLHM"]["lstModulesIncludedInStartup"] will include all the modules
    # which are enabled in the Factory Config file. The HMI modules will be included in this list
    # if they are not allowed to start later. If they are allowed to start later then they will
    # be excluded from this list. This list is created from self._dctGloInterDict["dctOLHM"]["lstModulesToMonitor"]
    # but with HMI modules excluded if the HMIs are allowed to start later
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["lstModulesIncludedInStartup"] = []

    # This class clsModuleInterfaceConfigOlhm is auto-generated
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["objClsModuleInterfaceConfigOlhm"] = clsModuleInterfaceConfigOlhm()

    dctGlobalInterfaceDictionaryPar["dctOLHM"]["dctSubUnitNameToStateMachineLookup"] = {}
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["dctSubUnitNameToStateMachineLookup"]["DR"] = ("dctDR", "objClsDrTransitionsManager")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["dctSubUnitNameToStateMachineLookup"]["PDBP"] = ("dctPDBP", "objClsPdbpTransitionsManager")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["dctSubUnitNameToStateMachineLookup"]["EIU"] = ("dctEIU", "objClsEiuTransitionsManager")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["dctSubUnitNameToStateMachineLookup"]["TEWA"] = ("dctTEWA", "objClsTewaTransitionsManager")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["dctSubUnitNameToStateMachineLookup"]["TM"] = ("dctTM", "objClsTmTransitionsManager")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["dctSubUnitNameToStateMachineLookup"]["SF1"] = ("dctSF1", "objClsSf1TransitionsManager")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["dctSubUnitNameToStateMachineLookup"]["SF2"] = ("dctSF2", "objClsSf2TransitionsManager")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["dctSubUnitNameToStateMachineLookup"]["SF3"] = ("dctSF3", "objClsSf3TransitionsManager")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["dctSubUnitNameToStateMachineLookup"]["HMI_APM"] = ("dctHMIAPM", "objClsHmiApmTransitionsManager")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["dctSubUnitNameToStateMachineLookup"]["HMI_APM_FCO"] = ("dctHMIAPMFCO", "objClsHmiApmFcoTransitionsManager")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["dctSubUnitNameToStateMachineLookup"]["HMI_FCO"] = ("dctHMIFCO", "objClsHmiFcoTransitionsManager")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["dctSubUnitNameToStateMachineLookup"]["HMI_SPM"] = ("dctHMISPM", "objClsHmiSpmTransitionsManager")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["dctSubUnitNameToStateMachineLookup"]["HMI_SPM_FUFC"] = ("dctHMISPMFUFC", "objClsHmiSpmFufcTransitionsManager")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["dctSubUnitNameToStateMachineLookup"]["HMI_FUFC"] = ("dctHMIFUFC", "objClsHmiFufcTransitionsManager")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["dctSubUnitNameToStateMachineLookup"]["HMI_Oversight"] = ("dctHMIOversight", "objClsHmiOversightTransitionsManager")
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["dctSubUnitNameToStateMachineLookup"]["HMI_Maintainer"] = ("dctHMIMaintainer", "objClsHmiMaintainerTransitionsManager")

    # SUBUNITS
    # SUBUNITS
    # SUBUNITS
    dctGlobalInterfaceDictionaryPar["dctSubUnits"] = {}

    # Things related to subunits - DR
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctDR"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctDR"]["acLRUName"] = str("DR")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctDR"]["lstModulesForWhichToSendOutDatabaseMessages"] = []

    # Things related to subunits - PDBP
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctPDBP"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctPDBP"]["acLRUName"] = str("PDBP")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctPDBP"]["lstModulesForWhichToSendOutDatabaseMessages"] = []

    # Things related to subunits - EIU
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctEIU"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctEIU"]["acLRUName"] = str("EIU")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctEIU"]["lstModulesForWhichToSendOutDatabaseMessages"] = []

    # Things related to subunits - TM
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTM"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTM"]["acLRUName"] = str("TM")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTM"]["lstModulesForWhichToSendOutDatabaseMessages"] = []

    # Things related to subunits - TEWA
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTEWA"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTEWA"]["acLRUName"] = str("TEWA")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTEWA"]["lstModulesForWhichToSendOutDatabaseMessages"] = []

    # Things related to subunits - SF1
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF1"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF1"]["acLRUName"] = str("SF1")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF1"]["lstModulesForWhichToSendOutDatabaseMessages"] = []

    # Things related to subunits - SF2
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF2"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF2"]["acLRUName"] = str("SF2")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF2"]["lstModulesForWhichToSendOutDatabaseMessages"] = []

    # Things related to subunits - SF3
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF3"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF3"]["acLRUName"] = str("SF3")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF3"]["lstModulesForWhichToSendOutDatabaseMessages"] = []

    # Things related to subunits - HMI_APM
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPM"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPM"]["acLRUName"] = str("HMI_APM")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPM"]["lstModulesForWhichToSendOutDatabaseMessages"] = []

    # Things related to subunits - HMI_APM_FCO
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPMFCO"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPMFCO"]["acLRUName"] = str("HMI_APM_FCO")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPMFCO"]["lstModulesForWhichToSendOutDatabaseMessages"] = []

    # Things related to subunits - HMI_FCO
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFCO"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFCO"]["acLRUName"] = str("HMI_FCO")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFCO"]["lstModulesForWhichToSendOutDatabaseMessages"] = []

    # Things related to subunits - HMI_SPM
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPM"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPM"]["acLRUName"] = str("HMI_SPM")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPM"]["lstModulesForWhichToSendOutDatabaseMessages"] = []

    # Things related to subunits - HMI_SPM_FUFC
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPMFUFC"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPMFUFC"]["acLRUName"] = str("HMI_SPM_FUFC")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPMFUFC"]["lstModulesForWhichToSendOutDatabaseMessages"] = []

    # Things related to subunits - HMI_FUFC
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFUFC"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFUFC"]["acLRUName"] = str("HMI_FUFC")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFUFC"]["lstModulesForWhichToSendOutDatabaseMessages"] = []

    # Things related to subunits - HMI_Maintainer
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIMaintainer"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIMaintainer"]["acLRUName"] = str("HMI_Maintainer")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIMaintainer"]["lstModulesForWhichToSendOutDatabaseMessages"] = []

    # Things related to subunits - HMI_Oversight
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIOversight"] = {}
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIOversight"]["acLRUName"] = str("HMI_Oversight")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIOversight"]["lstModulesForWhichToSendOutDatabaseMessages"] = []

    # Iterate through all the subunits and set additional keys with values
    iCounter = int(0)
    for _, dctSubUnit in dctGlobalInterfaceDictionaryPar["dctSubUnits"].items():
        dctSubUnit["objsSTATUSREQRSP"] = None  # Store the StatusReportUnsol in here
        dctSubUnit["objClsProcessMessages"] = None  # Will be set later
        dctSubUnit["fTimeoutPeriodS"] = float(3.0)
        dctSubUnit["dctSubUnits"] = {}
        iCounter = iCounter + 1

    # DR
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctDR"]["objsSTATUSREPORTUNSOL"] = sDR_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctDR"]["objClsDrTransitionsManager"] = clsDrTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctDR"]["objClsProcessMessages"] = clsDrProcessMessages(dctGlobalInterfaceDictionaryPar)

    # PDBP
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctPDBP"]["objsSTATUSREPORTUNSOL"] = sPDBP_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctPDBP"]["objClsPdbpTransitionsManager"] = clsPdbpTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctPDBP"]["objClsProcessMessages"] = clsPdbpProcessMessages(dctGlobalInterfaceDictionaryPar)

    # EIU
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctEIU"]["objsSTATUSREPORTUNSOL"] = sEIU_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctEIU"]["objClsEiuTransitionsManager"] = clsEiuTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctEIU"]["objClsProcessMessages"] = clsEiuProcessMessages(dctGlobalInterfaceDictionaryPar)

    # TM
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTM"]["objsSTATUSREPORTUNSOL"] = sTM_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTM"]["objClsTmTransitionsManager"] = clsTmTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTM"]["objClsProcessMessages"] = clsTmProcessMessages(dctGlobalInterfaceDictionaryPar)

    # TEWA
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTEWA"]["objsSTATUSREPORTUNSOL"] = sTEWA_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTEWA"]["objClsTewaTransitionsManager"] = clsTewaTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctTEWA"]["objClsProcessMessages"] = clsTewaProcessMessages(dctGlobalInterfaceDictionaryPar)

    # SF1
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF1"]["objsSTATUSREPORTUNSOL"] = sSF1_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF1"]["objClsSf1TransitionsManager"] = clsSf1TransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF1"]["objClsProcessMessages"] = clsSf1ProcessMessages(dctGlobalInterfaceDictionaryPar)

    # SF2
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF2"]["objsSTATUSREPORTUNSOL"] = sSF2_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF2"]["objClsSf2TransitionsManager"] = clsSf2TransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF2"]["objClsProcessMessages"] = clsSf2ProcessMessages(dctGlobalInterfaceDictionaryPar)

    # SF3
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF3"]["objsSTATUSREPORTUNSOL"] = sSF3_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF3"]["objClsSf3TransitionsManager"] = clsSf3TransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctSF3"]["objClsProcessMessages"] = clsSf3ProcessMessages(dctGlobalInterfaceDictionaryPar)

    # HMI_APM
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPM"]["objsSTATUSREPORTUNSOL"] = sHMI_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPM"]["objClsHmiApmTransitionsManager"] = clsHmiApmTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPM"]["objClsProcessMessages"] = clsHmiApmProcessMessages(dctGlobalInterfaceDictionaryPar)

    # HMI_APM_FCO
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPMFCO"]["objsSTATUSREPORTUNSOL"] = sHMI_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"] = clsHmiApmFcoTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIAPMFCO"]["objClsProcessMessages"] = clsHmiApmFcoProcessMessages(dctGlobalInterfaceDictionaryPar)

    # HMI_FCO
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFCO"]["objsSTATUSREPORTUNSOL"] = sHMI_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFCO"]["objClsHmiFcoTransitionsManager"] = clsHmiFcoTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFCO"]["objClsProcessMessages"] = clsHmiFcoProcessMessages(dctGlobalInterfaceDictionaryPar)

    # HMI_SPM
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPM"]["objsSTATUSREPORTUNSOL"] = sHMI_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPM"]["objClsHmiSpmTransitionsManager"] = clsHmiSpmTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPM"]["objClsProcessMessages"] = clsHmiSpmProcessMessages(dctGlobalInterfaceDictionaryPar)

    # HMI_SPM_FUFC
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPMFUFC"]["objsSTATUSREPORTUNSOL"] = sHMI_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"] = clsHmiSpmFufcTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMISPMFUFC"]["objClsProcessMessages"] = clsHmiSpmFufcProcessMessages(dctGlobalInterfaceDictionaryPar)

    # HMI_FUFC
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFUFC"]["objsSTATUSREPORTUNSOL"] = sHMI_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"] = clsHmiFufcTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIFUFC"]["objClsProcessMessages"] = clsHmiFufcProcessMessages(dctGlobalInterfaceDictionaryPar)

    # HMI_Maintainer
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIMaintainer"]["objsSTATUSREPORTUNSOL"] = sHMI_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"] = clsHmiMaintainerTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIMaintainer"]["objClsProcessMessages"] = clsHmiMaintainerProcessMessages(dctGlobalInterfaceDictionaryPar)

    # HMI_Oversight
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIOversight"]["objsSTATUSREPORTUNSOL"] = sHMI_STATUS_REPORT_UNSOL()
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIOversight"]["objClsHmiOversightTransitionsManager"] = clsHmiOversightTransitionsManager(dctGlobalInterfaceDictionaryPar, acInitialStatePar="OFFLINE")
    dctGlobalInterfaceDictionaryPar["dctSubUnits"]["dctHMIOversight"]["objClsProcessMessages"] = clsHmiOversightProcessMessages(dctGlobalInterfaceDictionaryPar)

    return


def vInitialiseGlobalDictionaryAdvancedItems(dctGlobalInterfaceDictionaryPar: dict):
    """ This is a public function which sets up the global dictionary. This does not set up the skeleton!
    We only set things like instances of classes which needed to be delayed for some reason.

    Args:
        dctGlobalInterfaceDictionaryPar (dict): The first parameter. The global interface dictionary.

    Returns:

    Raises:
        Raises no exceptions
    """

    # Store an instance of the OLHM manager
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["objClsOlhmManager"] = clsOlhmManager(dctGlobalInterfaceDictionaryPar)
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["objClsOlhmTransitionsManager"] = clsOlhmTransitionsManager(dctGlobalInterfaceDictionaryPar)
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["objClsOlhmLauncherManager"] = clsOlhmLauncherManager(dctGlobalInterfaceDictionaryPar)
    dctGlobalInterfaceDictionaryPar["dctOLHM"]["objClsOlhmLauncherManager"].vGetGitHash()

    dctGlobalInterfaceDictionaryPar["dctOLHM"]["objClsOlhmConstructGroupStatus"] = clsOlhmConstructGroupStatus(dctGlobalInterfaceDictionaryPar)

    # Now that the Container and Factory Configuration files have been read update the group module timeout thresholds
    # Iterate through all subunits and set the timeout threshold
    for _, dctSubUnit in dctGlobalInterfaceDictionaryPar["dctSubUnits"].items():
        dctSubUnit["fTimeoutPeriodS"] = float(dctGlobalInterfaceDictionaryPar["dctOLHM"]["fModulePresenceTimeoutThresholdMs"]) / float(1000.0)

    return


def vGetGitRepoHashOlhmFromGit(dctGlobalInterfaceDictionaryPar: dict):
    """ This is a public function which read a text file in the OLHM source directory which contains the
    git repo hash as a text string. Shell script get_git_repo_hash.sh is responsible for creating the
    file we want to read here.

    Args:
        dctGlobalInterfaceDictionaryPar (dict): The first parameter. The global interface dictionary.

    Returns:

    Raises:
        Raises no exceptions
    """
    bGitRepoHashFileExists = bool(False)
    bContinue = bool(False)
    objFileHandler = None
    acFileRawData = None
    acGitRepoHashFilename = "./git_repo_hash.txt"  # This is the file which will contain the git repo hash

    # First verify that the file with the git hash in it exists
    try:
        bGitRepoHashFileExists = os.path.isfile(acGitRepoHashFilename)
    except Exception as E:
        logging.info("Git repo hash file %s does not exist - Exeception %s", acGitRepoHashFilename, str(E))
        return

    if (bGitRepoHashFileExists is False):
        logging.error("File git_repo_hash.txt does not exist")
        return

    # Try to open the file
    bContinue = bool(False)
    try:
        objFileHandler = open(acGitRepoHashFilename, "r")
        bContinue = True
    except Exception as E:
        logging.error("Could not open file %s - Exception %s", acGitRepoHashFilename, str(E))
        return

    if (objFileHandler is None):
        return

    if (bContinue is False):
        return

    bContinue = bool(False)
    try:
        acFileRawData = objFileHandler.read()
        bContinue = True
    except Exception as E:
        logging.error("Could not read file - Exception %s", str(E))

    # Check that the data we read is valid
    if ((bContinue is True) and (isinstance(acFileRawData, str) is True) and (acFileRawData)):
        # Strip possible newlines from the string
        acFileRawData = acFileRawData.rstrip()
        # Save the hash back into the global dictionary
        dctGlobalInterfaceDictionaryPar["dctOLHM"]["acGitRepoHashOlhmFromGit"] = acFileRawData

        logging.info("GIT repo hash is %s", acFileRawData)

    if (objFileHandler is not None):
        try:
            objFileHandler.close()
        except Exception as E:
            logging.error("Could not close file - Exception %s", str(E))

    return


def vGetGitRepoHashSicdFromAutogen(dctGlobalInterfaceDictionaryPar: dict):
    """ This is a public function which reads a text file in the Autogen output indicating
    what the GIT hash of the SICD repo is.

    Args:
        dctGlobalInterfaceDictionaryPar (dict): The first parameter. The global interface dictionary.

    Returns:

    Raises:
        Raises no exceptions
    """
    acSicdGitHashFileName = "sicd_hash.sha1"
    acSicdGitHashFilePath = str("")
    objHashFileHandle = None
    acSicdGitHashFileContent = str("")

    if (dctGlobalInterfaceDictionaryPar is None):
        logging.error("dctGlobalInterfaceDictionaryPar cannot be None")
        return

    if ("dctOLHM" not in dctGlobalInterfaceDictionaryPar):
        logging.error("dctOLHM not in dctGlobalInterfaceDictionaryPar")
        return

    if ("acCurrentDirectory" not in dctGlobalInterfaceDictionaryPar["dctOLHM"]):
        logging.error("acCurrentDirectory not in dctOLHM")
        return

    if ("acGitRepoHashSicdFromAutogen" not in dctGlobalInterfaceDictionaryPar["dctOLHM"]):
        logging.error("acGitRepoHashSicdFromAutogen not in dctOLHM")
        return

    # Join the path to Autogen SICD git hash
    try:
        acSicdGitHashFilePath = os.path.join(dctGlobalInterfaceDictionaryPar["dctOLHM"]["acCurrentDirectory"], "Autogen", acSicdGitHashFileName)
    except Exception as E:
        logging.error("Could not join path to the SICD git hash file from Autogen - Exception %s", str(E))
        return

    if (os.path.isfile(acSicdGitHashFilePath) is False):
        logging.error("File %s does not exist", acSicdGitHashFilePath)
        return

    try:
        # Open file for read
        objHashFileHandle = open(acSicdGitHashFilePath, "r")
        # Read the contents
        acSicdGitHashFileContent = objHashFileHandle.read()
        # Close the file
        objHashFileHandle.close()
        objHashFileHandle = None
    except Exception as E:
        logging.error("Could not open and read file %s - Exception %s", acSicdGitHashFilePath, str(E))

    if (not acSicdGitHashFileContent):
        logging.error("SICD GIT hash file is empty")
        return

    if (objHashFileHandle is not None):
        try:
            objHashFileHandle.close()
            objHashFileHandle = None
        except Exception as E:
            logging.error("Could not close file - Exception %s", str(E))

    if (len(acSicdGitHashFileContent) == 40):
        dctGlobalInterfaceDictionaryPar["dctOLHM"]["acGitRepoHashSicdFromAutogen"] = acSicdGitHashFileContent
        logging.info("The Autogen SICD hash is %s", dctGlobalInterfaceDictionaryPar["dctOLHM"]["acGitRepoHashSicdFromAutogen"])

    return


def vVerifyAutogenSicdHashMatchesContainerConfig(dctGlobalInterfaceDictionaryPar: dict):
    """ This is a public function which compates the SICD hash from the Autogen to
    that of the Container Config file.

    Args:
        dctGlobalInterfaceDictionaryPar (dict): The first parameter. The global interface dictionary.

    Returns:

    Raises:
        Raises no exceptions
    """

    if (dctGlobalInterfaceDictionaryPar is None):
        logging.error("dctGlobalInterfaceDictionaryPar cannot be None")
        return

    if ("acGitRepoHashSicdFromAutogen" not in dctGlobalInterfaceDictionaryPar["dctOLHM"]):
        logging.error("acGitRepoHashSicdFromAutogen not in dctGlobalInterfaceDictionaryPar")
        return

    if ("acGitRepoHashSicdFromContainerConfigFile" not in dctGlobalInterfaceDictionaryPar["dctOLHM"]):
        logging.error("acGitRepoHashSicdFromContainerConfigFile not in dctGlobalInterfaceDictionaryPar")
        return

    # If the config files were invalid then we might not have SICD hash - first check if we have one from the config file
    if (dctGlobalInterfaceDictionaryPar["dctOLHM"]["acGitRepoHashSicdFromContainerConfigFile"]):
        if (dctGlobalInterfaceDictionaryPar["dctOLHM"]["acGitRepoHashSicdFromAutogen"] == dctGlobalInterfaceDictionaryPar["dctOLHM"]["acGitRepoHashSicdFromContainerConfigFile"]):
            logging.info("The Autogen SICD hash %s macthes the SICD hash from the Container Config file", dctGlobalInterfaceDictionaryPar["dctOLHM"]["acGitRepoHashSicdFromAutogen"])
        else:
            logging.error("The Autogen SICD hash %s does not match the Container Config file hash %s", dctGlobalInterfaceDictionaryPar["dctOLHM"]["acGitRepoHashSicdFromAutogen"], dctGlobalInterfaceDictionaryPar["dctOLHM"]["acGitRepoHashSicdFromContainerConfigFile"])

    return


def vWriteToLogPublishAndSubscribeMessageNames(dctGlobalInterfaceDictionaryPar: dict):
    """ This is a public function writes to the log the names of the publish messages

    Args:
        dctGlobalInterfaceDictionaryPar (dict): The first parameter. The global interface dictionary.

    Returns:

    Raises:
        Raises no exceptions
    """
    lstModInterConfTopicInfoLocal = []
    lstPublishMessageNames = []
    lstMessageItems = []
    acFullTopic = str("")

    if (dctGlobalInterfaceDictionaryPar is None):
        logging.error("dctGlobalInterfaceDictionaryPar cannot be None")
        return

    if ("dctOLHM" not in dctGlobalInterfaceDictionaryPar):
        logging.error("Key dctOLHM is missing in dctGlobalInterfaceDictionaryPar")
        return

    if ("objClsModuleInterfaceConfigOlhm" not in dctGlobalInterfaceDictionaryPar["dctOLHM"]):
        logging.error("Key objClsModuleInterfaceConfigOlhm is missing")
        return

    if (dctGlobalInterfaceDictionaryPar["dctOLHM"]["objClsModuleInterfaceConfigOlhm"] is None):
        logging.error("objClsModuleInterfaceConfigOlhm cannot be None")
        return

    lstModInterConfTopicInfoLocal = dctGlobalInterfaceDictionaryPar["dctOLHM"]["objClsModuleInterfaceConfigOlhm"].lstModInterConfTopicInfo

    # Use list comprehension to filter out all the messages marked for publishing
    lstMessageItems = [dctMessageItem for dctMessageItem in lstModInterConfTopicInfoLocal if dctMessageItem["eMessageFlowDirection"] == E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_PUBLISH)]

    for dctMessageItem in lstMessageItems:
        acFullTopic = "%s/%s/%s" % (dctMessageItem["acSystem"], dctMessageItem["acModule"], dctMessageItem["acMessagename"])

        if (dctMessageItem["acRole"]):
            acFullTopic += "/%s" % (dctMessageItem["acRole"])

        lstPublishMessageNames.append(acFullTopic)
        logging.info("Publish topic for message %s is %s", dctMessageItem["acMessagename"], acFullTopic)

    # Use list comprehension to filter out all the messages marked for subscribe
    lstMessageItems = [dctMessageItem for dctMessageItem in lstModInterConfTopicInfoLocal if dctMessageItem["eMessageFlowDirection"] == E_MESSAGE_FLOW_DIRECTION(E_MESSAGE_FLOW_DIRECTION.MESSAGE_FLOW_DIRECTION_SUBSCRIBE)]

    for dctMessageItem in lstMessageItems:
        acFullTopic = "%s/%s/%s" % (dctMessageItem["acSystem"], dctMessageItem["acModule"], dctMessageItem["acMessagename"])

        if (dctMessageItem["acRole"]):
            acFullTopic += "/%s" % (dctMessageItem["acRole"])

        lstPublishMessageNames.append(acFullTopic)
        logging.info("Subscribe topic for message %s is %s", dctMessageItem["acMessagename"], acFullTopic)

    logging.info("Publish and subscribe parameters were read")

    return


def vModuleMain():
    """ This is a public function which is called when the global name is __main__. The entire Pythom module is kicked off using this
    method.

    Args:

    Returns:

    Raises:
        Raises no exceptions
    """

    C_I_MAX_MESSAGE_QUEUE_SIZE = int(10000)  # This value is used later to construct the python queue
    dctGlobalInterfaceDictionary = {}
    objDateTimeUtc = clsDatetimeUtilities.objGetUtcCurrentDatetime()
    objFileObjectContainerConfig = None
    objFileObjectFactoryConfig = None
    acOlhmPyFileDirName = str("")  # This is used to store the directory path in which this file (olhm.py) is

    objQueue = queue.Queue(C_I_MAX_MESSAGE_QUEUE_SIZE)  # Create a python queue to pass to the mqtt template

    # Before we do anything else first see if there is already an existing instance of myself running
    if (clsProcessMonitoringAndManagement.bSendSignalToSpecifiedCommandLine(["python3.6", "olhm.py"], signal.SIGTERM, os.getpid()) is True):
        print("Please wait while I terminate another instance of myself already running")
        time.sleep(1)

    # For argparse arguments
    # -> -i PATH                     The path of the ini file (REQUIRED)
    # -> -t                          Run the unit tests and exit (OPTIONAL)
    # -> -h                          Show the argparse help (OPTIONAL)

    # Make an instance of a argeparse to help us manage command line arguments
    objArgParser = argparse.ArgumentParser()
    objArgParser.add_argument("-t", action='store_true', required=False, help="Parameter indicating if unit test should be run")  # We must supply a INI file path
    args = objArgParser.parse_args()  # Parse the args and make sure we have everything we need

    # Get the path if this file olhm.py
    try:
        acOlhmPyFileDirName = os.path.dirname(os.path.abspath(__file__))
    except Exception as E:
        logging.error("Could not get directory name of this file - Exception %s", str(E))
        sys.exit()

    # If we can't get the path of this file then exit
    if (not acOlhmPyFileDirName):
        logging.error("Could not get the path of olhm.py")
        sys.exit()

    # Change the working directory to where olhm.py is
    try:
        os.chdir(acOlhmPyFileDirName)
    except Exception as E:
        logging.error("Could not change directory to %s - Exception %s", acOlhmPyFileDirName, str(E))
        sys.exit()

    # Immediately start the logger
    # We log datetime, filename, line number and message
    # Open the file in append mode so that we don't lose the history

    objClsLoggerManager = clsLoggingManager()
    # The OLHM ATP document 5850-BS-5000V01.00 TZ Rev C (page 12) states that the log files will live in a directory called "OLHM_Logs"
    objClsLoggerManager.vConfigureLogger(acFilenamePar="../OLHM_Logs/logging.log", acModuleNamePar="OLHM")
    objRootLogger = objClsLoggerManager.objGetLoggerInstance()
    objRootLogger.setLevel(logging.INFO)

    # If we passed in the unit-test option as an argument then run the unit tests and exit
    if (args.t is True):
        objRootLogger.setLevel(logging.DEBUG)
        if (clsMainTestClass.bMainTestMethod() is True):
            logging.info("All unit tests passed")
        else:
            logging.info("One or more unit tests failed")
        logging.info("Will now exit OLHM!!!")
        sys.exit()

    # Indicate that the logging has started
    logging.info("======================================================")
    logging.info("= OLHM                                               =")
    logging.info("======================================================")

    # Build up the global dictionary after getting the logger up
    # Note!!! this will only set up a basic skeleton
    vInitialiseGlobalDictionarySkeleton(dctGlobalInterfaceDictionary)

    dctGlobalInterfaceDictionary["dctMqtt"]["objQueue"] = objQueue  # Now store the Python Queue in the global dictionary
    dctGlobalInterfaceDictionary["dctOLHM"]["objArgs"] = args  # Save the args

    # Build up the client name as a combination of the filename, OLHM interface version number and the PID
    dctGlobalInterfaceDictionary["dctMqtt"]["acMqttId"] = os.path.basename(__file__) + ":V:" + str(dctGlobalInterfaceDictionary["dctOLHM"]["iVersionMajor"]) + "." + str(dctGlobalInterfaceDictionary["dctOLHM"]["iVersionMinor"]) + "." + str(dctGlobalInterfaceDictionary["dctOLHM"]["iVersionInternal"]) + ":PID:" + str(os.getpid())

    logging.info("OLHM version is %d.%d.%d ", dctGlobalInterfaceDictionary["dctOLHM"]["iVersionMajor"], dctGlobalInterfaceDictionary["dctOLHM"]["iVersionMinor"], dctGlobalInterfaceDictionary["dctOLHM"]["iVersionInternal"])
    logging.info("Startup UTC date and time is %s", str(objDateTimeUtc))

    logging.debug("Python version is [major] %d ", sys.version_info[0])
    logging.debug("Python version is [minor] %d ", sys.version_info[1])
    logging.debug("MQTT client name is %s", dctGlobalInterfaceDictionary["dctMqtt"]["acMqttId"])

    if ((float(sys.version_info[0]) + (float(sys.version_info[1]) / 10.0)) < 3.6):
        logging.error("Python version must be 3.6 or higher")
        dctGlobalInterfaceDictionary["dctOLHM"]["bConfigFilesAndSelfCheckPassed"] = bool(False)

    logging.debug("This platform is %s", sys.platform)

    # Get the current directory
    acCurrentDirectory = os.getcwd()
    logging.info("The current directory is %s", str(acCurrentDirectory))

    dctGlobalInterfaceDictionary["dctOLHM"]["acCurrentDirectory"] = acCurrentDirectory

    if (dctGlobalInterfaceDictionary["dctOLHM"]["bConfigFilesAndSelfCheckPassed"] is True):
        dctGlobalInterfaceDictionary["dctOLHM"]["bConfigFilesAndSelfCheckPassed"] = bCheckIfFilesAndDirectoriesExist(dctGlobalInterfaceDictionary)

    # Read the container config file
    if (dctGlobalInterfaceDictionary["dctOLHM"]["bContainerConfigFileExists"] is True):
        try:
            objFileObjectContainerConfig = open(dctGlobalInterfaceDictionary["dctOLHM"]["acContainerConfigAbsolutePath"], "r")
            dctGlobalInterfaceDictionary["dctOLHM"]["acContainerConfigFileContents"] = objFileObjectContainerConfig.read()
            dctGlobalInterfaceDictionary["dctOLHM"]["objContainerConfigTomlObject"] = toml.loads(dctGlobalInterfaceDictionary["dctOLHM"]["acContainerConfigFileContents"])
            logging.debug("Container config file read successfully")
        except Exception as E:
            logging.error("Could not open and read file %s - Exception %s", dctGlobalInterfaceDictionary["dctOLHM"]["acContainerConfigAbsolutePath"], str(E))
            dctGlobalInterfaceDictionary["dctOLHM"]["bConfigFilesAndSelfCheckPassed"] = bool(False)

    # Try to close the container config file
    if (objFileObjectContainerConfig is not None):
        try:
            objFileObjectContainerConfig.close()
        except Exception as E:
            logging.error("Could not close file %s - Exception %s", dctGlobalInterfaceDictionary["dctOLHM"]["acContainerConfigAbsolutePath"], str(E))
            dctGlobalInterfaceDictionary["dctOLHM"]["bConfigFilesAndSelfCheckPassed"] = bool(False)

    # Read the factory config file
    if (dctGlobalInterfaceDictionary["dctOLHM"]["bFactoryConfigFileExists"] is True):
        try:
            objFileObjectFactoryConfig = open(dctGlobalInterfaceDictionary["dctOLHM"]["acFactoryConfigAbsolutePath"], 'r')
            dctGlobalInterfaceDictionary["dctOLHM"]["acFactoryConfigFileContents"] = objFileObjectFactoryConfig.read()
            dctGlobalInterfaceDictionary["dctOLHM"]["objFactoryConfigTomlObject"] = toml.loads(dctGlobalInterfaceDictionary["dctOLHM"]["acFactoryConfigFileContents"])
            logging.debug("Factory config file read successfully")
        except Exception as E:
            logging.error("Could not open and read file %s - Exception %s", dctGlobalInterfaceDictionary["dctOLHM"]["acFactoryConfigAbsolutePath"], str(E))
            dctGlobalInterfaceDictionary["dctOLHM"]["bConfigFilesAndSelfCheckPassed"] = bool(False)

    # Try to close the container config file
    if (objFileObjectFactoryConfig is not None):
        try:
            objFileObjectFactoryConfig.close()
        except Exception as E:
            logging.error("Could not close file %s - Exception %s", dctGlobalInterfaceDictionary["dctOLHM"]["acFactoryConfigAbsolutePath"], str(E))
            dctGlobalInterfaceDictionary["dctOLHM"]["bConfigFilesAndSelfCheckPassed"] = bool(False)

    # Go through the container config and factory config contents and check it for validity.
    # Also set the global dictionary with the values in the INI file
    if (bValidateConfigFilesAndSetGlobalDict(dctGlobalInterfaceDictionary) is False):
        logging.error("OLHM Container Configuration and/or Factory Configuration files are invalid")
        dctGlobalInterfaceDictionary["dctOLHM"]["bConfigFilesAndSelfCheckPassed"] = bool(False)
    else:
        logging.info("OLHM Container Configuration and Factory Configuration files are consistent, complete and correct")
        logging.info("All parameters were read")

    if (dctGlobalInterfaceDictionary["dctOLHM"]["acLogLevel"] == "NOTSET"):
        objRootLogger.setLevel(logging.NOTSET)
    elif (dctGlobalInterfaceDictionary["dctOLHM"]["acLogLevel"] == "DEBUG"):
        objRootLogger.setLevel(logging.DEBUG)
    elif (dctGlobalInterfaceDictionary["dctOLHM"]["acLogLevel"] == "INFO"):
        objRootLogger.setLevel(logging.INFO)
    elif (dctGlobalInterfaceDictionary["dctOLHM"]["acLogLevel"] == "WARNING"):
        objRootLogger.setLevel(logging.WARNING)
    elif (dctGlobalInterfaceDictionary["dctOLHM"]["acLogLevel"] == "ERROR"):
        objRootLogger.setLevel(logging.ERROR)
    elif (dctGlobalInterfaceDictionary["dctOLHM"]["acLogLevel"] == "CRITICAL"):
        objRootLogger.setLevel(logging.CRITICAL)

    # Now that the INI file has been read, validated and more global dictionary items set, we can
    # now proceed and create instances of certain classes which needed some information from the INI file.
    vInitialiseGlobalDictionaryAdvancedItems(dctGlobalInterfaceDictionary)

    # Write to log all the messages which were marked as publish messages
    vWriteToLogPublishAndSubscribeMessageNames(dctGlobalInterfaceDictionary)

    client = mqtt.Client(client_id=dctGlobalInterfaceDictionary["dctMqtt"]["acMqttId"])  # Make an instance of a MQTT client
    objClsOlhmMqttAutogenHandler = clsOlhmMqttAutogenHandler(objQueue, [])    # Pass the queue on to the template so that messages can be sent back to the main thread
    client.on_connect = objClsOlhmMqttAutogenHandler.vOnConnect

    # Save the mqtt client object in the global dictionry
    dctGlobalInterfaceDictionary["dctMqtt"]["objMqttClientPar"] = client

    if (dctGlobalInterfaceDictionary["dctOLHM"]["bConfigFilesAndSelfCheckPassed"] is True):
        try:
            client.connect(dctGlobalInterfaceDictionary["dctMqtt"]["acMosquittoBrokerIp"],
                           dctGlobalInterfaceDictionary["dctMqtt"]["iMosquittoBrokerPort"],
                           dctGlobalInterfaceDictionary["dctMqtt"]["iMosquittoBrokerKeepAliveSec"])
            logging.info("Connected to MQTT broker IP %s on port %d with keep alive as %d", dctGlobalInterfaceDictionary["dctMqtt"]["acMosquittoBrokerIp"], dctGlobalInterfaceDictionary["dctMqtt"]["iMosquittoBrokerPort"], dctGlobalInterfaceDictionary["dctMqtt"]["iMosquittoBrokerKeepAliveSec"])
        except Exception as E:
            logging.error("Could not connect to the mosquitto broker - Exception %s", str(E))
            dctGlobalInterfaceDictionary["dctOLHM"]["bConfigFilesAndSelfCheckPassed"] = bool(False)
    else:
        logging.error("Config files failed validation so therefore will not connect to MQTT broker")

    if (dctGlobalInterfaceDictionary["dctOLHM"]["bConfigFilesAndSelfCheckPassed"] is True):
        try:
            client.loop_start()
            logging.debug("MQTT loop_start")
        except Exception as E:
            dctGlobalInterfaceDictionary["dctOLHM"]["bConfigFilesAndSelfCheckPassed"] = bool(False)
            logging.error("Could not loop_start the MQTT client - Exception %s", str(E))
    else:
        logging.error("Could not loop_start the MQTT client")

    objAsyncioLoop = None  # First declare the loop instance as None

    # Read the file created by the shell script which saves the git repo hash in a text file
    vGetGitRepoHashOlhmFromGit(dctGlobalInterfaceDictionary)
    # Read the SICD GIT hash from the Autogen
    vGetGitRepoHashSicdFromAutogen(dctGlobalInterfaceDictionary)
    # Compare the SICD hash from the Autogen against the one from the Container Config file
    vVerifyAutogenSicdHashMatchesContainerConfig(dctGlobalInterfaceDictionary)

    if (dctGlobalInterfaceDictionary["dctOLHM"]["bConfigFilesAndSelfCheckPassed"] is False):
        dctGlobalInterfaceDictionary["dctOLHM"]["objClsOlhmTransitionsManager"].trgFAILED()
    else:

        try:
            # Get the asyncio event loop instance
            objAsyncioLoop = asyncio.get_event_loop()
        except Exception as E:
            logging.error(str(E))
            objAsyncioLoop = None

        if (objAsyncioLoop is not None):
            objAsyncioLoop.run_until_complete(main(objAsyncioLoop, client, dctGlobalInterfaceDictionary))

    if (dctGlobalInterfaceDictionary["dctOLHM"]["objClsOlhmTransitionsManager"].state == "FAILED"):
        while True:
            time.sleep(0.1)

    logging.info("Exiting %s", dctGlobalInterfaceDictionary["dctMqtt"]["acMqttId"])


# ===========================================
# Module "__main__" function
# ===========================================


if __name__ == "__main__":
    vModuleMain()
