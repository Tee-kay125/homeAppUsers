#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which processes messages received from the SF2.


Todo:

"""

import logging
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
from python_toolbox.Datetime_Utilities.datetime_utilities import clsDatetimeUtilities
from Autogen.asyncio_message_processing_olhm import clsPythonAsyncioMessageProcessing
from Autogen.adcs_common_types import E1_ADCS_SYSTEM_STATE
from Autogen.mw_common_types import E2_MW_MESSAGE_STATUS
from Autogen.sf2_msg import sSF2_END_OF_SETUP_CMD
from Autogen.sf2_msg import sSF2_END_OF_SETUP_CMD_RSP
from Autogen.sf2_msg import sSF2_END_OF_READY_CMD
from Autogen.sf2_msg import sSF2_END_OF_READY_CMD_RSP
from Autogen.sf2_msg import sSF2_SHUTDOWN_CMD
from Autogen.sf2_msg import sSF2_SHUTDOWN_CMD_RSP


class clsAsyncioMsgProcessingClassSf2(clsPythonAsyncioMessageProcessing):
    """ This is the asyncio message processing class for the messages from the SF2.

    Args:
        objMqttClientPar (mqtt.Client): The first parameter. The instance of the MQTT client
        dctMessagesPar (dict): The second parameter. A dictionary containing all messages and futures for messages which were automatically processed by the autogen. This must be passed in for the autogen base class.
        objAsyncioLoopPar (object): The third parameter. The asyncio loop passed in so tasks can be created and for other asyncio functionality
        dctGlobalInterfaceDictionaryPar (dict): The fourth parameter. The interface's global dictionary.
        bLoggingEnabledPar (bool): The fifth parameter. A boolean flag indicating if logging should be done or not.
    """

    def __init__(self, objMqttClientPar: mqtt.Client, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar: bool = True):
        # Very important!!! The MRO (method resolution order) will not yet call the autogen base because it isn't last in the list of inheritance - therefore pass more parameter than used for the base class
        super().__init__(objMqttClientPar, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar)
        self._objMqttClient = objMqttClientPar
        self._dctMessages = dctMessagesPar
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar
        self._objClsSf2ProcessMessages = self._dctGloInterDict["dctSubUnits"]["dctSF2"]["objClsProcessMessages"]

        self._dctStateStringToE1AdcsSystemStateLookup = {}
        self._dctStateStringToE1AdcsSystemStateLookup["OFFLINE"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE
        self._dctStateStringToE1AdcsSystemStateLookup["INITIALISE"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE
        self._dctStateStringToE1AdcsSystemStateLookup["READY"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY
        self._dctStateStringToE1AdcsSystemStateLookup["OPERATIONAL"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL
        self._dctStateStringToE1AdcsSystemStateLookup["SHUTDOWN"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN
        self._dctStateStringToE1AdcsSystemStateLookup["FAILED"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED
        self._dctStateStringToE1AdcsSystemStateLookup["UNKNOWN"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN

        return

#    ==============================================================================================================
#    Base class methods to override - START
#    ==============================================================================================================

# 0x0000 - Sf2StatusReportUnsol
    async def objProcessPayloadSf2StatusReportUnsol(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for Sf2StatusReportUnsol

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        # Check that they are the same size
        if (dctObjectPar["MsgObject"].iSizeBytes() == self._dctGloInterDict["dctSubUnits"]["dctSF2"]["objsSTATUSREPORTUNSOL"].iSizeBytes()):
            self._dctGloInterDict["dctSubUnits"]["dctSF2"]["objsSTATUSREPORTUNSOL"].vDeserialise(dctObjectPar["MsgObject"].btaSerialise())
            lstEntries = self._objClsSf2ProcessMessages.lstCreateDetailedTreeEntriesFromSf2StatusReportUnsol(self._dctGloInterDict["dctSubUnits"]["dctSF2"]["objsSTATUSREPORTUNSOL"])
            self._dctGloInterDict["dctOLHM"]["objClsOlhmConstructGroupStatus"].vUpdateDetailedTreeFromListOfEntries(lstEntries)

        if (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE):
            self._dctGloInterDict["dctSubUnits"]["dctSF2"]["objClsSf2TransitionsManager"].trgSf2Initialise()
        elif (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY):
            self._dctGloInterDict["dctSubUnits"]["dctSF2"]["objClsSf2TransitionsManager"].trgSf2Ready()
        elif (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL):
            self._dctGloInterDict["dctSubUnits"]["dctSF2"]["objClsSf2TransitionsManager"].trgSf2Operational()
        elif (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED):
            self._dctGloInterDict["dctSubUnits"]["dctSF2"]["objClsSf2TransitionsManager"].trgSf2Failed()
        elif (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN):
            self._dctGloInterDict["dctSubUnits"]["dctSF2"]["objClsSf2TransitionsManager"].trgSf2Shutdown()
        else:
            self._dctGloInterDict["dctSubUnits"]["dctSF2"]["objClsSf2TransitionsManager"].trgSf2Failed()

        return(None)

# 0x0001 - Sf2EndOfSetupCmdRsp
    async def objProcessPayloadSf2EndOfSetupCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for Sf2EndOfSetupCmdRsp

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        await super().objProcessPayloadSf2EndOfSetupCmdRsp(dctObjectPar)

        objsSF2_END_OF_SETUP_CMD_RSP = sSF2_END_OF_SETUP_CMD_RSP()
        objsSF2_END_OF_SETUP_CMD_RSP.vDeserialise(dctObjectPar["MsgObject"].btaSerialise())

        # See if the CmdRsp status is normal
        if (objsSF2_END_OF_SETUP_CMD_RSP.sMsgHeader.e2MsgStatus.Value == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            self._dctGloInterDict["dctSubUnits"]["dctSF2"]["objClsSf2TransitionsManager"].trgSf2Ready()
        else:
            logging.error("sSF2_END_OF_SETUP_CMD_RSP status is not normal with a value of %d", objsSF2_END_OF_SETUP_CMD_RSP.sMsgHeader.e2MsgStatus.Value)

        return(None)

# 0x0002 - Sf2EndOfReadyCmdRsp
    async def objProcessPayloadSf2EndOfReadyCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for Sf2EndOfReadyCmdRsp

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        await super().objProcessPayloadSf2EndOfReadyCmdRsp(dctObjectPar)

        objsSF2_END_OF_READY_CMD_RSP = sSF2_END_OF_READY_CMD_RSP()
        objsSF2_END_OF_READY_CMD_RSP.vDeserialise(dctObjectPar["MsgObject"].btaSerialise())

        # See if the CmdRsp status is normal
        if (objsSF2_END_OF_READY_CMD_RSP.sMsgHeader.e2MsgStatus.Value == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            self._dctGloInterDict["dctSubUnits"]["dctSF2"]["objClsSf2TransitionsManager"].trgSf2Operational()
        else:
            logging.error("sSF2_END_OF_READY_CMD_RSP status is not normal with a value of %d", objsSF2_END_OF_READY_CMD_RSP.sMsgHeader.e2MsgStatus.Value)

        return(None)

# 0x0003 - Sf2ShutdownCmdRsp
    async def objProcessPayloadSf2ShutdownCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for Sf2ShutdownCmdRsp

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        await super().objProcessPayloadSf2ShutdownCmdRsp(dctObjectPar)

        objsSF2_SHUTDOWN_CMD_RSP = sSF2_SHUTDOWN_CMD_RSP()
        objsSF2_SHUTDOWN_CMD_RSP.vDeserialise(dctObjectPar["MsgObject"].btaSerialise())

        # See if the CmdRsp status is normal
        if (objsSF2_SHUTDOWN_CMD_RSP.sMsgHeader.e2MsgStatus.Value == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            self._dctGloInterDict["dctSubUnits"]["dctSF2"]["objClsSf2TransitionsManager"].trgSf2Shutdown()
        else:
            logging.error("sSF2_SHUTDOWN_CMD_RSP status is not normal with a value of %d", objsSF2_SHUTDOWN_CMD_RSP.sMsgHeader.e2MsgStatus.Value)

        return(None)

#    ==============================================================================================================
#    Base class methods to override - END
#    ==============================================================================================================

# 0x0001 vSendSf2EndOfSetupCmd
    def vSendSf2EndOfSetupCmd(self):
        """ This is a public method which is used to send a sSF2_END_OF_SETUP_CMD message

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        objsSF2_END_OF_SETUP_CMD = sSF2_END_OF_SETUP_CMD()

        self.vIncreaseMessageCounter((type(objsSF2_END_OF_SETUP_CMD), ""))  # pylint: disable=no-member
        objsSF2_END_OF_SETUP_CMD.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsSF2_END_OF_SETUP_CMD), "")]  # pylint: disable=no-member
        objsSF2_END_OF_SETUP_CMD.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsSF2_END_OF_SETUP_CMD)  # pylint: disable=no-member

        return

# 0x0002 vSendSf2EndOfReadyCmd
    def vSendSf2EndOfReadyCmd(self):
        """ This is a public method which is used to send a sSF2_END_OF_READY_CMD message

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        objsSF2_END_OF_READY_CMD = sSF2_END_OF_READY_CMD()

        self.vIncreaseMessageCounter((type(objsSF2_END_OF_READY_CMD), ""))  # pylint: disable=no-member
        objsSF2_END_OF_READY_CMD.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsSF2_END_OF_READY_CMD), "")]  # pylint: disable=no-member
        objsSF2_END_OF_READY_CMD.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsSF2_END_OF_READY_CMD)  # pylint: disable=no-member

        return

# 0x0003 vSendSf2ShutdownCmd
    def vSendSf2ShutdownCmd(self):
        """ This is a public method which is used to send a sSF2_SHUTDOWN_CMD message

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        objsSF2_SHUTDOWN_CMD = sSF2_SHUTDOWN_CMD()

        self.vIncreaseMessageCounter((type(objsSF2_SHUTDOWN_CMD), ""))  # pylint: disable=no-member
        objsSF2_SHUTDOWN_CMD.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsSF2_SHUTDOWN_CMD), "")]  # pylint: disable=no-member
        objsSF2_SHUTDOWN_CMD.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsSF2_SHUTDOWN_CMD)  # pylint: disable=no-member

        return
