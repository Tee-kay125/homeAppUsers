#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which processes messages for the OLHM.

Todo:

"""


import logging
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
from python_toolbox.Datetime_Utilities.datetime_utilities import clsDatetimeUtilities

from Autogen.asyncio_message_processing_olhm import clsPythonAsyncioMessageProcessing
from Autogen.olhm_msg import E1_OLHM_ACTION_STATUS_REPORT
from Autogen.olhm_msg import sOLHM_ADCS_STATUS_UNSOL  # ID 0x0000
from Autogen.olhm_msg import sOLHM_END_OF_READY_CMD_RSP
from Autogen.olhm_msg import sOLHM_ADCS_SHUTDOWN_CMD_RSP
from Autogen.olhm_msg import sOLHM_ADCS_HMI_STATUS_UNSOL  # ID 0x0011
from Autogen.olhm_msg import sOLHM_ACTION_STATUS_REPORT_UNSOL  # ID 0x0012


class clsAsyncioMsgProcessingClassOlhm(clsPythonAsyncioMessageProcessing):
    """This is a class for processing messages for the SCS.

    Args:
        objMqttClientPar (object): The first parameter. The MQTT client.
        dctMessagesPar (dict): The second parameter. The dictionary in which the base class saves the messages and their futures.
        objAsyncioLoopPar (object): The third parameter. The asyncio loop object.
        dctGlobalInterfaceDictionaryPar (dct): The fourth parameter. The global interface dictionary. See olhm.py for the layout and breakdown of the keys.
        bLoggingEnabledPar (bool): The fifth parameter. A boolean flag used to indicate if the base class should log or not.

    """

    def __init__(self, objMqttClientPar: mqtt.Client, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar: bool = True):
        # Very important!!! The next constructor to be called will be clsPythonAsyncioMessageProcessing() init(...) - This class was last in the list multiple inheritance and therefore it special
        # The clsPythonAsyncioMessageProcessing() init(...) takes fewer parameters than the constructors which came before
        super().__init__(objMqttClientPar, dctMessagesPar, dctGlobalInterfaceDictionaryPar["dctMqtt"]["lstTasksAllowedForsimultaneousExecution"], objAsyncioLoopPar, bLoggingEnabledPar)
        self._objMqttClient = objMqttClientPar
        self._dctMessages = dctMessagesPar
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar

        return

#    ==============================================================================================================
#    Base class methods to override - START
#    ==============================================================================================================

    async def objProcessPayloadOlhmEndOfReadyCmd(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for OlhmEndOfReadyCmd

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """
        objsOLHM_END_OF_READY_CMD_RSP = sOLHM_END_OF_READY_CMD_RSP()

        # Do some sanity checks
        if (self._dctGloInterDict is None):
            logging.error("_dctGloInterDict cannot be None")
            return(None)

        self._dctMessageCounters[(type(objsOLHM_END_OF_READY_CMD_RSP), "")] += 1  # pylint: disable=no-member
        objsOLHM_END_OF_READY_CMD_RSP.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsOLHM_END_OF_READY_CMD_RSP), "")]  # pylint: disable=no-member
        objsOLHM_END_OF_READY_CMD_RSP.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        return(objsOLHM_END_OF_READY_CMD_RSP)

    async def objProcessPayloadOlhmAdcsShutdownCmd(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for OlhmAdcsShutdownCmd

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """
        bSendResponse = bool(True)

        # Do some sanity checks
        if (self._dctGloInterDict is None):
            logging.error("_dctGloInterDict cannot be None")
            return(None)

        # See if we are already in a SHUTDOWN state
        # If we enter the SHUTDOWN state then we will reply in there
        bSendResponse = self._dctGloInterDict["dctOLHM"]["objClsOlhmTransitionsManager"].state == "SHUTDOWN"

        self._dctGloInterDict["dctOLHM"]["objClsOlhmTransitionsManager"].vTriggerShutdown("OlhmAdcsShutdownCmd")

        # If this is true then it means we were already in a SHUTDOWN and we would need to reply here because on enter won't trigger
        if (bSendResponse is True):
            self.vSendOlhmAdcsShutdownCmdRsp()

        return(None)

#    ==============================================================================================================
#    Base class methods to override - END
#    ==============================================================================================================

# 0x0000 vSendOlhmAdcsStatusUnsol
    def vSendOlhmAdcsStatusUnsol(self, objsOLHM_ADCS_STATUS_UNSOLPar: sOLHM_ADCS_STATUS_UNSOL):
        """ This is a public method which is used to send a OlhmAdcsStatusUnsol message

        Args:
            objsOLHM_ADCS_STATUS_UNSOLPar (sOLHM_ADCS_STATUS_UNSOL): A sOLHM_ADCS_STATUS_UNSOL message autogen object

        Returns:

        Raises:
            Raises no exception.
        """

        if (objsOLHM_ADCS_STATUS_UNSOLPar is None):
            logging.error("objsOLHM_ADCS_STATUS_UNSOLPar cannot be None")
            return

        self.vIncreaseMessageCounter((type(objsOLHM_ADCS_STATUS_UNSOLPar), ""))  # pylint: disable=no-member
        objsOLHM_ADCS_STATUS_UNSOLPar.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsOLHM_ADCS_STATUS_UNSOLPar), "")]  # pylint: disable=no-member
        objsOLHM_ADCS_STATUS_UNSOLPar.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsOLHM_ADCS_STATUS_UNSOLPar)  # pylint: disable=no-member

        return

# 0x0010 vSendOlhmAdcsShutdownCmdRsp
    def vSendOlhmAdcsShutdownCmdRsp(self):
        """ This is a public method which is used to send a OlhmAdcsShutdownCmdRsp message

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        objsOLHM_ADCS_SHUTDOWN_CMD_RSP = sOLHM_ADCS_SHUTDOWN_CMD_RSP()

        if (objsOLHM_ADCS_SHUTDOWN_CMD_RSP is None):
            logging.error("objsOLHM_ADCS_SHUTDOWN_CMD_RSP cannot be None")
            return

        self.vIncreaseMessageCounter((type(objsOLHM_ADCS_SHUTDOWN_CMD_RSP), ""))  # pylint: disable=no-member
        objsOLHM_ADCS_SHUTDOWN_CMD_RSP.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsOLHM_ADCS_SHUTDOWN_CMD_RSP), "")]  # pylint: disable=no-member
        objsOLHM_ADCS_SHUTDOWN_CMD_RSP.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsOLHM_ADCS_SHUTDOWN_CMD_RSP)  # pylint: disable=no-member

        return

# 0x0011 vSendOlhmAdcsHmiStatusUnsol
    def vSendOlhmAdcsHmiStatusUnsol(self, objsOLHM_ADCS_HMI_STATUS_UNSOLPar: sOLHM_ADCS_HMI_STATUS_UNSOL):
        """ This is a public method which is used to send a OlhmAdcsHmiStatusUnsol message

        Args:
            objsOLHM_ADCS_HMI_STATUS_UNSOLPar (sOLHM_ADCS_HMI_STATUS_UNSOL): A sOLHM_ADCS_HMI_STATUS_UNSOL message autogen object

        Returns:

        Raises:
            Raises no exception.
        """

        if (objsOLHM_ADCS_HMI_STATUS_UNSOLPar is None):
            logging.error("objsOLHM_ADCS_HMI_STATUS_UNSOLPar cannot be None")
            return

        self.vIncreaseMessageCounter((type(objsOLHM_ADCS_HMI_STATUS_UNSOLPar), ""))  # pylint: disable=no-member
        objsOLHM_ADCS_HMI_STATUS_UNSOLPar.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsOLHM_ADCS_HMI_STATUS_UNSOLPar), "")]  # pylint: disable=no-member
        objsOLHM_ADCS_HMI_STATUS_UNSOLPar.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsOLHM_ADCS_HMI_STATUS_UNSOLPar)  # pylint: disable=no-member

        return

# 0x0012 vSendOlhmActionStatusReportUnsol
    def vSendOlhmActionStatusReportUnsol(self, e1OlhmActionStatusReportPar: E1_OLHM_ACTION_STATUS_REPORT):
        """ This is a public method which is used to send a OlhmActionStatusReportUnsol message

        Args:
            e1OlhmActionStatusReportPar (E1_OLHM_ACTION_STATUS_REPORT): A E1_OLHM_ACTION_STATUS_REPORT object.

        Returns:

        Raises:
            Raises no exception.
        """
        objsOLHM_ACTION_STATUS_REPORT_UNSOL = sOLHM_ACTION_STATUS_REPORT_UNSOL()

        if (e1OlhmActionStatusReportPar is None):
            logging.error("e1OlhmActionStatusReportPar cannot be None")
            return

        self.vIncreaseMessageCounter((type(objsOLHM_ACTION_STATUS_REPORT_UNSOL), ""))  # pylint: disable=no-member
        objsOLHM_ACTION_STATUS_REPORT_UNSOL.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsOLHM_ACTION_STATUS_REPORT_UNSOL), "")]  # pylint: disable=no-member
        objsOLHM_ACTION_STATUS_REPORT_UNSOL.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()
        objsOLHM_ACTION_STATUS_REPORT_UNSOL.sMsgPayload.e1OlhmActionStatusReport.Value = e1OlhmActionStatusReportPar.Value

        self.bPublishMqttAutogenObject(objsOLHM_ACTION_STATUS_REPORT_UNSOL)  # pylint: disable=no-member

        return
