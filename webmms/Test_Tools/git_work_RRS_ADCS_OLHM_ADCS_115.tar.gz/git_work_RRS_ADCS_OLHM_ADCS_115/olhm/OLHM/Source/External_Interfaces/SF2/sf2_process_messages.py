#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which processes SF2 messages

Todo:

"""
import logging
from Autogen.sf2_msg import sSF2_STATUS_REPORT_UNSOL
from Autogen.sf2_msg import E1_SF2_STATUS
from Autogen.olhm_msg import E1_OLHM_STATE
from Autogen.olhm_msg import E1_OLHM_HEALTH_STATUS
from Autogen.adcs_common_types import E1_ADCS_SYSTEM_STATE


class clsSf2ProcessMessages:
    """ This is a class which processes SF2 messages.

    Args:
        dctGlobalInterfaceDictionaryPar (object): The first parameter. The global interface dictionary.
    """
    def __init__(self, dctGlobalInterfaceDictionaryPar: dict):
        super().__init__()
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar

        self._dctE1_SF2_STATUSToE1_OLHM_HEALTH_STATUSLookup = {}
        self._dctE1_SF2_STATUSToE1_OLHM_HEALTH_STATUSLookup[E1_SF2_STATUS.SF2_STATUS_FAILED] = E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_FAILED
        self._dctE1_SF2_STATUSToE1_OLHM_HEALTH_STATUSLookup[E1_SF2_STATUS.SF2_STATUS_PASSED] = E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_PASSED

        self._dctE1_ADCS_SYSTEM_STATEToE1_OLHM_STATELookup = {}
        self._dctE1_ADCS_SYSTEM_STATEToE1_OLHM_STATELookup[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = E1_OLHM_STATE.OLHM_STATE_OFFLINE
        self._dctE1_ADCS_SYSTEM_STATEToE1_OLHM_STATELookup[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = E1_OLHM_STATE.OLHM_STATE_UNKNOWN
        self._dctE1_ADCS_SYSTEM_STATEToE1_OLHM_STATELookup[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = E1_OLHM_STATE.OLHM_STATE_SHUTDOWN
        self._dctE1_ADCS_SYSTEM_STATEToE1_OLHM_STATELookup[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = E1_OLHM_STATE.OLHM_STATE_FAILED
        self._dctE1_ADCS_SYSTEM_STATEToE1_OLHM_STATELookup[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = E1_OLHM_STATE.OLHM_STATE_INITIALISE
        self._dctE1_ADCS_SYSTEM_STATEToE1_OLHM_STATELookup[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = E1_OLHM_STATE.OLHM_STATE_READY
        self._dctE1_ADCS_SYSTEM_STATEToE1_OLHM_STATELookup[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = E1_OLHM_STATE.OLHM_STATE_OPERATIONAL

        return

    def lstCreateDetailedTreeEntriesFromSf2StatusReportUnsol(self, objsSF2_STATUS_REPORT_UNSOLPar: sSF2_STATUS_REPORT_UNSOL):
        """ This is a public method which processes a sSF2_STATUS_REPORT_UNSOL and then creates a list of detailed BIT tree items to modify

        Args:
            objsSF2_STATUS_REPORT_UNSOLPar (sSF2_STATUS_REPORT_UNSOL): The first parameter. The message we want to process.

        Returns:
            (list): The return value.

        Raises:
            Raises no exception.
        """
        lstReturn = []
        e1OlhmHealthStatus = E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN)
        e1OlhmState = E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE)
        dctCurrentItem = {}

        if (objsSF2_STATUS_REPORT_UNSOLPar is None):
            logging.error("objsSF2_STATUS_REPORT_UNSOLPar cannot be None")
            return(lstReturn)

        e1OlhmState.Value = self._dctE1_ADCS_SYSTEM_STATEToE1_OLHM_STATELookup[objsSF2_STATUS_REPORT_UNSOLPar.sMsgPayload.sModuleState.e1SystemState.Value]

        # SF2 rolled up
        dctCurrentItem = {}
        dctCurrentItem["lstTreePath"] = ["SF2"]
        dctCurrentItem["acValue"] = ""
        e1OlhmHealthStatus.Value = self._dctE1_SF2_STATUSToE1_OLHM_HEALTH_STATUSLookup[objsSF2_STATUS_REPORT_UNSOLPar.sMsgPayload.e1OverallStatus.Value]
        dctCurrentItem["e1OlhmHealthStatus"] = E1_OLHM_HEALTH_STATUS(e1OlhmHealthStatus.Value)
        dctCurrentItem["e1OlhmState"] = E1_OLHM_STATE(e1OlhmState.Value)

        lstReturn += [dctCurrentItem]

        # SF2 - STATUS - E1_SF2_STATUS
        dctCurrentItem = {}
        dctCurrentItem["lstTreePath"] = ["SF2", "STATUS"]
        dctCurrentItem["acValue"] = ""
        e1OlhmHealthStatus.Value = self._dctE1_SF2_STATUSToE1_OLHM_HEALTH_STATUSLookup[objsSF2_STATUS_REPORT_UNSOLPar.sMsgPayload.e1OverallStatus.Value]
        dctCurrentItem["e1OlhmHealthStatus"] = E1_OLHM_HEALTH_STATUS(e1OlhmHealthStatus.Value)
        dctCurrentItem["e1OlhmState"] = E1_OLHM_STATE(e1OlhmState.Value)

        lstReturn += [dctCurrentItem]

        return(lstReturn)
