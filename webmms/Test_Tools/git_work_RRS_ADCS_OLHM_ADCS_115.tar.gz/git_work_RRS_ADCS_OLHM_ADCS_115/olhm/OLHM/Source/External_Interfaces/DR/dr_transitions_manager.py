#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which manages a transitions (PyPi library) state machine.

Todo:

"""
import logging
from Base_Classes.module_transitions_manager import clsModuleTransitionsManager

from Autogen.olhm_msg import E1_OLHM_HEALTH_STATUS
from Autogen.olhm_msg import E1_OLHM_STATE
from Autogen.dr_msg import sDR_STATUS_REPORT_UNSOL


class clsDrTransitionsManager(clsModuleTransitionsManager):
    """ This is the periodic monitor manager.

    Args:
        dctGlobalInterfaceDictionaryPar (object): The first parameter. The global interface dictionary.
        acInitialStatePar (str): The second parameter. The initial state
    """
    def __init__(self, dctGlobalInterfaceDictionaryPar: object, acInitialStatePar: str = "OFFLINE"):
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar

        # First set all the derived class properties we need in the base class
        self._acUnit = "DR"  # This is needed for logging
        self._acStatusReportUnsolTopic = "ADCS/DR/DrStatusReportUnsol"
        self._acSubUnitDictKey = "dctDR"
        self._typeMODULE_STATUS_REPORT_UNSOL = sDR_STATUS_REPORT_UNSOL
        self._acTriggerInitialise = "trgDrInitialise"
        self._acTriggerReady = "trgDrReady"
        self._acTriggerOperational = "trgDrOperational"
        self._acTriggerShutdown = "trgDrShutdown"
        self._acTriggerFailed = "trgDrFailed"
        self._acMethodToSendEndOfSetup = None  # Will be filled in later

        # Call the constructor in the base class
        super().__init__(dctGlobalInterfaceDictionaryPar, acInitialStatePar)

        # The trigger methods only now exists after the base constructor was called
        self._acTriggerSelfFailed = self.trgDrFailed  # pylint: disable=no-member

        return

    def vProcessState(self, objDateTimeCurrent=None):

        super().vProcessState(objDateTimeCurrent)

        if (self._acMethodToSendEndOfSetup is None):
            self._acMethodToSendEndOfSetup = self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendDrEndOfSetupCmd

        super()._vProcessStateInInitialiseForMandatoryModules(objDateTimeCurrent)

        return

    def _vUpdateBitTreeForOffline(self):
        """ This is a private method which sets the status tree for OFFLINE state

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        super()._vUpdateBitTreeForOffline()

        return

    def _vUpdateBitTreeForFailed(self):
        """ This is a private method which sets the DR section of the BIT to FAILED when the DR is FAILED

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        super()._vUpdateBitTreeForFailed()

        lstEntries = []
        dctCurrentItem = None
        lstSubNodes = []

        # DR - DR - DR

        lstSubNodes = ["STATUS"]

        # Set the DR tree heading to FAILED
        dctCurrentItem = {}
        dctCurrentItem["lstTreePath"] = ["DR"]
        dctCurrentItem["acValue"] = ""
        # Because we are FAILED make the health FAILED
        dctCurrentItem["e1OlhmHealthStatus"] = E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_FAILED)
        dctCurrentItem["e1OlhmState"] = E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_FAILED)
        lstEntries += [dctCurrentItem]

        # Iterate through all the DR subnodes now - the nodes under the DR heading
        for acItem in lstSubNodes:
            dctCurrentItem = {}
            dctCurrentItem["lstTreePath"] = ["DR", acItem]
            dctCurrentItem["acValue"] = ""
            # Because we are FAILED make the health FAILED
            dctCurrentItem["e1OlhmHealthStatus"] = E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_FAILED)
            dctCurrentItem["e1OlhmState"] = E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_FAILED)
            lstEntries += [dctCurrentItem]

        # Now finally send all the entries
        if (self._dctGloInterDict["dctOLHM"]["objClsOlhmConstructGroupStatus"] is not None):
            self._dctGloInterDict["dctOLHM"]["objClsOlhmConstructGroupStatus"].vUpdateDetailedTreeFromListOfEntries(lstEntries)
        else:
            logging.error("objClsOlhmConstructGroupStatus cannot be None")

        return

    def _vUpdateBitTreeForShutdown(self):
        """ This is a private method which sets the DR section of the BIT to SHUTDOWN when the DR is SHUTDOWN

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        e1OlhmHealthStatus = E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN)

        super()._vUpdateBitTreeForShutdown()

        if (self._dctGloInterDict["dctSubUnits"][self._acSubUnitDictKey]["objsSTATUSREPORTUNSOL"] is not None):
            e1OlhmHealthStatus.Value = self._dctGloInterDict["dctSubUnits"][self._acSubUnitDictKey]["objsSTATUSREPORTUNSOL"].sMsgPayload.e1OverallStatus.Value

        lstEntries = []
        dctCurrentItem = None
        lstSubNodes = []

        # DR - DR - DR

        lstSubNodes = ["STATUS"]

        # Set the DR tree heading to FAILED
        dctCurrentItem = {}
        dctCurrentItem["lstTreePath"] = ["DR"]
        dctCurrentItem["acValue"] = ""
        # Because we are FAILED make the health FAILED
        dctCurrentItem["e1OlhmHealthStatus"] = E1_OLHM_HEALTH_STATUS(e1OlhmHealthStatus.Value)
        dctCurrentItem["e1OlhmState"] = E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_SHUTDOWN)
        lstEntries += [dctCurrentItem]

        # Iterate through all the DR subnodes now - the nodes under the DR heading
        for acItem in lstSubNodes:
            dctCurrentItem = {}
            dctCurrentItem["lstTreePath"] = ["DR", acItem]
            dctCurrentItem["acValue"] = ""
            # Because we are FAILED make the health FAILED
            dctCurrentItem["e1OlhmHealthStatus"] = E1_OLHM_HEALTH_STATUS(e1OlhmHealthStatus.Value)
            dctCurrentItem["e1OlhmState"] = E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_SHUTDOWN)
            lstEntries += [dctCurrentItem]

        # Now finally send all the entries
        if (self._dctGloInterDict["dctOLHM"]["objClsOlhmConstructGroupStatus"] is not None):
            self._dctGloInterDict["dctOLHM"]["objClsOlhmConstructGroupStatus"].vUpdateDetailedTreeFromListOfEntries(lstEntries)
        else:
            logging.error("objClsOlhmConstructGroupStatus cannot be None")

        return
