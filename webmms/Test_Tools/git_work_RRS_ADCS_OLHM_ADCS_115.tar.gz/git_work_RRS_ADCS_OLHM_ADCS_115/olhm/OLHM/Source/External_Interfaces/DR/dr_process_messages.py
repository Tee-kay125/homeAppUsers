#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which processes DR messages

Todo:

"""
import logging
from Autogen.dr_msg import sDR_STATUS_REPORT_UNSOL
from Autogen.dr_msg import E1_DR_STATUS
from Autogen.olhm_msg import E1_OLHM_STATE
from Autogen.olhm_msg import E1_OLHM_HEALTH_STATUS
from Autogen.adcs_common_types import E1_ADCS_SYSTEM_STATE


class clsDrProcessMessages:
    """ This is a class which processes DR messages.

    Args:
        dctGlobalInterfaceDictionaryPar (object): The first parameter. The global interface dictionary.
    """
    def __init__(self, dctGlobalInterfaceDictionaryPar: dict):
        super().__init__()
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar

        self._dctE1_DR_STATUSToE1_OLHM_HEALTH_STATUSLookup = {}
        self._dctE1_DR_STATUSToE1_OLHM_HEALTH_STATUSLookup[E1_DR_STATUS.DR_STATUS_FAILED] = E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_FAILED
        self._dctE1_DR_STATUSToE1_OLHM_HEALTH_STATUSLookup[E1_DR_STATUS.DR_STATUS_PASSED] = E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_PASSED

        self._dctE1_ADCS_SYSTEM_STATEToE1_OLHM_STATELookup = {}
        self._dctE1_ADCS_SYSTEM_STATEToE1_OLHM_STATELookup[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = E1_OLHM_STATE.OLHM_STATE_OFFLINE
        self._dctE1_ADCS_SYSTEM_STATEToE1_OLHM_STATELookup[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = E1_OLHM_STATE.OLHM_STATE_UNKNOWN
        self._dctE1_ADCS_SYSTEM_STATEToE1_OLHM_STATELookup[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = E1_OLHM_STATE.OLHM_STATE_SHUTDOWN
        self._dctE1_ADCS_SYSTEM_STATEToE1_OLHM_STATELookup[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = E1_OLHM_STATE.OLHM_STATE_FAILED
        self._dctE1_ADCS_SYSTEM_STATEToE1_OLHM_STATELookup[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = E1_OLHM_STATE.OLHM_STATE_INITIALISE
        self._dctE1_ADCS_SYSTEM_STATEToE1_OLHM_STATELookup[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = E1_OLHM_STATE.OLHM_STATE_READY
        self._dctE1_ADCS_SYSTEM_STATEToE1_OLHM_STATELookup[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = E1_OLHM_STATE.OLHM_STATE_OPERATIONAL

        return

    def lstCreateDetailedTreeEntriesFromDrStatusReportUnsol(self, objsDR_STATUS_REPORT_UNSOLPar: sDR_STATUS_REPORT_UNSOL):
        """ This is a public method which processes a sDR_STATUS_REPORT_UNSOL and then creates a list of detailed BIT tree items to modify

        Args:
            objsDR_STATUS_REPORT_UNSOLPar (sDR_STATUS_REPORT_UNSOL): The first parameter. The message we want to process.

        Returns:
            (list): The return value.

        Raises:
            Raises no exception.
        """
        lstReturn = []
        e1OlhmHealthStatus = E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN)
        e1OlhmState = E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE)
        dctCurrentItem = {}

        if (objsDR_STATUS_REPORT_UNSOLPar is None):
            logging.error("objsDR_STATUS_REPORT_UNSOLPar cannot be None")
            return(lstReturn)

        e1OlhmState.Value = self._dctE1_ADCS_SYSTEM_STATEToE1_OLHM_STATELookup[objsDR_STATUS_REPORT_UNSOLPar.sMsgPayload.sModuleState.e1SystemState.Value]

        # DR rolled up
        dctCurrentItem = {}
        dctCurrentItem["lstTreePath"] = ["DR"]
        dctCurrentItem["acValue"] = ""
        e1OlhmHealthStatus.Value = self._dctE1_DR_STATUSToE1_OLHM_HEALTH_STATUSLookup[objsDR_STATUS_REPORT_UNSOLPar.sMsgPayload.e1OverallStatus.Value]
        dctCurrentItem["e1OlhmHealthStatus"] = E1_OLHM_HEALTH_STATUS(e1OlhmHealthStatus.Value)
        dctCurrentItem["e1OlhmState"] = E1_OLHM_STATE(e1OlhmState.Value)

        lstReturn += [dctCurrentItem]

        # DR - STATUS - E1_DR_STATUS
        dctCurrentItem = {}
        dctCurrentItem["lstTreePath"] = ["DR", "STATUS"]
        dctCurrentItem["acValue"] = ""
        e1OlhmHealthStatus.Value = self._dctE1_DR_STATUSToE1_OLHM_HEALTH_STATUSLookup[objsDR_STATUS_REPORT_UNSOLPar.sMsgPayload.e1OverallStatus.Value]
        dctCurrentItem["e1OlhmHealthStatus"] = E1_OLHM_HEALTH_STATUS(e1OlhmHealthStatus.Value)
        dctCurrentItem["e1OlhmState"] = E1_OLHM_STATE(e1OlhmState.Value)

        lstReturn += [dctCurrentItem]

        return(lstReturn)
