#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which processes messages received from the PDBP.


Todo:

"""

import logging
from enum import Enum
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
from python_toolbox.Datetime_Utilities.datetime_utilities import clsDatetimeUtilities
from Autogen.asyncio_message_processing_olhm import clsPythonAsyncioMessageProcessing
from Autogen.adcs_common_types import E1_ADCS_SYSTEM_STATE
from Autogen.adcs_common_types import E1_ADCS_BOOLEAN
from Autogen.mw_common_types import E2_MW_MESSAGE_STATUS
from Autogen.pdbp_msg import sPDBP_END_OF_READY_CMD
from Autogen.pdbp_msg import sPDBP_END_OF_READY_CMD_RSP
from Autogen.pdbp_msg import sPDBP_SHUTDOWN_CMD
from Autogen.pdbp_msg import sPDBP_SHUTDOWN_CMD_RSP
from Autogen.pdbp_msg import sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD
from Autogen.pdbp_msg import sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP


class E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(Enum):
    """ This is Enum class which denotes the states which represents stages for a PDBP send database message task.
        This enum is used amongst other places in vSendOutPdbpSendOutModuleDbMessageAndWaitForReply

    """
    NO_TASK = 1
    IN_PROGRESS_TASK = 2
    COMPLETED_TASK = 3
    FAILED_TASK = 4


class clsAsyncioMsgProcessingClassPdbp(clsPythonAsyncioMessageProcessing):
    """ This is the asyncio message processing class for the messages from the PDBP.

    Args:
        objMqttClientPar (mqtt.Client): The first parameter. The instance of the MQTT client
        dctMessagesPar (dict): The second parameter. A dictionary containing all messages and futures for messages which were automatically processed by the autogen. This must be passed in for the autogen base class.
        objAsyncioLoopPar (object): The third parameter. The asyncio loop passed in so tasks can be created and for other asyncio functionality
        dctGlobalInterfaceDictionaryPar (dict): The fourth parameter. The interface's global dictionary.
        bLoggingEnabledPar (bool): The fifth parameter. A boolean flag indicating if logging should be done or not.
    """

    def __init__(self, objMqttClientPar: mqtt.Client, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar: bool = True):
        # Very important!!! The MRO (method resolution order) will not yet call the autogen base because it isn't last in the list of inheritance - therefore pass more parameter than used for the base class
        super().__init__(objMqttClientPar, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar)
        self._objMqttClient = objMqttClientPar
        self._dctMessages = dctMessagesPar
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar
        self._objClsPdbpProcessMessages = self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objClsProcessMessages"]

        self._dctStateStringToE1AdcsSystemStateLookup = {}
        self._dctStateStringToE1AdcsSystemStateLookup["OFFLINE"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE
        self._dctStateStringToE1AdcsSystemStateLookup["INITIALISE"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE
        self._dctStateStringToE1AdcsSystemStateLookup["READY"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY
        self._dctStateStringToE1AdcsSystemStateLookup["OPERATIONAL"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL
        self._dctStateStringToE1AdcsSystemStateLookup["SHUTDOWN"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN
        self._dctStateStringToE1AdcsSystemStateLookup["FAILED"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED
        self._dctStateStringToE1AdcsSystemStateLookup["UNKNOWN"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN

        # This property is used in vSendOutPdbpSendOutModuleDbMessageAndWaitForReply()
        self._bPdbpSendOutModuleDbMessageTaskInProgress = bool(False)

        return

#    ==============================================================================================================
#    Base class methods to override - START
#    ==============================================================================================================

# 0x0000 - PdbpStatusReportUnsol
    async def objProcessPayloadPdbpStatusReportUnsol(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for PdbpStatusReportUnsol

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        # Check that they are the same size
        if (dctObjectPar["MsgObject"].iSizeBytes() == self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objsSTATUSREPORTUNSOL"].iSizeBytes()):
            self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objsSTATUSREPORTUNSOL"].vDeserialise(dctObjectPar["MsgObject"].btaSerialise())
            lstEntries = self._objClsPdbpProcessMessages.lstCreateDetailedTreeEntriesFromPdbpStatusReportUnsol(self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objsSTATUSREPORTUNSOL"])
            self._dctGloInterDict["dctOLHM"]["objClsOlhmConstructGroupStatus"].vUpdateDetailedTreeFromListOfEntries(lstEntries)

        if (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE):
            self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objClsPdbpTransitionsManager"].trgPdbpInitialise()
        elif (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY):
            self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objClsPdbpTransitionsManager"].trgPdbpReady()
        elif (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL):
            self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objClsPdbpTransitionsManager"].trgPdbpOperational()
        elif (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED):
            self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objClsPdbpTransitionsManager"].trgPdbpFailed()
        elif (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN):
            self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objClsPdbpTransitionsManager"].trgPdbpShutdown()
        else:
            self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objClsPdbpTransitionsManager"].trgPdbpFailed()

        return(None)

# 0x0002 - PdbpEndOfReadyCmdRsp
    async def objProcessPayloadPdbpEndOfReadyCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for PdbpEndOfReadyCmdRsp

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        await super().objProcessPayloadPdbpEndOfReadyCmdRsp(dctObjectPar)

        objsPDBP_END_OF_READY_CMD_RSP = sPDBP_END_OF_READY_CMD_RSP()
        objsPDBP_END_OF_READY_CMD_RSP.vDeserialise(dctObjectPar["MsgObject"].btaSerialise())

        # See if the CmdRsp status is normal
        if (objsPDBP_END_OF_READY_CMD_RSP.sMsgHeader.e2MsgStatus.Value == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objClsPdbpTransitionsManager"].trgPdbpOperational()
        else:
            logging.error("sPDBP_END_OF_READY_CMD_RSP status is not normal with a value of %d", objsPDBP_END_OF_READY_CMD_RSP.sMsgHeader.e2MsgStatus.Value)

        return(None)

# 0x0003 - PdbpShutdownCmdRsp
    async def objProcessPayloadPdbpShutdownCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for PdbpShutdownCmdRsp

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        await super().objProcessPayloadPdbpShutdownCmdRsp(dctObjectPar)

        objsPDBP_SHUTDOWN_CMD_RSP = sPDBP_SHUTDOWN_CMD_RSP()
        objsPDBP_SHUTDOWN_CMD_RSP.vDeserialise(dctObjectPar["MsgObject"].btaSerialise())

        # See if the CmdRsp status is normal
        if (objsPDBP_SHUTDOWN_CMD_RSP.sMsgHeader.e2MsgStatus.Value == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objClsPdbpTransitionsManager"].trgPdbpShutdown()
        else:
            logging.error("sPDBP_SHUTDOWN_CMD_RSP status is not normal with a value of %d", objsPDBP_SHUTDOWN_CMD_RSP.sMsgHeader.e2MsgStatus.Value)

        return(None)

# 0x0010 - PdbpSendOutModuleDbMessagesCmdRsp
    async def objProcessPayloadPdbpSendOutModuleDbMessagesCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for PdbpSendOutModuleDbMessagesCmdRsp

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        await super().objProcessPayloadPdbpSendOutModuleDbMessagesCmdRsp(dctObjectPar)

        return(None)

#    ==============================================================================================================
#    Base class methods to override - END
#    ==============================================================================================================

    async def vSendOutPdbpSendOutModuleDbMessageAndWaitForReply(self, tplTaskOwnerAndTaskNumberPar: tuple):
        """ This is a public async method which sends and manages the sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD message.
        We should not send multiple sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD messages at the same time so we need to manage
        it with a property which acts as a lock. Property self._bPdbpSendOutModuleDbMessageTaskInProgress is this lock.
        It is very important that we upon early exit of this method set self._bPdbpSendOutModuleDbMessageTaskInProgress
        to False so that other tasks can have to opportunity to use the method.

        Args:
            tplTaskOwnerAndTaskNumberPar (tuple): The module and task number for that module which requested this task.
                * [0](str): The module which requested the task
                * [1](int): The task number for that module

        Returns:

        Raises:
            Raises no exception.
        """
        dctMessages = {}
        lstMessageToSendCmd = []
        lstMessageToSendCmdRsp = []

        # Check if we already have a task in progress
        if (self._bPdbpSendOutModuleDbMessageTaskInProgress is True):
            # If we are here then it means we already have a asyncio task handling method vSendOutPdbpSendOutModuleDbMessageAndWaitForReply
            return

        self._bPdbpSendOutModuleDbMessageTaskInProgress = True

        if (self._dctGloInterDict is None):
            logging.error("self._dctGloInterDict cannot be None")
            self._bPdbpSendOutModuleDbMessageTaskInProgress = False
            return

        if (tplTaskOwnerAndTaskNumberPar is None):
            logging.error("tplTaskOwnerAndTaskNumberPar cannot be None")
            self._bPdbpSendOutModuleDbMessageTaskInProgress = False
            return

        if (isinstance(tplTaskOwnerAndTaskNumberPar, tuple) is False):
            logging.error("tplTaskOwnerAndTaskNumberPar must be a tuple")
            self._bPdbpSendOutModuleDbMessageTaskInProgress = False
            return

        if (self._dctMessages["ADCS/PDBP/PdbpSendOutModuleDbMessagesCmdRsp"]["objAsyncioFutureProcessCompleted"] is None):
            logging.error("Future for PdbpSendOutModuleDbMessagesCmdRsp cannot be None")
            self._bPdbpSendOutModuleDbMessageTaskInProgress = False
            return

        if (self._dctPdbpDatabaseMessageResultStateDictionary is None):
            self._bPdbpSendOutModuleDbMessageTaskInProgress = False
            return

        if (tplTaskOwnerAndTaskNumberPar not in self._dctPdbpDatabaseMessageResultStateDictionary):
            self._bPdbpSendOutModuleDbMessageTaskInProgress = False
            return

        self._dctPdbpDatabaseMessageResultStateDictionary[tplTaskOwnerAndTaskNumberPar]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.IN_PROGRESS_TASK)

        objsPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD = sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD()

        self.vIncreaseMessageCounter((type(objsPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD), ""))  # pylint: disable=no-member
        objsPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD), "")]  # pylint: disable=no-member
        objsPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()
        objsPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD.sMsgPayload.acModuleName.Value = self._dctPdbpDatabaseMessageResultStateDictionary[tplTaskOwnerAndTaskNumberPar]["acModuleName"]
        objsPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD.sMsgPayload.e1CompletedSuccessfully.Value = E1_ADCS_BOOLEAN.ADCS_BOOLEAN_TRUE

        dctMessages["tplMessageTypeRolePairCmd"] = ((sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD), "")
        dctMessages["tplMessageTypeRolePairRsp"] = ((sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP), "")
        dctMessages["objCmdMessage"] = objsPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD
        dctMessages["objCmdRspMessage"] = None
        dctMessages["fTimeoutPeriodS"] = float(4.0)

        lstMessageToSendCmd += [dctMessages]

        lstMessageToSendCmdRsp = await self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].lstSendListOfMessagesAndWaitForResponse(lstMessageToSendCmd)  # noqa: F841

        if (dctMessages["objCmdRspMessage"] is None):
            # No reply so therefore FAILED
            logging.error("sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP timed-out for requester %s with task number %s", tplTaskOwnerAndTaskNumberPar[0], tplTaskOwnerAndTaskNumberPar[1])
            self._dctPdbpDatabaseMessageResultStateDictionary[tplTaskOwnerAndTaskNumberPar]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.FAILED_TASK)

        elif ((dctMessages["objCmdRspMessage"].sMsgHeader.e2MsgStatus.Value == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL) and
              (dctMessages["objCmdRspMessage"].sMsgPayload.e1CompletedSuccessfully.Value == E1_ADCS_BOOLEAN.ADCS_BOOLEAN_TRUE) and
              (dctMessages["objCmdRspMessage"].sMsgPayload.acModuleName.Value == self._dctPdbpDatabaseMessageResultStateDictionary[tplTaskOwnerAndTaskNumberPar]["acModuleName"])):
            # We check the MsgStatus, if the PDBP completed successfully and if it is the correct module name
            logging.info("sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP received for requester module %s task number %s", tplTaskOwnerAndTaskNumberPar[0], tplTaskOwnerAndTaskNumberPar[1])
            self._dctPdbpDatabaseMessageResultStateDictionary[tplTaskOwnerAndTaskNumberPar]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.COMPLETED_TASK)

        else:
            # We did get a reply but it was not successful or it was not the reply we expected
            logging.error("sPDBP_SEND_OUT_MODULE_DB_MESSAGES_CMD_RSP was not successful for requester %s with task number %s", tplTaskOwnerAndTaskNumberPar[0], tplTaskOwnerAndTaskNumberPar[1])
            self._dctPdbpDatabaseMessageResultStateDictionary[tplTaskOwnerAndTaskNumberPar]["ePdbpDatabaseMessageSendTaskState"] = E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE(E_PDBP_DATABASE_MESSAGE_SEND_TASK_STATE.FAILED_TASK)

        self._bPdbpSendOutModuleDbMessageTaskInProgress = False
        return

# 0x0002 vSendPdbpEndOfReadyCmd
    def vSendPdbpEndOfReadyCmd(self):
        """ This is a public method which is used to send a sPDBP_END_OF_READY_CMD message

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        objsPDBP_END_OF_READY_CMD = sPDBP_END_OF_READY_CMD()

        self.vIncreaseMessageCounter((type(objsPDBP_END_OF_READY_CMD), ""))  # pylint: disable=no-member
        objsPDBP_END_OF_READY_CMD.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsPDBP_END_OF_READY_CMD), "")]  # pylint: disable=no-member
        objsPDBP_END_OF_READY_CMD.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsPDBP_END_OF_READY_CMD)  # pylint: disable=no-member

        return

# 0x0003 vSendPdbpShutdownCmd
    def vSendPdbpShutdownCmd(self):
        """ This is a public method which is used to send a sPDBP_SHUTDOWN_CMD message

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        objsPDBP_SHUTDOWN_CMD = sPDBP_SHUTDOWN_CMD()

        self.vIncreaseMessageCounter((type(objsPDBP_SHUTDOWN_CMD), ""))  # pylint: disable=no-member
        objsPDBP_SHUTDOWN_CMD.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsPDBP_SHUTDOWN_CMD), "")]  # pylint: disable=no-member
        objsPDBP_SHUTDOWN_CMD.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsPDBP_SHUTDOWN_CMD)  # pylint: disable=no-member

        return
