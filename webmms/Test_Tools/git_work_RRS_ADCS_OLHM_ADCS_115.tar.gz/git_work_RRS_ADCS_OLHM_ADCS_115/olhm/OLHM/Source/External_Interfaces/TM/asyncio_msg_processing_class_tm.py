#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which processes messages received from the TM.


Todo:

"""

import logging
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
from python_toolbox.Datetime_Utilities.datetime_utilities import clsDatetimeUtilities
from Autogen.asyncio_message_processing_olhm import clsPythonAsyncioMessageProcessing
from Autogen.adcs_common_types import E1_ADCS_SYSTEM_STATE
from Autogen.mw_common_types import E2_MW_MESSAGE_STATUS
from Autogen.tm_msg import sTM_END_OF_SETUP_CMD
from Autogen.tm_msg import sTM_END_OF_SETUP_CMD_RSP
from Autogen.tm_msg import sTM_END_OF_READY_CMD
from Autogen.tm_msg import sTM_END_OF_READY_CMD_RSP
from Autogen.tm_msg import sTM_SHUTDOWN_CMD
from Autogen.tm_msg import sTM_SHUTDOWN_CMD_RSP


class clsAsyncioMsgProcessingClassTm(clsPythonAsyncioMessageProcessing):
    """ This is the asyncio message processing class for the messages from the TM.

    Args:
        objMqttClientPar (mqtt.Client): The first parameter. The instance of the MQTT client
        dctMessagesPar (dict): The second parameter. A dictionary containing all messages and futures for messages which were automatically processed by the autogen. This must be passed in for the autogen base class.
        objAsyncioLoopPar (object): The third parameter. The asyncio loop passed in so tasks can be created and for other asyncio functionality
        dctGlobalInterfaceDictionaryPar (dict): The fourth parameter. The interface's global dictionary.
        bLoggingEnabledPar (bool): The fifth parameter. A boolean flag indicating if logging should be done or not.
    """

    def __init__(self, objMqttClientPar: mqtt.Client, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar: bool = True):
        # Very important!!! The MRO (method resolution order) will not yet call the autogen base because it isn't last in the list of inheritance - therefore pass more parameter than used for the base class
        super().__init__(objMqttClientPar, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar)
        self._objMqttClient = objMqttClientPar
        self._dctMessages = dctMessagesPar
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar
        self._objClsTmProcessMessages = self._dctGloInterDict["dctSubUnits"]["dctTM"]["objClsProcessMessages"]

        self._dctStateStringToE1AdcsSystemStateLookup = {}
        self._dctStateStringToE1AdcsSystemStateLookup["OFFLINE"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE
        self._dctStateStringToE1AdcsSystemStateLookup["INITIALISE"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE
        self._dctStateStringToE1AdcsSystemStateLookup["READY"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY
        self._dctStateStringToE1AdcsSystemStateLookup["OPERATIONAL"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL
        self._dctStateStringToE1AdcsSystemStateLookup["SHUTDOWN"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN
        self._dctStateStringToE1AdcsSystemStateLookup["FAILED"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED
        self._dctStateStringToE1AdcsSystemStateLookup["UNKNOWN"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN

        return

#    ==============================================================================================================
#    Base class methods to override - START
#    ==============================================================================================================

# 0x0000 - TmStatusReportUnsol
    async def objProcessPayloadTmStatusReportUnsol(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for TmStatusReportUnsol

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        # Check that they are the same size
        if (dctObjectPar["MsgObject"].iSizeBytes() == self._dctGloInterDict["dctSubUnits"]["dctTM"]["objsSTATUSREPORTUNSOL"].iSizeBytes()):
            self._dctGloInterDict["dctSubUnits"]["dctTM"]["objsSTATUSREPORTUNSOL"].vDeserialise(dctObjectPar["MsgObject"].btaSerialise())
            lstEntries = self._objClsTmProcessMessages.lstCreateDetailedTreeEntriesFromTmStatusReportUnsol(self._dctGloInterDict["dctSubUnits"]["dctTM"]["objsSTATUSREPORTUNSOL"])
            self._dctGloInterDict["dctOLHM"]["objClsOlhmConstructGroupStatus"].vUpdateDetailedTreeFromListOfEntries(lstEntries)

        if (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE):
            self._dctGloInterDict["dctSubUnits"]["dctTM"]["objClsTmTransitionsManager"].trgTmInitialise()
        elif (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY):
            self._dctGloInterDict["dctSubUnits"]["dctTM"]["objClsTmTransitionsManager"].trgTmReady()
        elif (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL):
            self._dctGloInterDict["dctSubUnits"]["dctTM"]["objClsTmTransitionsManager"].trgTmOperational()
        elif (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED):
            self._dctGloInterDict["dctSubUnits"]["dctTM"]["objClsTmTransitionsManager"].trgTmFailed()
        elif (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN):
            self._dctGloInterDict["dctSubUnits"]["dctTM"]["objClsTmTransitionsManager"].trgTmShutdown()
        else:
            self._dctGloInterDict["dctSubUnits"]["dctTM"]["objClsTmTransitionsManager"].trgTmFailed()

        return(None)

# 0x0001 - TmEndOfSetupCmdRsp
    async def objProcessPayloadTmEndOfSetupCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for TmEndOfSetupCmdRsp

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        await super().objProcessPayloadTmEndOfSetupCmdRsp(dctObjectPar)

        objsTM_END_OF_SETUP_CMD_RSP = sTM_END_OF_SETUP_CMD_RSP()
        objsTM_END_OF_SETUP_CMD_RSP.vDeserialise(dctObjectPar["MsgObject"].btaSerialise())

        # See if the CmdRsp status is normal
        if (objsTM_END_OF_SETUP_CMD_RSP.sMsgHeader.e2MsgStatus.Value == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            self._dctGloInterDict["dctSubUnits"]["dctTM"]["objClsTmTransitionsManager"].trgTmReady()
        else:
            logging.error("sTM_END_OF_SETUP_CMD_RSP status is not normal with a value of %d", objsTM_END_OF_SETUP_CMD_RSP.sMsgHeader.e2MsgStatus.Value)

        return(None)

# 0x0002 - TmEndOfReadyCmdRsp
    async def objProcessPayloadTmEndOfReadyCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for TmEndOfReadyCmdRsp

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        await super().objProcessPayloadTmEndOfReadyCmdRsp(dctObjectPar)

        objsTM_END_OF_READY_CMD_RSP = sTM_END_OF_READY_CMD_RSP()
        objsTM_END_OF_READY_CMD_RSP.vDeserialise(dctObjectPar["MsgObject"].btaSerialise())

        # See if the CmdRsp status is normal
        if (objsTM_END_OF_READY_CMD_RSP.sMsgHeader.e2MsgStatus.Value == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            self._dctGloInterDict["dctSubUnits"]["dctTM"]["objClsTmTransitionsManager"].trgTmOperational()
        else:
            logging.error("sTM_END_OF_READY_CMD_RSP status is not normal with a value of %d", objsTM_END_OF_READY_CMD_RSP.sMsgHeader.e2MsgStatus.Value)

        return(None)

# 0x0003 - TmShutdownCmdRsp
    async def objProcessPayloadTmShutdownCmdRsp(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for TmShutdownCmdRsp

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        await super().objProcessPayloadTmShutdownCmdRsp(dctObjectPar)

        objsTM_SHUTDOWN_CMD_RSP = sTM_SHUTDOWN_CMD_RSP()
        objsTM_SHUTDOWN_CMD_RSP.vDeserialise(dctObjectPar["MsgObject"].btaSerialise())

        # See if the CmdRsp status is normal
        if (objsTM_SHUTDOWN_CMD_RSP.sMsgHeader.e2MsgStatus.Value == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            self._dctGloInterDict["dctSubUnits"]["dctTM"]["objClsTmTransitionsManager"].trgTmShutdown()
        else:
            logging.error("sTM_SHUTDOWN_CMD_RSP status is not normal with a value of %d", objsTM_SHUTDOWN_CMD_RSP.sMsgHeader.e2MsgStatus.Value)

        return(None)

#    ==============================================================================================================
#    Base class methods to override - END
#    ==============================================================================================================

# 0x0001 vSendTmEndOfSetupCmd
    def vSendTmEndOfSetupCmd(self):
        """ This is a public method which is used to send a sTM_END_OF_SETUP_CMD message

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        objsTM_END_OF_SETUP_CMD = sTM_END_OF_SETUP_CMD()

        self.vIncreaseMessageCounter((type(objsTM_END_OF_SETUP_CMD), ""))  # pylint: disable=no-member
        objsTM_END_OF_SETUP_CMD.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsTM_END_OF_SETUP_CMD), "")]  # pylint: disable=no-member
        objsTM_END_OF_SETUP_CMD.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsTM_END_OF_SETUP_CMD)  # pylint: disable=no-member

        return

# 0x0002 vSendTmEndOfReadyCmd
    def vSendTmEndOfReadyCmd(self):
        """ This is a public method which is used to send a sTM_END_OF_READY_CMD message

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        objsTM_END_OF_READY_CMD = sTM_END_OF_READY_CMD()

        self.vIncreaseMessageCounter((type(objsTM_END_OF_READY_CMD), ""))  # pylint: disable=no-member
        objsTM_END_OF_READY_CMD.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsTM_END_OF_READY_CMD), "")]  # pylint: disable=no-member
        objsTM_END_OF_READY_CMD.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsTM_END_OF_READY_CMD)  # pylint: disable=no-member

        return

# 0x0003 vSendTmShutdownCmd
    def vSendTmShutdownCmd(self):
        """ This is a public method which is used to send a sTM_SHUTDOWN_CMD message

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        objsTM_SHUTDOWN_CMD = sTM_SHUTDOWN_CMD()

        self.vIncreaseMessageCounter((type(objsTM_SHUTDOWN_CMD), ""))  # pylint: disable=no-member
        objsTM_SHUTDOWN_CMD.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsTM_SHUTDOWN_CMD), "")]  # pylint: disable=no-member
        objsTM_SHUTDOWN_CMD.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsTM_SHUTDOWN_CMD)  # pylint: disable=no-member

        return
