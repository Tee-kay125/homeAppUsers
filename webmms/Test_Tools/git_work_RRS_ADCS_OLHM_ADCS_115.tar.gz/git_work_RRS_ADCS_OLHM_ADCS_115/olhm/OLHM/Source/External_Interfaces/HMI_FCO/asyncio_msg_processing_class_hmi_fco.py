#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module provides a class which processes messages received from the HMI_FCO.


Todo:

"""

import logging
import paho.mqtt.client as mqtt  # This is the import required to make use of paho mqtt client
from python_toolbox.Datetime_Utilities.datetime_utilities import clsDatetimeUtilities
from Autogen.asyncio_message_processing_olhm import clsPythonAsyncioMessageProcessing
from Autogen.adcs_common_types import E1_ADCS_SYSTEM_STATE
from Autogen.mw_common_types import E2_MW_MESSAGE_STATUS
from Autogen.hmi_msg import sHMI_END_OF_SETUP_CMD
from Autogen.hmi_msg import sHMI_END_OF_SETUP_CMD_RSP
from Autogen.hmi_msg import sHMI_END_OF_READY_CMD
from Autogen.hmi_msg import sHMI_END_OF_READY_CMD_RSP
from Autogen.hmi_msg import sHMI_SHUTDOWN_CMD
from Autogen.hmi_msg import sHMI_SHUTDOWN_CMD_RSP
from Autogen.hmi_msg import sHMI_SHUTDOWN_UNSOL
from Autogen.hmi_msg import sHMI_ADCS_SHUTDOWN_CMD_RSP


class clsAsyncioMsgProcessingClassHmiFco(clsPythonAsyncioMessageProcessing):
    """ This is the asyncio message processing class for the messages from the HMI_FCO.

    Args:
        objMqttClientPar (mqtt.Client): The first parameter. The instance of the MQTT client
        dctMessagesPar (dict): The second parameter. A dictionary containing all messages and futures for messages which were automatically processed by the autogen. This must be passed in for the autogen base class.
        objAsyncioLoopPar (object): The third parameter. The asyncio loop passed in so tasks can be created and for other asyncio functionality
        dctGlobalInterfaceDictionaryPar (dict): The fourth parameter. The interface's global dictionary.
        bLoggingEnabledPar (bool): The fifth parameter. A boolean flag indicating if logging should be done or not.
    """

    def __init__(self, objMqttClientPar: mqtt.Client, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar: bool = True):
        # Very important!!! The MRO (method resolution order) will not yet call the autogen base because it isn't last in the list of inheritance - therefore pass more parameter than used for the base class
        super().__init__(objMqttClientPar, dctMessagesPar, objAsyncioLoopPar, dctGlobalInterfaceDictionaryPar, bLoggingEnabledPar)
        self._objMqttClient = objMqttClientPar
        self._dctMessages = dctMessagesPar
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar
        self._objClsHmiFcoProcessMessages = self._dctGloInterDict["dctSubUnits"]["dctHMIFCO"]["objClsProcessMessages"]

        self._dctStateStringToE1AdcsSystemStateLookup = {}
        self._dctStateStringToE1AdcsSystemStateLookup["OFFLINE"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE
        self._dctStateStringToE1AdcsSystemStateLookup["INITIALISE"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE
        self._dctStateStringToE1AdcsSystemStateLookup["READY"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY
        self._dctStateStringToE1AdcsSystemStateLookup["OPERATIONAL"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL
        self._dctStateStringToE1AdcsSystemStateLookup["SHUTDOWN"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN
        self._dctStateStringToE1AdcsSystemStateLookup["FAILED"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED
        self._dctStateStringToE1AdcsSystemStateLookup["UNKNOWN"] = E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN

        return

#    ==============================================================================================================
#    Base class methods to override - START
#    ==============================================================================================================

# 0x0000 - HmiStatusReportUnsolFCO
    async def objProcessPayloadHmiStatusReportUnsolFCO(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for HmiStatusReportUnsolFCO

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        # Check that they are the same size
        if (dctObjectPar["MsgObject"].iSizeBytes() == self._dctGloInterDict["dctSubUnits"]["dctHMIFCO"]["objsSTATUSREPORTUNSOL"].iSizeBytes()):
            self._dctGloInterDict["dctSubUnits"]["dctHMIFCO"]["objsSTATUSREPORTUNSOL"].vDeserialise(dctObjectPar["MsgObject"].btaSerialise())
            lstEntries = self._objClsHmiFcoProcessMessages.lstCreateDetailedTreeEntriesFromHmiFcoStatusReportUnsol(self._dctGloInterDict["dctSubUnits"]["dctHMIFCO"]["objsSTATUSREPORTUNSOL"])
            self._dctGloInterDict["dctOLHM"]["objClsOlhmConstructGroupStatus"].vUpdateDetailedTreeFromListOfEntries(lstEntries)

        if (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE):
            self._dctGloInterDict["dctSubUnits"]["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].trgHmiFcoInitialise()
        elif (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY):
            self._dctGloInterDict["dctSubUnits"]["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].trgHmiFcoReady()
        elif (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL):
            self._dctGloInterDict["dctSubUnits"]["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].trgHmiFcoOperational()
        elif (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED):
            self._dctGloInterDict["dctSubUnits"]["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].trgHmiFcoFailed()
        elif (dctObjectPar["MsgObject"].sMsgPayload.sModuleState.e1SystemState.Value == E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN):
            self._dctGloInterDict["dctSubUnits"]["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].trgHmiFcoShutdown()
        else:
            self._dctGloInterDict["dctSubUnits"]["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].trgHmiFcoFailed()

        return(None)

# 0x0001 - HmiEndOfSetupCmdRspFCO
    async def objProcessPayloadHmiEndOfSetupCmdRspFCO(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for HmiEndOfSetupCmdRspFCO

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        await super().objProcessPayloadHmiEndOfSetupCmdRspFCO(dctObjectPar)  # pylint: disable=no-member

        objsHMI_END_OF_SETUP_CMD_RSP = sHMI_END_OF_SETUP_CMD_RSP()
        objsHMI_END_OF_SETUP_CMD_RSP.vDeserialise(dctObjectPar["MsgObject"].btaSerialise())

        # See if the CmdRsp status is normal
        if (objsHMI_END_OF_SETUP_CMD_RSP.sMsgHeader.e2MsgStatus.Value == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            self._dctGloInterDict["dctSubUnits"]["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].trgHmiFcoReady()
        else:
            logging.error("sHMI_END_OF_SETUP_CMD_RSP status is not normal with a value of %d", objsHMI_END_OF_SETUP_CMD_RSP.sMsgHeader.e2MsgStatus.Value)

        return(None)

# 0x0002 - HmiEndOfReadyCmdRspFCO
    async def objProcessPayloadHmiEndOfReadyCmdRspFCO(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for HmiEndOfReadyCmdRspFCO

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        await super().objProcessPayloadHmiEndOfReadyCmdRspFCO(dctObjectPar)

        objsHMI_END_OF_READY_CMD_RSP = sHMI_END_OF_READY_CMD_RSP()
        objsHMI_END_OF_READY_CMD_RSP.vDeserialise(dctObjectPar["MsgObject"].btaSerialise())

        # See if the CmdRsp status is normal
        if (objsHMI_END_OF_READY_CMD_RSP.sMsgHeader.e2MsgStatus.Value == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            self._dctGloInterDict["dctSubUnits"]["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].trgHmiFcoOperational()
        else:
            logging.error("sHMI_END_OF_READY_CMD_RSP status is not normal with a value of %d", objsHMI_END_OF_READY_CMD_RSP.sMsgHeader.e2MsgStatus.Value)

        return(None)

# 0x0003 - HmiShutdownCmdRspFCO
    async def objProcessPayloadHmiShutdownCmdRspFCO(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for HmiShutdownCmdRspFCO

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        await super().objProcessPayloadHmiShutdownCmdRspFCO(dctObjectPar)

        objsHMI_SHUTDOWN_CMD_RSP = sHMI_SHUTDOWN_CMD_RSP()
        objsHMI_SHUTDOWN_CMD_RSP.vDeserialise(dctObjectPar["MsgObject"].btaSerialise())

        # See if the CmdRsp status is normal
        if (objsHMI_SHUTDOWN_CMD_RSP.sMsgHeader.e2MsgStatus.Value == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            self._dctGloInterDict["dctSubUnits"]["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].trgHmiFcoShutdown()
        else:
            logging.error("sHMI_SHUTDOWN_CMD_RSP status is not normal with a value of %d", objsHMI_SHUTDOWN_CMD_RSP.sMsgHeader.e2MsgStatus.Value)

        return(None)

# 0x0004 - HmiShutdownUnsolFCO
    async def objProcessPayloadHmiShutdownUnsolFCO(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for HmiShutdownUnsolFCO

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """

        await super().objProcessPayloadHmiShutdownUnsolFCO(dctObjectPar)

        objsHMI_SHUTDOWN_UNSOL = sHMI_SHUTDOWN_UNSOL()
        objsHMI_SHUTDOWN_UNSOL.vDeserialise(dctObjectPar["MsgObject"].btaSerialise())

        # See if the CmdRsp status is normal
        if (objsHMI_SHUTDOWN_UNSOL.sMsgHeader.e2MsgStatus.Value == E2_MW_MESSAGE_STATUS.MW_MESSAGE_STATUS_NORMAL):
            self._dctGloInterDict["dctSubUnits"]["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].trgHmiFcoShutdown()
        else:
            logging.error("sHMI_SHUTDOWN_UNSOL status is not normal with a value of %d", objsHMI_SHUTDOWN_UNSOL.sMsgHeader.e2MsgStatus.Value)

        return(None)

# 0x0006 - HmiAdcsShutdownCmdFCO
    async def objProcessPayloadHmiAdcsShutdownCmdFCO(self, dctObjectPar) -> object:
        """ This is a public method which process a payload for HmiAdcsShutdownCmdFCO

        Args:
            dctObjectPar (dict): The first parameter. The dictionary received from the queue.

        Returns:
            (object): Will return an instance of a reply message if there is one

        Raises:
            Raises no exception.
        """
        bSendResponse = bool(True)

        # Do some sanity checks
        if (self._dctGloInterDict is None):
            logging.error("_dctGloInterDict cannot be None")
            return(None)

        # See if we are already in a SHUTDOWN state
        # If we enter the SHUTDOWN state then we will reply in there
        bSendResponse = self._dctGloInterDict["dctOLHM"]["objClsOlhmTransitionsManager"].state == "SHUTDOWN"

        self._dctGloInterDict["dctOLHM"]["objClsOlhmTransitionsManager"].vTriggerShutdown("HmiAdcsShutdownCmdFCO")

        # If this is true then it means we were already in a SHUTDOWN and we would need to reply here because on enter won't trigger
        if (bSendResponse is True):
            self.vSendHmiAdcsShutdownCmdRspFCO()

        return(None)

#    ==============================================================================================================
#    Base class methods to override - END
#    ==============================================================================================================

# 0x0001 vSendHmiEndOfSetupCmdFCO
    def vSendHmiEndOfSetupCmdFCO(self):
        """ This is a public method which is used to send a sHMI_END_OF_SETUP_CMD message

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        objsHMI_END_OF_SETUP_CMD = sHMI_END_OF_SETUP_CMD()

        self.vIncreaseMessageCounter((type(objsHMI_END_OF_SETUP_CMD), "FCO"))  # pylint: disable=no-member
        objsHMI_END_OF_SETUP_CMD.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsHMI_END_OF_SETUP_CMD), "FCO")]  # pylint: disable=no-member
        objsHMI_END_OF_SETUP_CMD.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsHMI_END_OF_SETUP_CMD, "FCO")  # pylint: disable=no-member

        return

# 0x0002 vSendHmiEndOfReadyCmdFCO
    def vSendHmiEndOfReadyCmdFCO(self):
        """ This is a public method which is used to send a sHMI_END_OF_READY_CMD message

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        objsHMI_END_OF_READY_CMD = sHMI_END_OF_READY_CMD()

        self.vIncreaseMessageCounter((type(objsHMI_END_OF_READY_CMD), "FCO"))  # pylint: disable=no-member
        objsHMI_END_OF_READY_CMD.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsHMI_END_OF_READY_CMD), "FCO")]  # pylint: disable=no-member
        objsHMI_END_OF_READY_CMD.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsHMI_END_OF_READY_CMD, "FCO")  # pylint: disable=no-member

        return

# 0x0003 vSendHmiShutdownCmdFCO
    def vSendHmiShutdownCmdFCO(self):
        """ This is a public method which is used to send a sHMI_SHUTDOWN_CMD message

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        objsHMI_SHUTDOWN_CMD = sHMI_SHUTDOWN_CMD()

        self.vIncreaseMessageCounter((type(objsHMI_SHUTDOWN_CMD), "FCO"))  # pylint: disable=no-member
        objsHMI_SHUTDOWN_CMD.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsHMI_SHUTDOWN_CMD), "FCO")]  # pylint: disable=no-member
        objsHMI_SHUTDOWN_CMD.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsHMI_SHUTDOWN_CMD, "FCO")  # pylint: disable=no-member

        return

# 0x0006 vSendHmiAdcsShutdownCmdRspFCO
    def vSendHmiAdcsShutdownCmdRspFCO(self):
        """ This is a public method which is used to send a sHMI_ADCS_SHUTDOWN_CMD_RSP message

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        objsHMI_ADCS_SHUTDOWN_CMD_RSP = sHMI_ADCS_SHUTDOWN_CMD_RSP()

        self.vIncreaseMessageCounter((type(objsHMI_ADCS_SHUTDOWN_CMD_RSP), "FCO"))  # pylint: disable=no-member
        objsHMI_ADCS_SHUTDOWN_CMD_RSP.sMsgHeader.u2MsgCount.Value = self._dctMessageCounters[(type(objsHMI_ADCS_SHUTDOWN_CMD_RSP), "FCO")]  # pylint: disable=no-member
        objsHMI_ADCS_SHUTDOWN_CMD_RSP.sMsgHeader.u8TimeStampMs.Value = clsDatetimeUtilities.iGetUtcCurrentDatetimeInMilliSecondsSinceEpoch()

        self.bPublishMqttAutogenObject(objsHMI_ADCS_SHUTDOWN_CMD_RSP, "FCO")  # pylint: disable=no-member

        return
