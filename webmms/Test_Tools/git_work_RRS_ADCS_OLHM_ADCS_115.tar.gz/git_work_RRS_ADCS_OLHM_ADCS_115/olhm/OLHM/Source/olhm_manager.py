#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module contains a class to manage the states of the OLHM

Todo:

"""

import logging
import datetime
import socket
from python_toolbox.Datetime_Utilities.datetime_utilities import clsDatetimeUtilities

from Autogen.olhm_msg import E1_OLHM_HEALTH_STATUS
from Autogen.olhm_msg import E1_OLHM_STATE
from Autogen.dr_msg import sDR_STATUS_REPORT_UNSOL_PL
from Autogen.pdbp_msg import sPDBP_STATUS_REPORT_UNSOL_PL
from Autogen.eiu_msg import sEIU_STATUS_REPORT_UNSOL_PL
from Autogen.tm_msg import sTM_STATUS_REPORT_UNSOL_PL
from Autogen.tewa_msg import sTEWA_STATUS_REPORT_UNSOL_PL
from Autogen.sf1_msg import sSF1_STATUS_REPORT_UNSOL_PL
from Autogen.sf2_msg import sSF2_STATUS_REPORT_UNSOL_PL
from Autogen.sf3_msg import sSF3_STATUS_REPORT_UNSOL_PL
from Autogen.hmi_msg import sHMI_STATUS_REPORT_UNSOL_PL
from Autogen.adcs_common_types import E1_ADCS_SYSTEM_STATE


class clsOlhmManager():
    """ This is the OLHM manager class.

    Args:
        dctGlobalInterfaceDictionaryPar (object): The first parameter. The global interface dictionary.

    """

    def __init__(self, dctGlobalInterfaceDictionaryPar):
        super().__init__()
        # Make this name short to be more readable
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar
        self._dctDateTime = {}
        self._dctDateTime["objDateTimeMonotonicRawCurrent"] = None
        self._dctDateTime["objDateTimeMonotonicRawPrev"] = None
        self._dctDateTime["iDateTimeMonotonicRawCurrent"] = int(0)
        self._dctDateTime["iDateTimeMonotonicRawPrev"] = int(0)
        self._dctDateTime["fDateTimeMonotonicRawCurrent"] = float(0.0)
        self._dctDateTime["fDateTimeMonotonicRawPrev"] = float(0.0)

        # We keep a socket for sending out OLHM state information as a text monitor screen
        self._objUdpTextMonitorSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._bClearAnsiScreen = bool(True)
        self._objDateTimeAnsiTerLastRedraw = None
        self._objDateTimeMonitorSubunit = clsDatetimeUtilities.objGetMonotonicRawCurrentDatetime()
        self._objDateTimeLastOlhmAdcsStatusUnsol = None
        self._iAnsiRedrawTick = int(0)

        # DR
        self._dctDRStatusReportUnsolState = {}
        self._dctDRStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctDRStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctDRStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctDRStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctDRStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctDRStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctDRStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # PDBP
        self._dctPDBPStatusReportUnsolState = {}
        self._dctPDBPStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctPDBPStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctPDBPStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctPDBPStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctPDBPStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctPDBPStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctPDBPStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # EIU
        self._dctEIUStatusReportUnsolState = {}
        self._dctEIUStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctEIUStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctEIUStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctEIUStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctEIUStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctEIUStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctEIUStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # TM
        self._dctTMStatusReportUnsolState = {}
        self._dctTMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctTMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctTMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctTMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctTMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctTMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctTMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # TEWA
        self._dctTEWAStatusReportUnsolState = {}
        self._dctTEWAStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctTEWAStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctTEWAStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctTEWAStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctTEWAStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctTEWAStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctTEWAStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # SF1
        self._dctSF1StatusReportUnsolState = {}
        self._dctSF1StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctSF1StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctSF1StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctSF1StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctSF1StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctSF1StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctSF1StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # SF2
        self._dctSF2StatusReportUnsolState = {}
        self._dctSF2StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctSF2StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctSF2StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctSF2StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctSF2StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctSF2StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctSF2StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # SF3
        self._dctSF3StatusReportUnsolState = {}
        self._dctSF3StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctSF3StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctSF3StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctSF3StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctSF3StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctSF3StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctSF3StatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # HMI_APM
        self._dctHMIAPMStatusReportUnsolState = {}
        self._dctHMIAPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctHMIAPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctHMIAPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctHMIAPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctHMIAPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctHMIAPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctHMIAPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # HMI_APM_FCO
        self._dctHMIAPMFCOStatusReportUnsolState = {}
        self._dctHMIAPMFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctHMIAPMFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctHMIAPMFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctHMIAPMFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctHMIAPMFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctHMIAPMFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctHMIAPMFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # HMI_FCO
        self._dctHMIFCOStatusReportUnsolState = {}
        self._dctHMIFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctHMIFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctHMIFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctHMIFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctHMIFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctHMIFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctHMIFCOStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # HMI_SPM
        self._dctHMISPMStatusReportUnsolState = {}
        self._dctHMISPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctHMISPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctHMISPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctHMISPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctHMISPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctHMISPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctHMISPMStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # HMI_SPM_FUFC
        self._dctHMISPMFUFCStatusReportUnsolState = {}
        self._dctHMISPMFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctHMISPMFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctHMISPMFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctHMISPMFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctHMISPMFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctHMISPMFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctHMISPMFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # HMI_FUFC
        self._dctHMIFUFCStatusReportUnsolState = {}
        self._dctHMIFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctHMIFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctHMIFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctHMIFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctHMIFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctHMIFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctHMIFUFCStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # HMI_Maintainer
        self._dctHMIMaintainerStatusReportUnsolState = {}
        self._dctHMIMaintainerStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctHMIMaintainerStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctHMIMaintainerStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctHMIMaintainerStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctHMIMaintainerStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctHMIMaintainerStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctHMIMaintainerStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        # HMI_Oversight
        self._dctHMIOversightStatusReportUnsolState = {}
        self._dctHMIOversightStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_UNKNOWN] = "UNKNOWN"
        self._dctHMIOversightStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OFFLINE] = "OFFLINE"
        self._dctHMIOversightStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_INITIALISE] = "INITIALISE"
        self._dctHMIOversightStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_READY] = "READY"
        self._dctHMIOversightStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_OPERATIONAL] = "OPERATIONAL"
        self._dctHMIOversightStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_FAILED] = "FAILED"
        self._dctHMIOversightStatusReportUnsolState[E1_ADCS_SYSTEM_STATE.SYSTEM_STATE_SHUTDOWN] = "SHUTDOWN"

        self._dctANSIMonitorRowLookup = {}
        self._dctANSIMonitorRowLookup["dctDR"] = {"acUnit": "DR", "acManager": "objClsDrTransitionsManager", "iRow": 2, "dctStateLookup": self._dctDRStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctPDBP"] = {"acUnit": "PDBP", "acManager": "objClsPdbpTransitionsManager", "iRow": 3, "dctStateLookup": self._dctPDBPStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctEIU"] = {"acUnit": "EIU", "acManager": "objClsEiuTransitionsManager", "iRow": 4, "dctStateLookup": self._dctEIUStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctTM"] = {"acUnit": "TM", "acManager": "objClsTmTransitionsManager", "iRow": 5, "dctStateLookup": self._dctTMStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctTEWA"] = {"acUnit": "TEWA", "acManager": "objClsTewaTransitionsManager", "iRow": 6, "dctStateLookup": self._dctTEWAStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctSF1"] = {"acUnit": "SF1", "acManager": "objClsSf1TransitionsManager", "iRow": 7, "dctStateLookup": self._dctSF1StatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctSF2"] = {"acUnit": "SF2", "acManager": "objClsSf2TransitionsManager", "iRow": 8, "dctStateLookup": self._dctSF2StatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctSF3"] = {"acUnit": "SF3", "acManager": "objClsSf3TransitionsManager", "iRow": 9, "dctStateLookup": self._dctSF3StatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctHMIAPM"] = {"acUnit": "HMI_APM", "acManager": "objClsHmiApmTransitionsManager", "iRow": 10, "dctStateLookup": self._dctHMIAPMStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctHMIAPMFCO"] = {"acUnit": "HMI_APM_FCO", "acManager": "objClsHmiApmFcoTransitionsManager", "iRow": 11, "dctStateLookup": self._dctHMIAPMFCOStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctHMIFCO"] = {"acUnit": "HMI_FCO", "acManager": "objClsHmiFcoTransitionsManager", "iRow": 12, "dctStateLookup": self._dctHMIFCOStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctHMISPM"] = {"acUnit": "HMI_SPM", "acManager": "objClsHmiSpmTransitionsManager", "iRow": 13, "dctStateLookup": self._dctHMISPMStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctHMISPMFUFC"] = {"acUnit": "HMI_SPM_FUFC", "acManager": "objClsHmiSpmFufcTransitionsManager", "iRow": 14, "dctStateLookup": self._dctHMISPMFUFCStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctHMIFUFC"] = {"acUnit": "HMI_FUFC", "acManager": "objClsHmiFufcTransitionsManager", "iRow": 15, "dctStateLookup": self._dctHMIFUFCStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctHMIMaintainer"] = {"acUnit": "HMI_Maintainer", "acManager": "objClsHmiMaintainerTransitionsManager", "iRow": 16, "dctStateLookup": self._dctHMIMaintainerStatusReportUnsolState}
        self._dctANSIMonitorRowLookup["dctHMIOversight"] = {"acUnit": "HMI_Oversight", "acManager": "objClsHmiOversightTransitionsManager", "iRow": 17, "dctStateLookup": self._dctHMIOversightStatusReportUnsolState}

        # This is used for ANSI prints
        self._dctTrainingSubModeStateLookup = {}
        self._dctTrainingSubModeStateLookup["INIT"] = "INIT"
        self._dctTrainingSubModeStateLookup["TRAINING_TRAINING"] = "TRAINING"
        self._dctTrainingSubModeStateLookup["TRAINING_PLAYBACK"] = "PLAYBACK"

        # This is used for ANSI prints
        self._dctRfTestTargetStateLookup = {}
        self._dctRfTestTargetStateLookup["INIT"] = "INIT"
        self._dctRfTestTargetStateLookup["RF_TEST_TARGET_ACTIVE"] = "ACTIVE"
        self._dctRfTestTargetStateLookup["RF_TEST_TARGET_INACTIVE"] = "INACTIVE"

        # This is used for ANSI prints
        self._dctEccmStateLookup = {}
        self._dctEccmStateLookup["INIT"] = "INIT"
        self._dctEccmStateLookup["ECCM_ACTIVE"] = "ACTIVE"
        self._dctEccmStateLookup["ECCM_INACTIVE"] = "INACTIVE"

        # This is used for ANSI prints
        self._dctAmrsStateLookup = {}
        self._dctAmrsStateLookup["INIT"] = "INIT"
        self._dctAmrsStateLookup["AMRS_ACTIVE"] = "ACTIVE"
        self._dctAmrsStateLookup["AMRS_INACTIVE"] = "INACTIVE"

        # This is used for ANSI prints
        self._dctIffTransmitStateLookup = {}
        self._dctIffTransmitStateLookup["INIT"] = "INIT"
        self._dctIffTransmitStateLookup["IFF_TRANSMITTING"] = "TRANSMITTING"
        self._dctIffTransmitStateLookup["IFF_NOT_TRANSMITTING"] = "NOT_TRANSMITTING"

        self._dctOlhmStateToE1_OLHM_STATELookup = {}
        self._dctOlhmStateToE1_OLHM_STATELookup["UNKNOWN"] = E1_OLHM_STATE.OLHM_STATE_UNKNOWN
        self._dctOlhmStateToE1_OLHM_STATELookup["OFFLINE"] = E1_OLHM_STATE.OLHM_STATE_OFFLINE
        self._dctOlhmStateToE1_OLHM_STATELookup["INITIALISE"] = E1_OLHM_STATE.OLHM_STATE_INITIALISE
        self._dctOlhmStateToE1_OLHM_STATELookup["READY"] = E1_OLHM_STATE.OLHM_STATE_READY
        self._dctOlhmStateToE1_OLHM_STATELookup["OPERATIONAL"] = E1_OLHM_STATE.OLHM_STATE_OPERATIONAL
        self._dctOlhmStateToE1_OLHM_STATELookup["FAILED"] = E1_OLHM_STATE.OLHM_STATE_FAILED
        self._dctOlhmStateToE1_OLHM_STATELookup["SHUTDOWN"] = E1_OLHM_STATE.OLHM_STATE_SHUTDOWN

        return

    def vAsyncioLoopProcess(self):
        """ This is a public method which is called repeatedly inside the Asyncio loop. This method in turn will call other methods which need to do some work.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        self._vGetTimestamp()  # This method must always be called first so that we get our current and previous timestamps
        self._vMonitorSubunitStatus()  # Call each subunits' state manager
        self._vSendBitMessages()
        self._vSendOlhmAdcsStatusUnsol()
        self._vUdpTextStateMonitor()

    def vSetOlhmState(self):
        """ This is a public method which is called to set the OLHM state for use in the group status tree.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        lstEntries = []  # Needed to make a list of status items for the group status tree
        dctCurrentItem = {}
        e1OlhmHealthStatus = E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN)
        e1OlhmState = E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE)

        if (self._dctGloInterDict is None):
            logging.error("self._dctGloInterDict cannot be None")
            return

        if (self._dctGloInterDict["dctOLHM"]["objClsOlhmConstructGroupStatus"] is None):
            logging.error("objClsOlhmConstructGroupStatus cannot be None")
            return

        if (self._dctGloInterDict["dctOLHM"]["objClsOlhmTransitionsManager"] is None):
            logging.error("objClsOlhmTransitionsManager cannot be None")
            return

        # Get the OLHM state from its state machine
        e1OlhmState.Value = self._dctOlhmStateToE1_OLHM_STATELookup[self._dctGloInterDict["dctOLHM"]["objClsOlhmTransitionsManager"].state]

        # OLHM rolled up
        dctCurrentItem = {}
        dctCurrentItem["lstTreePath"] = ["OLHM"]
        dctCurrentItem["acValue"] = ""
        e1OlhmHealthStatus.Value = E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_PASSED
        dctCurrentItem["e1OlhmHealthStatus"] = E1_OLHM_HEALTH_STATUS(e1OlhmHealthStatus.Value)
        dctCurrentItem["e1OlhmState"] = E1_OLHM_STATE(e1OlhmState.Value)

        lstEntries += [dctCurrentItem]

        # DR - STATUS - E1_DR_STATUS
        dctCurrentItem = {}
        dctCurrentItem["lstTreePath"] = ["OLHM", "STATUS"]
        dctCurrentItem["acValue"] = ""
        e1OlhmHealthStatus.Value = E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_PASSED
        dctCurrentItem["e1OlhmHealthStatus"] = E1_OLHM_HEALTH_STATUS(e1OlhmHealthStatus.Value)
        dctCurrentItem["e1OlhmState"] = E1_OLHM_STATE(e1OlhmState.Value)

        lstEntries += [dctCurrentItem]

        self._dctGloInterDict["dctOLHM"]["objClsOlhmConstructGroupStatus"].vUpdateDetailedTreeFromListOfEntries(lstEntries)

        return

    def _vGetTimestamp(self):
        """ This is a private method which saves the current timestamp when called. The resultant timestamp is stored locally as a class attribute.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        self._dctDateTime["fDateTimeMonotonicRawPrev"] = self._dctDateTime["fDateTimeMonotonicRawCurrent"]
        self._dctDateTime["iDateTimeMonotonicRawPrev"] = self._dctDateTime["iDateTimeMonotonicRawCurrent"]
        self._dctDateTime["objDateTimeMonotonicRawPrev"] = self._dctDateTime["objDateTimeMonotonicRawCurrent"]
        self._dctDateTime["objDateTimeMonotonicRawCurrent"] = clsDatetimeUtilities.objGetMonotonicRawCurrentDatetime()
        # Python reference: timestamp() -> Return POSIX timestamp corresponding to the datetime instance. The return value is a float similar to that returned by time.time().
        self._dctDateTime["fDateTimeMonotonicRawCurrent"] = self._dctDateTime["objDateTimeMonotonicRawCurrent"].timestamp()
        self._dctDateTime["iDateTimeMonotonicRawCurrent"] = int(self._dctDateTime["fDateTimeMonotonicRawCurrent"])

    def _vMonitorSubunitStatus(self):
        """ This is a private method which call each subunits' state manager to ascertain the state and status of the system.

        This is method which will actually do the state transition of the SCS.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        if (self._dctDateTime["objDateTimeMonotonicRawCurrent"] is None):
            return

        # Monitor high rate items
        # Nothing yet

        # Enter every 100ms - exit if we haven't waited that long yet
        if ((datetime.timedelta(seconds=0.1)) > (self._dctDateTime["objDateTimeMonotonicRawCurrent"] - self._objDateTimeMonitorSubunit)):
            return

        # Get a new datetime for the MonitorSubUnit
        self._objDateTimeMonitorSubunit = clsDatetimeUtilities.objGetMonotonicRawCurrentDatetime()

        # Process subunit state and BIT (XxxStatusReportUnsol OFFLINE)
        self._dctGloInterDict["dctSubUnits"]["dctDR"]["objClsDrTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the DR state
        self._dctGloInterDict["dctSubUnits"]["dctPDBP"]["objClsPdbpTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the PDBP state
        self._dctGloInterDict["dctSubUnits"]["dctEIU"]["objClsEiuTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the EIU state
        self._dctGloInterDict["dctSubUnits"]["dctTM"]["objClsTmTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the TM state
        self._dctGloInterDict["dctSubUnits"]["dctTEWA"]["objClsTewaTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the TEWA state
        self._dctGloInterDict["dctSubUnits"]["dctSF1"]["objClsSf1TransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the SF1 state
        self._dctGloInterDict["dctSubUnits"]["dctSF2"]["objClsSf2TransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the SF2 state
        self._dctGloInterDict["dctSubUnits"]["dctSF3"]["objClsSf3TransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the SF3 state
        self._dctGloInterDict["dctSubUnits"]["dctHMIAPM"]["objClsHmiApmTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the HMI_APM state
        self._dctGloInterDict["dctSubUnits"]["dctHMIAPMFCO"]["objClsHmiApmFcoTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the HMI_APM_FCO state
        self._dctGloInterDict["dctSubUnits"]["dctHMIFCO"]["objClsHmiFcoTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the HMI_FCO state
        self._dctGloInterDict["dctSubUnits"]["dctHMISPM"]["objClsHmiSpmTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the HMI_SPM state
        self._dctGloInterDict["dctSubUnits"]["dctHMISPMFUFC"]["objClsHmiSpmFufcTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the HMI_SPM_FUFC state
        self._dctGloInterDict["dctSubUnits"]["dctHMIFUFC"]["objClsHmiFufcTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the HMI_FUFC state
        self._dctGloInterDict["dctSubUnits"]["dctHMIMaintainer"]["objClsHmiMaintainerTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the HMI_Maintainer state
        self._dctGloInterDict["dctSubUnits"]["dctHMIOversight"]["objClsHmiOversightTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])  # Process the HMI_Oversight state

        # Process the OLHM's transitions but not the BIT - see _vSendOlhmAdcsStatusUnsol for group status
        self._dctGloInterDict["dctOLHM"]["objClsOlhmTransitionsManager"].vProcessState(self._dctDateTime["objDateTimeMonotonicRawCurrent"])

        return

    def _vSendOlhmAdcsStatusUnsol(self):
        """ This is a private method which sends out the OlhmAdcsStatusUnsol message.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        # The last datetime cannot be None
        if (self._objDateTimeLastOlhmAdcsStatusUnsol is None):
            self._objDateTimeLastOlhmAdcsStatusUnsol = clsDatetimeUtilities.objGetMonotonicRawCurrentDatetime()
            return

        # Every 1000ms - exit if we haven't waited that long yet
        if ((datetime.timedelta(seconds=1.00)) > (self._dctDateTime["objDateTimeMonotonicRawCurrent"] - self._objDateTimeLastOlhmAdcsStatusUnsol)):
            return

        # Take a new timestamp
        self._objDateTimeLastOlhmAdcsStatusUnsol = clsDatetimeUtilities.objGetMonotonicRawCurrentDatetime()

        if (self._dctGloInterDict is None):
            logging.error("self._dctGloInterDict cannot be None")
            return

        if (self._dctGloInterDict["dctOLHM"]["objClsOlhmConstructGroupStatus"] is None):
            logging.error("objClsOlhmConstructGroupStatus cannot be None")
            return

        self._dctGloInterDict["dctOLHM"]["objClsOlhmConstructGroupStatus"].vSendOlhmAdcsStatusUnsol()
        self._dctGloInterDict["dctOLHM"]["objClsOlhmConstructGroupStatus"].vSendOlhmAdcsHmiStatusUnsol()

        return

    def _vSendBitMessages(self):
        """ This is a private method sends out BIT information at a slow rate

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        # Send out messages at a slow rate of about once/1 sec
        if (self._dctDateTime["iDateTimeMonotonicRawCurrent"] == self._dctDateTime["iDateTimeMonotonicRawPrev"]):
            return

        if (self._dctGloInterDict is None):
            logging.error("_dctGloInterDict cannot be None")
            return(None)

        return

    def _vUdpTextStateMonitor(self):
        """ This is a private method which sends ANSI strings to a specific UDP port and IP address. Used for testing.

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        # The last datetime cannot be None
        if (self._objDateTimeAnsiTerLastRedraw is None):
            self._objDateTimeAnsiTerLastRedraw = clsDatetimeUtilities.objGetMonotonicRawCurrentDatetime()
            return

        # Redraw every 100ms - exit if we haven't waited that long yet
        if ((datetime.timedelta(seconds=0.1)) > (self._dctDateTime["objDateTimeMonotonicRawCurrent"] - self._objDateTimeAnsiTerLastRedraw)):
            return

        # Take a new timestamp
        self._objDateTimeAnsiTerLastRedraw = clsDatetimeUtilities.objGetMonotonicRawCurrentDatetime()

        if (self._objUdpTextMonitorSocket is None):
            logging.error("self._objUdpTextMonitorSocket cannot be None")
            return

        acSendIp = "127.0.0.1"
        iSendPort = 65111
        acText = ""
        acTextFull = ""
        iAnsiColumn0Num = int(0)
        iAnsiColumn1Num = int(15)
        iAnsiColumn2Num = int(30)
        iAnsiColumn3Num = int(50)

        objDateTimeUtc = clsDatetimeUtilities.objGetUtcCurrentDatetime()

        # Clear the ANSI screen
        acTextFull += "\x1b[2J"

        # ANSI - [ <Y> ; <X> H

        # Header
        acText = "\x1b[1;{}HUnit \x1b[1;{}HCurrent \x1b[1;{}HPrev \x1b[1;{}HStatusReportUnsol".format(iAnsiColumn0Num, iAnsiColumn1Num, iAnsiColumn2Num, iAnsiColumn3Num)
        acTextFull += acText

        for acKey, dctValue in self._dctANSIMonitorRowLookup.items():

            acText = "\x1b[{};{}H{}".format(dctValue["iRow"], iAnsiColumn0Num, dctValue["acUnit"])
            acTextFull += acText

            if (acKey in []):
                continue

            tplStatusReportUnsolStateValue = self._tplGetStateValueFromStatusReportUnsol(self._dctGloInterDict["dctSubUnits"][acKey]["objsSTATUSREPORTUNSOL"].sMsgPayload)

            if (tplStatusReportUnsolStateValue[0] is False):
                continue

            acText = "\x1b[{};{}H{}".format(dctValue["iRow"], iAnsiColumn1Num, self._dctGloInterDict["dctSubUnits"][acKey][dctValue["acManager"]].state)
            acTextFull += acText
            acText = "\x1b[{};{}H{}".format(dctValue["iRow"], iAnsiColumn2Num, self._dctGloInterDict["dctSubUnits"][acKey][dctValue["acManager"]].acPrevState())
            acTextFull += acText
            acText = "\x1b[{};{}H{}".format(dctValue["iRow"], iAnsiColumn3Num, dctValue["dctStateLookup"][tplStatusReportUnsolStateValue[1]])
            acTextFull += acText

        # OLHM state
        acText = "\x1b[20;{}HOLHM".format(iAnsiColumn0Num)
        acTextFull += acText
        acText = "\x1b[20;{}H{}".format(iAnsiColumn1Num, self._dctGloInterDict["dctOLHM"]["objClsOlhmTransitionsManager"].state)
        acTextFull += acText
        acText = "\x1b[20;{}H{}".format(iAnsiColumn2Num, self._dctGloInterDict["dctOLHM"]["objClsOlhmTransitionsManager"].acPrevState())
        acTextFull += acText

        acText = "\x1b[23;{}HUTC TIME {}".format(iAnsiColumn0Num, str(objDateTimeUtc))
        acTextFull += acText

        # Write the redraw to see that we are still alive
        acText = "\x1b[24;{}H{}".format(iAnsiColumn0Num, self._iAnsiRedrawTick)
        acTextFull += acText

        # Write the version number
        acText = "\x1b[24;{}H OLHM V{}.{}.{} {}".format(iAnsiColumn1Num, self._dctGloInterDict["dctOLHM"]["iVersionMajor"], self._dctGloInterDict["dctOLHM"]["iVersionMinor"], self._dctGloInterDict["dctOLHM"]["iVersionInternal"], self._dctGloInterDict["dctOLHM"]["acGitRepoHashOlhmFromGit"])
        acTextFull += acText

        # Now send the full text
        self._objUdpTextMonitorSocket.sendto(acTextFull.encode(encoding="ascii"), (acSendIp, iSendPort))  # Label

        self._iAnsiRedrawTick += 1

        return

    def _tplGetStateValueFromStatusReportUnsol(self, objStatusReportUnsolPayloadPar: object):
        """ This is a private method which resolves a StatusReportUnsol payload to a state enum value

        Args:
            objStatusReportUnsolPayloadPar (object). The a payload of a StatusReportUnsol message.

        Returns:
            (tuple): (bSuccess, iValue) tuple with bool to indicate if lookup was a success and then an int with the value.

        Raises:
            Raises no exception.
        """
        tplReturn = (False, int(0))

        if (isinstance(objStatusReportUnsolPayloadPar, sDR_STATUS_REPORT_UNSOL_PL) is True):
            return((True, objStatusReportUnsolPayloadPar.sModuleState.e1SystemState.Value))
        elif (isinstance(objStatusReportUnsolPayloadPar, sPDBP_STATUS_REPORT_UNSOL_PL) is True):
            return((True, objStatusReportUnsolPayloadPar.sModuleState.e1SystemState.Value))
        elif (isinstance(objStatusReportUnsolPayloadPar, sEIU_STATUS_REPORT_UNSOL_PL) is True):
            return((True, objStatusReportUnsolPayloadPar.sModuleState.e1SystemState.Value))
        elif (isinstance(objStatusReportUnsolPayloadPar, sTM_STATUS_REPORT_UNSOL_PL) is True):
            return((True, objStatusReportUnsolPayloadPar.sModuleState.e1SystemState.Value))
        elif (isinstance(objStatusReportUnsolPayloadPar, sTEWA_STATUS_REPORT_UNSOL_PL) is True):
            return((True, objStatusReportUnsolPayloadPar.sModuleState.e1SystemState.Value))
        elif (isinstance(objStatusReportUnsolPayloadPar, sSF1_STATUS_REPORT_UNSOL_PL) is True):
            return((True, objStatusReportUnsolPayloadPar.sModuleState.e1SystemState.Value))
        elif (isinstance(objStatusReportUnsolPayloadPar, sSF2_STATUS_REPORT_UNSOL_PL) is True):
            return((True, objStatusReportUnsolPayloadPar.sModuleState.e1SystemState.Value))
        elif (isinstance(objStatusReportUnsolPayloadPar, sSF3_STATUS_REPORT_UNSOL_PL) is True):
            return((True, objStatusReportUnsolPayloadPar.sModuleState.e1SystemState.Value))
        elif (isinstance(objStatusReportUnsolPayloadPar, sHMI_STATUS_REPORT_UNSOL_PL) is True):
            return((True, objStatusReportUnsolPayloadPar.sModuleState.e1SystemState.Value))
        else:
            return(tplReturn)

        return(tplReturn)
