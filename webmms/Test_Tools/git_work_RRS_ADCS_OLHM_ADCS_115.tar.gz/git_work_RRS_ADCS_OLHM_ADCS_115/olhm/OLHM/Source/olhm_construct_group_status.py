#! /usr/bin/env python3.6
# -*- coding: utf-8 -*-
"""This module contains a class to construct ADCS group status

Todo:

"""
import logging
import collections

from Autogen.olhm_msg import E1_OLHM_HEALTH_STATUS
from Autogen.olhm_msg import E1_OLHM_STATE
from Autogen.olhm_msg import sOLHM_ADCS_STATUS_UNSOL
from Autogen.olhm_msg import sOLHM_ADCS_HMI_STATUS_UNSOL


class clsOlhmConstructGroupStatus():
    """ This is the OLHM class for monitoring the ADCS group status.

    Args:
        dctGlobalInterfaceDictionaryPar (object): The first parameter. The global interface dictionary.

    """

    def __init__(self, dctGlobalInterfaceDictionaryPar):
        super().__init__()
        # Make this name short to be more readable
        self._dctGloInterDict = dctGlobalInterfaceDictionaryPar

        self._objsOLHM_ADCS_STATUS_UNSOLCurrent = sOLHM_ADCS_STATUS_UNSOL()
        self._objsOLHM_ADCS_STATUS_UNSOLPrev = sOLHM_ADCS_STATUS_UNSOL()
        self._objsOLHM_ADCS_STATUS_UNSOLUnknown = sOLHM_ADCS_STATUS_UNSOL()

        self._objsOLHM_ADCS_HMI_STATUS_UNSOLCurrent = sOLHM_ADCS_HMI_STATUS_UNSOL()
        self._objsOLHM_ADCS_HMI_STATUS_UNSOLPrev = sOLHM_ADCS_HMI_STATUS_UNSOL()
        self._objsOLHM_ADCS_HMI_STATUS_UNSOLUnknown = sOLHM_ADCS_HMI_STATUS_UNSOL()

        self._lstParentLRUItems = []
        self._lstParentLRUItems += ["OLHM"]
        self._lstParentLRUItems += ["TM"]
        self._lstParentLRUItems += ["TEWA"]
        self._lstParentLRUItems += ["PDBP"]
        self._lstParentLRUItems += ["DR"]
        self._lstParentLRUItems += ["EIU"]
        self._lstParentLRUItems += ["HMI_APM"]
        self._lstParentLRUItems += ["HMI_FCO"]
        self._lstParentLRUItems += ["HMI_APM_FCO"]
        self._lstParentLRUItems += ["HMI_SPM"]
        self._lstParentLRUItems += ["HMI_FUFC"]
        self._lstParentLRUItems += ["HMI_SPM_FUFC"]
        self._lstParentLRUItems += ["HMI_Oversight"]
        self._lstParentLRUItems += ["HMI_Maintainer"]
        self._lstParentLRUItems += ["SF1"]
        self._lstParentLRUItems += ["SF2"]
        self._lstParentLRUItems += ["SF3"]

        self._dctOrderedDetailedGroupBit = collections.OrderedDict()

        # Use the list of top level subunits and populate the top level of the detailed bit tree
        for acKey in self._lstParentLRUItems:

            # Fill up the detailed message
            self._dctOrderedDetailedGroupBit[acKey] = {}  # This dictionary does not have to ordered
            self._vPopulateDetailedBitTreeNode(self._dctOrderedDetailedGroupBit[acKey], acKey, acKey, "", E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN), 0, E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE))

        # Now iterate through the detailed bit tree and populate the nodes of the high level items
        for acKey, dctItem in self._dctOrderedDetailedGroupBit.items():

            if (acKey == "OLHM"):
                self._vInitAndPopulateDetailedBitForOlhm(dctItem)
            elif (acKey == "TM"):
                self._vInitAndPopulateDetailedBitForTm(dctItem)
            elif (acKey == "TEWA"):
                self._vInitAndPopulateDetailedBitForTewa(dctItem)
            elif (acKey == "PDBP"):
                self._vInitAndPopulateDetailedBitForPdbp(dctItem)
            elif (acKey == "DR"):
                self._vInitAndPopulateDetailedBitForDr(dctItem)
            elif (acKey == "EIU"):
                self._vInitAndPopulateDetailedBitForEiu(dctItem)
            elif (acKey == "HMI_APM"):
                self._vInitAndPopulateDetailedBitForHmiApm(dctItem)
            elif (acKey == "HMI_APM_FCO"):
                self._vInitAndPopulateDetailedBitForHmiApmFco(dctItem)
            elif (acKey == "HMI_FCO"):
                self._vInitAndPopulateDetailedBitForHmiFco(dctItem)
            elif (acKey == "HMI_SPM"):
                self._vInitAndPopulateDetailedBitForHmiSpm(dctItem)
            elif (acKey == "HMI_SPM_FUFC"):
                self._vInitAndPopulateDetailedBitForHmiSpmFufc(dctItem)
            elif (acKey == "HMI_FUFC"):
                self._vInitAndPopulateDetailedBitForHmiFufc(dctItem)
            elif (acKey == "HMI_Maintainer"):
                self._vInitAndPopulateDetailedBitForHmiMaintainer(dctItem)
            elif (acKey == "HMI_Oversight"):
                self._vInitAndPopulateDetailedBitForHmiOversight(dctItem)
            elif (acKey == "SF1"):
                self._vInitAndPopulateDetailedBitForSf1(dctItem)
            elif (acKey == "SF2"):
                self._vInitAndPopulateDetailedBitForSf2(dctItem)
            elif (acKey == "SF3"):
                self._vInitAndPopulateDetailedBitForSf3(dctItem)

        # Because we have just started build up a sOlhmAdcsStatusUnsol so can record it as the start up values of the tree
        self.vBuildUpOlhmAdcsStatusUnsol(self._objsOLHM_ADCS_STATUS_UNSOLUnknown)

        if (self._objsOLHM_ADCS_HMI_STATUS_UNSOLUnknown.sMsgPayload.iSizeBytes() == self._objsOLHM_ADCS_STATUS_UNSOLUnknown.sMsgPayload.iSizeBytes()):
            self._objsOLHM_ADCS_HMI_STATUS_UNSOLUnknown.sMsgPayload.vDeserialise(self._objsOLHM_ADCS_STATUS_UNSOLUnknown.sMsgPayload.btaSerialise())
        else:
            logging.error("Messages sOLHM_ADCS_STATUS_UNSOL and sOLHM_ADCS_HMI_STATUS_UNSOL are not the same size")

        self._bDetailedTreeChanged = bool(False)

        return

    def vSendUnknownOlhmAdcsStatusUnsol(self):
        """ This is a public method which sends message an sOLHM_ADCS_STATUS_UNSOL with all fields listed as UNKNOWN

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        # Do some sanity checks

        if (self._dctGloInterDict is None):
            logging.error("_dctGloInterDict cannot be None")
            return

        if (self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"] is None):
            logging.error("objClsMessageProcessForMqtt cannot be None")
            return

        if (self._objsOLHM_ADCS_STATUS_UNSOLUnknown is None):
            logging.error("_objsOLHM_ADCS_STATUS_UNSOLUnknown cannot be None")
            return

        self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendOlhmAdcsStatusUnsol(self._objsOLHM_ADCS_STATUS_UNSOLUnknown)

        return

    def vSendUnknownOlhmAdcsHmiStatusUnsol(self):
        """ This is a public method which sends message an sOLHM_ADCS_HMI_STATUS_UNSOL with all fields listed as UNKNOWN

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        # Do some sanity checks

        if (self._dctGloInterDict is None):
            logging.error("_dctGloInterDict cannot be None")
            return

        if (self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"] is None):
            logging.error("objClsMessageProcessForMqtt cannot be None")
            return

        if (self._objsOLHM_ADCS_HMI_STATUS_UNSOLUnknown is None):
            logging.error("_objsOLHM_ADCS_HMI_STATUS_UNSOLUnknown cannot be None")
            return

        self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendOlhmAdcsHmiStatusUnsol(self._objsOLHM_ADCS_HMI_STATUS_UNSOLUnknown)

        return

    def vSendOlhmAdcsStatusUnsol(self):
        """ This is a public method which sends message sOLHM_ADCS_STATUS_UNSOL

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        if (self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"] is None):
            return

        self.vRecalculateDetailedBitTreeBranchSeverity()
        self.vBuildUpOlhmAdcsStatusUnsol(self._objsOLHM_ADCS_STATUS_UNSOLCurrent)

        self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendOlhmAdcsStatusUnsol(self._objsOLHM_ADCS_STATUS_UNSOLCurrent)

        return

    def vSendOlhmAdcsHmiStatusUnsol(self):
        """ This is a public method which sends message sOLHM_ADCS_HMI_STATUS_UNSOL

        Args:

        Returns:

        Raises:
            Raises no exception.
        """
        objsOLHM_ADCS_HMI_STATUS_UNSOL = None

        if (self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"] is None):
            return

        self.vRecalculateDetailedBitTreeBranchSeverity()
        self.vBuildUpOlhmAdcsStatusUnsol(self._objsOLHM_ADCS_STATUS_UNSOLCurrent)

        objsOLHM_ADCS_HMI_STATUS_UNSOL = sOLHM_ADCS_HMI_STATUS_UNSOL()

        # Make sure the two messages are the same size before the deserialise
        if (objsOLHM_ADCS_HMI_STATUS_UNSOL.sMsgPayload.iSizeBytes() == self._objsOLHM_ADCS_STATUS_UNSOLCurrent.sMsgPayload.iSizeBytes()):
            objsOLHM_ADCS_HMI_STATUS_UNSOL.sMsgPayload.vDeserialise(self._objsOLHM_ADCS_STATUS_UNSOLCurrent.sMsgPayload.btaSerialise())
            self._dctGloInterDict["dctMqtt"]["objClsMessageProcessForMqtt"].vSendOlhmAdcsHmiStatusUnsol(objsOLHM_ADCS_HMI_STATUS_UNSOL)
        else:
            logging.error("Messages sOLHM_ADCS_STATUS_UNSOL and sOLHM_ADCS_HMI_STATUS_UNSOL are not the same size")

        return

    def vBuildUpOlhmAdcsStatusUnsol(self, objsOLHM_ADCS_STATUS_UNSOLPar: object):
        """ This is a public method which builds up message sOLHM_ADCS_STATUS_UNSOL from an existing dictionary

        Args:
            objsOLHM_ADCS_STATUS_UNSOLPar (sOLHM_ADCS_STATUS_UNSOL): The first parameter. The object into which the values will be packed.

        Returns:

        Raises:
            Raises no exception.
        """
        objsOLHM_DETAILED_STATUS = None
        iLevel0Counter = int(-1)
        iLevel1Counter = int(-1)
        iLevel2Counter = int(-1)

        if (objsOLHM_ADCS_STATUS_UNSOLPar is None):
            logging.error("objsOLHM_ADCS_STATUS_UNSOLPar cannot be None")
            return

        if (self._dctOrderedDetailedGroupBit is None):
            logging.error("self._dctOrderedHighLevelStatus cannot be None")
            return

        # Take the nested Python dictionary BIT tree and convert it into a list
        lstBitItems = self._lstGetListOfDetailedSystemBitItems(self._dctOrderedDetailedGroupBit)

        if (not lstBitItems):
            return

        iCnt = int(0)
        for dctItem in lstBitItems:

            # Do not exceed the limit of the number of items stipulated in the XML file
            if (iCnt >= len(objsOLHM_ADCS_STATUS_UNSOLPar.sMsgPayload.asBitItems.Value)):
                break

            if (dctItem["iLevel"] == 0):
                iLevel0Counter += 1  # Increase the level 0 counter
                iLevel1Counter = -1  # Clear the level 1 counter
                iLevel2Counter = -1
            elif (dctItem["iLevel"] == 1):
                iLevel1Counter += 1  # Increase the level 1 counter
                iLevel2Counter = -1  # Clear the level 1 counter
            elif (dctItem["iLevel"] == 2):
                iLevel2Counter += 1  # Increase the level 2 counter
            else:
                logging.error("BIT tree levels exceeding 2 is not valid")
                continue

            objsOLHM_DETAILED_STATUS = objsOLHM_ADCS_STATUS_UNSOLPar.sMsgPayload.asBitItems.Value[iCnt]
            objsOLHM_DETAILED_STATUS.acName.Value = dctItem["acName"]
            objsOLHM_DETAILED_STATUS.acValue.Value = dctItem["acValue"]
            objsOLHM_DETAILED_STATUS.e1Status.Value = dctItem["e1OlhmHealthStatus"].Value
            objsOLHM_DETAILED_STATUS.e1State.Value = dctItem["e1OlhmState"].Value
            objsOLHM_DETAILED_STATUS.i2AbsoluteIndex.Value = iCnt
            objsOLHM_DETAILED_STATUS.i2Level0Index.Value = iLevel0Counter
            objsOLHM_DETAILED_STATUS.i2Level1Index.Value = iLevel1Counter
            objsOLHM_DETAILED_STATUS.i2Level2Index.Value = iLevel2Counter

            iCnt += 1

        objsOLHM_ADCS_STATUS_UNSOLPar.sMsgPayload.u2NumberOfValidBitItems.Value = iCnt

        return

    def vRecalculateDetailedBitTreeBranchSeverity(self):
        """ This is a public method which recalculates the BIT tree

        Args:

        Returns:

        Raises:
            Raises no exception.
        """

        self._iRecalculateDetailedBitTreeBranchSeverity(self._dctOrderedDetailedGroupBit)
        return

    def vUpdateDetailedTreeFromListOfEntries(self, lstEntriesPar: list):
        """ This is a public method which update the detailed BIT tree according to entries in a list

        Args:
            lstEntriesPar (list): The first parameter. A list of entries which are dictionaries
                Each list item contains dict keys:
                    * lstTreePath (list) Example -> ["DR", "STATUS"]
                    * acValue (str)
                    * e1OlhmHealthStatus (E1_OLHM_HEALTH_STATUS)
                    * e1OlhmState (E1_OLHM_STATE)

        Returns:

        Raises:
            Raises no exception.
        """
        dctTreeItem = None  # Make this None for now
        dctTreeItemChild = None  # Make this None for now

        if (self._dctGloInterDict is None):
            logging.error("_dctGloInterDict cannot be None")
            return

        if (self._dctOrderedDetailedGroupBit is None):
            logging.error("self._dctOrderedDetailedGroupBit cannot be None")
            return

        if (lstEntriesPar is None):
            logging.error("lstEntriesPar cannot be None")
            return

        if (not lstEntriesPar):
            return

        # Iterate through the list of tree entries we need to modify
        for dctItem in lstEntriesPar:
            # Start the tree item as the root of the tree
            dctTreeItem = self._dctOrderedDetailedGroupBit
            dctTreeItemChild = None  # make the child None for now

            # Iterate through the tree path
            for iCnt in range(len(dctItem["lstTreePath"])):
                acKey = dctItem["lstTreePath"][iCnt]

                # The child might have been None in the previous iteration so first check before doing anything else
                # If this level tree item is None then there is nothing to do
                if (dctTreeItem is None):
                    break

                # Key cannot be an empty string
                if (acKey == ""):
                    break

                if (acKey in dctTreeItem):
                    dctTreeItem = dctTreeItem[acKey]
                    dctTreeItemChild = dctTreeItem["dctChild"]  # Careful, this child might be None
                else:
                    logging.error("Key %s is not in detailed tree", acKey)
                    dctTreeItem = None
                    break

                # Only move on the child
                if (iCnt < (len(dctItem["lstTreePath"]) - 1)):
                    dctTreeItem = dctTreeItemChild

            # Only update the tree entries if we know the leaf into we will be writing is not None
            if (dctTreeItem is not None):
                # Keep record if the tree changed - set a flag if changed
                if (dctTreeItem["acValue"] != dctItem["acValue"]):
                    dctTreeItem["acValue"] = dctItem["acValue"]
                    self._bDetailedTreeChanged = bool(True)

                # Keep record if the tree changed - set a flag if changed
                if (dctTreeItem["e1OlhmHealthStatus"].Value != dctItem["e1OlhmHealthStatus"].Value):
                    dctTreeItem["e1OlhmHealthStatus"].Value = dctItem["e1OlhmHealthStatus"].Value
                    self._bDetailedTreeChanged = bool(True)

                if (dctTreeItem["e1OlhmState"].Value != dctItem["e1OlhmState"].Value):
                    dctTreeItem["e1OlhmState"].Value = dctItem["e1OlhmState"].Value
                    self._bDetailedTreeChanged = bool(True)

        # Check if we should send the tree
        self._vSendGroupBitTreeIfChanged()

        return

    def _iRecalculateDetailedBitTreeBranchSeverity(self, dctTreePar: dict, iLevelPar: int = 0):
        """ This is a private method which uses recursion to walk the tree and work out
        what the brach severity must be by looking at the children.

        Args:
            lstEntriesPar (list): The first parameter. A list of entries
                Each list item contains:
                    * lstTreePath (list) Example -> ["TTS", "AIRPROC"]
                    * acValue (str)
                    * e1OlhmHealthStatus (E1_OLHM_HEALTH_STATUS)
            iLevelPar (int): The second parameter. The current level of the tree.

        Returns:

        Raises:
            Raises no exception.
        """

        if (dctTreePar is None):
            return

        # This variable stores the combined status of all the items on this level
        e1OlhmHealthStatusReturn = E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_PASSED)  # Start with PASSED
        e1OlhmHealthStatusItem = E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN)  # Start with UNKNOWN

        for acKey, dctItem in dctTreePar.items():

            # First go down the branch before doing other calculations
            if (dctItem["dctChild"] is not None):

                # We want certain branches to be excluded from being summarised this way - keep list in order
                # Excluded ones are nothing - all the BIT tree level 0 branches are here
                if ((acKey in ["OLHM", "TM", "TEWA", "PDBP", "DR", "EIU", "HMI_APM", "HMI_FCO", "HMI_APM_FCO", "HMI_SPM", "HMI_FUFC", "HMI_SPM_FUFC", "HMI_Oversight", "HMI_Maintainer", "SF1", "SF2", "SF3"]) and (iLevelPar == 0)):
                    pass
                else:
                    # If there are children then we first need to go and combine their statuses
                    e1OlhmHealthStatusItem.Value = self._iRecalculateDetailedBitTreeBranchSeverity(dctItem["dctChild"], iLevelPar + 1)
                    dctItem["e1OlhmHealthStatus"].Value = e1OlhmHealthStatusItem.Value

            # Now go through all the statuses on this level and give more attention to the more severe status
            if (e1OlhmHealthStatusReturn.Value == E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_PASSED):
                if (dctItem["e1OlhmHealthStatus"].Value == E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_DEGRADED):
                    e1OlhmHealthStatusReturn.Value = E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_DEGRADED
                elif (dctItem["e1OlhmHealthStatus"].Value == E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_FAILED):
                    e1OlhmHealthStatusReturn.Value = E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_FAILED
            elif (e1OlhmHealthStatusReturn.Value == E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_DEGRADED):
                if (dctItem["e1OlhmHealthStatus"].Value == E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_FAILED):
                    e1OlhmHealthStatusReturn.Value = E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_FAILED
            elif (e1OlhmHealthStatusReturn.Value == E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_FAILED):
                pass
            elif (e1OlhmHealthStatusReturn.Value == E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_NOT_FITTED):
                pass
            elif (e1OlhmHealthStatusReturn.Value == E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN):
                pass

        return(e1OlhmHealthStatusReturn.Value)

    def _lstGetListOfDetailedSystemBitItems(self, dctDetailedBitTreePar: dict) -> list:
        """ This is a private method which convert the DetailedBitTree into a list of BIT items

        Args:
            dctDetailedBitTreePar (dict): The first parameter. The BIT tree

        Returns:
            list: A list of all the bit items

        Raises:
            Raises no exception.
        """

        lstReturnValue = []

        for _, dctItem in dctDetailedBitTreePar.items():
            lstReturnValue += [dctItem]
            if (dctItem["dctChild"] is not None):
                lstReturnValue += self._lstGetListOfDetailedSystemBitItems(dctItem["dctChild"])

        return(lstReturnValue)

    def _vSendGroupBitTreeIfChanged(self):

        if (self._bDetailedTreeChanged is True):
            self.vSendOlhmAdcsStatusUnsol()
            self.vSendOlhmAdcsHmiStatusUnsol()
            self._bDetailedTreeChanged = bool(False)

        return

    def _vInitAndPopulateDetailedBitForOlhm(self, dctNodePar: object):
        """ This is a private method which initializes the OLHM level of the detailed BIT tree.

        Args:
            dctNodePar (dict): The first parameter. The OLHM dictionary node of the detailed bit tree

        Returns:

        Raises:
            Raises no exception.
        """

        lstSubNodes = ["STATUS"]

        if (dctNodePar is None):
            logging.error("dctNodePar cannot be None")
            return

        dctNodePar["dctChild"] = collections.OrderedDict()

        for acNode in lstSubNodes:
            acNewKey = acNode
            dctNodePar["dctChild"][acNewKey] = {}  # This dictionary does not have to ordered

            self._vPopulateDetailedBitTreeNode(dctNodePar["dctChild"][acNewKey], dctNodePar["acName"], acNewKey, "", E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN), 1, E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE))

        return

    def _vInitAndPopulateDetailedBitForTm(self, dctNodePar: object):
        """ This is a private method which initializes the TM level of the detailed BIT tree.

        Args:
            dctNodePar (dict): The first parameter. The TM dictionary node of the detailed bit tree

        Returns:

        Raises:
            Raises no exception.
        """

        lstSubNodes = ["STATUS"]

        if (dctNodePar is None):
            logging.error("dctNodePar cannot be None")
            return

        dctNodePar["dctChild"] = collections.OrderedDict()

        for acNode in lstSubNodes:
            acNewKey = acNode
            dctNodePar["dctChild"][acNewKey] = {}  # This dictionary does not have to ordered

            self._vPopulateDetailedBitTreeNode(dctNodePar["dctChild"][acNewKey], dctNodePar["acName"], acNewKey, "", E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN), 1, E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE))

        return

    def _vInitAndPopulateDetailedBitForTewa(self, dctNodePar: object):
        """ This is a private method which initializes the TEWA level of the detailed BIT tree.

        Args:
            dctNodePar (dict): The first parameter. The TEWA dictionary node of the detailed bit tree

        Returns:

        Raises:
            Raises no exception.
        """

        lstSubNodes = ["STATUS"]

        if (dctNodePar is None):
            logging.error("dctNodePar cannot be None")
            return

        dctNodePar["dctChild"] = collections.OrderedDict()

        for acNode in lstSubNodes:
            acNewKey = acNode
            dctNodePar["dctChild"][acNewKey] = {}  # This dictionary does not have to ordered

            self._vPopulateDetailedBitTreeNode(dctNodePar["dctChild"][acNewKey], dctNodePar["acName"], acNewKey, "", E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN), 1, E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE))

        return

    def _vInitAndPopulateDetailedBitForPdbp(self, dctNodePar: object):
        """ This is a private method which initializes the PDBP level of the detailed BIT tree.

        Args:
            dctNodePar (dict): The first parameter. The PDBP dictionary node of the detailed bit tree

        Returns:

        Raises:
            Raises no exception.
        """

        lstSubNodes = ["STATUS"]

        if (dctNodePar is None):
            logging.error("dctNodePar cannot be None")
            return

        dctNodePar["dctChild"] = collections.OrderedDict()

        for acNode in lstSubNodes:
            acNewKey = acNode
            dctNodePar["dctChild"][acNewKey] = {}  # This dictionary does not have to ordered

            self._vPopulateDetailedBitTreeNode(dctNodePar["dctChild"][acNewKey], dctNodePar["acName"], acNewKey, "", E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN), 1, E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE))

        return

    def _vInitAndPopulateDetailedBitForDr(self, dctNodePar: object):
        """ This is a private method which initializes the DR level of the detailed BIT tree.

        Args:
            dctNodePar (dict): The first parameter. The DR dictionary node of the detailed bit tree

        Returns:

        Raises:
            Raises no exception.
        """

        lstSubNodes = ["STATUS"]

        if (dctNodePar is None):
            logging.error("dctNodePar cannot be None")
            return

        dctNodePar["dctChild"] = collections.OrderedDict()

        for acNode in lstSubNodes:
            acNewKey = acNode
            dctNodePar["dctChild"][acNewKey] = {}  # This dictionary does not have to ordered

            self._vPopulateDetailedBitTreeNode(dctNodePar["dctChild"][acNewKey], dctNodePar["acName"], acNewKey, "", E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN), 1, E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE))

        return

    def _vInitAndPopulateDetailedBitForEiu(self, dctNodePar: object):
        """ This is a private method which initializes the EIU level of the detailed BIT tree.

        Args:
            dctNodePar (dict): The first parameter. The EIU dictionary node of the detailed bit tree

        Returns:

        Raises:
            Raises no exception.
        """

        lstSubNodes = ["STATUS"]

        if (dctNodePar is None):
            logging.error("dctNodePar cannot be None")
            return

        dctNodePar["dctChild"] = collections.OrderedDict()

        for acNode in lstSubNodes:
            acNewKey = acNode
            dctNodePar["dctChild"][acNewKey] = {}  # This dictionary does not have to ordered

            self._vPopulateDetailedBitTreeNode(dctNodePar["dctChild"][acNewKey], dctNodePar["acName"], acNewKey, "", E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN), 1, E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE))

        return

    def _vInitAndPopulateDetailedBitForHmiApm(self, dctNodePar: object):
        """ This is a private method which initializes the HMI_APM level of the detailed BIT tree.

        Args:
            dctNodePar (dict): The first parameter. The HMI_APM dictionary node of the detailed bit tree

        Returns:

        Raises:
            Raises no exception.
        """

        lstSubNodes = ["STATUS"]

        if (dctNodePar is None):
            logging.error("dctNodePar cannot be None")
            return

        dctNodePar["dctChild"] = collections.OrderedDict()

        for acNode in lstSubNodes:
            acNewKey = acNode
            dctNodePar["dctChild"][acNewKey] = {}  # This dictionary does not have to ordered

            self._vPopulateDetailedBitTreeNode(dctNodePar["dctChild"][acNewKey], dctNodePar["acName"], acNewKey, "", E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN), 1, E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE))

        return

    def _vInitAndPopulateDetailedBitForHmiApmFco(self, dctNodePar: object):
        """ This is a private method which initializes the HMI_APM_FCO level of the detailed BIT tree.

        Args:
            dctNodePar (dict): The first parameter. The HMI_APM_FCO dictionary node of the detailed bit tree

        Returns:

        Raises:
            Raises no exception.
        """

        lstSubNodes = ["STATUS"]

        if (dctNodePar is None):
            logging.error("dctNodePar cannot be None")
            return

        dctNodePar["dctChild"] = collections.OrderedDict()

        for acNode in lstSubNodes:
            acNewKey = acNode
            dctNodePar["dctChild"][acNewKey] = {}  # This dictionary does not have to ordered

            self._vPopulateDetailedBitTreeNode(dctNodePar["dctChild"][acNewKey], dctNodePar["acName"], acNewKey, "", E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN), 1, E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE))

        return

    def _vInitAndPopulateDetailedBitForHmiFco(self, dctNodePar: object):
        """ This is a private method which initializes the HMI_FCO level of the detailed BIT tree.

        Args:
            dctNodePar (dict): The first parameter. The HMI_FCO dictionary node of the detailed bit tree

        Returns:

        Raises:
            Raises no exception.
        """

        lstSubNodes = ["STATUS"]

        if (dctNodePar is None):
            logging.error("dctNodePar cannot be None")
            return

        dctNodePar["dctChild"] = collections.OrderedDict()

        for acNode in lstSubNodes:
            acNewKey = acNode
            dctNodePar["dctChild"][acNewKey] = {}  # This dictionary does not have to ordered

            self._vPopulateDetailedBitTreeNode(dctNodePar["dctChild"][acNewKey], dctNodePar["acName"], acNewKey, "", E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN), 1, E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE))

        return

    def _vInitAndPopulateDetailedBitForHmiSpm(self, dctNodePar: object):
        """ This is a private method which initializes the HMI_SPM level of the detailed BIT tree.

        Args:
            dctNodePar (dict): The first parameter. The HMI_SPM dictionary node of the detailed bit tree

        Returns:

        Raises:
            Raises no exception.
        """

        lstSubNodes = ["STATUS"]

        if (dctNodePar is None):
            logging.error("dctNodePar cannot be None")
            return

        dctNodePar["dctChild"] = collections.OrderedDict()

        for acNode in lstSubNodes:
            acNewKey = acNode
            dctNodePar["dctChild"][acNewKey] = {}  # This dictionary does not have to ordered

            self._vPopulateDetailedBitTreeNode(dctNodePar["dctChild"][acNewKey], dctNodePar["acName"], acNewKey, "", E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN), 1, E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE))

        return

    def _vInitAndPopulateDetailedBitForHmiSpmFufc(self, dctNodePar: object):
        """ This is a private method which initializes the HMI_SPM_FUFC level of the detailed BIT tree.

        Args:
            dctNodePar (dict): The first parameter. The HMI_SPM_FUFC dictionary node of the detailed bit tree

        Returns:

        Raises:
            Raises no exception.
        """

        lstSubNodes = ["STATUS"]

        if (dctNodePar is None):
            logging.error("dctNodePar cannot be None")
            return

        dctNodePar["dctChild"] = collections.OrderedDict()

        for acNode in lstSubNodes:
            acNewKey = acNode
            dctNodePar["dctChild"][acNewKey] = {}  # This dictionary does not have to ordered

            self._vPopulateDetailedBitTreeNode(dctNodePar["dctChild"][acNewKey], dctNodePar["acName"], acNewKey, "", E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN), 1, E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE))

        return

    def _vInitAndPopulateDetailedBitForHmiFufc(self, dctNodePar: object):
        """ This is a private method which initializes the HMI_FUFC level of the detailed BIT tree.

        Args:
            dctNodePar (dict): The first parameter. The HMI_FUFC dictionary node of the detailed bit tree

        Returns:

        Raises:
            Raises no exception.
        """

        lstSubNodes = ["STATUS"]

        if (dctNodePar is None):
            logging.error("dctNodePar cannot be None")
            return

        dctNodePar["dctChild"] = collections.OrderedDict()

        for acNode in lstSubNodes:
            acNewKey = acNode
            dctNodePar["dctChild"][acNewKey] = {}  # This dictionary does not have to ordered

            self._vPopulateDetailedBitTreeNode(dctNodePar["dctChild"][acNewKey], dctNodePar["acName"], acNewKey, "", E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN), 1, E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE))

        return

    def _vInitAndPopulateDetailedBitForHmiMaintainer(self, dctNodePar: object):
        """ This is a private method which initializes the HMI_Maintainer level of the detailed BIT tree.

        Args:
            dctNodePar (dict): The first parameter. The HMI_Maintainer dictionary node of the detailed bit tree

        Returns:

        Raises:
            Raises no exception.
        """

        lstSubNodes = ["STATUS"]

        if (dctNodePar is None):
            logging.error("dctNodePar cannot be None")
            return

        dctNodePar["dctChild"] = collections.OrderedDict()

        for acNode in lstSubNodes:
            acNewKey = acNode
            dctNodePar["dctChild"][acNewKey] = {}  # This dictionary does not have to ordered

            self._vPopulateDetailedBitTreeNode(dctNodePar["dctChild"][acNewKey], dctNodePar["acName"], acNewKey, "", E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN), 1, E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE))

        return

    def _vInitAndPopulateDetailedBitForHmiOversight(self, dctNodePar: object):
        """ This is a private method which initializes the HMI_Oversight level of the detailed BIT tree.

        Args:
            dctNodePar (dict): The first parameter. The HMI_Oversight dictionary node of the detailed bit tree

        Returns:

        Raises:
            Raises no exception.
        """

        lstSubNodes = ["STATUS"]

        if (dctNodePar is None):
            logging.error("dctNodePar cannot be None")
            return

        dctNodePar["dctChild"] = collections.OrderedDict()

        for acNode in lstSubNodes:
            acNewKey = acNode
            dctNodePar["dctChild"][acNewKey] = {}  # This dictionary does not have to ordered

            self._vPopulateDetailedBitTreeNode(dctNodePar["dctChild"][acNewKey], dctNodePar["acName"], acNewKey, "", E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN), 1, E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE))

        return

    def _vInitAndPopulateDetailedBitForSf1(self, dctNodePar: object):
        """ This is a private method which initializes the SF1 level of the detailed BIT tree.

        Args:
            dctNodePar (dict): The first parameter. The SF1 dictionary node of the detailed bit tree

        Returns:

        Raises:
            Raises no exception.
        """

        lstSubNodes = ["STATUS"]

        if (dctNodePar is None):
            logging.error("dctNodePar cannot be None")
            return

        dctNodePar["dctChild"] = collections.OrderedDict()

        for acNode in lstSubNodes:
            acNewKey = acNode
            dctNodePar["dctChild"][acNewKey] = {}  # This dictionary does not have to ordered

            self._vPopulateDetailedBitTreeNode(dctNodePar["dctChild"][acNewKey], dctNodePar["acName"], acNewKey, "", E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN), 1, E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE))

        return

    def _vInitAndPopulateDetailedBitForSf2(self, dctNodePar: object):
        """ This is a private method which initializes the SF2 level of the detailed BIT tree.

        Args:
            dctNodePar (dict): The first parameter. The SF2 dictionary node of the detailed bit tree

        Returns:

        Raises:
            Raises no exception.
        """

        lstSubNodes = ["STATUS"]

        if (dctNodePar is None):
            logging.error("dctNodePar cannot be None")
            return

        dctNodePar["dctChild"] = collections.OrderedDict()

        for acNode in lstSubNodes:
            acNewKey = acNode
            dctNodePar["dctChild"][acNewKey] = {}  # This dictionary does not have to ordered

            self._vPopulateDetailedBitTreeNode(dctNodePar["dctChild"][acNewKey], dctNodePar["acName"], acNewKey, "", E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN), 1, E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE))

        return

    def _vInitAndPopulateDetailedBitForSf3(self, dctNodePar: object):
        """ This is a private method which initializes the SF3 level of the detailed BIT tree.

        Args:
            dctNodePar (dict): The first parameter. The SF3 dictionary node of the detailed bit tree

        Returns:

        Raises:
            Raises no exception.
        """

        lstSubNodes = ["STATUS"]

        if (dctNodePar is None):
            logging.error("dctNodePar cannot be None")
            return

        dctNodePar["dctChild"] = collections.OrderedDict()

        for acNode in lstSubNodes:
            acNewKey = acNode
            dctNodePar["dctChild"][acNewKey] = {}  # This dictionary does not have to ordered

            self._vPopulateDetailedBitTreeNode(dctNodePar["dctChild"][acNewKey], dctNodePar["acName"], acNewKey, "", E1_OLHM_HEALTH_STATUS(E1_OLHM_HEALTH_STATUS.OLHM_SYSTEM_HEALTH_UNKNOWN), 1, E1_OLHM_STATE(E1_OLHM_STATE.OLHM_STATE_OFFLINE))

        return

    def _vPopulateDetailedBitTreeNode(self, dctItemPar: object, acParentPar: str, acNamePar: str, acValuePar: str, e1OlhmHealthStatusPar: E1_OLHM_HEALTH_STATUS, iLevelPar: int, e1OlhmStatePar: E1_OLHM_STATE):
        """ This is a private method fills in the keys of a node in the detailed bit tree

        Args:
            dctItemPar (dict): The first parameter. The dictionary to fill in.
            acParentPar (str): The second parameter. The parent name.
            acNamePar (str): The third parameter. The name of the node.
            acValuePar (str): The fourth parameter. The value as string.
            e1OlhmHealthStatusPar (E1_OLHM_HEALTH_STATUS): The fifth parameter. The system health enum.
            iLevelPar (int): The sixth parameter. The level in the tree
            e1OlhmStatePar (E1_OLHM_STATE): The seventh parameter. The module state

        Returns:
            list: A list of all the bit items

        Raises:
            Raises no exception.
        """
        dctItemPar["acParent"] = acParentPar
        dctItemPar["acName"] = acNamePar
        dctItemPar["acValue"] = acValuePar
        dctItemPar["e1OlhmHealthStatus"] = E1_OLHM_HEALTH_STATUS(e1OlhmHealthStatusPar.Value)
        dctItemPar["e1OlhmState"] = E1_OLHM_STATE(e1OlhmStatePar.Value)
        dctItemPar["iLevel"] = iLevelPar
        dctItemPar["dctChild"] = None

        return
